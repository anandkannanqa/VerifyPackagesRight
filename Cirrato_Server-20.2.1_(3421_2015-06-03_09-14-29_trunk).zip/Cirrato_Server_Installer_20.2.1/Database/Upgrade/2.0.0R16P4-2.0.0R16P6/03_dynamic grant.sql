-- This script grants execution rights on appropriate objects to the Cirrato database user
-- Make sure you are in the correct database, then change the username below (if necessary) before executing the script

DECLARE @CirratoUserName varchar(200)

SET @CirratoUserName = 'cirrato' -- change here if using other username than default



-- DO NOT EDIT SCRIPT BELOW --

DECLARE @sql varchar(8000)
,@cObjectName	sysname
,@count int
SET @sql = ''
SET @count = 0
DECLARE curObjects CURSOR FAST_FORWARD  FOR
	select top 1000
		name
	from sysobjects
	where xtype in ('P', 'FN')
	order by crdate desc

OPEN curObjects

FETCH NEXT FROM curObjects INTO @cObjectName
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @count = @count + 1
	SET  @sql = 'GRANT execute on ' + @cObjectName +' to ' + @CirratoUserName

	--PRINT @sql
	
	EXEC(@sql)

	FETCH NEXT FROM curObjects INTO @cObjectName
END

CLOSE curObjects
DEALLOCATE curObjects

PRINT 'Execute permission granted on '+  CAST(@count as varchar(20)) + ' objects'
