-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode


:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

IF (select
		cmptlevel	
	from master.dbo.sysdatabases
	where name = db_name()) < 90
  RAISERROR ('Database must be SQL Server 2005 or later',20,1) with log
GO

if (db_name() = 'master' 
	OR db_name() = 'msdb'
	OR db_name() = 'model'
	OR db_name() = 'tempdb'
	OR db_name() = 'ReportServer'
	OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

GO

:on error continue

GO


SET NOCOUNT ON
GO
-- DATA TYPE CREATION


IF NOT EXISTS ( select * from systypes where name = 'dt_monthday')
	CREATE TYPE [dbo].[dt_monthday] FROM [char](4) NULL
GO


IF OBJECT_ID('tbl_report_users') IS NULL
BEGIN
	CREATE TABLE tbl_report_users
	(UserId						int	PRIMARY KEY		NOT NULL IDENTITY(1,1)
	,UserName					nvarchar(510)		NOT NULL
	,Domain						nvarchar(510)		NOT NULL
	,RegDate					datetime			NOT NULL DEFAULT(getdate()))

--	ALTER TABLE tbl_report_users
--		ADD CONSTRAINT cs_tbl_report_users_uq UNIQUE (UserName, Domain)
END

GO

--DROP  TABLE tbl_report_jobs_detail
--DROP  TABLE tbl_report_users

GO





GO
IF OBJECT_ID('tbl_report_group_umbrella') IS NULL
BEGIN
	CREATE TABLE tbl_report_group_umbrella
	(UmbrellaId			int PRIMARY KEY IDENTITY(1,1) NOT NULL
	,UmbrellaName		nvarchar(256) NOT NULL
	,UmbrellaComment	nvarchar(512) NULL
	,MinTicketGroups	int NULL
	,MaxTicketGroups	int NULL
	,StartDate			datetime NULL
	,EndDate			datetime NULL
	,IsDeleted			bit NOT NULL DEFAULT(0))
END

----------------------------------

GO
IF OBJECT_ID('tbl_report_group') IS NULL
BEGIN
	CREATE TABLE  tbl_report_group
	(GroupId		INT PRIMARY KEY IDENTITY(1,1) NOT NULL
	,GroupName		nvarchar(256) NOT NULL
	,GroupComment	nvarchar(512) NULL
--	,Priority		int NOT NULL
	,UmbrellaId		int REFERENCES tbl_report_group_umbrella(UmbrellaId) NOT NULL
	,StartDate		datetime NULL
	,EndDate		datetime NULL
	,IsDeleted		bit NOT NULL DEFAULT(0))
END
GO
-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_report_group'
				AND c.name = 'LogTickets')

ALTER TABLE tbl_report_group ADD  LogTickets bit NOT NULL default(1)
GO

-----------------------

GO
IF OBJECT_ID('tbl_report_ticket_group') IS NULL
BEGIN
	CREATE TABLE  tbl_report_ticket_group
	(TicketId	uniqueidentifier							NOT NULL
	,GroupId	int REFERENCES tbl_report_group(GroupId)	NOT NULL)

	ALTER TABLE tbl_report_ticket_group
		ADD CONSTRAINT cs_tbl_report_ticket_group_uq UNIQUE (TicketId, GroupId)
END

GO

-- 2009-08-20: Added bundle tables
--DROP TABLE tbl_report_group_bundle

IF OBJECT_ID('tbl_report_group_bundle') IS NULL
BEGIN
	CREATE TABLE  tbl_report_group_bundle
	(BundleId		uniqueidentifier	PRIMARY KEY		NOT NULL
	,GroupId		int					NOT NULL REFERENCES tbl_report_group(GroupId)	
	,BundleType		tinyint				NOT NULL
	,CreatedDate	datetime			NOT NULL	default(GETDATE())
	,CreatorUserId	int					NULL REFERENCES tbl_report_users(UserId) )
END


GO

IF OBJECT_ID('tbl_report_group_bundle_user') IS NULL
BEGIN
	CREATE TABLE  tbl_report_group_bundle_user
	(BundleId		uniqueidentifier	NOT NULL REFERENCES tbl_report_group_bundle(BundleId)		
	,UserName		nvarchar(510)		NOT NULL
	,Domain			nvarchar(510)		NOT NULL
	,UserId			int					NULL REFERENCES tbl_report_users(UserId))


END
GO
-- 2009-11-23: Added group graph relation table & group ExternalId Column
---

--DROP TABLE tbl_report_group_group
IF OBJECT_ID('tbl_report_group_group') IS NULL
BEGIN
	CREATE TABLE  tbl_report_group_group
	(GroupParentId		INT NOT NULL REFERENCES tbl_report_group(GroupId)
	,GroupChildId		INT NOT NULL REFERENCES tbl_report_group(GroupId))

	ALTER TABLE tbl_report_group_group
		ADD CONSTRAINT cs_tbl_report_group_group_uq UNIQUE (GroupParentId, GroupChildId)
END

GO
-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_report_group'
				AND c.name = 'ExternalId')

ALTER TABLE tbl_report_group ADD  ExternalId nvarchar(128) NULL
GO


-- 2009-09-30
-- Create tables that hold user/group/umbrella rights for Client Billing

IF OBJECT_ID('tbl_client_billing_user_rights ') IS NULL
BEGIN
	CREATE TABLE tbl_client_billing_user_rights 
		(ClientBillingId		bigint	/*REFERENCES tbl_client_billing(cb_id)*/ NOT NULL -- kan ej s�tta FK eftersom tbl_client_billing inte har PK
		,UserId					int		REFERENCES tbl_report_users (UserId) NOT NULL
		,Rights					int DEFAULT(0)	NOT NULL
		,IsRecursive			bit DEFAULT(1)	NOT NULL
		,StartDate				datetime		NULL
		,EndDate				datetime		NULL
		,RegUser				int				REFERENCES tbl_report_users (UserId) NULL
		,RegDate				datetime		DEFAULT(getdate())	NULL

		,PRIMARY KEY (ClientBillingId, UserId))

END

GO

IF OBJECT_ID('tbl_client_billing_group_rights ') IS NULL
BEGIN
	CREATE TABLE tbl_client_billing_group_rights 
		(ClientBillingId		bigint	/*REFERENCES tbl_client_billing(cb_id)*/ NOT NULL -- kan ej s�tta FK eftersom tbl_client_billing inte har PK
		,GroupId				int				REFERENCES tbl_report_group (GroupId) NOT NULL
		,Rights					int DEFAULT(0)	NOT NULL
		,IsRecursive			bit DEFAULT(1)	NOT NULL
		,StartDate				datetime		NULL
		,EndDate				datetime		NULL
		,RegUser				int				REFERENCES tbl_report_users (UserId) NULL
		,RegDate				datetime		DEFAULT(getdate())	NULL

		,PRIMARY KEY (ClientBillingId, GroupId))

END

GO


IF OBJECT_ID('tbl_client_billing_umbrella_rights ') IS NULL
BEGIN
	CREATE TABLE tbl_client_billing_umbrella_rights 
		(ClientBillingId		bigint	/*REFERENCES tbl_client_billing(cb_id)*/ NOT NULL -- kan ej s�tta FK eftersom tbl_client_billing inte har PK
		,UmbrellaId				int				REFERENCES tbl_report_group_umbrella (UmbrellaId) NOT NULL
		,Rights					int DEFAULT(0)	NOT NULL
		,IsRecursive			bit DEFAULT(1)	NOT NULL
		,StartDate				datetime		NULL
		,EndDate				datetime		NULL
		,RegUser				int				REFERENCES tbl_report_users (UserId) NULL
		,RegDate				datetime		DEFAULT(getdate())	NULL

		,PRIMARY KEY (ClientBillingId, UmbrellaId))

END



GO


GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_configuration') IS NULL
BEGIN
	CREATE TABLE tbl_org_configuration (
		ConfigID	integer PRIMARY KEY IDENTITY NOT NULL,
		GUID		nvarchar(64) NOT NULL DEFAULT NEWID(),
		Name		nvarchar(256),
		Type		nvarchar(32) NOT NULL DEFAULT 'LDAP',
		Host		nvarchar(128),
		Port		integer,
		Username	nvarchar(64),
		Password	nvarchar(64),
		DomainDC	nvarchar(256),
		RootOU		nvarchar(256),
		TimeoutInMinutes integer NOT NULL DEFAULT 2,				
		SyncIntervalInMinutes	integer,
		LastSync	datetime,
		NextSync	datetime,
		Blocked		bit NOT NULL DEFAULT 0,
		InProgress	bit NOT NULL DEFAULT 0,
		Valid		bit NOT NULL DEFAULT 0,
		Complete	bit NOT NULL DEFAULT 0,
		Updated		datetime
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_domain') IS NULL
BEGIN
	CREATE TABLE tbl_org_domain (
		ConfigID		integer NOT NULL,
		GUID			nvarchar(64) NOT NULL,
		DN				nvarchar(1024),
		Name			nvarchar(256),
		NetBIOSName		nvarchar(256),
		Updated			datetime	
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_group') IS NULL
BEGIN
	CREATE TABLE tbl_org_group (
		ConfigID		integer NOT NULL,
		GUID			nvarchar(64) NOT NULL,
		DN				nvarchar(1024),
		Name			nvarchar(256),
		Updated			datetime	
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_group_group_map') IS NULL
BEGIN
	CREATE TABLE tbl_org_group_group_map (
		ConfigID	integer NOT NULL,
		ParentDN	nvarchar(1024)	NOT NULL,
		ChildDN		nvarchar(1024)	NOT NULL,
		Updated		datetime
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/12/09

IF OBJECT_ID('tbl_org_group_member_tmp') IS NULL
BEGIN
	CREATE TABLE tbl_org_group_member_tmp (
		ConfigID		integer NOT NULL,
		GroupDN			nvarchar(1024) NOT NULL,
		MemberDN		nvarchar(1024) NOT NULL,
		Done			bit NOT NULL DEFAULT 0,
		Updated			datetime	
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_group_user_map') IS NULL
BEGIN
	CREATE TABLE tbl_org_group_user_map (
		ConfigID	integer NOT NULL,
		ParentDN	nvarchar(1024)	NOT NULL,
		ChildDN		nvarchar(1024)	NOT NULL,
		Updated		datetime
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_unit') IS NULL
BEGIN
	CREATE TABLE tbl_org_unit (
		ConfigID		integer NOT NULL,
		GUID			nvarchar(64) NOT NULL,
		DN				nvarchar(1024),
		Name			nvarchar(256),
		Updated			datetime
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_unit_group_map') IS NULL
BEGIN
	CREATE TABLE tbl_org_unit_group_map (
		ConfigID	integer NOT NULL,
		ParentDN	nvarchar(1024)	NOT NULL,
		ChildDN		nvarchar(1024)	NOT NULL,
		Updated		datetime
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_unit_unit_map') IS NULL
BEGIN
	CREATE TABLE tbl_org_unit_unit_map (
		ConfigID	integer NOT NULL,
		ParentDN	nvarchar(1024)	NOT NULL,
		ChildDN		nvarchar(1024)	NOT NULL,
		Updated		datetime
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_unit_user_map') IS NULL
BEGIN
	CREATE TABLE tbl_org_unit_user_map (
		ConfigID	integer NOT NULL,
		ParentDN	nvarchar(1024)	NOT NULL,
		ChildDN		nvarchar(1024)	NOT NULL,
		Updated		datetime	
	)
END
GO

GO
-- Ruchira Bomiriya
-- 2009/11/26

IF OBJECT_ID('tbl_org_user') IS NULL
BEGIN
	CREATE TABLE tbl_org_user (
		ConfigID		integer NOT NULL,
		GUID			nvarchar(64) NOT NULL,
		DN				nvarchar(1024),
		Name			nvarchar(256),
		Updated			datetime
	)
END
GO

--DROP TABLE tbl_cirrato_wallet_import_file_user_row
--DROP TABLE tbl_cirrato_wallet_import_file_group_row
IF OBJECT_ID('tbl_cirrato_wallet_import_file') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_import_file
	(FileId					INT PRIMARY KEY IDENTITY(1,1) NOT NULL
	,FileName				nvarchar(510) NOT NULL
	,FileUniqueId			nvarchar(256)	NOT NULL
	,CreatedDate			datetime DEFAULT(getdate()) NOT NULL
	,MajorVersion			int NOT NULL
	,MinorVersion			int NOT NULL
	,ImporterUserId			int REFERENCES tbl_report_users(UserId) NOT NULL
	,ChecksumVerified		bit DEFAULT(0) NOT NULL 
	,Checksum				varchar(64) NOT NULL
	,ProcessedDate			datetime
	,Outcome				int NULL
	,NumUsersAffected		int NULL
	,NumGroupsAffected		int NULL
	,TotalNumUsersAffected	int NULL)
END

GO

IF OBJECT_ID('tbl_cirrato_wallet_import_file_user_row') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_import_file_user_row
	(FileId					INT REFERENCES tbl_cirrato_wallet_import_file(FileId)  NOT NULL
	,RowNo					INT					NOT NULL
	,Domain					nvarchar(510)		NOT NULL
	,Username				nvarchar(510)		NOT NULL
	,Amount					float				NOT NULL
	,Action					int					NOT NULL
	,Description			nvarchar(510)		NULL)

	ALTER TABLE tbl_cirrato_wallet_import_file_user_row
		ADD CONSTRAINT cs_uq_tbl_cirrato_wallet_import_file_user_row UNIQUE CLUSTERED ( FileId, RowNo)

END

GO

IF OBJECT_ID('tbl_cirrato_wallet_import_file_group_row') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_import_file_group_row
	(FileId					INT REFERENCES tbl_cirrato_wallet_import_file(FileId)  NOT NULL
	,RowNo					INT					NOT NULL
	,GroupName				nvarchar(510)		NOT NULL
	,GroupExternalId		nvarchar(128)		NULL
	,Amount					float				NOT NULL
	,Action					int					NOT NULL
	,Description			nvarchar(510)		NULL)

	ALTER TABLE tbl_cirrato_wallet_import_file_group_row
		ADD CONSTRAINT cs_uq_tbl_cirrato_wallet_import_file_group_row UNIQUE CLUSTERED ( FileId, RowNo)

END
GO



--DROP TABLE dbo.tbl_scan_destination_email
--DROP TABLE dbo.tbl_scan_destination_ftp
--DROP TABLE dbo.tbl_scan_destination_ncp
--DROP TABLE dbo.tbl_scan_destination_smb
--DROP TABLE dbo.tbl_scan_destination_webdav

IF OBJECT_ID('tbl_scan_destination_email') IS NULL
BEGIN
	CREATE TABLE tbl_scan_destination_email 
	(
		EmailDestinationId				INT PRIMARY KEY IDENTITY(1,1) NOT NULL
		,DestinationName				nvarchar(510) NOT NULL
		,DestinationComment				nvarchar(510)

		,FromEmailAddress				nvarchar(510)
		,FromName						nvarchar(510)
		,MaxBytes						int
		,ReplyToEmailAddress			nvarchar(510)
		,SMTPServerFQDN					nvarchar(510)
		,SMTPServerPort					int
		,SMTPLoginUserName				nvarchar(510)
		,SMTPLoginPassword				nvarchar(510)


		-- Common to all scan destinations
		,SortOrder						int DEFAULT(100) NOT NULL
		,IsDefault						bit DEFAULT(0) NOT NULL
		,IsDeleted						bit DEFAULT(0) NOT NULL
		,IsVisible						bit DEFAULT(1) NOT NULL
		,RegUserId						int REFERENCES tbl_report_users(UserId) NOT NULL -- Who created this version of the row?
		,RegDate						datetime DEFAULT(getdate()) NOT NULL --When was this version of the row created?
	)
END

GO

IF OBJECT_ID('tbl_scan_destination_smb') IS NULL
BEGIN
	CREATE TABLE tbl_scan_destination_smb 
	(
		SMBDestinationId				INT PRIMARY KEY IDENTITY(1,1) NOT NULL
		,DestinationName				nvarchar(510) NOT NULL
		,DestinationComment				nvarchar(510)

		,SMBLoginUserName				nvarchar(510)
		,SMBLoginPassword				nvarchar(510)

		,SMBPath						nvarchar(510)

		-- Common to all scan destinations
		,SortOrder						int DEFAULT(100) NOT NULL
		,IsDefault						bit DEFAULT(0) NOT NULL
		,IsDeleted						bit DEFAULT(0) NOT NULL
		,IsVisible						bit DEFAULT(1) NOT NULL
		,RegUserId						int REFERENCES tbl_report_users(UserId) NOT NULL -- Who created this version of the row?
		,RegDate						datetime DEFAULT(getdate()) NOT NULL --When was this version of the row created?
	)
END

GO

IF OBJECT_ID('tbl_scan_destination_ftp') IS NULL
BEGIN
	CREATE TABLE tbl_scan_destination_ftp 
	(
		FTPDestinationId				INT PRIMARY KEY IDENTITY(1,1) NOT NULL
		,DestinationName				nvarchar(510) NOT NULL
		,DestinationComment				nvarchar(510)

		,FTPServerFQDN					nvarchar(510)
		,FTPServerPort					int DEFAULT(21)
		,FTPPath						nvarchar(510)
		,FTPLoginUserName				nvarchar(510)
		,FTPLoginPassword				nvarchar(510)

		-- Common to all scan destinations
		,SortOrder						int DEFAULT(100) NOT NULL
		,IsDefault						bit DEFAULT(0) NOT NULL
		,IsDeleted						bit DEFAULT(0) NOT NULL
		,IsVisible						bit DEFAULT(1) NOT NULL
		,RegUserId						int REFERENCES tbl_report_users(UserId) NOT NULL -- Who created this version of the row?
		,RegDate						datetime DEFAULT(getdate()) NOT NULL --When was this version of the row created?
	)
END

GO

IF OBJECT_ID('tbl_scan_destination_ncp') IS NULL
BEGIN
	CREATE TABLE tbl_scan_destination_ncp 
	(
		NCPDestinationId				INT PRIMARY KEY IDENTITY(1,1) NOT NULL
		,DestinationName				nvarchar(510) NOT NULL
		,DestinationComment				nvarchar(510)

		,NCPPath						nvarchar(510)
		,NCPBindery						bit default(0)
		,NCPLoginUserName				nvarchar(510)
		,NCPLoginPassword				nvarchar(510)


		-- Common to all scan destinations
		,SortOrder						int DEFAULT(100) NOT NULL
		,IsDefault						bit DEFAULT(0) NOT NULL
		,IsDeleted						bit DEFAULT(0) NOT NULL
		,IsVisible						bit DEFAULT(1) NOT NULL
		,RegUserId						int REFERENCES tbl_report_users(UserId) NOT NULL -- Who created this version of the row?
		,RegDate						datetime DEFAULT(getdate()) NOT NULL --When was this version of the row created?
	)
END



GO

IF OBJECT_ID('tbl_scan_destination_webdav') IS NULL
BEGIN
	CREATE TABLE tbl_scan_destination_webdav 
	(
		WebDAVDestinationId				INT PRIMARY KEY IDENTITY(1,1) NOT NULL
		,DestinationName				nvarchar(510) NOT NULL
		,DestinationComment				nvarchar(510)

		,WebDAVFQDN						nvarchar(510)
		,WebDAVPort						int
		,WebDAVSSL						bit
		,WebDAVDirectory				nvarchar(510)
		,WebDAVUserName					nvarchar(510)
		,WebDAVPassword					nvarchar(510)

		-- Common to all scan destinations
		,SortOrder						int DEFAULT(100) NOT NULL
		,IsDefault						bit DEFAULT(0) NOT NULL
		,IsDeleted						bit DEFAULT(0) NOT NULL
		,IsVisible						bit DEFAULT(1) NOT NULL
		,RegUserId						int REFERENCES tbl_report_users(UserId) NOT NULL -- Who created this version of the row?
		,RegDate						datetime DEFAULT(getdate()) NOT NULL --When was this version of the row created?
	)
END
GO




-- Add index

SET ANSI_WARNINGS OFF
if not exists (select * from sysindexes where name = 'ixClientSessionLog1')
	CREATE INDEX ixClientSessionLog1 ON tbl_cirrato_client_session_log (logcsessionIp, logcsessionUser, logcsessionDate	)

SET ANSI_WARNINGS ON
GO

-- 2009-09-30
-- Create tables that hold user/group/umbrella rights for Client Billing

IF OBJECT_ID('tbl_client_billing_user_rights ') IS NULL
BEGIN
	CREATE TABLE tbl_client_billing_user_rights 
		(ClientBillingId		bigint	/*REFERENCES tbl_client_billing(cb_id)*/ NOT NULL -- kan ej s�tta FK eftersom tbl_client_billing inte har PK
		,UserId					int		REFERENCES tbl_report_users (UserId) NOT NULL
		,Rights					int DEFAULT(0)	NOT NULL
		,IsRecursive			bit DEFAULT(1)	NOT NULL
		,StartDate				datetime		NULL
		,EndDate				datetime		NULL
		,RegUser				int				REFERENCES tbl_report_users (UserId) NULL
		,RegDate				datetime		DEFAULT(getdate())	NULL

		,PRIMARY KEY (ClientBillingId, UserId))

END

GO

IF OBJECT_ID('tbl_client_billing_group_rights ') IS NULL
BEGIN
	CREATE TABLE tbl_client_billing_group_rights 
		(ClientBillingId		bigint	/*REFERENCES tbl_client_billing(cb_id)*/ NOT NULL -- kan ej s�tta FK eftersom tbl_client_billing inte har PK
		,GroupId				int				REFERENCES tbl_report_group (GroupId) NOT NULL
		,Rights					int DEFAULT(0)	NOT NULL
		,IsRecursive			bit DEFAULT(1)	NOT NULL
		,StartDate				datetime		NULL
		,EndDate				datetime		NULL
		,RegUser				int				REFERENCES tbl_report_users (UserId) NULL
		,RegDate				datetime		DEFAULT(getdate())	NULL

		,PRIMARY KEY (ClientBillingId, GroupId))

END

GO


IF OBJECT_ID('tbl_client_billing_umbrella_rights ') IS NULL
BEGIN
	CREATE TABLE tbl_client_billing_umbrella_rights 
		(ClientBillingId		bigint	/*REFERENCES tbl_client_billing(cb_id)*/ NOT NULL -- kan ej s�tta FK eftersom tbl_client_billing inte har PK
		,UmbrellaId				int				REFERENCES tbl_report_group_umbrella (UmbrellaId) NOT NULL
		,Rights					int DEFAULT(0)	NOT NULL
		,IsRecursive			bit DEFAULT(1)	NOT NULL
		,StartDate				datetime		NULL
		,EndDate				datetime		NULL
		,RegUser				int				REFERENCES tbl_report_users (UserId) NULL
		,RegDate				datetime		DEFAULT(getdate())	NULL

		,PRIMARY KEY (ClientBillingId, UmbrellaId))

END



GO


IF OBJECT_ID('tbl_directory_monitor_config') IS NULL
BEGIN
	CREATE TABLE tbl_directory_monitor_config
	(DirectoryId		int PRIMARY KEY IDENTITY(1,1) NOT NULL
	,DirectoryType		tinyint NOT NULL -- 1=AD, 2=OpenLDAP
	,DirectoryName		nvarchar(256) NOT NULL
	,DirectoryComment	nvarchar(512)
    ,ServerIP			varchar(64) NOT NULL
    ,ServerPort			int
	,ConnectionType		tinyint -- encrypted, not encrypted, etc
    ,UserName			nvarchar(512)
    ,Password			nvarchar(512)
    ,BaseDN				nvarchar(512)
	,UniqueAttribute	varchar(128) NULL           
	,NTDomain			varchar(64)
	,UmbrellaId			int)

--	ALTER TABLE tbl_support_advice
--		ADD CONSTRAINT cs_support_advice UNIQUE (SourceTable, Level1, Level2, Level3, SortOrder)

END

GO


IF OBJECT_ID('tbl_information_window') IS NULL
BEGIN
	CREATE TABLE tbl_information_window
	(InfoTypeGroup			char(3)
	,DataColumnName			varchar(100)
	,DisplayColumnName		nvarchar(255)	NULL
	,SortOrder				int
	,RequiredAccessLevel	int)

	ALTER TABLE tbl_information_window
		ADD CONSTRAINT cs_information_window_group_data UNIQUE ( InfoTypeGroup, DataColumnName)
	ALTER TABLE tbl_information_window
		ADD CONSTRAINT cs_information_window_group_sortorder UNIQUE ( InfoTypeGroup, SortOrder)
END

GO

-- Queue Info
DELETE tbl_information_window WHERE InfoTypeGroup = 'QUE'

INSERT tbl_information_window (InfoTypeGroup, DataColumnName, DisplayColumnName, SortOrder ,RequiredAccessLevel)
VALUES ('QUE','QueueName','Name',10,0)

INSERT tbl_information_window (InfoTypeGroup, DataColumnName, DisplayColumnName, SortOrder ,RequiredAccessLevel)
VALUES ('QUE','RegionPath','Region',20,0)

INSERT tbl_information_window (InfoTypeGroup, DataColumnName, DisplayColumnName, SortOrder ,RequiredAccessLevel)
VALUES ('QUE','Location','Location',30,0)

INSERT tbl_information_window (InfoTypeGroup, DataColumnName, DisplayColumnName, SortOrder ,RequiredAccessLevel)
VALUES ('QUE','DisplayText','Printer Display',50,0)


INSERT tbl_information_window (InfoTypeGroup, DataColumnName, DisplayColumnName, SortOrder ,RequiredAccessLevel)
VALUES ('QUE','adminComment','Admin Comment',100,4)

--RegionPath HenriksPrinterRegion/Henrik2  
--Location Bredvid kaffemaskinen 
--ErrorTime   
--LastCheck   
--DisplayText   
--PhysicalStatusSeverity 0 
--PhysicalStatusVerbose OK 
--NewStatusVerbose   
--HighestSmartAlarmLevel   
--SmartAlarmCount   
--HighestTotalAlarmLevel 0 
--PrinterIP 66.67.68.69 
--PrinterId C48CA6E0-E871-11DD-AC4F-0018F3B26688 
--PrinterName Henrik2 Printer2 
--ModelName Xerox WorkCentre M128 PCL 6 
--JobCount 8 
--RegionId 17 
--AdminComment   


-- Printer Info


-- Add index

SET ANSI_WARNINGS OFF
if not exists (select * from sysindexes where name = 'ixInstallLog1')
	CREATE INDEX ixInstallLog1 ON tbl_install_log (installClientIp, installLogBegin)

SET ANSI_WARNINGS ON
GO



GO

BEGIN TRY
	SET ANSI_WARNINGS OFF
	IF EXISTS(SELECT * FROM sysobjects o
					INNER JOIN syscolumns c ON c.id = o.id
					AND o.name = 'tbl_inventory_printjob'
					AND c.name = 'GetPortSNMPCommunity')
	BEGIN
		EXECUTE sp_rename N'dbo.tbl_inventory_printjob.GetPortSNMPCommunity', N'Tmp_PortSNMPCommunity', 'COLUMN' 
		EXECUTE sp_rename N'dbo.tbl_inventory_printjob.Tmp_PortSNMPCommunity', N'PortSNMPCommunity', 'COLUMN' 
	END
	SET ANSI_WARNINGS ON
END TRY
BEGIN CATCH
END CATCH

GO


IF OBJECT_ID('tbl_papersize') IS NULL
BEGIN
	CREATE TABLE tbl_papersize
	(PaperSize			int				NOT NULL
	,PaperSizeName		nvarchar(100)	NOT NULL
	,PaperWidth			int				NOT NULL
	,PaperHeight		int				NOT NULL)

	ALTER TABLE tbl_papersize
		ADD CONSTRAINT cs_tbl_papersize UNIQUE (PaperSize)

END

GO

--DROP TABLE tbl_papersize

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_printer'
				AND c.name = 'offlineReason')

ALTER TABLE tbl_printer ADD  offlineReason nvarchar(128)
GO

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_printer'
				AND c.name = 'printerMapPosX')
BEGIN
	ALTER TABLE tbl_printer ADD  printerMapPosX int NULL
	ALTER TABLE tbl_printer ADD  printerMapPosY int NULL
END
GO

ALTER TABLE tbl_property ALTER COLUMN propertyValue nvarchar(510) NULL



IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_property'
				AND c.name = 'propertyValueNumeric')

ALTER TABLE tbl_property ADD  propertyValueNumeric int

GO
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_property'
				AND c.name = 'propertyValueDate')

ALTER TABLE tbl_property ADD  propertyValueDate datetime
GO

IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_property'
				AND c.name = 'propertyDescription')

ALTER TABLE tbl_property ADD  propertyDescription varchar(100)
GO


IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_property'
				AND c.name = 'propertyGroup')
BEGIN
	ALTER TABLE tbl_property ADD  propertyGroup varchar(64)

	IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'cs_uq_tbl_property')
		ALTER TABLE tbl_property
			ADD CONSTRAINT cs_uq_tbl_property UNIQUE (propertyGroup, propertyName)
END
GO

UPDATE tbl_property
	SET propertyGroup='Generic'
WHERE propertyGroup IS NULL
GO
-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_queue'
				AND c.name = 'offlineReason')

ALTER TABLE tbl_queue ADD  offlineReason nvarchar(128)
GO

IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_queue'
				AND c.name = 'pagesPerMinuteBWSingle')
BEGIN
	ALTER TABLE tbl_queue ADD  pagesPerMinuteBWSingle real
	ALTER TABLE tbl_queue ADD  pagesPerMinuteColorSingle real
	ALTER TABLE tbl_queue ADD  pagesPerMinuteBWDuplex real
	ALTER TABLE tbl_queue ADD  pagesPerMinuteColorDuplex real

END
GO

IF OBJECT_ID('tbl_queue_speed_run_log ') IS NULL
BEGIN
	CREATE TABLE tbl_queue_speed_run_log 
	(RunId				int PRIMARY KEY IDENTITY(1,1)
	,RunStartDate		datetime
	,RunEndDate			datetime
	,PrintStartDate		datetime
	,PrintEndDate		datetime)

--	ALTER TABLE tbl_queue_speed_run_log 
--		ADD CONSTRAINT cs_tbl_queue_speed_status UNIQUE (QueueId, Color, Duplex, PaperSize)

END


IF OBJECT_ID('tbl_queue_speed_status ') IS NULL
BEGIN
	CREATE TABLE tbl_queue_speed_status 
	(QueueId		varchar(64)
	,Pages			bigint
	,Duration		bigint
	,Color			smallint
	,Duplex			smallint
	,PaperSize		int)

	ALTER TABLE tbl_queue_speed_status 
		ADD CONSTRAINT cs_tbl_queue_speed_status UNIQUE (QueueId, Color, Duplex, PaperSize)

END

IF OBJECT_ID('tbl_queue_speed_status_log ') IS NULL
BEGIN
	CREATE TABLE tbl_queue_speed_status_log 
	(RunId			int REFERENCES tbl_queue_speed_run_log(RunId)
	,QueueId		varchar(64)
	,Pages			int
	,Duration		int
	,Color			smallint
	,Duplex			smallint
	,PaperSize		int)

	ALTER TABLE tbl_queue_speed_status_log 
		ADD CONSTRAINT cs_tbl_queue_speed_status_log UNIQUE (RunId, QueueId, Color, Duplex, PaperSize)

END

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_region'
				AND c.name = 'regionSortOrder')
BEGIN
	ALTER TABLE tbl_region ADD  regionSortOrder int NULL DEFAULT(100)
	ALTER TABLE tbl_region ADD  regionMapFile nvarchar(256) NULL
	ALTER TABLE tbl_region ADD  regionParentMapShape varchar(10) NULL DEFAULT('poly')
	ALTER TABLE tbl_region ADD  regionParentMapCoords varchar(8000) NULL


END
GO


IF OBJECT_ID('tbl_report_brand_cache') IS NULL
BEGIN
	CREATE TABLE tbl_report_brand_cache
	(BrandId				uniqueidentifier PRIMARY KEY
	,BrandName				nvarchar(512))
--	ALTER TABLE tbl_report_jobs_queue_regiondepth_cache
--		ADD CONSTRAINT cs_tbl_report_jobs_queue_regiondepth_cache_uq UNIQUE (QueueId, Depth)
END
GO

IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_report_brand_cache'
				AND c.name = 'PrinterCount')

ALTER TABLE tbl_report_brand_cache ADD PrinterCount int

GO
-- tbl_brand
--DROP TABLE tbl_report_brand_cache


GO



GO
IF OBJECT_ID('tbl_report_group_umbrella') IS NULL
BEGIN
	CREATE TABLE tbl_report_group_umbrella
	(UmbrellaId			int PRIMARY KEY IDENTITY(1,1) NOT NULL
	,UmbrellaName		nvarchar(256) NOT NULL
	,UmbrellaComment	nvarchar(512) NULL
	,MinTicketGroups	int NULL
	,MaxTicketGroups	int NULL
	,StartDate			datetime NULL
	,EndDate			datetime NULL
	,IsDeleted			bit NOT NULL DEFAULT(0))
END

----------------------------------

GO
IF OBJECT_ID('tbl_report_group') IS NULL
BEGIN
	CREATE TABLE  tbl_report_group
	(GroupId		INT PRIMARY KEY IDENTITY(1,1) NOT NULL
	,GroupName		nvarchar(256) NOT NULL
	,GroupComment	nvarchar(512) NULL
--	,Priority		int NOT NULL
	,UmbrellaId		int REFERENCES tbl_report_group_umbrella(UmbrellaId) NOT NULL
	,StartDate		datetime NULL
	,EndDate		datetime NULL
	,IsDeleted		bit NOT NULL DEFAULT(0))
END
GO
-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_report_group'
				AND c.name = 'LogTickets')

ALTER TABLE tbl_report_group ADD  LogTickets bit NOT NULL default(1)
GO

-----------------------

GO
IF OBJECT_ID('tbl_report_ticket_group') IS NULL
BEGIN
	CREATE TABLE  tbl_report_ticket_group
	(TicketId	uniqueidentifier							NOT NULL
	,GroupId	int REFERENCES tbl_report_group(GroupId)	NOT NULL)

	ALTER TABLE tbl_report_ticket_group
		ADD CONSTRAINT cs_tbl_report_ticket_group_uq UNIQUE (TicketId, GroupId)
END

GO

-- 2009-08-20: Added bundle tables
--DROP TABLE tbl_report_group_bundle

IF OBJECT_ID('tbl_report_group_bundle') IS NULL
BEGIN
	CREATE TABLE  tbl_report_group_bundle
	(BundleId		uniqueidentifier	PRIMARY KEY		NOT NULL
	,GroupId		int					NOT NULL REFERENCES tbl_report_group(GroupId)	
	,BundleType		tinyint				NOT NULL
	,CreatedDate	datetime			NOT NULL	default(GETDATE())
	,CreatorUserId	int					NULL REFERENCES tbl_report_users(UserId) )
END


GO

IF OBJECT_ID('tbl_report_group_bundle_user') IS NULL
BEGIN
	CREATE TABLE  tbl_report_group_bundle_user
	(BundleId		uniqueidentifier	NOT NULL REFERENCES tbl_report_group_bundle(BundleId)		
	,UserName		nvarchar(510)		NOT NULL
	,Domain			nvarchar(510)		NOT NULL
	,UserId			int					NULL REFERENCES tbl_report_users(UserId))


END
GO
-- 2009-11-23: Added group graph relation table & group ExternalId Column
---

--DROP TABLE tbl_report_group_group
IF OBJECT_ID('tbl_report_group_group') IS NULL
BEGIN
	CREATE TABLE  tbl_report_group_group
	(GroupParentId		INT NOT NULL REFERENCES tbl_report_group(GroupId)
	,GroupChildId		INT NOT NULL REFERENCES tbl_report_group(GroupId))

	ALTER TABLE tbl_report_group_group
		ADD CONSTRAINT cs_tbl_report_group_group_uq UNIQUE (GroupParentId, GroupChildId)
END

GO
-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_report_group'
				AND c.name = 'ExternalId')

ALTER TABLE tbl_report_group ADD  ExternalId nvarchar(128) NULL
GO


IF OBJECT_ID('tbl_report_jobs_detail') IS NULL
BEGIN
	CREATE TABLE tbl_report_jobs_detail
	(TicketId					uniqueidentifier PRIMARY KEY	NOT NULL
	,JobDate					datetime			NOT NULL
	,JobName					nvarchar(510)		NOT NULL
	,UserId						int					NOT NULL
	,QueueId					uniqueidentifier	NOT NULL
	,FollowPrintQueueId			uniqueidentifier	NULL
	,IsLocalPrinter				bit					NOT NULL
	,JobType					tinyint				NOT NULL --(1=print, 2=copy, 3=fax, 4=scan)
	,IsFollowPrint				bit					NOT NULL
	,PaperType					smallint			NOT NULL
	,Duplex						bit					NOT NULL
	,Size						bigint				NOT NULL 
	,PagesBW					int					NOT NULL
	,PagesColor					int					NOT NULL
	,TicketPrice				float				NULL)


	ALTER TABLE tbl_report_jobs_detail
		ADD CONSTRAINT cs_tbl_report_jobs_detail_fk FOREIGN KEY (UserId) REFERENCES tbl_report_users (UserId)



END

GO

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_report_jobs_detail'
				AND c.name = 'BillingCodeId')

ALTER TABLE tbl_report_jobs_detail ADD BillingCodeId bigint
GO


-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_report_jobs_detail'
				AND c.name = 'DnId')

ALTER TABLE tbl_report_jobs_detail ADD DnId int REFERENCES tbl_dn (DnId)
GO

-- 2009-10-23: Added a couple of indexes

if not exists (select * from sysindexes where name = 'ixReportJobDetails01')
BEGIN

	CREATE INDEX ixReportJobDetails01 ON tbl_report_jobs_detail 
		(UserId 
		,QueueId
		,IsLocalPrinter
		,JobType 
		,Duplex )

	CREATE INDEX ixReportJobDetails11 ON tbl_report_jobs_detail 
		(JobDate
		,UserId
		,JobType 
		,PaperType 
		,PagesBW
		,PagesColor)
END

GO

--DROP TABLE tbl_report_jobs_detail

GO

IF OBJECT_ID('tbl_report_jobs_queue') IS NULL
BEGIN
	CREATE TABLE tbl_report_jobs_queue
	(JobDay					datetime NOT NULL
	,QueueId				uniqueidentifier NULL
	,FollowPrintQueueId		uniqueidentifier NULL
	,IsLocalPrinter			bit NOT NULL
	,JobType				tinyint NOT NULL --(1=print, 2=copy, 3=fax, 4=scan)
	,IsFollowPrint			bit NOT NULL
	,Color					bit NOT NULL
	,Duplex					bit NOT NULL
	,PaperType				smallint NOT NULL
	,Size					bigint NOT NULL 
	,Pages					int NOT NULL
	,JobCount				int NOT NULL
	,TicketPrice			float NULL)

	ALTER TABLE tbl_report_jobs_queue
		ADD CONSTRAINT cs_tbl_report_jobs_queue_uq UNIQUE (JobDay, QueueId, FollowPrintQueueId, IsLocalPrinter, JobType, IsFollowPrint, Color, Duplex, PaperType)
END

GO

--DROP TABLE tbl_report_jobs_queue

GO



IF OBJECT_ID('tbl_report_model_cache') IS NULL
BEGIN
	CREATE TABLE tbl_report_model_cache
	(ModelId				uniqueidentifier PRIMARY KEY
	,BrandId				uniqueidentifier -- FK
	,ModelName				nvarchar(512))
--	ALTER TABLE tbl_report_jobs_queue_regiondepth_cache
--		ADD CONSTRAINT cs_tbl_report_jobs_queue_regiondepth_cache_uq UNIQUE (QueueId, Depth)
END
GO

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_report_model_cache'
				AND c.name = 'PrinterCount')

ALTER TABLE tbl_report_model_cache ADD PrinterCount int
GO


GO
-- tbl_model
--DROP TABLE tbl_report_model_cache


GO



IF OBJECT_ID('tbl_report_printer_cache') IS NULL
BEGIN
	CREATE TABLE tbl_report_printer_cache
	(PrinterId				uniqueidentifier PRIMARY KEY
	,PrinterName			nvarchar(512)
	,PrinterType			char(1)
	,PrinterComment			nvarchar(510)
	,ModelId				uniqueidentifier -- i tbl_printer: nvarchar(510) -- ????
	,Hidden					bit
	,ParentRegionId			bigint)
--	ALTER TABLE tbl_report_jobs_queue_regiondepth_cache
--		ADD CONSTRAINT cs_tbl_report_jobs_queue_regiondepth_cache_uq UNIQUE (QueueId, Depth)
END
GO




GO
-- select printerModel, modelId, * from tbl_printer where printerModel <> modelId
-- select * from tbl_model
-- select * from tbl_brand
--DROP TABLE tbl_report_printer_cache

GO



IF OBJECT_ID('tbl_report_queue_cache') IS NULL
BEGIN
	CREATE TABLE tbl_report_queue_cache
	(QueueId				uniqueidentifier PRIMARY KEY
	,QueueName				nvarchar(512)
	,QueueType				smallint
	,PrinterId				uniqueidentifier
	,ParentRegionId			bigint)
--	ALTER TABLE tbl_report_jobs_queue_regiondepth_cache
--		ADD CONSTRAINT cs_tbl_report_jobs_queue_regiondepth_cache_uq UNIQUE (QueueId, Depth)
END

GO
-- tbl_queue
--DROP TABLE tbl_report_queue_cache

GO



IF OBJECT_ID('tbl_report_queue_regiondepth_cache') IS NULL
BEGIN
	CREATE TABLE tbl_report_queue_regiondepth_cache
	(QueueId				uniqueidentifier
	,Depth					smallint
	,RegionPath				nvarchar(512))

	ALTER TABLE tbl_report_queue_regiondepth_cache
		ADD CONSTRAINT cs_tbl_report_queue_regiondepth_cache_uq UNIQUE (QueueId, Depth)
END

GO

--DROP TABLE tbl_report_queue_regiondepth_cache

GO



IF OBJECT_ID('tbl_report_region_cache') IS NULL
BEGIN
	CREATE TABLE tbl_report_region_cache
	(RegionId				bigint PRIMARY KEY
	,ParentRegionId			bigint
	,RegionName				nvarchar(512)
	,RegionGUID				uniqueidentifier)
--	ALTER TABLE tbl_report_jobs_queue_regiondepth_cache
--		ADD CONSTRAINT cs_tbl_report_jobs_queue_regiondepth_cache_uq UNIQUE (QueueId, Depth)
END

GO

--DROP TABLE tbl_report_region_cache



GO



IF OBJECT_ID('tbl_report_status_cache') IS NULL
BEGIN
	CREATE TABLE tbl_report_status_cache
	(StatusTypeId			tinyint -- vilken funktion det kommer fr�n
	,StatusMajor			int
	,StatusMinor			int
	,StatusVerbose			nvarchar(510))
	ALTER TABLE tbl_report_status_cache
		ADD CONSTRAINT cs_ttbl_report_status_cache_uq UNIQUE (StatusTypeId, StatusMajor, StatusMinor)
END

GO

--DROP TABLE tbl_report_status_cache

GO



IF OBJECT_ID('tbl_report_users') IS NULL
BEGIN
	CREATE TABLE tbl_report_users
	(UserId						int	PRIMARY KEY		NOT NULL IDENTITY(1,1)
	,UserName					nvarchar(510)		NOT NULL
	,Domain						nvarchar(510)		NOT NULL
	,RegDate					datetime			NOT NULL DEFAULT(getdate()))

--	ALTER TABLE tbl_report_users
--		ADD CONSTRAINT cs_tbl_report_users_uq UNIQUE (UserName, Domain)
END

GO

--DROP  TABLE tbl_report_jobs_detail
--DROP  TABLE tbl_report_users

GO





GO


IF OBJECT_ID('tbl_scheduled_job') IS NULL
BEGIN
	CREATE TABLE tbl_scheduled_job 
	(JobId				int PRIMARY KEY IDENTITY(1,1) NOT NULL
	,JobName			nvarchar(128) NOT NULL
	,JobComment			nvarchar(512) NULL
	,Interval			int NOT NULL -- 1 = dagligen
	,RunOffset			int default(0) NOT NULL 
	,ExecSP				sysname NOT NULL
	,StartDate			datetime NULL
	,EndDate			datetime NULL
	,IsActive			bit default(1) NOT NULL
	,IsDeleted			bit default(0) NOT NULL
	,LastRun			datetime NULL
	,RetryTimes			tinyint default(0) NOT NULL)
END

GO

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_scheduled_job'
				AND c.name = 'IsRunning')

ALTER TABLE tbl_scheduled_job ADD  IsRunning bit NOT NULL DEFAULT(0)

GO


IF OBJECT_ID('tbl_scheduled_job_run_log') IS NULL
BEGIN
	CREATE TABLE tbl_scheduled_job_run_log 
	(RunId					int PRIMARY KEY IDENTITY(1,1) NOT NULL
	,JobId					int REFERENCES tbl_scheduled_job(JobId)
	,RunStartDate			datetime NOT NULL
	,RunEndDate				datetime NULL
	,ReturnStatus			int NOT NULL
	,ReturnStatusMessage	nvarchar(512) NULL
	,OutcomeInt1			int
	,OutcomeInt2			int
	,OutcomeInt3			int
	,OutcomeString1			nvarchar(128)
	,OutcomeString2			nvarchar(128)
	,OutcomeString3			nvarchar(128))

END

--drop table tbl_scheduled_job_run_log
--
--drop table tbl_scheduled_job
GO

--DROP TABLE tbl_smartalarm_type

IF OBJECT_ID('tbl_smartalarm_type') IS NULL
BEGIN
	CREATE TABLE tbl_smartalarm_type
		(AlarmTypeId		int				-- what type of alarm? 1 = job takes too long, 2 = max no of jobs in queue exceeded
		,AlarmSeverityId	int				-- 1 = warning, 2 = error
		,AlarmArea			int				-- 1=job, 2=printer, 3=queue
		,AlarmDescription	varchar(128)	-- Verbose alarm description 
		,DateCreated		datetime	DEFAULT CURRENT_TIMESTAMP)

	ALTER TABLE tbl_smartalarm_type ADD CONSTRAINT cs_uq_smartalarm_type UNIQUE(AlarmTypeId, AlarmSeverityId, AlarmArea)

END
GO

-- 2009-10-15 Multi-language support

	
	IF NOT EXISTS(SELECT * FROM sysobjects o
					INNER JOIN syscolumns c ON c.id = o.id
					AND o.name = 'tbl_smartalarm_type'
					AND c.name = 'LanguageId')
	BEGIN
		-- Remove old constraint
		ALTER TABLE tbl_smartalarm_type
			DROP CONSTRAINT cs_uq_smartalarm_type

		-- Add column
		ALTER TABLE tbl_smartalarm_type ADD LanguageId char(2) NOT NULL DEFAULT('en')

		-- Create new constraint
		ALTER TABLE tbl_smartalarm_type ADD CONSTRAINT cs_uq_smartalarm_type UNIQUE(AlarmTypeId, AlarmSeverityId, AlarmArea, LanguageId)
	END




GO


IF OBJECT_ID('tbl_support_advice') IS NULL
BEGIN
	CREATE TABLE tbl_support_advice
	(SourceTable		varchar(100)
	,Level1				int
	,Level2				int	NULL
	,Level3				int	NULL
	,SortOrder			int
	,AdviceText			nvarchar(510))

	ALTER TABLE tbl_support_advice
		ADD CONSTRAINT cs_support_advice UNIQUE (SourceTable, Level1, Level2, Level3, SortOrder)

END
GO
-- Change constraint and add language column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_support_advice'
				AND c.name = 'LanguageId')
BEGIN
	ALTER TABLE tbl_support_advice
		DROP CONSTRAINT cs_support_advice

	ALTER TABLE tbl_support_advice ADD LanguageId char(2) NOT NULL DEFAULT('en')

	ALTER TABLE tbl_support_advice
		ADD CONSTRAINT cs_support_advice UNIQUE (SourceTable, Level1, Level2, Level3, SortOrder, LanguageId)


END


GO
DELETE tbl_support_advice WHERE SourceTable = 'tbl_ticket_log'

INSERT tbl_support_advice (SourceTable, Level1, Level2, SortOrder, AdviceText, LanguageId)
VALUES ('tbl_ticket_log', 2, 2, 10, 'Try turning off your firewall', 'en')

INSERT tbl_support_advice (SourceTable, Level1, Level2, SortOrder, AdviceText, LanguageId)
VALUES ('tbl_ticket_log', 2, 2, 10, 'Prova att st�nga av brandv�ggen', 'sv')

--	if(@minor=28) 'Deleted - No client session on client'
INSERT tbl_support_advice (SourceTable, Level1, Level2, SortOrder, AdviceText, LanguageId)
VALUES ('tbl_ticket_log', 2, 28, 10, 'Try logging out and in, then print the job again', 'en')
INSERT tbl_support_advice (SourceTable, Level1, Level2, SortOrder, AdviceText, LanguageId)
VALUES ('tbl_ticket_log', 2, 28, 10, 'Prova att logga ut och in, och skriv sedan ut igen', 'sv')


--SELECT * FROM tbl_support_advice
GO
-- Remove unused index
SET ANSI_WARNINGS OFF
if exists (select * from sysindexes where name = 'ixTicketLogSearch')
	DROP INDEX ixTicketLogSearch ON  tbl_ticket_log
SET ANSI_WARNINGS ON
GO

-- Add index


SET ANSI_WARNINGS OFF
if not exists (select * from sysindexes where name = 'ixTicketLogSearch4')
BEGIN
	PRINT 'Please ignore the following warning'

	CREATE INDEX ixTicketLogSearch4 ON tbl_ticket_log (logticketId, logDateEvent, logjobName, logoriginatingIp, loguserName)
END

SET ANSI_WARNINGS ON
GO

-- Add index

SET ANSI_WARNINGS OFF
if not exists (select * from sysindexes where name = 'ixVDMSLoginSessionLog1')
	CREATE INDEX ixVDMSLoginSessionLog1 ON tbl_vdms_loginsession_log (lvsIp, lvsUser, lvsDateLogin)

SET ANSI_WARNINGS ON
GO


IF OBJECT_ID('tbl_cirrato_wallet_user_group ') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_user_group
	(UserId				int REFERENCES tbl_report_users(UserId) NOT NULL
	,GroupId			int	REFERENCES tbl_report_group(GroupId) NOT NULL)
	ALTER TABLE tbl_cirrato_wallet_user_group
		ADD CONSTRAINT cs_tbl_cirrato_wallet_user_group_uq UNIQUE (UserId, GroupId)
END
GO

IF OBJECT_ID('tbl_cirrato_wallet_schedule') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_schedule
	(ScheduleId			int PRIMARY KEY IDENTITY(1,1) NOT NULL
	,ScheduleName		nvarchar(256)	NOT NULL
	,ScheduleComment	nvarchar(512)	NULL

	,Periodicity		tinyint			NULL	-- enum Periodicity. NULL = Custom dates, tabell nedan
	,OffsetType			tinyint			NOT NULL DEFAULT(0)
	,OffsetValue		int				NOT NULL DEFAULT(0)
	,PeriodStart		dt_monthday		NULL
	,PeriodEnd			dt_monthday		NULL

	,CreatedDate		datetime		NOT NULL DEFAULT(GETDATE())
	,CreatorUserName	nvarchar(512)	NULL
	,CreatorDomain		nvarchar(512)	NULL
	,IsDeleted			bit				NOT NULL DEFAULT(0))


END
GO

IF OBJECT_ID('tbl_cirrato_wallet_schedule_days') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_schedule_days
	(ScheduleId		int REFERENCES tbl_cirrato_wallet_schedule(ScheduleId) NOT NULL
	,MonthDay		dt_monthday NOT NULL)

	ALTER TABLE tbl_cirrato_wallet_schedule_days
		ADD CONSTRAINT cs_tbl_cirrato_wallet_schedule_days_uq UNIQUE (ScheduleId, MonthDay)

END
GO

IF OBJECT_ID('tbl_cirrato_wallet_rule') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_rule
	(RuleId			int PRIMARY KEY IDENTITY(1,1)							NOT NULL
	,RuleName		nvarchar(256)	NOT NULL
	,RuleComment	nvarchar(512)	NULL
	,SortOrder		int				NOT NULL DEFAULT(0)
	,ScheduleId		int REFERENCES tbl_cirrato_wallet_schedule(ScheduleId)	NULL -- (NULL = on user creation)
	,UmbrellaId		int REFERENCES tbl_report_group_umbrella(UmbrellaId)	NULL
	,GroupId		int REFERENCES tbl_report_group(GroupId)				NULL
	,Amount			float			NULL
	,Multiplier		float			NULL
	,StartDate		datetime		NULL	
	,EndDate		datetime		NULL
	,IsDeleted		bit				NOT NULL DEFAULT(0))

	ALTER TABLE tbl_cirrato_wallet_rule
		ADD CONSTRAINT cs_tbl_cirrato_wallet_rule_umbrella_group CHECK (	(UmbrellaId IS NULL AND GroupId IS NOT NULL)
																OR	(UmbrellaId IS NOT NULL AND GroupId IS NULL))
	ALTER TABLE tbl_cirrato_wallet_rule
		ADD CONSTRAINT cs_tbl_cirrato_wallet_rule_amount_multiplier CHECK (	(Amount IS NULL AND Multiplier IS NOT NULL)
																OR	(Amount IS NOT NULL AND Multiplier IS NULL))
END
GO

GO
--drop table tbl_cirrato_wallet_error
IF OBJECT_ID('tbl_cirrato_wallet_error') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_error
	(UserId			int REFERENCES tbl_report_users(UserId) NOT NULL
	,RuleId			int REFERENCES tbl_cirrato_wallet_rule(RuleId)			NOT NULL
	,RunDate		datetime		NOT NULL
	,RegDate		datetime		NOT NULL
	,Amount			float			NULL
	,Multiplier		float			NULL
	,ErrorNo		int				NULL)

END
GO

IF OBJECT_ID('tbl_cirrato_wallet_rule_run_log') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_rule_run_log
	(RuleId			int REFERENCES tbl_cirrato_wallet_rule(RuleId)			NOT NULL
	,RunDate		datetime		NOT NULL
	,RegDate		datetime		NOT NULL
	,ErrorNo		int				NULL)

END
GO
--drop table tbl_cirrato_wallet_rule_run_error

IF OBJECT_ID('tbl_cirrato_wallet_log_comment') IS NULL
BEGIN
	CREATE TABLE tbl_cirrato_wallet_log_comment
	(CommentId			int PRIMARY KEY IDENTITY(1,1)							NOT NULL
	,Comment			nvarchar(512) NOT NULL)

END
GO


-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_cirrato_wallet'
				AND c.name = 'firstRun')

ALTER TABLE tbl_cirrato_wallet ADD  firstRun datetime
GO

-- Drop trigger

IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[trigger_wallet]'))
DROP TRIGGER [dbo].[trigger_wallet]

GO

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_cirrato_wallet'
				AND c.name = 'wUserId')

ALTER TABLE tbl_cirrato_wallet ADD  wUserId int REFERENCES tbl_report_users (UserId)
GO

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_cirrato_wallet'
				AND c.name = 'IsDeleted')

ALTER TABLE tbl_cirrato_wallet ADD IsDeleted bit NOT NULL DEFAULT(0)
GO


-- Add users in wallet but not in tbl_report_users to tbl_report_users

INSERT tbl_report_users 
	(UserName
	,Domain)
SELECT
	w.wUser
	,w.wDomain
FROM tbl_cirrato_wallet w
LEFT JOIN tbl_report_users u
	ON w.wUser = u.UserName
	AND w.wDomain = u.Domain
WHERE u.UserName IS NULL


UPDATE w
	SET w.wUserId = u.UserId
FROM tbl_cirrato_wallet w
INNER JOIN tbl_report_users u
	ON w.wUser = u.UserName
	AND w.wDomain = u.Domain
WHERE w.wUserId IS NULL





GO

IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[trigger_wallet_userid]'))
DROP TRIGGER [dbo].[trigger_wallet_userid]

GO


CREATE TRIGGER [trigger_wallet_userid]
ON tbl_cirrato_wallet
AFTER INSERT
AS 
BEGIN

	INSERT tbl_report_users 
		(UserName
		,Domain)
	SELECT
		w.wUser
		,w.wDomain
	FROM tbl_cirrato_wallet w
	LEFT JOIN tbl_report_users u
		ON w.wUser = u.UserName
		AND w.wDomain = u.Domain
	WHERE u.UserName IS NULL


	UPDATE w
	SET w.wUserId = u.UserId
	FROM tbl_cirrato_wallet w
	INNER JOIN tbl_report_users u
		ON w.wUser = u.UserName
		AND w.wDomain = u.Domain
	WHERE w.wUserId IS NULL

END
GO





GO
-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_cirrato_wallet_log'
				AND c.name = 'wRuleId')

ALTER TABLE tbl_cirrato_wallet_log ADD  wRuleId int NULL REFERENCES tbl_cirrato_wallet_rule (RuleId)
GO

IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_cirrato_wallet_log'
				AND c.name = 'wRuleRunDate')

ALTER TABLE tbl_cirrato_wallet_log ADD wRuleRunDate datetime
GO

IF NOT EXISTS(SELECT * FROM sysobjects o
				INNER JOIN syscolumns c ON c.id = o.id
				AND o.name = 'tbl_cirrato_wallet_log'
				AND c.name = 'wCommentId')

ALTER TABLE tbl_cirrato_wallet_log ADD  wCommentId int NULL REFERENCES tbl_cirrato_wallet_log_comment (CommentId)
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_end_of_month') IS NOT NULL
	DROP FUNCTION fn_end_of_month
GO

CREATE FUNCTION fn_end_of_month
	(@iDate			datetime)
RETURNS   datetime

AS
BEGIN
	
	DECLARE @ReturnValue datetime

	



	RETURN @ReturnValue
END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_errorno_translate') IS NOT NULL
	DROP FUNCTION fn_errorno_translate
GO

CREATE FUNCTION fn_errorno_translate
	(@iErrorNo int
	,@iLanguageId	char(2))
RETURNS   nvarchar(1024)

AS
BEGIN

	if (@iErrorNo = 0) return 'Success';

		
	if (@iErrorNo = 100600) return 'SP must be run within a transaction';
	if (@iErrorNo = 100601) return 'ADOUUmbrellaId must be set';
	if (@iErrorNo = 100602) return 'ADUmbrellaId must be set';
	if (@iErrorNo = 100603) return 'ConfigID does not exist';
	if (@iErrorNo = 100604) return 'ConfigID dapper sync in progress - cannot do umbrella sync now';
	if (@iErrorNo = 100605) return 'Execution Error';
	if (@iErrorNo = 100606) return 'Config is not valid';
	if (@iErrorNo = 100607) return 'Config is blocked';
	if (@iErrorNo = 100608) return 'Config name must be set';
	if (@iErrorNo = 100609) return 'Config GUID must be set';
	if (@iErrorNo = 100610) return 'NetBIOSName of the domain must be retrieved from AD';
	if (@iErrorNo = 100611) return 'Quota batch job in progress - cannot do umbrella sync now';

	RETURN CAST(@iErrorNo AS VARCHAR(20))
END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_guid_addone') IS NOT NULL
	DROP FUNCTION fn_guid_addone
GO

CREATE FUNCTION fn_guid_addone
	(@iGUID			uniqueidentifier)
RETURNS   uniqueidentifier

AS
BEGIN
		
	DECLARE @ReturnValue uniqueidentifier

	DECLARE @lpart char(35)
	DECLARE @rpart char(1)
	DECLARE @rpartint int

	SET @lpart = LEFT(@iGUID, 35)
	SET @rpart = RIGHT(@iGUID, 1)


	
	IF ISNUMERIC(@rpart) = 1
		SET @rpartint = CAST(@rpart AS int)
	ELSE 
		SET @rpartint = -1
	
	IF @rpartint NOT BETWEEN 0 AND 8
		SET @rpartint = 0
	ELSE
		SET @rpartint = @rpartint + 1

	SET @ReturnValue = CAST(@lpart + CAST(@rpartint AS char(1)) AS uniqueidentifier)

	RETURN @ReturnValue
END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_lregion_get_partial_path_verbose') IS NOT NULL
	DROP FUNCTION fn_lregion_get_partial_path_verbose
GO

CREATE FUNCTION fn_lregion_get_partial_path_verbose
	(@iRegionId			bigint
	,@iDepth			int)
RETURNS   varchar(128)

AS
BEGIN

-- 1. get full region numeric path
-- 2. get nTh item


--declare	@npath varchar(100)
--		,@curRegionId int
--		,@curDepth int
--
--SET @npath = dbo.fn_region_get_path(@iRegionId,'/')
--
--
--SET @curRegionId = 0;
--SET @curDepth = 0;

IF (@iDepth = 0)
	RETURN dbo.GetAbsoluteLocalRegion(@iRegionId)



declare @regionpath table (invDepth int identity(1,1)
							,regionId bigint)


declare @cReg int
,@loopCount int

set @loopCount = 0
set @cReg = @iRegionId

while @cReg <> 0 AND @loopCount < 100
begin
	INSERT @regionpath (regionId) VALUES (@cReg)

	SELECT @cReg = lregionParentId FROM tbl_lregion WHERE lregionId = @cReg
SET @loopCount = @loopCount +1

end


declare @FullDepth int
select @FullDepth = MAX(invDepth) FROM @regionpath

declare @RightRegionId bigint
declare @rdept int


SET @rdept = @FullDepth - @iDepth + 1

if @rdept > @FullDepth SET  @rdept = @FullDepth
if @rdept < 1 SET  @rdept = 1


SELECT @RightRegionId =  regionId FROM @regionpath WHERE invDepth = @rdept




RETURN dbo.GetAbsoluteLocalRegion(@RightRegionId)

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_printer_physical_status_severity') IS NOT NULL
	DROP FUNCTION fn_printer_physical_status_severity
GO

CREATE FUNCTION fn_printer_physical_status_severity
	(@iStatus smallint
	,@iSNMPActive char(1))
RETURNS   int

AS

--------------------------------------------------------------
--Modified by:  Henrik Linder
--Modification date: 2009-03-25
--Description: Added support for SNMP turned off
--------------------------------------------------------------
--Modified by:  Henrik Linder
--Modification date: 2009-07-13
--Description: Ticket 164. Status 7 och 8 hade bytt plats.
--------------------------------------------------------------

BEGIN
	-- -1 = SNMP turned off
	--0 = info
	--1 = warning
	--2 = error

	IF (@iSNMPActive = '0')
		RETURN -1

	if(@iStatus=0)
		return 0 -- 'OK'
	if(@iStatus=1)
		return 1 -- 'Low Paper'
	if(@iStatus=2)
		return 1 -- 'Low Toner'
	if(@iStatus=3)
		return 1 -- 'Service Needed'
	if(@iStatus=4)
		return 2 -- 'No Paper'
	if(@iStatus=5)
		return 2 -- 'No Toner'
	if(@iStatus=6)
		return 2 -- 'Offline'
	if(@iStatus=7)
		return 2 -- 'Door Open'
	if(@iStatus=8)
		return 2 -- 'Paper Jam'
	if(@iStatus=9)
		return 2 -- 'No Contact'

	RETURN  2

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_property_get_date') IS NOT NULL
	DROP FUNCTION fn_property_get_date
GO

CREATE FUNCTION fn_property_get_date
	(@ipropertyName varchar(64))
RETURNS   datetime

AS
BEGIN
	DECLARE @ReturnValue datetime

	SELECT @ReturnValue = propertyValueDate FROM tbl_property WHERE propertyName = @ipropertyName


	RETURN  @ReturnValue

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_property_get_date_by_group') IS NOT NULL
	DROP FUNCTION fn_property_get_date_by_group
GO

CREATE FUNCTION fn_property_get_date_by_group
	(@iPropertyGroup	varchar(64)
	,@iPropertyName		varchar(64))
RETURNS   datetime

AS
BEGIN
	DECLARE @ReturnValue datetime

	SELECT @ReturnValue = propertyValueDate FROM tbl_property WHERE propertyName = @iPropertyName AND propertyGroup = @iPropertyGroup


	RETURN  @ReturnValue

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_property_get_numeric') IS NOT NULL
	DROP FUNCTION fn_property_get_numeric
GO

CREATE FUNCTION fn_property_get_numeric
	(@ipropertyName varchar(64))
RETURNS   int

AS
BEGIN
	DECLARE @ReturnValue int

	SELECT @ReturnValue = propertyValueNumeric FROM tbl_property WHERE propertyName = @ipropertyName


	RETURN  @ReturnValue

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_property_get_numeric_by_group') IS NOT NULL
	DROP FUNCTION fn_property_get_numeric_by_group
GO

CREATE FUNCTION fn_property_get_numeric_by_group
	(@iPropertyGroup	varchar(64)
	,@iPropertyName		varchar(64))
RETURNS   int

AS
BEGIN
	DECLARE @ReturnValue int

	SELECT @ReturnValue = propertyValueNumeric FROM tbl_property WHERE propertyName = @iPropertyName AND propertyGroup = @iPropertyGroup


	RETURN  @ReturnValue

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_property_get_string') IS NOT NULL
	DROP FUNCTION fn_property_get_string
GO

CREATE FUNCTION fn_property_get_string
	(@ipropertyName varchar(64))
RETURNS   nvarchar(510)

AS
BEGIN
	DECLARE @ReturnValue nvarchar(510)

	SELECT @ReturnValue = propertyValue FROM tbl_property WHERE propertyName = @ipropertyName


	RETURN  @ReturnValue

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_property_get_string_by_group') IS NOT NULL
	DROP FUNCTION fn_property_get_string_by_group
GO

CREATE FUNCTION fn_property_get_string_by_group
	(@iPropertyGroup	varchar(64)
	,@iPropertyName		varchar(64))
RETURNS   nvarchar(510)

AS
BEGIN
	DECLARE @ReturnValue nvarchar(510)

	SELECT @ReturnValue = propertyValue FROM tbl_property WHERE propertyName = @iPropertyName AND propertyGroup = @iPropertyGroup


	RETURN  @ReturnValue

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_region_get_name') IS NOT NULL
	DROP FUNCTION fn_region_get_name
GO

CREATE FUNCTION fn_region_get_name
	(@iRegionId			bigint)
RETURNS   nvarchar(512)

AS
BEGIN
	
	DECLARE @ReturnValue nvarchar(512)


	SELECT @ReturnValue = regionName FROM tbl_region WHERE regionId = @iRegionId

	--RETURN ISNULL(@ReturnValue,'')
	RETURN @ReturnValue
END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_region_get_partial_path_verbose') IS NOT NULL
	DROP FUNCTION fn_region_get_partial_path_verbose
GO

CREATE FUNCTION fn_region_get_partial_path_verbose
	(@iRegionId			bigint
	,@iDepth			int)
RETURNS   varchar(128)

AS
BEGIN

-- 1. get full region numeric path
-- 2. get nTh item


--declare	@npath varchar(100)
--		,@curRegionId int
--		,@curDepth int
--
--SET @npath = dbo.fn_region_get_path(@iRegionId,'/')
--
--
--SET @curRegionId = 0;
--SET @curDepth = 0;

IF (@iDepth = 0)
	RETURN dbo.GetAbsoluteRegion(@iRegionId)



declare @regionpath table (invDepth int identity(1,1)
							,regionId bigint)


declare @cReg int
,@loopCount int

set @loopCount = 0
set @cReg = @iRegionId

while @cReg <> 0 AND @loopCount < 100
begin
	INSERT @regionpath (regionId) VALUES (@cReg)

	SELECT @cReg = regionParentId FROM tbl_region WHERE regionId = @cReg
SET @loopCount = @loopCount +1

end


declare @FullDepth int
select @FullDepth = MAX(invDepth) FROM @regionpath

declare @RightRegionId bigint
declare @rdept int


SET @rdept = @FullDepth - @iDepth + 1

if @rdept > @FullDepth SET  @rdept = @FullDepth
if @rdept < 1 SET  @rdept = 1


SELECT @RightRegionId =  regionId FROM @regionpath WHERE invDepth = @rdept




RETURN dbo.GetAbsoluteRegion(@RightRegionId)

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_region_get_part_path_verbose') IS NOT NULL
	DROP FUNCTION fn_region_get_part_path_verbose
GO

CREATE FUNCTION fn_region_get_part_path_verbose
	(@iRegionId			bigint
	,@iDepth			int)
RETURNS   varchar(128)

AS
BEGIN

-- 1. get full region numeric path
-- 2. get nTh item



IF (@iDepth = 0)
	RETURN dbo.GetAbsoluteRegion(@iRegionId)



declare @regionpath table (invDepth int identity(1,1)
							,regionId bigint)


declare @cReg int
,@loopCount int

set @loopCount = 0
set @cReg = @iRegionId

while @cReg <> 0 AND @loopCount < 100
begin
	INSERT @regionpath (regionId) VALUES (@cReg)

	SELECT @cReg = regionParentId FROM tbl_region WHERE regionId = @cReg
	SET @loopCount = @loopCount +1
end


declare @FullDepth int
select @FullDepth = MAX(invDepth) FROM @regionpath

declare @RightRegionId bigint
declare @rdept int


SET @rdept = @FullDepth - @iDepth + 1

--if @rdept > @FullDepth SET  @rdept = @FullDepth
--if @rdept < 1 SET  @rdept = 1


SELECT @RightRegionId =  regionId FROM @regionpath WHERE invDepth = @rdept




--RETURN dbo.GetAbsoluteRegion(@RightRegionId)
RETURN dbo.fn_region_get_name(@RightRegionId)


END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_region_get_path') IS NOT NULL
	DROP FUNCTION fn_region_get_path
GO

CREATE FUNCTION fn_region_get_path
	(@iregionId			bigint
	,@iseparator		varchar(10))
RETURNS   varchar(128)

AS
BEGIN
	DECLARE @parentRegionId bigint

	SELECT @parentRegionId = regionParentId FROM tbl_region WHERE regionId = @iregionId

	IF (@parentRegionId IS NOT NULL AND @parentRegionId <> 0)
		RETURN dbo.fn_region_get_path(@parentRegionId,@iseparator) + @iseparator + CAST(@iregionId AS VARCHAR(128)) 

	RETURN  CAST(@iregionId AS VARCHAR(128))

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_translate') IS NOT NULL
	DROP FUNCTION fn_translate
GO

CREATE FUNCTION fn_translate
	(@iTerm			varchar(20)
	,@iLanguageId	char(2))
RETURNS   nvarchar(256)

AS
BEGIN
	
	IF @iLanguageId = 'sv'
	BEGIN
		IF @iTerm = 'ClosedJob'				RETURN 'Avslutat'
		IF @iTerm = 'TotalBalance'			RETURN 'Totalt saldo'
		IF @iTerm = 'Users'					RETURN 'Anv�ndare'
		IF @iTerm = 'UsersWithBalance'		RETURN 'Anv�ndare med saldo'
		IF @iTerm = 'CurrentBalance'		RETURN 'Aktuellt saldo'
		IF @iTerm = 'reserved'				RETURN 'reserverat'

		IF @iTerm = 'Queue Name'				RETURN 'K�namn'
		IF @iTerm = 'Location'					RETURN 'Plats'
		IF @iTerm = 'Region'					RETURN 'Region'
		IF @iTerm = 'Jobs'						RETURN 'Jobb'
		IF @iTerm = 'Display Text'				RETURN 'Displaytext'
		IF @iTerm = 'Offline Reason'			RETURN 'Nerst�ngningsorsak'
		IF @iTerm = 'Speed B/W Single'			RETURN 'Hastighet sv/v simplex'
		IF @iTerm = 'Speed B/W Duplex'			RETURN 'Hastighet sv/v duplex'
		IF @iTerm = 'Speed Color Single'		RETURN 'Hastighet f�rg simplex'
		IF @iTerm = 'Speed Color Duplex'		RETURN 'Hastighet f�rg duplex'
		IF @iTerm = 'Admin Comment'				RETURN 'Administrat�rskommentar'
		IF @iTerm = 'Name'						RETURN 'Namn'
		IF @iTerm = 'Hidden'					RETURN 'Dold'


		IF @iTerm = 'Colour'					RETURN 'F�rg'
		IF @iTerm = 'B/W'						RETURN 'Sv/v'
		IF @iTerm = 'Simplex'					RETURN 'Simplex'
		IF @iTerm = 'Duplex'					RETURN 'Duplex'




	END


	-- Revert to English if chosen language is not avail
	IF @iTerm = 'ClosedJob'				RETURN 'Closed'
	IF @iTerm = 'TotalBalance'			RETURN 'Total balance'
	IF @iTerm = 'Users'					RETURN 'Users'
	IF @iTerm = 'UsersWithBalance'		RETURN 'Users with balance'
	IF @iTerm = 'CurrentBalance'		RETURN 'Current balance'
	IF @iTerm = 'reserved'				RETURN 'reserved'


	IF @iTerm = 'Queue Name'				RETURN 'Queue Name'
	IF @iTerm = 'Location'					RETURN 'Location'
	IF @iTerm = 'Region'					RETURN 'Region'
	IF @iTerm = 'Jobs'						RETURN 'Jobs'
	IF @iTerm = 'Display Text'				RETURN 'Display Text'
	IF @iTerm = 'Offline Reason'			RETURN 'Offline Reason'
	IF @iTerm = 'Speed B/W Single'			RETURN 'Speed B/W Single'
	IF @iTerm = 'Speed B/W Duplex'			RETURN 'Speed B/W Duplex'
	IF @iTerm = 'Speed Color Single'		RETURN 'Speed Colour Single'
	IF @iTerm = 'Speed Color Duplex'		RETURN 'Speed Colour Duplex'
	IF @iTerm = 'Admin Comment'				RETURN 'Admin Comment'
	IF @iTerm = 'Name'						RETURN 'Name'
	IF @iTerm = 'Hidden'					RETURN 'Hidden'
	IF @iTerm = 'Colour'					RETURN 'Colour'
	IF @iTerm = 'B/W'						RETURN 'B/W'
	IF @iTerm = 'Simplex'					RETURN 'Simplex'
	IF @iTerm = 'Duplex'					RETURN 'Duplex'

	IF @iTerm = 'NetworkPrinters'			RETURN 'Network Printers'
	IF @iTerm = 'LocalPrinters'				RETURN 'Local Printers'

	RETURN @iTerm


END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('fn_value_list_parse') IS NOT NULL
	DROP FUNCTION fn_value_list_parse
GO

CREATE FUNCTION fn_value_list_parse
	(@ivalueList varchar(8000))
RETURNS   @ValueTable table
  (
   RowId       int IDENTITY(1,1)   
  ,ValueTypeId varchar(64)
  )

AS


BEGIN
  DECLARE @Separator    char(1),
          @WorkField    varchar(255),
          @LenValueList int
  
  -- Get the separator-character from the valuelist
  SET  @Separator = SUBSTRING(@ivalueList,1,1)
  
  -- Delete the separator that comes first in the string
  SET  @ivalueList = SUBSTRING(@ivalueList,2,LEN(@ivalueList))
  
  WHILE @ivalueList IS NOT NULL
  BEGIN  --while
    IF @ivalueList = ''       -- error! 
    BEGIN
        SET @ivalueList = NULL
    END
    ELSE
    BEGIN
      SELECT @LenValueList = CHARINDEX (@Separator,@ivalueList)
      
      IF @LenValueList <> 0   -- many values in the string
        SET  @WorkField = LEFT(@ivalueList,(@LenValueList-1))
      ELSE
      BEGIN   -- only one value in the string
        SET @WorkField = @ivalueList
        SET @ivalueList = NULL
      END
      
      SET @WorkField = LTRIM(RTRIM(@WorkField))
      
      -- Insert the value in the table that will be returned 
      INSERT INTO @ValueTable
      VALUES (@WorkField)    
      
      SET @ivalueList = STUFF(@ivalueList, 1, @LenValueList,'')
      
    END --else
  END  --while

RETURN

END

GO
SET QUOTED_IDENTIFIER OFF
GO
SET ANSI_NULLS OFF 
GO



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseClientSessionEvent') IS NOT NULL
	DROP FUNCTION verboseClientSessionEvent
GO

CREATE FUNCTION verboseClientSessionEvent
	(@logcsessionEvent				smallint
	,@logcsessionKerberosEnabled	smallint)
RETURNS VARCHAR(128)
AS
BEGIN

	DECLARE @ReturnValue varchar(128)

--enum ESessionEvent
--{
-- ESE_CREATE,
-- ESE_MESSAGE_NO_CONTACT,
-- ESE_LOGIN,
-- ESE_LOGOUT,
-- ESE_SIMPLE_LOGIN_SUCCESS,
-- ESE_SIMPLE_LOGIN_FAILED,
-- ESE_AUTH_WRONG_PASSWORD,
-- ESE_AUTH_USER_CANCEL,
-- ESE_AUTH_W2K_CANCEL,
-- ESE_AUTH_EXCEPTION
--};

--create = man startade sessionen
--Login = du blev autenticerad
--n�r du autenticerar dig blior det ESE_LOGIN alternativt n�gon ESE_AUTH

	SET @ReturnValue = 'Event ' + cast(@logcsessionEvent as varchar(10))


	IF @logcsessionEvent = 0
		SET @ReturnValue = 'Session started'
	IF @logcsessionEvent = 1
		SET @ReturnValue = 'No contact'
	IF @logcsessionEvent = 2
	BEGIN
		SET @ReturnValue = 'Logged in'
		IF @logcsessionKerberosEnabled = 1
			SET @ReturnValue = @ReturnValue + ' (Kerberos authentication)'
	END

	IF @logcsessionEvent = 3
		SET @ReturnValue = 'Logged out'
	IF @logcsessionEvent = 4
		SET @ReturnValue = 'Logged in (simple client)'
	IF @logcsessionEvent = 5
		SET @ReturnValue = 'Logged out (simple client)'
	IF @logcsessionEvent = 6
		SET @ReturnValue = 'Login failed (wrong password)'
	IF @logcsessionEvent = 7
		SET @ReturnValue = 'Login failed (user cancelled)'
	IF @logcsessionEvent = 8
		SET @ReturnValue = 'Login failed (Windows 2000 cancelled)'
	IF @logcsessionEvent = 9
		SET @ReturnValue = 'Login failed'



	return @ReturnValue
END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseClientSessionEventByLanguage') IS NOT NULL
	DROP FUNCTION verboseClientSessionEventByLanguage
GO

CREATE FUNCTION verboseClientSessionEventByLanguage
	(@logcsessionEvent				smallint
	,@logcsessionKerberosEnabled	smallint
	,@iLanguageId					char(2))
RETURNS VARCHAR(128)
AS
BEGIN

	DECLARE @ReturnValue varchar(128)

--enum ESessionEvent
--{
-- ESE_CREATE,
-- ESE_MESSAGE_NO_CONTACT,
-- ESE_LOGIN,
-- ESE_LOGOUT,
-- ESE_SIMPLE_LOGIN_SUCCESS,
-- ESE_SIMPLE_LOGIN_FAILED,
-- ESE_AUTH_WRONG_PASSWORD,
-- ESE_AUTH_USER_CANCEL,
-- ESE_AUTH_W2K_CANCEL,
-- ESE_AUTH_EXCEPTION
--};

--create = man startade sessionen
--Login = du blev autenticerad
--n�r du autenticerar dig blior det ESE_LOGIN alternativt n�gon ESE_AUTH

	IF @iLanguageId = 'en'
		RETURN dbo.verboseClientSessionEvent(@logcsessionEvent, @logcsessionKerberosEnabled)

	SET @ReturnValue = 'Event ' + cast(@logcsessionEvent as varchar(10))


	-- Below is in implicitly in Swedish --

	IF @logcsessionEvent = 0
		SET @ReturnValue = 'Session p�b�rjad'
	IF @logcsessionEvent = 1
		SET @ReturnValue = 'No ingen kontakt'
	IF @logcsessionEvent = 2
	BEGIN
		SET @ReturnValue = 'Inloggad'
		IF @logcsessionKerberosEnabled = 1
			SET @ReturnValue = @ReturnValue + ' (Kerberosautenticering)'
	END

	IF @logcsessionEvent = 3
		SET @ReturnValue = 'Utloggad'
	IF @logcsessionEvent = 4
		SET @ReturnValue = 'Inloggad (enkel klient)'
	IF @logcsessionEvent = 5
		SET @ReturnValue = 'Utloggad (enkel klient)'
	IF @logcsessionEvent = 6
		SET @ReturnValue = 'Inlogging misslyckades (felaktigt l�senord)'
	IF @logcsessionEvent = 7
		SET @ReturnValue = 'Inlogging misslyckades (anv�ndare avbr�t)'
	IF @logcsessionEvent = 8
		SET @ReturnValue = 'Inlogging misslyckades (Windows 2000 avbruten)'
	IF @logcsessionEvent = 9
		SET @ReturnValue = 'Inlogging misslyckades'

	IF @ReturnValue = ''
		RETURN dbo.verboseClientSessionEvent(@logcsessionEvent, @logcsessionKerberosEnabled)

	return @ReturnValue
END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseDocumentTypeByLanguage') IS NOT NULL
	DROP FUNCTION verboseDocumentTypeByLanguage
GO

CREATE FUNCTION verboseDocumentTypeByLanguage
	( @Filename			nvarchar(510)
	, @iLanguageId		char(2))
RETURNS NVARCHAR(128)
AS
BEGIN

	IF @iLanguageId = 'sv'
	BEGIN
		RETURN (case upper(right(@Filename,4)) 
					when '.DOC' then 'Worddokument' 
					when '.XLS' then 'Excelark'
					when '.PDF' then 'Acrobat'
					when '.PPT' then 'PowerPoint-presentation' 
					when '.TXT' then 'Textdokument'
					else 'Dokument' end)

	END
	ELSE
	BEGIN -- English
		RETURN (case upper(right(@Filename,4)) 
					when '.DOC' then 'Word document' 
					when '.XLS' then 'Excel sheet'
					when '.PDF' then 'Acrobat file'
					when '.PPT' then 'PowerPoint presentation' 
					when '.TXT' then 'Text document'
					else 'Document' end)

	END


		RETURN 'Document'

END

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseInstallMethod') IS NOT NULL
	DROP FUNCTION verboseInstallMethod
GO

CREATE FUNCTION verboseInstallMethod
	(@status smallint)
RETURNS VARCHAR(64)
AS
BEGIN

--enum InstallMethod {
--INSTALL_METHOD_RUNDLL_NTPRINTINF,
--INSTALL_METHOD_RUNDLL_USE_CURRENT_DRIVER,
--INSTALL_METHOD_RUNDLL_DRIVERPACKAGE,
--INSTALL_METHOD_INSTALL_NTPRINT,
--INSTALL_METHOD_INSTALL_DRIVERPACKAGE,
--INSTALL_METHOD_DRIVER_DOES_NOT_EXIST_FOR_OS,
--INSTALL_METHOD_UNAUTHORIZED,
--INSTALL_METHOD_INSTALL_USE_CURRENT_DRIVER,
--INSTALL_METHOD_RUNDLL_DRIVERPACKAGE_NOPNP,
--INSTALL_METHOD_INSTALL_DRIVERPACKAGE_NOPNP
--};


	if(@status=0)
		return '(RunDLL) NTPRINTINF'
	if(@status=1)
		return '(RunDLL) Use current driver'
	if(@status=2)
		return '(RunDLL) Driver package'
	if(@status=3)
		return 'NT Print'
	if(@status=4)
		return 'Driver package'
	if(@status=5)
		return 'Driver not available for operating system'
	if(@status=6)
		return 'Unauthorised'
	if(@status=7)
		return 'Use current driver'
	if(@status=8)
		return '(RunDLL) Driver package Non-PnP'
	if(@status=9)
		return '(Install) Driver package Non-PnP'


	return cast(@status as varchar(64))



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseInstallMethodByLanguage') IS NOT NULL
	DROP FUNCTION verboseInstallMethodByLanguage
GO

CREATE FUNCTION verboseInstallMethodByLanguage
	(@status smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN


	IF @iLanguageId = 'en'
		RETURN dbo.verboseInstallMethod(@status)

	-- below is Swedish

	if(@status=0)
		return '(RunDLL) NTPRINTINF'
	if(@status=1)
		return '(RunDLL) Anv�nd nuvarande drivrutin'
	if(@status=2)
		return '(RunDLL) Drivrutinspaket'
	if(@status=3)
		return 'NT Print'
	if(@status=4)
		return 'Drivrutinspaket'
	if(@status=5)
		return 'Drivrutin inte tillg�nglig f�r operativsystemet'
	if(@status=6)
		return 'Beh�righet nekad'
	if(@status=7)
		return 'Anv�nd nuvarande drivrutin'
	if(@status=8)
		return '(RunDLL) Drivrutinspaket Non-PnP'
	if(@status=9)
		return '(Install) Drivrutinspaket Non-PnP'


	RETURN dbo.verboseInstallMethod(@status)


END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseInstallResult') IS NOT NULL
	DROP FUNCTION verboseInstallResult
GO

CREATE FUNCTION verboseInstallResult
	(@status smallint)
RETURNS VARCHAR(64)
AS
BEGIN

--enum InstallResult {
--IR_INSTALL_OK,
--IR_INSTALL_FAILED,      //Install of queue failed 
--IR_INSTALL_CONFIG_FAILED,  // Installation successful - but config could not be installed
--IR_INSTALL_ALREADY_EXIST,
--IR_INSTALL_ALREADY_EXIST_DPT,
--IR_INSTALL_UPGRADE_DRIVER_SUCCESSFUL, //Upgrade of driver AND config was successful
--IR_INSTALL_UPGRADE_CONFIG_SUCCESSFUL,  //Upgrade of configuration was successful
--IR_INSTALL_UPGRADE_DRIVER_FAIL, //Upgrade of driver AND config was unsuccessful
--IR_INSTALL_UPGRADE_CONFIG_FAIL  //Upgrade of configuration was unsuccessful
--};



	if(@status=0)
		return 'Queue Installed'
	if(@status=1)
		return 'Install failed'
	if(@status=2)
		return 'Queue Installed, but configuration could not be installed'
	if(@status=3)
		return 'Queue is already installed'
	if(@status=4)
		return 'Queue is already installed DPT'
	if(@status=5)
		return 'Successfully updated driver and config'
	if(@status=6)
		return 'Successfully updated config'
	if(@status=7)
		return 'Failed to update driver and config'
	if(@status=8)
		return 'Failed to update config'


	return cast(@status as varchar(64))



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseInstallResultByLanguage') IS NOT NULL
	DROP FUNCTION verboseInstallResultByLanguage
GO

CREATE FUNCTION verboseInstallResultByLanguage
	(@status smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN


	IF @iLanguageId = 'en'
		RETURN dbo.verboseInstallResult(@status)

	if(@status=0)
		return 'K� installerad'
	if(@status=1)
		return 'Installation misslyckades'
	if(@status=2)
		return 'K� installerad, men konfiguration kunde inte installeras'
	if(@status=3)
		return 'K� redan installerad'
	if(@status=4)
		return 'K� redan installerad DPT'
	if(@status=5)
		return 'Drivrutiner och konfiguration uppdaterade'
	if(@status=6)
		return 'Konfiguration uppdaterad'
	if(@status=7)
		return 'Uppdatering av drivrutiner och konfiguration misslyckades' 
	if(@status=8)
		return 'Uppdatering av konfiguration misslyckades'


	RETURN dbo.verboseInstallResult(@status)



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseInstallSpecial') IS NOT NULL
	DROP FUNCTION verboseInstallSpecial
GO

CREATE FUNCTION verboseInstallSpecial
	(@status smallint)
RETURNS VARCHAR(64)
AS
BEGIN

-- enum saknas


	if(@status=-2)
		return 'Network transfer failed'
	if(@status=-1)
		return 'Could not find printer'
	if(@status=0)
		return ''



	return cast(@status as varchar(64))



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseInstallSpecialByLanguage') IS NOT NULL
	DROP FUNCTION verboseInstallSpecialByLanguage
GO

CREATE FUNCTION verboseInstallSpecialByLanguage
	(@status				smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN

-- enum saknas

	IF @iLanguageId = 'en'
		RETURN dbo.verboseInstallSpecial(@status)

-- nedan p� svenska

	if(@status=-2)
		return 'N�tverks�verf�ring misslyckades'
	if(@status=-1)
		return 'Kunde inte hitta skrivare'
	if(@status=0)
		return ''



	RETURN dbo.verboseInstallSpecial(@status)



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseOperatingSystem') IS NOT NULL
	DROP FUNCTION verboseOperatingSystem
GO

CREATE FUNCTION verboseOperatingSystem
	(@OS int -- Finns ej �nnu
	,@MajorVersion int
	,@MinorVersion int
	,@MajorSP smallint
	,@MinorSP smallint
	,@Architecture smallint)
RETURNS VARCHAR(128)
AS
BEGIN

	DECLARE @ReturnValue varchar(128)

--	SET @ReturnValue = CASE WHEN @OS=0 THEN 'Windows'
--						WHEN @OS=1 THEN 'Mac OS'
--						WHEN @OS=2 THEN 'Linux'
--						ELSE 'OS ' + cast(@OS as varchar(4)) END

	SET @ReturnValue = 'Windows'

	SET @ReturnValue = @ReturnValue + ' ' + cast(ISNULL(@MajorVersion,0) as varchar(4)) + '.' + cast(ISNULL(@MinorVersion,0) as varchar(4))

	IF @MajorSP > 0
	BEGIN
		SET @ReturnValue = @ReturnValue + ' SP' + cast(ISNULL(@MajorSP,0) as varchar(4)) 

		IF @MinorSP > 0
			SET @ReturnValue = @ReturnValue + '.' + cast(ISNULL(@MinorSP,0) as varchar(4))
	END

	IF @Architecture = 1	
		SET @ReturnValue = @ReturnValue + ' x86'
	IF @Architecture = 9	
		SET @ReturnValue = @ReturnValue + ' x64'


	return @ReturnValue



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePaperType') IS NOT NULL
	DROP FUNCTION verbosePaperType
GO

CREATE FUNCTION verbosePaperType
	(@paper int)
RETURNS VARCHAR(64)
AS
BEGIN

--public enum PageSizes
--{
--    LETTER       =        1,  /* Letter 8 1/2 x 11 in               */
--    LETTERSMALL  =        2,  /* Letter Small 8 1/2 x 11 in         */
--    TABLOID      =        3,  /* Tabloid 11 x 17 in                 */
--    LEDGER       =        4,  /* Ledger 17 x 11 in                  */
--    LEGAL        =        5,  /* Legal 8 1/2 x 14 in                */
--    STATEMENT    =        6,  /* Statement 5 1/2 x 8 1/2 in         */
--    EXECUTIVE    =        7,  /* Executive 7 1/4 x 10 1/2 in        */
--    A3           =        8,
--    A4           =        9,
--    A4SMALL      =       10,  /* A4 Small 210 x 297 mm              */
--    A5           =       11,  /* A5 148 x 210 mm                    */
--    B4           =       12,  /* B4 (JIS) 250 x 354                 */
--    B5           =       13,  /* B5 (JIS) 182 x 257 mm              */
--    FOLIO        =       14,  /* Folio 8 1/2 x 13 in                */
--    QUARTO       =       15,  /* Quarto 215 x 275 mm                */
--    NOTE         =       18,  /* Note 8 1/2 x 11 in                 */
--    ENV_9        =       19,  /* Envelope #9 3 7/8 x 8 7/8          */
--    ENV_10       =       20,  /* Envelope #10 4 1/8 x 9 1/2         */
--    ENV_11       =       21,  /* Envelope #11 4 1/2 x 10 3/8        */
--    ENV_12       =       22   /* Envelope #12 4 \276 x 11              */
--};


	if(@paper=1)
		return 'Letter'
	if(@paper=2)
		return 'Letter small'
	if(@paper=3)
		return 'Tabloid'
	if(@paper=4)
		return 'Ledger'
	if(@paper=5)
		return 'Legal'
	if(@paper=6)
		return 'Statement'
	if(@paper=7)
		return 'Executive'
	if(@paper=8)
		return 'A3'
	if(@paper=9)
		return 'A4'
	if(@paper=10)
		return 'A4 small'
	if(@paper=11)
		return 'A5'
	if(@paper=12)
		return 'B4'
	if(@paper=13)
		return 'B5'
	if(@paper=14)
		return 'Folio'
	if(@paper=15)
		return 'Quarto'
	if(@paper=16)
		return '16'
	if(@paper=17)
		return '17'
	if(@paper=18)
		return 'Note'
	if(@paper=19)
		return 'Envelope 9'
	if(@paper=20)
		return 'Envelope 10'
	if(@paper=21)
		return 'Envelope 11'
	if(@paper=22)
		return 'Envelope 12'




	return cast(@paper as varchar(64))



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePrinterAdmStatus') IS NOT NULL
	DROP FUNCTION verbosePrinterAdmStatus
GO

CREATE FUNCTION verbosePrinterAdmStatus
	(@iStatus smallint)
RETURNS VARCHAR(64)
AS
BEGIN
-- enum PrinterAdmStatus
-- Used by tbl_queue.queueStatus and tbl_printer.adminStatus


	if(@iStatus=0)
		return 'OK'
	if(@iStatus=1)
		return 'Paused'
	if(@iStatus=2)
		return 'Stopped'
	if(@iStatus=3)
		return 'Deleted'
	if(@iStatus=4)
		return 'Hidden'


	return cast(@iStatus as varchar(64))

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePrinterAdmStatusByLanguage') IS NOT NULL
	DROP FUNCTION verbosePrinterAdmStatusByLanguage
GO

CREATE FUNCTION verbosePrinterAdmStatusByLanguage
	(@iStatus				smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN
-- enum PrinterAdmStatus
-- Used by tbl_queue.queueStatus and tbl_printer.adminStatus


	IF @iLanguageId = 'en'
		RETURN dbo.verbosePrinterAdmStatus(@iStatus)


	if(@iStatus=0)
		return 'OK'
	if(@iStatus=1)
		return 'Pausad'
	if(@iStatus=2)
		return 'Stoppad'
	if(@iStatus=3)
		return 'Borttagen'
	if(@iStatus=4)
		return 'Dold'

	-- Return english by default
	RETURN dbo.verbosePrinterAdmStatus(@iStatus)

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePrinterAggregatedStatus') IS NOT NULL
	DROP FUNCTION verbosePrinterAggregatedStatus
GO

CREATE FUNCTION verbosePrinterAggregatedStatus
	(@iAdminStatus smallint
	,@iNewStatus smallint)
--	,@iSNMPActive char(1))
RETURNS VARCHAR(64)
AS


BEGIN

--	IF (@iSNMPActive = '0')
--		RETURN 'N/A'

	IF (@iAdminStatus = 0)
	BEGIN
		IF (@iNewStatus = 0) 
			RETURN ''
		ELSE
			RETURN dbo.verbosePrinterNewStatus(@iNewStatus)
	END
	ELSE
	BEGIN
		IF (@iNewStatus = 0) 
			RETURN dbo.verbosePrinterAdmStatus(@iAdminStatus)
		ELSE
			RETURN dbo.verbosePrinterAdmStatus(@iAdminStatus) + ' (' + dbo.verbosePrinterNewStatus(@iNewStatus) + ')'
	END

	return cast(@iAdminStatus as varchar(64)) + cast(@iNewStatus as varchar(64))

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePrinterAggregatedStatusByLanguage') IS NOT NULL
	DROP FUNCTION verbosePrinterAggregatedStatusByLanguage
GO

CREATE FUNCTION verbosePrinterAggregatedStatusByLanguage
	(@iAdminStatus			smallint
	,@iNewStatus			smallint
	,@iLanguageId			char(2))
--	,@iSNMPActive char(1))
RETURNS VARCHAR(64)
AS


BEGIN

--	IF (@iSNMPActive = '0')
--		RETURN 'N/A'

	IF @iLanguageId = 'en'
		RETURN dbo.verbosePrinterAggregatedStatus(@iAdminStatus, @iNewStatus)

	IF (@iAdminStatus = 0)
	BEGIN
		IF (@iNewStatus = 0) 
			RETURN ''
		ELSE
			RETURN dbo.verbosePrinterNewStatusByLanguage(@iNewStatus, @iLanguageId)
	END
	ELSE
	BEGIN
		IF (@iNewStatus = 0) 
			RETURN dbo.verbosePrinterAdmStatusByLanguage(@iAdminStatus, @iLanguageId)
		ELSE
			RETURN dbo.verbosePrinterAdmStatusByLanguage(@iAdminStatus, @iLanguageId) + ' (' + dbo.verbosePrinterNewStatusByLanguage(@iNewStatus, @iLanguageId) + ')'
	END

	RETURN dbo.verbosePrinterAggregatedStatus(@iAdminStatus, @iNewStatus)

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePrinterNewStatus') IS NOT NULL
	DROP FUNCTION verbosePrinterNewStatus
GO

CREATE FUNCTION verbosePrinterNewStatus
	(@iStatus smallint)
RETURNS VARCHAR(64)
AS
BEGIN


	if(@iStatus=1)
		return 'Stopping'
	if(@iStatus=2)
		return 'Starting'
	if(@iStatus=3)
		return 'Pausing'
	if(@iStatus=4)
		return 'Restarting'
	if(@iStatus=5)
		return 'Deleting Job'
	if(@iStatus=6)
		return 'Pausing Job'
	if(@iStatus=7)
		return 'Starting Job'
	if(@iStatus=8)
		return 'Sending Message'
	if(@iStatus=9)
		return 'Installing queue'
	if(@iStatus=10)
		return 'Removing Queue'

	return cast(@iStatus as varchar(64))

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePrinterNewStatusByLanguage') IS NOT NULL
	DROP FUNCTION verbosePrinterNewStatusByLanguage
GO

CREATE FUNCTION verbosePrinterNewStatusByLanguage
	(@iStatus				smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN

	IF @iLanguageId = 'en'
		RETURN dbo.verbosePrinterNewStatus(@iStatus)

	if(@iStatus=1)
		return 'Stoppas'
	if(@iStatus=2)
		return 'Startas'
	if(@iStatus=3)
		return 'Pausas'
	if(@iStatus=4)
		return 'Startar om'
	if(@iStatus=5)
		return 'Tar bort jobb'
	if(@iStatus=6)
		return 'Pausar jobb'
	if(@iStatus=7)
		return 'Startar jobb'
	if(@iStatus=8)
		return 'Skickar meddelande'
	if(@iStatus=9)
		return 'Installerar k�'
	if(@iStatus=10)
		return 'Avinstallerar k�'

	RETURN dbo.verbosePrinterNewStatus(@iStatus)

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePrinterPhysicalStatus') IS NOT NULL
	DROP FUNCTION verbosePrinterPhysicalStatus
GO

CREATE FUNCTION verbosePrinterPhysicalStatus
	(@iStatus smallint
	,@iSNMPActive char(1))
RETURNS VARCHAR(64)
AS

--------------------------------------------------------------
--Modified by:  Henrik Linder
--Modification date: 2009-03-25
--Description: Added support for SNMP turned off
--------------------------------------------------------------
--Modified by:  Henrik Linder
--Modification date: 2009-07-13
--Description: Ticket 164. Status 7 och 8 hade bytt plats.
--------------------------------------------------------------

BEGIN


	IF (@iSNMPActive = '0')
		RETURN 'N/A'


	if(@iStatus=0)
		return 'OK'
	if(@iStatus=1)
		return 'Low Paper'
	if(@iStatus=2)
		return 'Low Toner'
	if(@iStatus=3)
		return 'Service Needed'
	if(@iStatus=4)
		return 'No Paper'
	if(@iStatus=5)
		return 'No Toner'
	if(@iStatus=6)
		return 'Offline'
	if(@iStatus=7)
		return 'Door Open'
	if(@iStatus=8)
		return 'Paper Jam'
	if(@iStatus=9)
		return 'No Contact'

	return cast(@iStatus as varchar(64))

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verbosePrinterPhysicalStatusByLanguage') IS NOT NULL
	DROP FUNCTION verbosePrinterPhysicalStatusByLanguage
GO

CREATE FUNCTION verbosePrinterPhysicalStatusByLanguage
	(@iStatus				smallint
	,@iSNMPActive			char(1)
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS

--------------------------------------------------------------
--Modified by:  Henrik Linder
--Modification date: 2009-10-15
--Description: Multilangauage wrapper
--------------------------------------------------------------

BEGIN

	IF @iLanguageId = 'en'
		RETURN dbo.verbosePrinterPhysicalStatus(@iStatus, @iSNMPActive)

	IF (@iSNMPActive = '0')
		RETURN 'N/A'


	if(@iStatus=0)
		return 'OK'
	if(@iStatus=1)
		return 'L�g pappersniv�'
	if(@iStatus=2)
		return 'L�g tonerniv�'
	if(@iStatus=3)
		return 'Service efterfr�gas'
	if(@iStatus=4)
		return 'Slut p� papper'
	if(@iStatus=5)
		return 'Slut p� toner'
	if(@iStatus=6)
		return 'Offline'
	if(@iStatus=7)
		return 'D�rr �ppen'
	if(@iStatus=8)
		return 'Pappersmatningsfel'
	if(@iStatus=9)
		return 'Ingen kontakt'

	RETURN dbo.verbosePrinterPhysicalStatus(@iStatus, @iSNMPActive)

END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseRuleStatusByLanguage') IS NOT NULL
	DROP FUNCTION verboseRuleStatusByLanguage
GO

CREATE FUNCTION verboseRuleStatusByLanguage
	(@status			smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN
	-- Erik underh�ller underliggande engelskspr�kig version.



	IF @iLanguageId = 'en'
		RETURN dbo.verboseRuleStatus(@status)

	--	TI_PRINT_MISC,
		if(@status=0)
			RETURN ''
	--	TI_PRINT_OK,
		if(@status=1)
			RETURN 'Autenticering kr�vs'


	RETURN dbo.verboseRuleStatus(@status)


END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseTicketAdminStatusByLanguage') IS NOT NULL
	DROP FUNCTION verboseTicketAdminStatusByLanguage
GO

CREATE FUNCTION verboseTicketAdminStatusByLanguage
	(@ticketStatus			smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN
	-- Erik underh�ller underliggande engelskspr�kig version.



	IF @iLanguageId = 'en'
		RETURN dbo.verboseTicketAdminStatus(@ticketStatus)

--	TICKET_PAUSED = 7 ,

	if(@ticketStatus=7)
		return 'Pausad'

--	TICKET_LOCKED = 8 ,

	if(@ticketStatus=8)
		return 'L�st'

--	TICKET_DELETED = 9 ,

	if(@ticketStatus=9)
		return 'Borttagen'


	RETURN dbo.verboseTicketAdminStatus(@ticketStatus)


END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseTicketLogByLanguage') IS NOT NULL
	DROP FUNCTION verboseTicketLogByLanguage
GO

CREATE FUNCTION verboseTicketLogByLanguage
	( @major smallint, @minor smallint, @iLanguageId char(2))
RETURNS NVARCHAR(128)
AS
BEGIN

	IF @iLanguageId = 'en'
		RETURN dbo.verboseTicketLog(@major, @minor)


	-- BELOW IS IMPLICITY SWEDISH, MUST BE EXTENDED AND FIXED WHEN MORE LANGUAGES ARE ADDED --

--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	--TI_DELETED_AUTOMATICALLY,
	if(@minor=25)
		RETURN 'Automatically deleted'

	--TI_USER_CANCELLED_AUTHENTICATION_DELETE
	if(@minor=26)
		RETURN 'Deleted - User cancel authentication'


	--TI_AUTHENTICATION_ERROR
	if(@minor=27)
		RETURN 'Deleted - Authentication error on client'


	--TI_DELETED_AUTOMATICALLY_NO_CLIENT_SESSION
	if(@minor=28)
		RETURN 'Borttaget - Klientsession saknas'


	--TI_RULESET_DELETE,
	if(@minor=29)
		RETURN 'Deleted - By ruleset'

	--TI_RULESET_MOVE,
	if(@minor=30)
		RETURN 'Moved - by ruleset'

	--TI_RULESET_PAUSE
	if(@minor=31)
		RETURN 'Paused - by ruleset'

	-- TI_DELETED_CREATED,
	if(@minor=32)
		RETURN 'Deleted - created job'


	-- TI_DELETED_HANDOVER_OVERDUE,
	if(@minor=33)
		RETURN 'Deleted - handover overdue'

	-- TI_DELETED_AUTOMATICALLY_NO_CONTACT_WITH_CLIENT

	if(@minor=34)
		RETURN 'Deleted - no contact with client during authentication'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_CB_SET
	if(@minor=36)
		RETURN 'Client billing code set'

	-- TI_CB_CANCEL_PRESS_DELETE
	if(@minor=37)
		RETURN 'Deleted - Client billing cancel pressed'

	if(@minor=38)
		RETURN 'Deleted - Wrong client version'

	--TI_MANUALLY_MOVED,
	if(@minor=39)
		RETURN 'Moved - manually'

	--TI_AUTOMATICALLY_MOVED
	if(@minor=40)
		RETURN 'Moved - automatically'

--	TI_PAGES_RESET,
	if(@minor=41)
		RETURN 'Pages reset from 0 to 1 (Driver error)'

	-- TI_DELETED_QUEUE,
	if(@minor=42)
		RETURN 'Deleted - Queue deleted'

	-- TI_DELETED_QUEUE,
	if(@minor=43)
		RETURN 'Deleted - Queue Stopped'

	-- TI_DELETED_WRONG_DRIVER,
	if(@minor=44)
		RETURN 'Deleted - Wrong driver'

--	TI_DELETED_NO_QUEUE
	if(@minor=45)
		RETURN 'Deleted - No queue with UUID'

--
	if(@minor=46)
		RETURN 'Changed price plan'

--	TI_MULTIPLE_PRINT,
	if(@minor=47)
		RETURN 'Multiple print job'

--	TI_CPT_RELEASE_JOB
	if(@minor=48)
		RETURN 'CPT Release job'

--	TI_VDMS_RELEASE_JOB
	if(@minor=49)
		RETURN 'VDMS Release job'

-- TI_FPRINT_RELEASE_JOB
	if(@minor=50)
		RETURN 'Fprint Release job'


	RETURN dbo.verboseTicketLog(@major, @minor)



END

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseTicketNewStatus') IS NOT NULL
	DROP FUNCTION verboseTicketNewStatus
GO

CREATE FUNCTION verboseTicketNewStatus
	(@ticketStatus smallint)
RETURNS VARCHAR(64)
AS
BEGIN


--		ExternalTransaction:
--	ETR_STOP_PRINTER = 1,
--	ETR_START_PRINTER = 2 ,
--	ETR_PAUSE_PRINTER = 3,
--	ETR_RESTART_PRINTER = 4 ,
--	ETR_DELETE_JOB = 5,
--	ETR_PAUSE_JOB = 6,
--	ETR_START_JOB = 7,
--	ETR_SEND_MESSAGE = 8,
--	ETR_PUSH_QUEUE = 9,
--	ETR_REMOVE_QUEUE = 10,
--  ETR_MOVE_JOB = 11
--  changing owner = 12
--  ETR_PRINT_JOB = 13
--	ETR_CHANGE_BILLING_CODE = 14


	if(@ticketStatus=5)
		return 'Deleting'

	if(@ticketStatus=6)
		return 'Pausing'

	if(@ticketStatus=7)
		return 'Starting'


	if(@ticketStatus=11)
		return 'Moving'

	if(@ticketStatus=12)
		return 'Changing owner'

	if(@ticketStatus=13)
		return 'Printing'

	if(@ticketStatus=14)
		return 'Changing billing code'

	return cast(@ticketStatus as varchar(64))



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseTicketNewStatusByLanguage') IS NOT NULL
	DROP FUNCTION verboseTicketNewStatusByLanguage
GO

CREATE FUNCTION verboseTicketNewStatusByLanguage
	(@ticketStatus			smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN


--		Enum ExternalTransaction. Se engelskspr�kig funktion f�r detaljer.

	IF @iLanguageId = 'en'
		RETURN dbo.verboseTicketNewStatus(@ticketStatus)

	if(@ticketStatus=5)
		return 'Tas bort'

	if(@ticketStatus=6)
		return 'Pausas'

	if(@ticketStatus=7)
		return 'Startas'


	if(@ticketStatus=11)
		return 'Flyttas'

	if(@ticketStatus=12)
		return 'Byter �gare'

	if(@ticketStatus=13)
		return 'Skrivs ut'

	if(@ticketStatus=14)
		return '�ndrar kostnadsst�lle'

	RETURN dbo.verboseTicketNewStatus(@ticketStatus)



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseTicketStatusByLanguage') IS NOT NULL
	DROP FUNCTION verboseTicketStatusByLanguage
GO

CREATE FUNCTION verboseTicketStatusByLanguage
	(@ticketStatus			smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN
	-- Erik underh�ller underliggande engelskspr�kig version.



	IF @iLanguageId = 'en'
		RETURN dbo.verboseTicketStatus(@ticketStatus)

--	TICKET_NOOP =-1,

	if(@ticketStatus=-1)
		return 'Noop'

--	TICKET_CREATED = 0,

	if(@ticketStatus=0)
		return 'Skapad'

--	TICKET_SPOOLING = 1,

	if(@ticketStatus=1)
		return 'Spooling'

--	TICKET_READY = 2,

	if(@ticketStatus=2)
		return 'Klar'

--	TICKET_IN_NOTIFIER_QUEUE = 3,

	if(@ticketStatus=3)
		return 'V�ntar p� anslutning till klient'

--	TICKET_CONTACTING_CLIENT = 4,

	if(@ticketStatus=4)
		return 'Server kontaktar klient'

--	TICKET_CLIENT_CONTACTING_PRINTER = 5,

	if(@ticketStatus=5)
		return 'Klient kontaktar skrivare'

--	TICKET_PRINTING = 6,

	if(@ticketStatus=6)
		return 'Utskrift p�g�r'

--	TICKET_PAUSED = 7 ,

	if(@ticketStatus=7)
		return 'Pausad'

--	TICKET_LOCKED = 8 ,

	if(@ticketStatus=8)
		return 'L�st'

--	TICKET_DELETED = 9 ,

	if(@ticketStatus=9)
		return 'Borttagen'

--	TICKET_HANDOVER_PENDING = 10 , // Ticket must be handover to handover point

	if(@ticketStatus=10)
		return 'V�ntar p� �verl�mning'

--	TICKET_HANDOVER_IN_PROGRESS = 11, // Ticket is set to be handover

	if(@ticketStatus=11)
		return '�verl�mning p�g�r'

--	TICKET_HANDOVER_FAILED = 12, // Handover has failed - retry ?

	if(@ticketStatus=12)
		return '�verl�mning misslyckades'

--	TICKET_AUTH_PENDING = 13,// Ticket need an authentication before print

	if(@ticketStatus=13)
		return 'V�ntar p� autenticering'

--	TICKET_SIMPLE_CLIENT_PENDING = 14

	if(@ticketStatus=14)
		return 'Enkel klient �verf�r jobb'


	RETURN dbo.verboseTicketStatus(@ticketStatus)


END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseWalletLogEvent') IS NOT NULL
	DROP FUNCTION verboseWalletLogEvent
GO

CREATE FUNCTION verboseWalletLogEvent
	(@status smallint)
RETURNS VARCHAR(64)
AS
BEGIN



--enum EWalletEvent
--{
-- WE_CAPTURE_OK = 0,
-- WE_RETURN_BALANCE, 1
-- WE_NOT_ENOUGH_BALANCE, 2
-- WE_NO_SUCH_USER, 3
-- WE_ALREADY_EXIST, 4 
-- WE_UNKNOWN_ERROR 5
-- 10 = skapad, credit added eller reserved resettad
-- 11 = subctract credit
-- 99 = konto borttaget
--};

	if(@status=0)
		return 'Print job, cost:'
	if(@status=1)
		return 'Return balance' -- b�r f�rtydligas
	if(@status=2)
		return 'Not enough balance'
	if(@status=3)
		return 'No such user'
	if(@status=4)
		return 'Already exists' -- b�r f�rtydligas
	if(@status=5)
		return 'Unkown error'
	if(@status=10)
		return 'Credit added, new balance:'
	if(@status=11)
		return 'Credit subtracted, new balance:'

	if(@status=50)
		return 'Batch:'
	if(@status=51)
		return 'Initial balance:'
	if(@status=52)
		return 'Adjustment:'

	if(@status=98)
		return 'User created:'

	if(@status=99)
		return 'Balance deleted'


	return cast(@status as varchar(64))



END

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('verboseWalletLogEventByLanguage') IS NOT NULL
	DROP FUNCTION verboseWalletLogEventByLanguage
GO

CREATE FUNCTION verboseWalletLogEventByLanguage
	(@status				smallint
	,@iLanguageId			char(2))
RETURNS VARCHAR(64)
AS
BEGIN



--enum EWalletEvent
	IF @iLanguageId = 'en'
		RETURN dbo.verboseWalletLogEvent(@status)

	if(@status=0)
		return 'Utskrift, pris:'
	if(@status=1)
		return 'Return balance' -- b�r f�rtydligas
	if(@status=2)
		return 'Otillr�ckligt saldo'
	if(@status=3)
		return 'Anv�ndare saknas'
	if(@status=4)
		return 'Finns redan' -- b�r f�rtydligas
	if(@status=5)
		return 'Ok�nt fel'
	if(@status=10)
		return 'Saldo �kat, nytt saldo:'
	if(@status=11)
		return 'Saldo minskat, nytt saldo:'

	if(@status=50)
		return 'Batch:'
	if(@status=51)
		return 'Startsaldo:'
	if(@status=52)
		return 'Justering:'

	if(@status=98)
		return 'Anv�ndare skapad:'



	if(@status=99)
		return 'Saldo borttaget'

	RETURN dbo.verboseWalletLogEvent(@status)


END

GO
IF OBJECT_ID('vw_queue') IS NOT NULL
	DROP VIEW vw_queue
GO

CREATE VIEW
	vw_queue
AS

SELECT
	q.queueId						QueueId
	,q.queueName					QueueName
	,q.queueModelId					ModelId
	,q.queueLocation				Location
	,q.queueComment					Comment
	,q.queueRegion					RegionId
	,q.queueType					QueueType
	,q.queueStatus					QueueStatus
	,q.queueTTL						TTL
	,q.queueAdminComment			AdminComment
	,q.queueNewStatus				NewStatus
	,q.offlineReason				OfflineReason
	,q.pagesPerMinuteBWSingle		PagesPerMinuteBWSingle
	,q.pagesPerMinuteColorSingle	PagesPerMinuteColorSingle
	,q.pagesPerMinuteBWDuplex		PagesPerMinuteBWDuplex
	,q.pagesPerMinuteColorDuplex	PagesPerMinuteColorDuplex
	,q.queueHidden					Hidden
	,map.mapPhyPrinter				PrinterId
FROM tbl_queue q
LEFT OUTER JOIN tbl_queue_printer_map map
	ON map.mapQueue = q.queueId
	AND map.mapStatus = 0

GO


IF OBJECT_ID('view_log') IS NOT NULL
	DROP VIEW view_log
GO

CREATE view view_log AS
select logDateCreated, logdateBegan, logDateFinished, 
logJobName, logUserName, logUserdomain, logJobsize, logPages, logPaper, logDuplex, logColor, 
queueId, queueName, queueLocation,
modelName,
printerName,
printerId, regionId, regionName, regionActive, typeId, typeName, typeImageURL
,CASE WHEN logEventMinor IN (1, 6)	THEN 1 -- print job (0 = alla jobbtyper, i webben)
	  WHEN logEventMinor = 10		THEN 2 -- copy job
END as jobTypeAggregate
,ISNULL(logclientBillingCode,'<i>None</i>') ClientBillingCode
from tbl_ticket_log, tbl_queue , tbl_printer , tbl_model, tbl_region, tbl_documenttype
where logEventMinor IN (1, 6, 10) 
and logQueueId=queueId 
and logPrinterId=printerId
and queueModelId=tbl_model.modelId
and tbl_printer.region=tbl_region.regionId
and tbl_ticket_log.logDocumentTypeId=tbl_documenttype.typeId;

GO
IF OBJECT_ID('vw_cirrato_priceplan_row') IS NOT NULL
	DROP VIEW vw_cirrato_priceplan_row
GO

CREATE VIEW
vw_cirrato_priceplan_row
AS


SELECT 
	cprId
	,cprPlanid		PricePlanId
	,cprRowName		RowName
	,cprType
	,cprValue
	,cprCost
	,cprTypeSubtype
FROM tbl_cirrato_priceplan_row


GO
IF OBJECT_ID('vw_client_billing') IS NOT NULL
	DROP VIEW vw_client_billing
GO

CREATE VIEW vw_client_billing
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-17
Description: Wrapper for client billing table, used in Reports.
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 
Description: 
************************************************************/
AS

	SELECT
		cb_id				BillingCodeId
		,cb_parentId		ParentId
		,cb_active			Active
		,cb_type			[Type]
		,cb_code			BillingCode
		,cb_name			BillingCodeName
		,cb_comment			BillingCodeComment
		,cb_creator_name	CreatorName
		,cb_creator_domain	CreatorDomain
		,cb_creation_date	CreationDate
		,cb_active_date		StartDate
		,cb_deactive_date	EndDate
		,CASE WHEN cb_type IN (1,11) THEN 'BillingCode' ELSE 'Region' END AS TypeVerbose
		,CASE WHEN cb_type IN (0,10) THEN cb_name ELSE cb_name + ' (' + cb_code +')' END AS BillingCodeNameVerbose
	FROM tbl_client_billing cb
	UNION
		SELECT
		-1						--cb_id
		,1						--cb_parentId
		,1						--cb_active
		,1						--cb_type
		,''						--cb_code
		,'No billing code'		--cb_name
		,''						--cb_comment
		,'SYSTEM'				--cb_creator_name
		,'DIPRITEC'				--cb_creator_domain
		,NULL					--cb_creation_date
		,NULL					--cb_active_date
		,NULL					--cb_deactive_date
		,'BillingCode'
		,'No billing code'

GO
IF OBJECT_ID('vw_group_user_full') IS NOT NULL
	DROP VIEW vw_group_user_full
GO

CREATE VIEW	vw_group_user_full
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-30
Description:  See all users in a group. To be updated when group structure becomes hierarchical.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS


SELECT DISTINCT
	g.GroupId
	,g.GroupName
	,g.UmbrellaId
	,u.UserId
	,u.UserName
	,u.Domain
FROM tbl_report_group g
INNER JOIN tbl_cirrato_wallet_user_group ug
	ON g.GroupId = ug.GroupId
INNER JOIN tbl_report_users u
	ON u.UserId = ug.UserId

GO
IF OBJECT_ID('vw_org_group') IS NOT NULL
	DROP VIEW vw_org_group
GO

CREATE VIEW	vw_org_group
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-09
Description:  Make GUID a unique ExternalId for umbrella sync across multiple ConfigIDs
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

	SELECT 
		ConfigID
		,CAST(ConfigId AS varchar(20)) + '_' + GUID GUID
		,DN
		,Name
		,Updated
	FROM tbl_org_group

GO
IF OBJECT_ID('vw_org_unit') IS NOT NULL
	DROP VIEW vw_org_unit
GO

CREATE VIEW	vw_org_unit
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-09
Description:  Make GUID a unique ExternalId for umbrella sync across multiple ConfigIDs
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

	SELECT 
		ConfigID
		,CAST(ConfigId AS varchar(20)) + '_' + GUID GUID
		,DN
		,Name
		,Updated
	FROM tbl_org_unit

GO
IF OBJECT_ID('vw_printer') IS NOT NULL
	DROP VIEW vw_printer
GO

CREATE VIEW
	vw_printer
AS

SELECT
	printerId					PrinterId
	,printerName				PrinterName
	,printerLocation			Location
	,printerComment				Comment
	,printerModel				ModelId
	,printerIp					PrinterIP
	,printerPort				Port
	,printerNetPort				NetPort
	,modelId					ModelId2
	,region						RegionId
	,physStatus					PhysicalStatus
	,printStatus				PrintStatus
	,deviceStatus				DeviceStatus
	,adminStatus				AdminStatus
	,printerAdminComment		AdminComment
	,localDriverCheck			LocalDriverCheck
	,localConfigCheck			LocalConfigCheck
	,printerTTL					TTL
	,printerType				PrinterType
	,printerNewStatus			NewStatus
	,snmpCheck					SNMPCheck
	,printerCommunity			Community
	,printerSnmpIndex			SnmpIndex
	,printerLastCheck			LastCheck
	,printerNextCheck			NextCheck
	,printerDisplayText			DisplayText
	,printerMailMessage			MailMessage
	,printerSnmpVersion			SNMPVersion
	,printerProgramId			ProgramId
	,printerChecking			Checking
	,printerCheckInterval		CheckInterval
	,printerStatLastCheck		StatLastCheck
	,printerStatNextCheck		StatNextCheck
	,printerCounterProgramId	CounterProgramId
	,printerNumIp				NumIP
	,offlineReason				OfflineReason
	,printerHidden				Hidden
FROM tbl_printer p


GO
IF OBJECT_ID('vw_printer_full') IS NOT NULL
	DROP VIEW vw_printer_full
GO

CREATE VIEW
	vw_printer_full
AS

SELECT
	printerId					PrinterId
	,printerName				PrinterName
	,printerLocation			Location
	,printerComment				Comment
	,printerModel				ModelId
	,printerIp					PrinterIP
	,printerPort				Port
	,printerNetPort				NetPort
	,p.modelId					ModelId2
	,region						RegionId
	,physStatus					PhysicalStatus
	,printStatus				PrintStatus
	,deviceStatus				DeviceStatus
	,adminStatus				AdminStatus
	,printerAdminComment		AdminComment
	,localDriverCheck			LocalDriverCheck
	,localConfigCheck			LocalConfigCheck
	,printerTTL					TTL
	,printerType				PrinterType
	,printerNewStatus			NewStatus
	,snmpCheck					SNMPCheck
	,printerCommunity			Community
	,printerSnmpIndex			SnmpIndex
	,printerLastCheck			LastCheck
	,printerNextCheck			NextCheck
	,printerDisplayText			DisplayText
	,printerMailMessage			MailMessage
	,printerSnmpVersion			SNMPVersion
	,printerProgramId			ProgramId
	,printerChecking			Checking
	,printerCheckInterval		CheckInterval
	,printerStatLastCheck		StatLastCheck
	,printerStatNextCheck		StatNextCheck
	,printerCounterProgramId	CounterProgramId
	,printerNumIp				NumIP
	,offlineReason				OfflineReason
	,printerHidden				Hidden
	,p.printerMapPosX			PrinterMapPosX
	,p.printerMapPosY			PrinterMapPosY

	,m.modelName				ModelName
	,m.modelComment				ModelComment
	,b.brandName				BrandName
	,b.brandComment				BrandComment
FROM tbl_printer p
LEFT JOIN tbl_model m
	ON p.printerModel = m.modelId
LEFT JOIN tbl_brand b
	ON m.modelBrandId = b.brandId


GO
IF OBJECT_ID('vw_printer_model_compatible') IS NOT NULL
	DROP VIEW vw_printer_model_compatible
GO

CREATE VIEW	vw_printer_model_compatible
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-11-12
Description:  List all printers and all models they are compatible with
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

	SELECT 
		PrinterId
		,ModelId
	FROM vw_queue
	WHERE QueueType = 1 AND QueueStatus = 0
	GROUP BY PrinterId, ModelId
GO
IF OBJECT_ID('vw_queue') IS NOT NULL
	DROP VIEW vw_queue
GO

CREATE VIEW
	vw_queue
AS

SELECT
	q.queueId						QueueId
	,q.queueName					QueueName
	,q.queueModelId					ModelId
	,q.queueLocation				Location
	,q.queueComment					Comment
	,q.queueRegion					RegionId
	,q.queueType					QueueType
	,q.queueStatus					QueueStatus
	,q.queueTTL						TTL
	,q.queueAdminComment			AdminComment
	,q.queueNewStatus				NewStatus
	,q.offlineReason				OfflineReason
	,q.pagesPerMinuteBWSingle		PagesPerMinuteBWSingle
	,q.pagesPerMinuteColorSingle	PagesPerMinuteColorSingle
	,q.pagesPerMinuteBWDuplex		PagesPerMinuteBWDuplex
	,q.pagesPerMinuteColorDuplex	PagesPerMinuteColorDuplex
	,q.queueHidden					Hidden
	,map.mapPhyPrinter				PrinterId
FROM tbl_queue q
LEFT OUTER JOIN tbl_queue_printer_map map
	ON map.mapQueue = q.queueId
	AND map.mapStatus = 0

GO
IF OBJECT_ID('vw_region') IS NOT NULL
	DROP VIEW vw_region
GO

CREATE VIEW	vw_region
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-07
Description:  Region table with aggregated SortOrder field.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

SELECT
	regionId
	,regionParentId
	,regionName
	,regionActive
	,ISNULL(regionSortOrder,100)*1000 + 
		ROW_NUMBER() OVER (PARTITION BY  regionParentId, regionSortOrder ORDER BY regionName) AS regionSortOrder
	,regionMapFile
	,regionParentMapShape
	,regionParentMapCoords

FROM tbl_region 

GO
IF OBJECT_ID('vw_report_group') IS NOT NULL
	DROP VIEW vw_report_group
GO

CREATE VIEW	vw_report_group
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-11-24
Description:  View only non-deleted rows
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

	SELECT 
		*
	FROM tbl_report_group
	WHERE IsDeleted = 0

GO
IF OBJECT_ID('vw_report_group_display') IS NOT NULL
	DROP VIEW vw_report_group_display
GO

CREATE VIEW	vw_report_group_display
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-11-24
Description:  Recursive view of groups - suitable for displaying in a listbox or similar. Parses all nodes of a graph to a tree.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

	WITH gRecursive 
		(GroupId
		,GroupParentId 
		,UmbrellaId
		,RootUmbrellaId
		,GroupName
		,GroupFullPath
		,GroupParentPath)
	AS (
		SELECT 
			g.GroupId
			,NULL					-- GroupParentId 
			,g.UmbrellaId				--UmbrellaId
			,g.UmbrellaId				--RootUmbrellaId
			,g.GroupName				-- GroupName
			,CAST('/' + g.GroupName	AS nvarchar(4000))	-- GroupFullPath
			,CAST('/'		AS nvarchar(4000))				--GroupParentPath
		FROM vw_report_group g
			WHERE GroupId NOT IN (SELECT GroupChildId FROM tbl_report_group_group)

		UNION ALL

		SELECT
			g.GroupId
			,gg.GroupParentId
			,g.UmbrellaId
			,gr.RootUmbrellaId
			,g.GroupName
			,CAST(gr.GroupFullPath + '/' + g.GroupName	AS nvarchar(4000))
			,CAST(gr.GroupFullPath 	AS nvarchar(4000))
		FROM tbl_report_group_group gg
		INNER JOIN gRecursive gr
			ON gg.GroupParentId = gr.GroupId
		INNER JOIN vw_report_group g
			ON g.GroupId = gg.GroupChildId
	)
	SELECT * FROM gRecursive

GO
IF OBJECT_ID('vw_report_group_display_unique') IS NOT NULL
	DROP VIEW vw_report_group_display_unique
GO

CREATE VIEW	vw_report_group_display_unique
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-08
Description:  Like vw_report_group_display, but every group is guaranteed to only appear once. The "first" path is chosen.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

	SELECT
		GroupId
		,MIN(GroupParentId)		GroupParentId
		,MIN(UmbrellaId)		UmbrellaId
		,MIN(RootUmbrellaId)	RootUmbrellaId
		,MIN(GroupName)			GroupName
		,MIN(GroupFullPath)		GroupFullPath
		,MIN(GroupParentPath)	GroupParentPath
	FROM vw_report_group_display
	GROUP BY GroupId


GO
IF OBJECT_ID('vw_report_group_umbrella') IS NOT NULL
	DROP VIEW vw_report_group_umbrella
GO

CREATE VIEW	vw_report_group_umbrella
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-11-24
Description:  View only non-deleted rows
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

	SELECT 
		*
	FROM tbl_report_group_umbrella
	WHERE IsDeleted = 0

GO
IF OBJECT_ID('vw_report_jobs_detail') IS NOT NULL
	DROP VIEW vw_report_jobs_detail
GO

CREATE VIEW vw_report_jobs_detail
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Detail view of historic jobs
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-05-26
Description: Added Printer information
************************************************************/
AS

	SELECT
		t.TicketId
		,t.JobDate
		,t.JobName
		,u.UserName
		,u.Domain
		,t.QueueId
		,t.FollowPrintQueueId
		,t.IsLocalPrinter
		,t.JobType
		,t.IsFollowPrint
		,t.PaperType
		,t.Duplex
		,t.Size
		,PagesBW
		,PagesColor
		,PagesBW + PagesColor AS PagesTotal
		,q.QueueName
		,p.PrinterName
		,p.PrinterId
		,t.TicketPrice
		,t.BillingCodeId
	FROM tbl_report_jobs_detail t
	INNER JOIN tbl_report_users u
		ON t.UserId = u.UserId
	INNER JOIN tbl_report_queue_cache q
		ON q.QueueId = t.QueueId
	INNER JOIN tbl_report_printer_cache p
		ON p.PrinterId = q.PrinterId

GO

IF OBJECT_ID('vw_report_jobs_detail_n') IS NOT NULL
	DROP VIEW vw_report_jobs_detail_n
GO

CREATE VIEW	vw_report_jobs_detail_n
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-22
Description:	Normalised view of this table: One column "Pages" and booleans/numerics for all attributes. 
				The same job may appear more than once, so this view should not be used for job-listing reports.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS


	SELECT
		TicketId
		,JobDate
		,JobName
		,UserId
		,QueueId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,PaperType
		,0							AS Color
		,Duplex
		,Size
		,PagesBW					AS Pages
-- need to cast as float etc before using. And even then it's not accurate, so skipping it:
--		,TicketPrice * (PagesBW / (ISNULL(PagesBW,0) + ISNULL(PagesColor,0)))		TicketPrice
		,BillingCodeId
	FROM tbl_report_jobs_detail bw
	WHERE PagesBW > 0

	UNION
	 
	SELECT
		TicketId
		,JobDate
		,JobName
		,UserId
		,QueueId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,PaperType
		,1							AS Color
		,Duplex
		,Size
		,PagesColor					AS Pages
--		,TicketPrice * (PagesColor / (ISNULL(PagesBW,0) + ISNULL(PagesColor,0)))		TicketPrice
		,BillingCodeId
	FROM tbl_report_jobs_detail c
	WHERE PagesColor > 0



GO
IF OBJECT_ID('vw_report_jobs_queue_color') IS NOT NULL
	DROP VIEW vw_report_jobs_queue_color
GO

CREATE VIEW vw_report_jobs_queue_color
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-08
Description: Get number of color and bw pages by queue, per day
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
AS

WITH bw (JobDay, QueueId, PageCountBW) AS 
	(select JobDay, QueueId, SUM(Pages) PageCount
	 from  tbl_report_jobs_queue
	WHERE Color = 0
	GROUP BY  JobDay, QueueId)
,c (JobDay, QueueId, PageCountColor) AS 
	(select JobDay, QueueId, SUM(Pages) PageCount
	 from  tbl_report_jobs_queue
	WHERE Color = 1
	GROUP BY  JobDay, QueueId)

SELECT 
	ISNULL(bw.JobDay, c.JobDay)		AS JobDay
	,ISNULL(bw.QueueId, c.QueueId)	AS QueueId
	,ISNULL(PageCountBW,0)			AS PageCountBW
	,ISNULL(PageCountColor,0)		AS PageCountColor
FROM bw
FULL OUTER JOIN c
ON bw.QueueId = c.QueueId
	AND bw.JobDay = c.JobDay


GO
IF OBJECT_ID('vw_report_jobs_queue_duplex') IS NOT NULL
	DROP VIEW vw_report_jobs_queue_duplex
GO

CREATE VIEW vw_report_jobs_queue_duplex
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-18
Description: Get number of duplex/simplex pages by queue, per day
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
AS

WITH s (JobDay, QueueId, PageCountSimplex) AS 
	(select JobDay, QueueId, SUM(Pages) PageCount
	 from  tbl_report_jobs_queue
	WHERE Duplex = 0
	GROUP BY  JobDay, QueueId)
,d (JobDay, QueueId, PageCountDuplex) AS 
	(select JobDay, QueueId, SUM(Pages) PageCount
	 from  tbl_report_jobs_queue
	WHERE Duplex = 1
	GROUP BY  JobDay, QueueId)

SELECT 
	ISNULL(s.JobDay, d.JobDay)		AS JobDay
	,ISNULL(s.QueueId, d.QueueId)	AS QueueId
	,ISNULL(PageCountSimplex,0)		AS PageCountSimplex
	,ISNULL(PageCountDuplex,0)		AS PageCountDuplex
FROM s
FULL OUTER JOIN d
ON s.QueueId = d.QueueId
	AND s.JobDay = d.JobDay


GO
IF OBJECT_ID('vw_report_matrix_snmp') IS NOT NULL
	DROP VIEW vw_report_matrix_snmp
GO

CREATE VIEW vw_report_matrix_snmp
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-02
Description: Printer SNMP log for dynamic matrix report. Group by day, printer, event type, (event count, total duration)
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
AS

	WITH a (StatusDay, PrinterId, PhysicalStatus, StatusDuration) AS (
		SELECT
			CAST(convert(char(8), l.statlogFirstDetected, 112) AS datetime)		AS StatusDay
			,CAST(l.statlogPrinterId AS uniqueidentifier)						AS PrinterId
			,l.statlogPhysStatus												AS PhysicalStatus
			,datediff(s, l.statlogFirstDetected, l.statlogClosed)				AS StatusDuration
		FROM tbl_event_status_log l
	)
	SELECT 
		a.StatusDay
		,a.PrinterId
		,a.PhysicalStatus
		,SUM(a.StatusDuration) AS TotalStatusDuration
		,COUNT(1)			  AS StatusCount
	FROM a
	GROUP BY 
		a.StatusDay
		,a.PrinterId
		,a.PhysicalStatus


GO
IF OBJECT_ID('vw_report_matrix_snmp_brandmodel') IS NOT NULL
	DROP VIEW vw_report_matrix_snmp_brandmodel
GO

CREATE VIEW vw_report_matrix_snmp_brandmodel
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-03
Description: Group by MONTH, brand, model, count, duration, type
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
AS

--	WITH a (StatusDay, PrinterId, PhysicalStatus, StatusDuration) AS (



	SELECT
		convert(char(8), l.statlogFirstDetected, 112)		AS YearMonthNum
		,b.BrandName
		,b.PrinterCount BrandPrinterCount
		,m.ModelName
		,b.PrinterCount ModelPrinterCount
		,COUNT(*) AS EventCount

--		,CAST(l.statlogPrinterId AS uniqueidentifier)						AS PrinterId
--		,l.statlogPhysStatus												AS PhysicalStatus
		,SUM(datediff(s, l.statlogFirstDetected, l.statlogClosed))				AS StatusDuration
		,sv.StatusVerbose AS PhysicalStatusVerbose
	FROM tbl_event_status_log l
	INNER JOIN tbl_report_printer_cache p
		ON CAST(l.statlogPrinterId AS uniqueidentifier) = p.PrinterId
	INNER JOIN tbl_report_model_cache m
		ON p.ModelId = m.ModelId
	INNER JOIN tbl_report_brand_cache b
		ON m.BrandId = b.BrandId
	INNER JOIN tbl_report_status_cache sv
		ON sv.StatusMajor = l.statlogPhysStatus
		AND StatusTypeId = 1
	GROUP BY 
		convert(char(8), l.statlogFirstDetected, 112)
		,b.BrandName
		,m.ModelName
		,sv.StatusVerbose
		,b.PrinterCount

--	)
--	SELECT 
--		a.StatusDay
--		,a.PrinterId
--		,a.PhysicalStatus
--		,SUM(a.StatusDuration) AS TotalStatusDuration
--		,COUNT(1)			  AS StatusCount
--	FROM a
--	GROUP BY 
--		a.StatusDay
--		,a.PrinterId
--		,a.PhysicalStatus
--

GO
IF OBJECT_ID('vw_report_matrix_usage') IS NOT NULL
	DROP VIEW vw_report_matrix_usage
GO

CREATE VIEW vw_report_matrix_usage
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-29
Description: Raw data for custom matrix report / usage.
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
AS

	WITH r (JobDay, QueueId, LocalPrinter, Color, Duplex, JobTypeFunction, Pages, JobCount, TicketPrice) AS (
		SELECT
			t.JobDay
			,t.QueueId
			,t.IsLocalPrinter
			,t.Color
			,t.Duplex
			,t.JobType						-- (1=print, 2=copy, 3=fax, 4=scan)
			-- For detail scope:
			,SUM(t.Pages)					AS Pages
			,SUM(t.JobCount)				AS JobCount
			,SUM(ISNULL(t.TicketPrice,0))	AS TicketPrice
		FROM tbl_report_jobs_queue t
		GROUP BY
			t.JobDay
			,t.QueueId
			,t.IsLocalPrinter
			,t.Color
			,t.Duplex
			,t.JobType
--		ORDER BY 1,2,3,4,5,6
	)
	SELECT
		-- Groupings (row/col scope):
		r.JobDay
		,r.QueueId
		,q.QueueName
		,p.PrinterId
		,p.PrinterName
		,m.ModelId
		,m.ModelName
		,b.BrandId
		,b.BrandName
		,CASE WHEN r.Color = 1 THEN 'Colour' ELSE 'B/W' END AS JobTypeC
		,CASE WHEN r.Duplex = 1 THEN 'Duplex' ELSE 'Simplex' END AS JobTypeD
		,CASE WHEN r.Color = 1 THEN 
				CASE WHEN r.Duplex = 1 THEN 'Colour Duplex' ELSE 'Colour Simplex' END
			ELSE 
				CASE WHEN r.Duplex = 1 THEN 'B/W Duplex' ELSE 'B/W Simplex' END
			END AS JobTypeCD
		,CASE WHEN r.LocalPrinter = 1 THEN 'Local' ELSE 'Network' END AS PrinterType
		,CASE WHEN r.JobTypeFunction = 1 THEN 'Print'
				WHEN r.JobTypeFunction = 2 THEN 'Copy'
				WHEN r.JobTypeFunction = 3 THEN 'Fax'
				WHEN r.JobTypeFunction = 4 THEN 'Scan'
			END AS JobTypeFunctionVerbose

		-- Used for report filter (depends on choice of detail view):
		,r.Color
		,r.Duplex

		-- Used for detail functions:
		,r.Pages
		,r.JobCount
		,r.TicketPrice

		-- For future use (for example, we may want to give user option to choose only network printers, only local, or both
		,r.LocalPrinter
		,r.JobTypeFunction
	FROM r
	INNER JOIN tbl_report_queue_cache q
		ON r.QueueId = q.QueueId
	INNER JOIN tbl_report_printer_cache p
		ON q.PrinterId = p.PrinterId
	INNER JOIN tbl_report_model_cache m
		ON p.ModelId = m.ModelId
	INNER JOIN tbl_report_brand_cache b
		ON m.BrandId = b.BrandId

--
--select * from tbl_report_jobs_queue
--select * from vw_report_matrix_usage


GO

IF OBJECT_ID('vw_report_snmp') IS NOT NULL
	DROP VIEW vw_report_snmp
GO

CREATE VIEW vw_report_snmp
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-19
Description: Printer SNMP log
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
AS

	SELECT
		p.PrinterId
		,p.PrinterName
		,l.statlogPhysStatus												AS PhysicalStatus
		,s.StatusVerbose													AS PhysicalStatusVerbose
		,CAST(convert(char(8), l.statlogFirstDetected, 112) AS datetime)	AS StatusDay
		,l.statlogFirstDetected												AS StatusStart
		,l.statlogClosed													AS StatusEnd
		,datediff(s, l.statlogFirstDetected, l.statlogClosed)				AS StatusDuration
		,m.ModelId
		,m.ModelName
		,b.BrandId
		,b.BrandName
		,p.ParentRegionId
	FROM tbl_event_status_log l
	INNER JOIN tbl_report_printer_cache p
		ON CAST(l.statlogPrinterId AS uniqueidentifier) = p.PrinterId
	INNER JOIN tbl_report_status_cache s
		ON l.statlogPhysStatus = s.StatusMajor AND s.StatusTypeId = 1
	INNER JOIN tbl_report_region_cache r
		ON r.RegionId = p.ParentRegionId
	INNER JOIN tbl_report_model_cache m
		ON p.ModelId = m.ModelId
	INNER JOIN tbl_report_brand_cache b
		ON m.BrandId = b.BrandId


GO
IF OBJECT_ID('vw_scheduled_job_run_log') IS NOT NULL
	DROP VIEW vw_scheduled_job_run_log
GO

CREATE VIEW	vw_scheduled_job_run_log
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-04
Description:  Easy view of run log
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS

	SELECT 
		l.RunId
		,j.JobName
		,l.RunStartDate
		,l.RunEndDate
		,l.ReturnStatus
		,l.ReturnStatusMessage
	FROM tbl_scheduled_job_run_log l
	INNER JOIN tbl_scheduled_job j
		ON l.JobId = j.JobId

GO

IF OBJECT_ID('vw_ticket_log_report_calc') IS NOT NULL
	DROP VIEW vw_ticket_log_report_calc
GO

CREATE VIEW vw_ticket_log_report_calc
-- Some jobs dont have a queue id. use printer id in these cases

AS

	SELECT 
		logticketId
		,CASE WHEN LEN(logqueueId) = 0 THEN logprinterId ELSE logqueueId END AS logqueueId
		,logprinterId
		,logjobName
		,loguserName
		,loguserDomain
		,logjobSize
		,logpages
		,logpaper
		,logduplex
		,logcolor
		,logdateEvent
		,logdateCreated
		,logdateSort
		,logdateBegan
		,logdateFinished
		,logsentBytes
		,logsentPages
		,logclientId
		,logclientIp
		,logEventMajor
		,logEventMinor
		,logData
		,logText
		,logfprintQ
		,logticketDriver
		,logticketModel
		,logLoggedColorPages
		,logLoggedBWPages
		,logpricePlan
		,logTicketPrice
		,logoriginatingIp
		,logDocumentTypeId
		,logclientBillingCode
	FROM tbl_ticket_log t


GO

IF OBJECT_ID('vw_ticket_log') IS NOT NULL
	DROP VIEW vw_ticket_log
GO

CREATE VIEW vw_ticket_log
-- get all data from ticket log table, to be joined with queue info etc

AS

	WITH a (RowNo, TicketId, DateEvent, QueueId, JobName, UserName, EventMinor, [Time], Pages, JobSize, Color, Duplex, FPQueueId, ClientBillingCode, PricePlan, TicketPrice) AS (
	SELECT 
		ROW_NUMBER() OVER(PARTITION BY logticketId ORDER BY logdateEvent DESC)
		,logTicketId			TicketId
		,logdateEvent			DateEvent
		,t.logqueueId			QueueId
		,t.logjobName			JobName
		,t.loguserName			UserName
		,logeventminor			EventMinor
		,t.logdateCreated		[Time] 
		,t.logpages				Pages
		,t.logjobSize			JobSize
		,t.logcolor				Color
		,t.logduplex			Duplex
		,t.logfprintQ			FPQueueId
		,t.logclientBillingCode ClientBillingCode
		,t.logPricePlan			PricePlan
		,logticketPrice			TicketPrice
	FROM tbl_ticket_log t)
	SELECT a.*
	FROM a WHERE RowNo = 1

GO
IF OBJECT_ID('vw_ticket_ok') IS NOT NULL
	DROP VIEW vw_ticket_ok
GO

CREATE VIEW
vw_ticket_ok
AS


SELECT logticketId ticketId
FROM tbl_ticket_log
WHERE logeventmajor = 2 
	AND logeventminor = 1

GO
IF OBJECT_ID('vw_ticket_outcome') IS NOT NULL
	DROP VIEW vw_ticket_outcome
GO

CREATE VIEW
vw_ticket_outcome
AS

WITH a (ticketId, minorEvent, RowNo) AS
	(SELECT 
		logticketId ticketId
		,logeventminor minorevent
		,ROW_NUMBER() OVER (PARTITION BY logticketId ORDER BY logdateevent DESC)
	FROM tbl_ticket_log t
	LEFT OUTER JOIN vw_ticket_ok ok
		ON t.logticketId = ok.ticketId
	WHERE ok.ticketId IS NULL)
SELECT ticketId
		,minorEvent
FROM a WHERE RowNo = 1

UNION

SELECT
ticketId
,1
FROM vw_ticket_ok


GO
IF OBJECT_ID('vw_ticket_outcome2') IS NOT NULL
	DROP VIEW vw_ticket_outcome2
GO

CREATE VIEW
vw_ticket_outcome2
AS

WITH a (ticketId, minorEvent, dateEvent, RowNo) AS
	(SELECT 
		logticketId ticketId
		,logeventminor minorevent
		,logdateevent dateEvent
		,ROW_NUMBER() OVER (PARTITION BY logticketId ORDER BY logdateevent DESC)
	FROM tbl_ticket_log t
	LEFT OUTER JOIN vw_ticket_ok ok
		ON t.logticketId = ok.ticketId
	WHERE ok.ticketId IS NULL)
SELECT ticketId
		,minorEvent
		,dateEvent
FROM a WHERE RowNo = 1

UNION

SELECT
ticketId
,1
,getdate()
FROM vw_ticket_ok


GO
IF OBJECT_ID('vw_umbrella_user_full') IS NOT NULL
	DROP VIEW vw_umbrella_user_full
GO

CREATE VIEW	vw_umbrella_user_full
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-30
Description:  See all users in umbrella. To be updated when group structure becomes hierarchical.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
AS


SELECT DISTINCT
	u.UmbrellaId
	,u.UmbrellaName
	,g.UserId
	,g.UserName
	,g.Domain
FROM vw_group_user_full g
INNER JOIN tbl_report_group_umbrella u
	ON g.UmbrellaId = u.UmbrellaId

GO

IF OBJECT_ID('sp_property_upd') IS NOT NULL
	DROP PROCEDURE sp_property_upd
GO

CREATE PROCEDURE sp_property_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Update a property value
------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
	@ipropertyGroup				varchar(64)		= NULL
	,@ipropertyName				varchar(64)
	,@ipropertyValue			nvarchar(510)	= NULL
	,@ipropertyValueNumeric		int				= NULL
	,@ipropertyValueDate		datetime		= NULL
	,@ipropertyChangedBy		nvarchar(510)	= NULL
	,@ipropertyDescription		varchar(100)	= NULL
AS
BEGIN

	DECLARE @ErrorNo int

	IF NOT EXISTS (SELECT 1 FROM tbl_property WHERE propertyName = @ipropertyName)
		RETURN (100035)

	UPDATE tbl_property
	SET propertyGroup			= ISNULL(@ipropertyGroup, propertyGroup)
		,propertyValue			= ISNULL(@ipropertyValue, propertyValue)
		,propertyValueNumeric	= ISNULL(@ipropertyValueNumeric, propertyValueNumeric)
		,propertyValueDate		= ISNULL(@ipropertyValueDate, propertyValueDate)
		,propertyChangedBy		= ISNULL(@ipropertyChangedBy, propertyChangedBy)
		,propertyDescription	= ISNULL(@ipropertyDescription, propertyDescription)
	WHERE propertyName = @ipropertyName

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_ticket_get_structured_pageinfo') IS NOT NULL
	DROP PROCEDURE sp_ticket_get_structured_pageinfo
GO

CREATE PROCEDURE sp_ticket_get_structured_pageinfo
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-06
Description:  Given mix of pages, pagescolor, pagesbw, color, duplex - calculate actual characteristics of ticket
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iPaperSize				int
	,@iPages				int
	,@iColor				varchar(3)	-- Yes / No
	,@iDuplex				varchar(3)  -- Yes / No
	,@iLoggedBWPages		int
	,@iLoggedColorPages		int

	,@oPagesBW				int			OUTPUT
	,@oPagesColor			int			OUTPUT
	,@oPaperSize			tinyint		OUTPUT
	,@oDuplex				bit			OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int

	SET @oPagesBW		= NULL
	SET @oPagesColor	= NULL
	SET @oPaperSize		= NULL
	SET @oDuplex		= NULL


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Color / BW
	IF @iLoggedBWPages = 0 AND @iLoggedColorPages = 0
	BEGIN
		IF @iColor = 'Yes'
		BEGIN
			SET @oPagesColor = @iPages
			SET @oPagesBW = 0
		END
		ELSE
		BEGIN
			SET @oPagesColor = 0
			SET @oPagesBW = @iPages
		END
	END
	ELSE
	BEGIN
		SET @oPagesBW = @iLoggedBWPages
		SET @oPagesColor = @iLoggedColorPages
	END

	-- Duplex
	IF @iDuplex = 'Yes'
		SET @oDuplex = 1
	ELSE
		SET @oDuplex = 0

	-- PaperSize
	IF @iPaperSize BETWEEN 0 AND 255
		SET @oPaperSize = @iPaperSize
	ELSE
		SET @oPaperSize = 0

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_priceplan_get_explicit') IS NOT NULL
	DROP PROCEDURE sp_priceplan_get_explicit
GO

CREATE PROCEDURE sp_priceplan_get_explicit
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-08
Description: Get actual calculated prices for a priceplan
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-04
Description: Fix for determining if a papersize is priced abs or rel.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-11
Description: Fix for changed column order in priceplan row
************************************************************/
	@iPricePlanId		varchar(64)
--	,@iJobType			int = NULL
--	,@iPaperSize		smallint = NULL
--	,@iDuplex			bit = NULL
--	,@iColor			bit = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF;


	IF NOT EXISTS (SELECT 1 FROM tbl_cirrato_priceplan WHERE cppId = @iPricePlanId)
		RETURN (100060)


	DECLARE @ThisPlan TABLE
		(RowId varchar(64)
		,PricePlanid varchar(64)
		,RowName nvarchar(64)
		,Type smallint
		,PaperSize smallint
		,Cost float
		,SubType smallint)

	INSERT @ThisPlan
	SELECT  
		cprId
		,cprPlanid
		,cprRowName
		,cprType
		,cprValue
		,cprCost
		,cprTypeSubtype
	FROM tbl_cirrato_priceplan_row r1 WHERE r1.cprPlanId = @iPricePlanId;

	DECLARE @DuplexMultiplier float
			,@ColorMultiplier float
			,@CopyMultiplier float
			,@ScanMultiplier float
			,@FaxMultiplier float

	SELECT @DuplexMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 2
	SELECT @ColorMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 3
	SELECT @CopyMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 4
	SELECT @ScanMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 5
	SELECT @FaxMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 6;

	DECLARE @Prices TABLE (
		PaperSize smallint
		,BWSimplex float
		,BWDuplex  float
		,ColorSimplex float
		,ColorDuplex float
		,CopyBWSimplex float
		,CopyBWDuplex float
		,CopyColorSimplex float
		,CopyColorDuplex float
		,ScanBW float
		,ScanColor float);



	WITH PaperSizes (PaperSize, PricePlanType) AS
		(SELECT DISTINCT
			PaperSize
			,CASE WHEN EXISTS(SELECT * FROM @ThisPlan r2 
				WHERE r2.PaperSize = r1.PaperSize 
				AND ISNULL(r2.SubType,0) = 0) THEN 'rel' ELSE 'abs'  END
--				AND r2.SubType IS NOT NULL) THEN 'abs' ELSE 'rel' END
		FROM @ThisPlan r1 )
	INSERT @Prices
	SELECT 
		p.PaperSize

		,BasePrice.Cost						BWSimplex
		,BasePrice.Cost * @DuplexMultiplier BWDuplex	
		,BasePrice.Cost * @ColorMultiplier	ColorSimplex	
		,BasePrice.Cost * @ColorMultiplier * @DuplexMultiplier ColorDuplex	

		,BasePrice.Cost * @CopyMultiplier CopyBWSimplex
		,BasePrice.Cost * @DuplexMultiplier * @CopyMultiplier CopyBWDuplex	
		,BasePrice.Cost * @ColorMultiplier * @CopyMultiplier CopyColorSimplex	
		,BasePrice.Cost * @ColorMultiplier * @DuplexMultiplier * @CopyMultiplier CopyColorDuplex	

		,BasePrice.Cost * @ScanMultiplier ScanBW
		,BasePrice.Cost * @ScanMultiplier * @ColorMultiplier ScanColor
	FROM PaperSizes p
	INNER JOIN @ThisPlan BasePrice
		ON BasePrice.PaperSize = p.PaperSize
		AND BasePrice.Type IN (0, 1)
	WHERE p.PricePlanType = 'rel'

	UNION

	SELECT 
		p.PaperSize
		,BWSimplex.Cost BWSimplex
		,BWDuplex.Cost BWDuplex 
		,ColorSimplex.Cost ColorSimplex
		,ColorDuplex.Cost ColorDuplex

		,CopyBWSimplex.Cost CopyBWSimplex
		,CopyBWDuplex.Cost CopyBWDuplex
		,CopyColorSimplex.Cost
		,CopyColorDuplex.Cost

		,ScanBW.Cost ScanBW
		,ScanColor.Cost ScanColor
	FROM PaperSizes p

	LEFT JOIN @ThisPlan BWSimplex
		ON BWSimplex.PaperSize = p.PaperSize AND BWSimplex.Type = 1 AND BWSimplex.SubType = 10
	LEFT JOIN @ThisPlan BWDuplex
		ON BWDuplex.PaperSize = p.PaperSize AND BWDuplex.Type = 1 AND BWDuplex.SubType = 11
	LEFT JOIN @ThisPlan ColorSimplex
		ON ColorSimplex.PaperSize = p.PaperSize AND ColorSimplex.Type = 1 AND ColorSimplex.SubType = 12
	LEFT JOIN @ThisPlan ColorDuplex
		ON ColorDuplex.PaperSize = p.PaperSize AND ColorDuplex.Type = 1 AND ColorDuplex.SubType = 13

	LEFT JOIN @ThisPlan CopyBWSimplex
		ON CopyBWSimplex.PaperSize = p.PaperSize AND CopyBWSimplex.Type = 1 AND CopyBWSimplex.SubType = 20
	LEFT JOIN @ThisPlan CopyBWDuplex
		ON CopyBWDuplex.PaperSize = p.PaperSize AND CopyBWDuplex.Type = 1 AND CopyBWDuplex.SubType = 21
	LEFT JOIN @ThisPlan CopyColorSimplex
		ON CopyColorSimplex.PaperSize = p.PaperSize AND CopyColorSimplex.Type = 1 AND CopyColorSimplex.SubType = 22
	LEFT JOIN @ThisPlan CopyColorDuplex
		ON CopyColorDuplex.PaperSize = p.PaperSize AND CopyColorDuplex.Type = 1 AND CopyColorDuplex.SubType = 23

	LEFT JOIN @ThisPlan ScanBW
		ON ScanBW.PaperSize = p.PaperSize AND ScanBW.Type = 1 AND ScanBW.SubType = 30
	LEFT JOIN @ThisPlan ScanColor
		ON ScanColor.PaperSize = p.PaperSize AND ScanColor.Type = 1 AND ScanColor.SubType = 31

	WHERE p.PricePlanType = 'abs'


	-- Final output:

	SELECT
		1 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,0 AS Color
		,0 AS Duplex
		,BWSimplex Price
	FROM @Prices
	UNION 
	SELECT
		1 AS JobType
		,PaperSize	
		,0 AS Color
		,1 AS Duplex
		,BWDuplex Price
	FROM @Prices
	UNION 
	SELECT
		1 AS JobType
		,PaperSize	
		,1 AS Color
		,0 AS Duplex
		,ColorSimplex Price
	FROM @Prices

	UNION 
	SELECT
		1 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,1 AS Color
		,1 AS Duplex
		,ColorDuplex Price
	FROM @Prices

	UNION 
	SELECT
		2 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,0 AS Color
		,0 AS Duplex
		,CopyBWSimplex Price
	FROM @Prices
	UNION 
	SELECT
		2 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,0 AS Color
		,1 AS Duplex
		,CopyBWDuplex Price
	FROM @Prices
	UNION 
	SELECT
		2 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,1 AS Color
		,0 AS Duplex
		,CopyColorSimplex Price
	FROM @Prices
	UNION 
	SELECT
		2 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,1 AS Color
		,1 AS Duplex
		,CopyColorDuplex Price
	FROM @Prices
	UNION 
	SELECT
		4 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,0 AS Color
		,0 AS Duplex
		,ScanBW Price
	FROM @Prices
	UNION 
	SELECT
		4 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,1 AS Color
		,0 AS Duplex
		,ScanColor Price
	FROM @Prices

	ORDER BY 1,2,3,4


--SELECT @DuplexMultiplier DuplexMultiplier
--	 ,@ColorMultiplier ColorMultiplier
--	 ,@CopyMultiplier CopyMultiplier
--	 ,@ScanMultiplier ScanMultiplier
--	 ,@FaxMultiplier FaxMultiplier

--		SELECT * FROM @ThisPlan
--		SELECT * FROM @Prices

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_priceplan_get_ticket_price') IS NOT NULL
	DROP PROCEDURE sp_priceplan_get_ticket_price
GO

CREATE PROCEDURE sp_priceplan_get_ticket_price
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-13
Description: Given a price plan and job details, calculate the price
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-04
Description: Added min/max price for a one-page ticket of given JobType in the current priceplan.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-06
Description: Added option to use pre-calculated priceplans. Useful if this function is called multiple times with same PricePlan.
************************************************************/
	@iPricePlanId		varchar(64)
	,@iJobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
	,@iPagesBW			int
	,@iPagesColor		int
	,@iPaperSize		tinyint
	,@iDuplex			bit
	,@oTicketPrice		float	OUTPUT
	,@oMinTicketPrice	float	OUTPUT
	,@oMaxTicketPrice	float	OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@PriceBW				float
			,@PriceColor			float


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF;

	SET @oTicketPrice	 = NULL
	SET @oMinTicketPrice = NULL
	SET @oMaxTicketPrice = NULL

	DECLARE @Prices TABLE
	(JobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
	,PaperSize			tinyint
	,Color				bit
	,Duplex				bit
	,TicketPrice		float)

	IF object_id('tempdb..#Prices') IS NULL -- calculate prices for the priceplan
	BEGIN
		INSERT @Prices
		EXEC @ReturnStatus = sp_priceplan_get_explicit @iPricePlanId = @iPricePlanId

		IF @ReturnStatus <> 0
			RETURN (@ReturnStatus)
		END
	ELSE
	BEGIN -- priceplan is precalculates
		INSERT @Prices
		SELECT * FROM #Prices
	END

	-- if papersize is explicit, get it, otherwise use default price (papersize = 0)

	SELECT TOP 1
		@PriceBW = TicketPrice * (cast (@iPagesBW as float))
	FROM @Prices WHERE	
		JobType = @iJobType
		AND Duplex = @iDuplex
		AND Color = 0
		AND (PaperSize = @iPaperSize
			OR PaperSize = 0)
	ORDER BY PaperSize DESC

	SELECT TOP 1
		@PriceColor = TicketPrice * (cast (@iPagesColor as float))
	FROM @Prices WHERE	
		JobType = @iJobType
		AND Duplex = @iDuplex
		AND Color = 1
		AND (PaperSize = @iPaperSize
			OR PaperSize = 0)
	ORDER BY PaperSize DESC


	SET @oTicketPrice = ISNULL(@PriceBW,0) + ISNULL(@PriceColor,0)


	-- Return min/max price
	SELECT
		@oMinTicketPrice	= MIN(TicketPrice)
		,@oMaxTicketPrice	= MAX(TicketPrice)
	FROM @Prices
	WHERE JobType = @iJobType
	GROUP BY JobType


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_get_tickets_sub') IS NOT NULL
	DROP PROCEDURE sp_get_tickets_sub
GO

CREATE PROCEDURE sp_get_tickets_sub
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-13
Description: Get tickets for a set of queues (for display in Web)
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-01-29
Description: Changed criteria for follow-print
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-17
Description: Get proper outcome of historic jobs
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-04
Description: Get proper latest outcome of historic jobs
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-11
Description: Increase performance
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-01
Description: Additional columns
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-15
Description: Added authIp and calculated column HasOwner
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-21
Description: Removed check on ticketRuleStatus after discussion with Erik.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-29
Description: Changed conditions for isFollowPrint flag.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-05-05
Description: Return additional fields.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-11
Description: Added DeleteAfterPrint field.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-12
Description: UserName field hiding for ownerless jobs moved to WebGUI.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-23
Description: Always output authIp = ''.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-24
Description: Ticket 835 - do not limit active jobs listing to 100.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-25
Description: New field: RequireBillingCode.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-07-14
Description: New field: PaperSize, NumCopies.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-08-06
Description: Added optional input parameter Priceplan. If given, prices for active tickets without price will be calculated.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-09-11
Description: Added support to filter by ticket model and FP/non-FP. Model filter only for active tickets. 
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-09-16
Description: Added support for PrintDivert flag. 
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added support for listing jobs that are compatible with a specific printer
************************************************************/
	@iruleStatus			smallint = 0
	,@iincludeActive		bit = 1
	,@iincludeOld			bit = 0
	,@iPricePlanId			varchar(64) = NULL
	,@iModelId				varchar(64) = NULL
	,@iCompatiblePrinterId	varchar(64) = NULL
	,@iIncludeFPJobs		bit = 1
	,@iIncludeNonFPJobs		bit = 1
	,@iLanguageId			char(2)	= 'en'
AS
BEGIN



-- tbl_ticket.ticketRuleStatus=0 inneb�r att alla kan se den, 1 = bara admin kan se
-- 1 = jobbet "l�st" (kan ej skrivas ut), 0 = ol�st = vanligt


DECLARE  @tinfo TABLE
	(ticketId varchar(64), QueueId varchar(64), JobName nvarchar(510), username nvarchar(510), queueName nvarchar(510)
	,printerName nvarchar(510)
	,queuePrinterName nvarchar(510)
	,imageurl varchar(100)
	,[Time] datetime
	,Pages int, JobSize int, Color varchar(3), duplex varchar(3), ticketStatus nvarchar(100)
	,isFollowPrint bit, ticketActive bit, allowJobAction bit
	,clientBillingCode nvarchar(100), PricePlan varchar(64), TicketPrice float(53), DocumentTypeVerbose varchar(100)
	,finalEventMinor smallint, finalTicketStatus varchar(64)
	,FollowPrintQueueId varchar(64)
	,OriginatingIp varchar(64)
	,ClientIp varchar(64)
	,authIp varchar(64)
	,HasOwner bit
	,ticketStatusNumeric smallint
	,ticketAdminStatus smallint
	,ticketNewStatus smallint
	,ticketRuleStatus smallint
	,deleteAfterPrint smallint
	,RequireBillingCode bit
	,PaperSize int
	,NumCopies smallint
	,BWPages int
	,ColorPages int
	,PrintDivert bit)

INSERT @tinfo
Select --TOP 100
	t.ticketId as 'ticketId'
	,t.QueueId as 'queueId'
	,t.jobName as 'JobName'
-- Hiding logic moved to WebGUI joblist control
--	,CASE WHEN t.authIP IS NOT NULL AND t.ticketRuleStatus = 1 THEN '<i>No owner</i>'
--			ELSE t.username 
--	END as 'username'
	,t.username
	,q.queueName as queueName
	,p.printerName as printerName
	,ISNULL(q.queueName, p.printerName) as queuePrinterName
	,(case upper(right(t.jobName,4)) 
		when '.DOC' then '~/images/icon-word.gif' 
		when '.XLS' then '~/images/icon-xls.gif'
		when '.PDF' then '~/images/icon-pdf.gif' 
		when '.PPT' then '~/images/icon-ppt.gif' 
		when '.TXT' then '~/images/icon-txt.gif'
		else '~/images/icon-none.gif' end) as 'imageurl'
	,t.dateCreated as 'Time' 
	,t.pages as 'Pages'
	,t.jobSize as 'JobSize'
	,(case t.color when 1 then 'No' else 'Yes' end) as Color
	,(case t.duplex when 1 then 'No' else 'Yes' end) as duplex
	,dbo.verboseTicketStatusByLanguage(ticketStatus, @iLanguageId) + ' ' 
		+ dbo.verboseTicketAdminStatusByLanguage(t.ticketAdminStatus, @iLanguageId) + ' ' 
		+ dbo.verboseRuleStatusByLanguage(ticketRuleStatus, @iLanguageId) + ' ' 
		+ case when ISNULL(ticketNewStatus,0) = 0 THEN ''
		else '(' + dbo.verboseTicketNewStatusByLanguage(ticketNewStatus, @iLanguageId) + ')' end
		as ticketStatus
	,cast(case when (t.queueId <> t.fprintQ ) OR (q.queueType = 3 ) then '1'
		else '0' end as varchar(10)) as isFollowPrint
	,1 as ticketActive
	,CAST(CASE WHEN t.ticketStatus IN(2, 7) THEN 1 ELSE 0 END AS bit) as allowJobAction
	,clientBillingCode
	,pricePlan
	,ticketPrice
	,dbo.verboseDocumentTypeByLanguage(t.jobName, @iLanguageId) AS DocumentTypeVerbose
	,NULL AS finalEventMinor
	,NULL AS finalTicketStatus
	,t.fprintQ
	,t.originatingIp
	,t.clientIp
	,ISNULL(t.authIp,'') authIp
	,CASE WHEN t.authIP IS NOT NULL AND t.ticketRuleStatus = 1 THEN 0 ELSE 1 END as HasOwner
	,ticketStatus AS ticketStatusNumeric 
	,ticketAdminStatus 
	,ticketNewStatus 
	,ticketRuleStatus 
	,deleteAfterPrint
	,CASE WHEN rbc.ticketFeatureTicket IS NOT NULL THEN 1 ELSE 0 END	AS RequireBillingCode
	,paper
	,numCopies
	,LoggedBWPages
	,LoggedColorPages
	,CASE WHEN pd.ticketFeatureTicket IS NOT NULL THEN 1 ELSE 0 END	AS PrintDivert
from tbl_ticket t 
join #tickets t1
	on t1.ticketId = t.ticketId
	and t1.ticketActive = 1
left outer join tbl_printer p
	on t.printerId = p.printerId
left outer join tbl_queue q
	on t.queueId = q.queueId
left outer join tbl_ticket_feature rbc
	on rbc.ticketFeatureTicket = t.ticketId
	and rbc.ticketFeatureFeature = 3 -- cb_lock
left outer join tbl_ticket_feature pd
	on pd.ticketFeatureTicket = t.ticketId
	and pd.ticketFeatureFeature = 4 -- TF_PRINTSERVICE_LOCK
WHERE --ISNULL(@iModelId, ISNULL(t.ticketModel,'')) = ISNULL(t.ticketModel,'')
	@iCompatiblePrinterId IS NULL 
--	OR t.ticketModel = ''
	OR t.ticketModel IN (SELECT ModelId FROM vw_printer_model_compatible WHERE PrinterId = @iCompatiblePrinterId)

--where
--	t.ticketRuleStatus <= @iruleStatus;
--	AND @iincludeActive = 1


	-- Calculate prices if priceplan is given
	-----------------------------------------

	IF @iPricePlanId IS NOT NULL
	BEGIN 
		CREATE TABLE #Prices
		(JobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
		,PaperSize			tinyint
		,Color				bit
		,Duplex				bit
		,TicketPrice		float)

		DECLARE @cTicketId				varchar(64)
				,@cPaperSize			int
				,@cPages				int
				,@cColor				varchar(3) -- Yes / No
				,@cDuplex				varchar(3)  
				,@cLoggedBWPages		int
				,@cLoggedColorPages		int

				-- goes into priceplan calc
				,@oPagesBW		int
				,@oPagesColor	int
				,@oPaperSize	tinyint
				,@oDuplex		bit

				,@TicketPrice		float
				,@MinTicketPrice	float
				,@MaxTicketPrice	float
				,@ReturnStatus		int


		INSERT #Prices
		EXEC @ReturnStatus = sp_priceplan_get_explicit @iPricePlanId = @iPricePlanId

		IF @ReturnStatus <> 0 GOTO FETCH_OLD

		DECLARE curTicketsWithoutPrice CURSOR FOR
		SELECT ticketId, papersize, pages, color, duplex, BWPages, ColorPages FROM @tinfo WHERE ticketPrice IS NULL

		OPEN curTicketsWithoutPrice
		FETCH NEXT FROM curTicketsWithoutPrice INTO @cTicketId, @cPaperSize, @cPages, @cColor, @cDuplex, @cLoggedBWPages, @cLoggedColorPages

		WHILE @@FETCH_STATUS = 0
		BEGIN

			EXEC sp_ticket_get_structured_pageinfo
					@iPaperSize				= @cPaperSize
					,@iPages				= @cPages
					,@iColor				= @cColor
					,@iDuplex				= @cDuplex
					,@iLoggedBWPages		= @cLoggedBWPages
					,@iLoggedColorPages		= @cLoggedColorPages
					,@oPagesBW				= @oPagesBW		OUTPUT
					,@oPagesColor			= @oPagesColor	OUTPUT
					,@oPaperSize			= @oPaperSize	OUTPUT
					,@oDuplex				= @oDuplex		OUTPUT

			EXEC sp_priceplan_get_ticket_price
					@iPricePlanId		= @iPricePlanId
					,@iJobType			= 1 -- print
					,@iPagesBW			= @oPagesBW
					,@iPagesColor		= @oPagesColor
					,@iPaperSize		= @oPaperSize
					,@iDuplex			= @oDuplex
					,@oTicketPrice		= @TicketPrice		OUTPUT
					,@oMinTicketPrice	= @MinTicketPrice	OUTPUT
					,@oMaxTicketPrice	= @MaxTicketPrice	OUTPUT
			
			UPDATE @tinfo SET ticketPrice = @TicketPrice WHERE ticketId = @cTicketId


			FETCH NEXT FROM curTicketsWithoutPrice INTO @cTicketId, @cPaperSize, @cPages, @cColor, @cDuplex, @cLoggedBWPages, @cLoggedColorPages

		END
				
		CLOSE curTicketsWithoutPrice
		DEALLOCATE curTicketsWithoutPrice


	END

	-- Insert old tickets
	-------------------------------------
	FETCH_OLD:
	INSERT @tinfo
	SELECT TOP 100 
		t.logticketId
		,t.logqueueId
		,t.logjobName
		,t.loguserName
		,q.queueName
		,p.printerName
		,ISNULL(p.printerName,q.queueName) as queuePrinterName
		,(case upper(right(t.logjobName,4)) 
			when '.DOC' then '~/images/icon-word.gif' 
			when '.XLS' then '~/images/icon-xls.gif'
			when '.PDF' then '~/images/icon-pdf.gif' 
			when '.PPT' then '~/images/icon-ppt.gif' 
			when '.TXT' then '~/images/icon-txt.gif'
			else '~/images/icon-none.gif' end) as 'imageurl'
		,t.logdateCreated [Time]
		,t.logpages
		,t.logJobSize
		,(case t.logcolor when 1 then 'No' else 'Yes' end) as Color
		,(case t.logduplex when 1 then 'No' else 'Yes' end) as duplex
		,dbo.fn_translate('ClosedJob', @iLanguageId) + ' - ' + dbo.verboseTicketLogByLanguage(0,t.logEventMinor, @iLanguageId)  ticketStatus
		,cast(case when t.logqueueId <> t.logfprintQ then '1'
			else '0' end as varchar(10)) as isFollowPrint
		,0 AS ticketActive
		,0 AS allowJobAction
		,t.logclientBillingCode
		,t.logPricePlan
		,t.logTicketPrice
		,dbo.verboseDocumentTypeByLanguage(t.logjobName, @iLanguageId) AS DocumentTypeVerbose
		,t.logEventMinor 
		,t.logEventMinor  finalTicketStatus
		,t.logfprintQ
		,t.logoriginatingIp
		,t.logclientIp
		,'' -- logAuthIp ????
		,1 -- HasOwner
		,NULL AS ticketStatusNumeric 
		,NULL AS ticketAdminStatus 
		,NULL AS ticketNewStatus 
		,0 AS ticketRuleStatus 
		,NULL AS deleteAfterPrint
		,0 AS RequireBillingCode
		,t.logpaper
		,0 --t.logNumCopies
		,t.logLoggedColorPages
		,t.logLoggedBWPages
		,NULL AS PrintDivert
	FROM #tickets t1
	INNER JOIN tbl_ticket_log t
		on t.logticketId = t1.ticketId
		AND t.logDateEvent = t1.DateEvent
		AND t.logEventMinor NOT BETWEEN 20 AND 24 -- These are all related to the outcome of the debit
	LEFT OUTER JOIN tbl_queue q
		on q.queueId = t.logqueueId
	left outer join tbl_printer p
		on t.logprinterId = p.printerId


	-- Return results
	-------------------------------------
	select * from @tinfo

	WHERE (isFollowPrint = 0 AND @iIncludeNonFPJobs = 1)
		OR (isFollowPrint = 1 AND @iIncludeFPJobs = 1)


	order by
	/* ticketActive desc,*/ [Time] desc


	RETURN (0)

END
GO

IF OBJECT_ID('sp_smartalarms_get_alarms') IS NOT NULL
	DROP PROCEDURE sp_smartalarms_get_alarms
GO

CREATE PROCEDURE sp_smartalarms_get_alarms
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-03
Description: Get current alarms
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-09
Description: Include username column
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-15
Description: Added multi-language support
************************************************************/
	@iincludeWarnings	bit			= 1
	,@iincludeErrors	bit			= 1
	,@iLanguageId		char(2)		= 'en'
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@JobDurationWarningLimit	int
			,@JobDurationErrorLimit		int
			,@QueueJobCountWarningLimit	int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT @JobDurationWarningLimit		= dbo.fn_property_get_numeric ('smartAlarmJobDurationWarning')
			,@JobDurationErrorLimit		= dbo.fn_property_get_numeric ('smartAlarmJobDurationError')
			,@QueueJobCountWarningLimit = dbo.fn_property_get_numeric ('smartAlarmQueueJobCountWarning')

	SET @CurrentTimestamp = GETDATE()
	SET @ErrorNo = 0
	
	IF @JobDurationWarningLimit IS NULL
		OR @JobDurationErrorLimit IS NULL
		OR @QueueJobCountWarningLimit IS NULL
	RETURN (100012)
	

	CREATE TABLE #alarms
	(AlarmTypeId		int				-- what type of alarm? 1 = job takes too long, 2 = max no of jobs in queue exceeded
	,AlarmSeverityId	int				-- 1 = warning, 2 = error
	,AlarmArea			int				-- 1=job, 2=queue, 3=printer
	,AlarmDescription	varchar(128)	COLLATE DATABASE_DEFAULT-- Verbose alarm description 
	,JobName			nvarchar(510)	COLLATE DATABASE_DEFAULT-- related ticket and queue (NULL if N/A)
	,TicketId			varchar(64)		COLLATE DATABASE_DEFAULT
	,QueueName			nvarchar(510)	COLLATE DATABASE_DEFAULT
	,QueueId			varchar(64)		COLLATE DATABASE_DEFAULT
	,NumericArg			int
	,UserName			nvarchar(510)	COLLATE DATABASE_DEFAULT)	



	-----------------------------------------------------
	-- Job takes too long - warning
	IF @iincludeWarnings = 1
	BEGIN
		INSERT #alarms 
			(AlarmTypeId
			,AlarmSeverityId
			,AlarmArea
			,AlarmDescription
			,JobName
			,TicketId
			,QueueName
			,QueueId
			,NumericArg
			,UserName)
		SELECT 
			 1		-- AlarmTypeId
			,1		-- AlarmSeverityId
			,1		-- AlarmArea
			,NULL	-- AlarmDescription
			,t.JobName
			,t.TicketId
			,q.QueueName
			,t.QueueId
			,DATEDIFF(n, t.dateBegan, @CurrentTimestamp) -- minutes this job has been printing
			,t.userName
		FROM tbl_ticket t
		INNER JOIN tbl_queue q
			on q.queueId = t.queueId
		WHERE t.ticketStatus = 6 -- Printing
			and DATEDIFF(n, t.dateBegan, @CurrentTimestamp) > @JobDurationWarningLimit
			and DATEDIFF(n, t.dateBegan, @CurrentTimestamp) <= @JobDurationErrorLimit
	END
	-----------------------------------------------------
	-- Job takes too long - error
	IF @iincludeErrors = 1
	BEGIN
		INSERT #alarms 
			(AlarmTypeId
			,AlarmSeverityId
			,AlarmArea
			,AlarmDescription
			,JobName
			,TicketId
			,QueueName
			,QueueId
			,NumericArg
			,UserName)
		SELECT 
			 1		-- AlarmTypeId
			,2		-- AlarmSeverityId
			,1		-- AlarmArea
			,NULL	-- AlarmDescription
			,t.JobName
			,t.TicketId
			,q.QueueName
			,t.QueueId
			,DATEDIFF(n, t.dateBegan, @CurrentTimestamp)
			,t.userName
		FROM tbl_ticket t
		INNER JOIN tbl_queue q
			on q.queueId = t.queueId
		WHERE t.ticketStatus = 6 -- Printing
			and DATEDIFF(n, t.dateBegan, @CurrentTimestamp) > @JobDurationErrorLimit;
	END
	-----------------------------------------------------
	-- Queue no. items limit warning
	IF @iincludeWarnings = 1
	BEGIN
		WITH qc (queueId, ticketCount) AS
			(SELECT queueId, Count(*) FROM tbl_ticket 
			GROUP BY queueId 
			HAVING Count(*) > @QueueJobCountWarningLimit)
		INSERT #alarms 
			(AlarmTypeId
			,AlarmSeverityId
			,AlarmArea
			,AlarmDescription
			,QueueName
			,QueueId
			,NumericArg
			,JobName)
		SELECT 
			 2		-- AlarmTypeId
			,1		-- warning
			,2		-- AlarmArea = queue
			,NULL	-- AlarmDescription
			,q.queueName
			,qc.queueId
			,qc.ticketCount
			,NULL--'No. of jobs:'
		FROM qc
		INNER JOIN tbl_queue q
			ON q.queueId = qc.queueId
		WHERE q.queueType = 1 -- only normal queues
	END

	-----------------------------------------------------
	--	Update table with static texts
	UPDATE a
		SET a.AlarmDescription = at.AlarmDescription
	FROM #alarms a
	inner join tbl_smartalarm_type at
		on a.AlarmTypeId		= at.AlarmTypeId
		and a.AlarmSeverityId	= at.AlarmSeverityId
		and a.AlarmArea			= at.AlarmArea
	WHERE at.LanguageId = @iLanguageId



	SELECT * FROM #alarms
	ORDER BY AlarmSeverityId DESC, AlarmTypeId, AlarmArea, QueueName, JobName

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_smartalarms_aggregate_by_queue') IS NOT NULL
	DROP PROCEDURE sp_smartalarms_aggregate_by_queue
GO

CREATE PROCEDURE sp_smartalarms_aggregate_by_queue
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-09
Description: For all queues, get the number of smartalarms at the highest level
			(results will be available in table #smartalarmsaggregatequeue)
************************************************************/
	@iincludeWarnings	bit = 1
	,@iincludeErrors	bit = 1
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@JobDurationWarningLimit	int
			,@JobDurationErrorLimit		int
			,@QueueJobCountWarningLimit	int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	SET @CurrentTimestamp = GETDATE()
	SET @ErrorNo = 0
	

	

	CREATE TABLE #queuealarms
	(AlarmTypeId		int				
	,AlarmSeverityId	int				
	,AlarmArea			int				
	,AlarmDescription	varchar(128)	COLLATE DATABASE_DEFAULT
	,JobName			nvarchar(510)	COLLATE DATABASE_DEFAULT
	,TicketId			varchar(64)		COLLATE DATABASE_DEFAULT
	,QueueName			nvarchar(510)	COLLATE DATABASE_DEFAULT
	,QueueId			varchar(64)		COLLATE DATABASE_DEFAULT
	,NumericArg			int
	,UserName			nvarchar(510)	COLLATE DATABASE_DEFAULT)		


	INSERT #queuealarms
	EXEC @ReturnStatus = sp_smartalarms_get_alarms
							@iincludeWarnings	= @iincludeWarnings
							,@iincludeErrors	= @iincludeErrors

	SET @ErrorNo = @@ERROR
	IF @ReturnStatus <> 0 OR @ErrorNo <> 0
		GOTO PROC_ERROR;



	-- Aggregate by queue
	WITH a (QueueId, AlarmSeverityId, AlarmCount, AlarmRank)
	AS
	(SELECT QueueId
			,AlarmSeverityId
			,COUNT(*)
			,ROW_NUMBER() OVER (PARTITION BY QueueId ORDER BY AlarmSeverityId DESC)	
	FROM #queuealarms GROUP BY QueueId, AlarmSeverityId)
	INSERT #smartalarmsaggregatequeue
	SELECT a.QueueId
		,a.AlarmSeverityId
		,a.AlarmCount
	FROM a 
	WHERE AlarmRank = 1
	ORDER BY QueueId, AlarmRank


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	DROP TABLE #queuealarms

	RETURN (@ReturnStatus)


	PROC_ERROR:
	DROP TABLE #queuealarms
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_queue_get_overview') IS NOT NULL
	DROP PROCEDURE sp_queue_get_overview
GO

CREATE PROCEDURE sp_queue_get_overview
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-09
Description: Get an overview of all active queues
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-19
Description: Added option to choose queue type
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-12
Description: Return print speed and stop reason
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-23
Description: Added support for hidden queues
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-25
Description: Added support for SNMP turned off
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-22
Description: Ticket 96 / Show queue, not printer, model
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-15
Description: Added multi-language support
************************************************************/
	@iincludeOK			bit = 1
	,@iincludeWarnings	bit = 1
	,@iincludeErrors	bit = 1
	,@iusername			nvarchar(510)	= NULL
	,@iprinterIP		varchar(100)	= NULL
	,@iqueueName		nvarchar(510)	= NULL
	,@ibrandId			varchar(64)		= NULL
	,@imodelId			varchar(64)		= NULL
	,@iqueueId			varchar(64)		= NULL
	,@iqueueType		smallint		= 1 -- 1 = Regular queue, 3 = FollowPrint Queue
	,@iSilent			bit				= 0 
	,@iHiddenQueueUser	nvarchar(510)	= NULL
	,@iLanguageId		char(2)			= 'en'
AS
BEGIN
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime
	
	IF OBJECT_ID('tempdb..#queue') IS NULL
	CREATE TABLE #queue
	(QueueId					varchar(64)		COLLATE DATABASE_DEFAULT
	,QueueName					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,RegionPath					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,Location					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,QueueStatusVerbose			varchar(64)		COLLATE DATABASE_DEFAULT
	,PrinterStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
	,ErrorTime					datetime
	,LastCheck					int
	,DisplayText				nvarchar(200)	COLLATE DATABASE_DEFAULT
	,PhysicalStatusSeverity		int
	,PhysicalStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
	,NewStatusVerbose			varchar(64)		COLLATE DATABASE_DEFAULT
	,HighestSmartAlarmLevel		int
	,SmartAlarmCount			int	
	,HighestTotalAlarmLevel		int
	,PrinterIP					varchar(64)		COLLATE DATABASE_DEFAULT
	,PrinterId					varchar(64)		COLLATE DATABASE_DEFAULT
	,PrinterName					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,ModelName					nvarchar(512)	COLLATE DATABASE_DEFAULT
	,JobCount					int
	,RegionId					bigint
	,AdminComment				nvarchar(510)	COLLATE DATABASE_DEFAULT
	,OfflineReason				nvarchar(256)	COLLATE DATABASE_DEFAULT
	,PagesPerMinuteBWSingle		real
	,PagesPerMinuteColorSingle	real
	,PagesPerMinuteBWDuplex		real
	,PagesPerMinuteColorDuplex	real)


	CREATE TABLE #smartalarmsaggregatequeue
	(QueueId				varchar(64)		COLLATE DATABASE_DEFAULT
	,HighestAlarmSeverityId int
	,AlarmCount				int)


	INSERT #queue
		(QueueId	
		,PrinterIP
		,PrinterId
		,PrinterName
		,QueueName
		,ModelName
		,JobCount				
		,RegionPath				
		,Location			
		,QueueStatusVerbose
		,PrinterStatusVerbose
		,PhysicalStatusSeverity		
		,PhysicalStatusVerbose
		,NewStatusVerbose
		,RegionId
		,AdminComment
		,OfflineReason
		,PagesPerMinuteBWSingle		
		,PagesPerMinuteColorSingle	
		,PagesPerMinuteBWDuplex		
		,PagesPerMinuteColorDuplex)
	SELECT 
		q.queueid as 'queueid'
		,max(p.printerIp) as 'PrinterIp'
		,max(p.printerId) as 'PrinterId'
		,max(p.printerName) 
		,max(q.queuename) as 'QueueName'
		,max(l.modelName) as 'Model'
		,count(t.ticketId) as 'JobCount'
		,max(dbo.GetAbsoluteRegion(q.queueRegion))as 'Region'
		,max(q.queueLocation) as 'Location' -- max(p.printerLocation) as 'Location'
		,dbo.verbosePrinterAggregatedStatusByLanguage(ISNULL(MAX(q.queueStatus),0), ISNULL(MAX(q.queueNewStatus),0), @iLanguageId) AS QueueStatusVerbose
		,dbo.verbosePrinterAggregatedStatusByLanguage(ISNULL(MAX(p.adminStatus),0), ISNULL(MAX(p.printerNewStatus),0), @iLanguageId) AS PrinterStatusVerbose
		,dbo.fn_printer_physical_status_severity(max(p.PhysStatus), ISNULL(MAX(p.snmpCheck),'0')) -- PhysicalStatusSeverity
		,dbo.verbosePrinterPhysicalStatusByLanguage(max(p.PhysStatus), ISNULL(MAX(p.snmpCheck),'0'), @iLanguageId)
		,dbo.verbosePrinterNewStatusByLanguage(max(p.printernewstatus), @iLanguageId)
		,MAX(p.region) RegionId
		,MAX(q.queueAdminComment) AdminComment
		,MAX(q.OfflineReason)
		,MAX(PagesPerMinuteBWSingle)		
		,MAX(PagesPerMinuteColorSingle)	
		,MAX(PagesPerMinuteBWDuplex)		
		,MAX(PagesPerMinuteColorDuplex)
	from tbl_queue q 
	left join  tbl_queue_printer_map m on q.queueid= m.mapqueue
	left join tbl_printer p on p.printerid = m.mapphyprinter 
	left join tbl_model l on q.queueModelId = l.modelId
	left join tbl_region r on p.region=r.regionId  
	left join tbl_ticket t on t.queueid=q.queueId  
	where (@iusername IS NULL OR t.userName LIKE @iusername)
			AND (@iprinterIP IS NULL OR p.printerIp LIKE @iprinterIP)
			AND (@iqueueName IS NULL OR q.queueName LIKE @iqueueName)
			AND (@ibrandId IS NULL OR l.modelBrandId = @ibrandId)
			AND (@imodelId IS NULL OR l.modelId = @imodelId)
			AND (@iqueueId IS NULL OR q.queueId = @iqueueId)
			AND q.queueType = @iqueueType
			AND q.queueStatus < 3 
			AND ((queueHidden = 0) OR
				(@iHiddenQueueUser IS NULL OR t.userName = @iHiddenQueueUser))
	group by q.queueid


	-- Smart alarms
	--------------------------------------------------------------------------
	EXEC @ReturnStatus = sp_smartalarms_aggregate_by_queue -- result is avail in #smartalarmsaggregatequeue

	SET @ErrorNo = @@ERROR
	IF @ReturnStatus <> 0 OR @ErrorNo <> 0
		GOTO PROC_ERROR;

	UPDATE q
	SET q.HighestSmartAlarmLevel = qsa.HighestAlarmSeverityId
		,q.SmartAlarmCount = qsa.AlarmCount
	FROM #queue q
	INNER JOIN #smartalarmsaggregatequeue qsa
		ON q.QueueId = qsa.QueueId

	UPDATE #queue
	SET HighestTotalAlarmLevel = 
			CASE WHEN PhysicalStatusSeverity > ISNULL(HighestSmartAlarmLevel,0) THEN PhysicalStatusSeverity
				 ELSE ISNULL(HighestSmartAlarmLevel,0) 
			END



	--	Return results
	IF @iSilent = 0
		SELECT * FROM #queue
		WHERE (@iincludeOK = 1 AND HighestTotalAlarmLevel = 0)
		OR (@iincludeWarnings = 1 AND HighestTotalAlarmLevel = 1)
		OR (@iincludeErrors = 1 AND HighestTotalAlarmLevel = 2)
		ORDER BY QueueName



	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_monitoring_get_printer_status') IS NOT NULL
	DROP PROCEDURE sp_monitoring_get_printer_status
GO

CREATE PROCEDURE sp_monitoring_get_printer_status
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-04
Description: Get printer status overview
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-13
Description: Additions so that this can be used in queue manager pages too
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-24
Description: Added status count output parameters
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-12
Description: Return stop reason
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-23
Description: Added support for hidden printers
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-25
Description: Added support for SNMP turned off
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-25
Description: Fixed multiple listing of printers with more than one open event.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
************************************************************/
	@iincludeOK			bit = 1
	,@iincludeWarnings	bit = 1
	,@iincludeErrors	bit = 1
	,@iusername			nvarchar(510)	= NULL
	,@iprinterIP		varchar(100)	= NULL
	,@iprinterName		nvarchar(510)	= NULL
	,@ibrandId			varchar(64)		= NULL
	,@imodelId			varchar(64)		= NULL
	,@iprinterId		varchar(64)		= NULL
	,@iprinterType		char(1)			= '0'  -- 0 = network printer, 1 = localprinter.
	,@iSilent			bit				= 0 
	,@iHiddenPrinterUser	nvarchar(510)	= NULL
	,@oOKCount			int				= NULL OUTPUT
	,@oWarningCount		int				= NULL OUTPUT
	,@oErrorCount		int				= NULL OUTPUT
	,@iCalculateRegionPath	bit			= 1
	,@iLanguageId		char(2)			= 'en'
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT	@oOKCount			= NULL
			,@oWarningCount		= NULL
			,@oErrorCount		= NULL

	IF OBJECT_ID('tempdb..#printer') IS NULL
	CREATE TABLE #printer
	(PrinterId					varchar(64)		COLLATE DATABASE_DEFAULT
	,PrinterName				nvarchar(510)	COLLATE DATABASE_DEFAULT
	,RegionPath					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,Location					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,ErrorTime					datetime
	,LastCheck					int
	,DisplayText				nvarchar(200)	COLLATE DATABASE_DEFAULT
	,PrinterStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
	,PhysicalStatusSeverity		int
	,PhysicalStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
	,HighestSmartAlarmLevel		int	-- Smart alarms
	,SmartAlarmCount			int	 -- No of smart alarms at the highest level of the printer!
	,RegionId					bigint
	,HighestTotalAlarmLevel		int -- MAX(PhysicalStatusSeverity, HighestAlarmLevel)
	,JobCount					int
	,PrinterIP					varchar(64)		COLLATE DATABASE_DEFAULT
	,ModelName					nvarchar(512)	COLLATE DATABASE_DEFAULT
	,AdminComment				nvarchar(510)	COLLATE DATABASE_DEFAULT
	,OfflineReason				nvarchar(256)	COLLATE DATABASE_DEFAULT);


	WITH OpenPrinterStatus (PrinterId, EventStartDate) AS
	(SELECT
		statopenPrinterId
		,MIN(statopenFirstDetected)
	FROM tbl_event_status_open
	GROUP BY statopenPrinterId)
	INSERT #printer
		(PrinterId				
		,PrinterName				
		,RegionPath				
		,Location			
		,ErrorTime		
		,LastCheck			
		,DisplayText		
		,PrinterStatusVerbose	
		,PhysicalStatusSeverity		
		,PhysicalStatusVerbose
		,RegionId
		,JobCount
		,PrinterIP
		,ModelName
		,AdminComment)
	SELECT 
		p.PrinterID as 'PrinterId'
		,max(p.printerName) as 'Printer Name'

		,CASE WHEN @iCalculateRegionPath = 1 THEN
				CASE	WHEN @iprinterType = '0' THEN max(dbo.GetAbsoluteRegion(p.region))
						WHEN @iprinterType = '1' THEN max(dbo.GetAbsoluteLocalRegion(p.region)) END 
			ELSE NULL END as 'RegionPath'
		,max(p.printerLocation) as 'Location'
		,e.EventStartDate as 'Error Time'
		,STR(datediff(minute,max(p.printerLastCheck),getdate())) LastCheck
		,p.printerDisplayText as 'Display Text'

		,dbo.verbosePrinterAggregatedStatusByLanguage(ISNULL(MAX(p.adminStatus),0), ISNULL(MAX(p.printerNewStatus),0), @iLanguageId) AS PrinterStatusVerbose
--		,dbo.verbosePrinterAdmStatus(MAX(p.adminStatus)) + ' ' 
--			+ case when ISNULL(MAX(p.printerNewStatus),0) = 0 THEN ''
--				else '(' + dbo.verbosePrinterNewStatus(MAX(p.printerNewStatus)) + ')' end	PrinterStatusVerbose

		,dbo.fn_printer_physical_status_severity(max(p.PhysStatus), ISNULL(MAX(p.snmpCheck),'0')) PhysicalStatusSeverity
		,dbo.verbosePrinterPhysicalStatusByLanguage(max(p.PhysStatus), ISNULL(MAX(p.snmpCheck),'0'), @iLanguageId) PhysicalStatusVerbose
		,MAX(p.region)
		,COUNT(t.ticketId)
		,MAX(p.printerIp)
		,MAX(m.modelName)
		,MAX(p.printerAdminComment)
	from tbl_printer p 
	left join tbl_model m on p.printerModel =m.modelId 
	left join tbl_region r on p.region=r.regionId 
--	left join tbl_lregion lr on p.region=lr.lregionId 
--	left join tbl_event_status_open e on p.printerId = e.statopenPrinterId AND statOpenPhysStatus = 1
	left join OpenPrinterStatus e on e.PrinterId = p.printerId
	left join tbl_queue_printer_map map	on map.mapPhyPrinter = p.printerId
	left join tbl_ticket t	on t.queueId = map.mapQueue
	where	(@iusername IS NULL OR t.userName LIKE @iusername)
			AND (@iprinterIP IS NULL OR p.printerIp LIKE @iprinterIP)
			AND (@iprinterName IS NULL OR p.printerName LIKE @iprinterName)
			AND (@ibrandId IS NULL OR m.modelBrandId = @ibrandId)
			AND (@imodelId IS NULL OR m.modelId = @imodelId)
			AND (@iprinterId IS NULL OR p.printerId = @iprinterId)

			AND p.adminStatus < 3
			AND p.printerType = @iprinterType

			AND ((printerHidden = 0) OR
				(@iHiddenPrinterUser IS NULL OR t.userName = @iHiddenPrinterUser))

	group by p.printerId, p.printerDisplayText , e.EventStartDate



	-- Smart alarms support
	-----------------------------------------------------------------------------

	-- Get All Current Smart Alarms
	CREATE TABLE #queuesmartalarms
		(AlarmTypeId		int				-- what type of alarm? 1 = job takes too long, 2 = max no of jobs in queue exceeded
		,AlarmSeverityId	int				-- 1 = warning, 2 = error
		,AlarmArea			int				-- 1=job, 2=queue, 3=printer
		,AlarmDescription	varchar(128)	COLLATE DATABASE_DEFAULT-- Verbose alarm description 
		,JobName			nvarchar(510)	COLLATE DATABASE_DEFAULT-- related ticket and queue (NULL if N/A)
		,TicketId			varchar(64)		COLLATE DATABASE_DEFAULT
		,QueueName			nvarchar(510)	COLLATE DATABASE_DEFAULT
		,QueueId			varchar(64)		COLLATE DATABASE_DEFAULT
		,NumericArg			int
		,UserName			nvarchar(510)	COLLATE DATABASE_DEFAULT)

	CREATE TABLE #printersmartalarms 
		(PrinterId			varchar(64)		COLLATE DATABASE_DEFAULT
		,AlarmSeverityId	int
		,AlarmCount			int
		,AlarmRank			int)

	INSERT #queuesmartalarms
	EXEC @ReturnStatus = sp_smartalarms_get_alarms		@iincludeWarnings	= 1 --@iincludeWarnings
														,@iincludeErrors	= 1 --@iincludeErrors

	SET @ErrorNo = @@ERROR
	IF @ReturnStatus <> 0 OR @ErrorNo <> 0
		GOTO PROC_ERROR;


	-- Get the highest severity per printer and the number of alarms with that severity
	WITH a (AlarmSeverityId, PrinterId, AlarmCount) AS
		(SELECT
			qa.AlarmSeverityId
			,map.mapPhyPrinter
			,COUNT(1)
		FROM #queuesmartalarms qa
		INNER JOIN tbl_queue_printer_map map
		ON map.mapQueue = qa.QueueId
		GROUP BY qa.AlarmSeverityId, map.mapPhyPrinter)
	INSERT #printersmartalarms
		(AlarmRank, AlarmSeverityId, PrinterId, AlarmCount)
	SELECT
		ROW_NUMBER() OVER(PARTITION BY PrinterId ORDER BY AlarmSeverityId DESC) AS RowNo
		,AlarmSeverityId
		,PrinterId
		,AlarmCount
	FROM a
	ORDER BY PrinterId, AlarmSeverityId DESC


	-- Merge tables
	UPDATE p
	SET p.HighestSmartAlarmLevel = psa.AlarmSeverityId
		,p.SmartAlarmCount = psa.AlarmCount
	FROM #printer p
	INNER JOIN #printersmartalarms psa
		ON p.PrinterId = psa.PrinterId
		AND psa.AlarmRank = 1

	UPDATE #printer
	SET HighestTotalAlarmLevel = 
			CASE WHEN PhysicalStatusSeverity > ISNULL(HighestSmartAlarmLevel,0) THEN PhysicalStatusSeverity
				 ELSE ISNULL(HighestSmartAlarmLevel,0) 
			END


	-- Return results
	SELECT	@oOKCount = COUNT(*) FROM #printer WHERE HighestTotalAlarmLevel = 0
	SELECT	@oWarningCount = COUNT(*) FROM #printer WHERE HighestTotalAlarmLevel = 1
	SELECT	@oErrorCount = COUNT(*) FROM #printer WHERE HighestTotalAlarmLevel = 2

	IF @iSilent = 0
		SELECT * FROM #printer
		WHERE (@iincludeOK = 1 AND (PhysicalStatusSeverity IN( 0,-1) AND ISNULL(HighestSmartAlarmLevel,0) = 0))
		OR (@iincludeWarnings = 1 AND (PhysicalStatusSeverity = 1 OR ISNULL(HighestSmartAlarmLevel,0) = 1))
		OR (@iincludeErrors = 1 AND (PhysicalStatusSeverity = 2 OR ISNULL(HighestSmartAlarmLevel,0) = 2))




	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)


	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_queue_get_related_queues_by_queue') IS NOT NULL
	DROP PROCEDURE sp_queue_get_related_queues_by_queue
GO

CREATE PROCEDURE sp_queue_get_related_queues_by_queue
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-09
Description: Get queues that are related to the given queue, 
			 i.e in same folder and of same make
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-03
Description: Do not include deleted queues (queuestatus = 3)
************************************************************/
	@iqueueId			varchar(64) = NULL
	,@iincludeSelf		bit = 0
AS
BEGIN

	
	SELECT b.queueId, b.queueName 
	FROM 
	(select * from tbl_queue q1
		join tbl_model m1
		on q1.queueModelId = m1.modelId) a
	join 	
	(select * from tbl_queue q1
	join tbl_model m1
		on q1.queueModelId = m1.modelId) b
	on a.modelBrandId = b.modelBrandId
		and a.queueRegion = b.queueRegion
		and a.queueId <> b.queueId
		and a.queueId = @iqueueId
	where b.queueStatus <> 3
	
	UNION

	select queueId, queueName 
	from tbl_queue q
	where q.queueId = @iqueueId AND @iincludeSelf = 1	

	ORDER BY queueName

	RETURN (0)

END
GO

IF OBJECT_ID('sp_client_billing_get_sub') IS NOT NULL
	DROP PROCEDURE sp_client_billing_get_sub
GO

CREATE PROCEDURE sp_client_billing_get_sub
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-01
Description: Given list of cb ids, return details about them
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF object_id('tempdb..#cb') IS NULL
		RETURN (100047) -- Client Billing get sub - #cb table must be created first



	SELECT
		cb.cb_id Id
		,cb_parentId ParentId
		,cb_type [Type]
		,cb_active Active
		,cb_code Code
		,cb_name [Name]
		,cb_comment Comment
		,cb_creator_name CreatorName
		,cb_creator_domain CreatorDomain
		,cb_creation_date CreationDate
		,cb_active_date StartDate
		,cb_deactive_date EndDate
		,CAST(1 AS bit) AS ValidForCurrentUser
		,cbChosen.Rights
	FROM tbl_client_billing cb
	INNER JOIN #cb cbChosen
		ON cb.cb_id = cbChosen.cb_id
	ORDER BY cb_code

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_client_billing_validate') IS NOT NULL
	DROP PROCEDURE sp_client_billing_validate
GO

CREATE PROCEDURE sp_client_billing_validate
/************************************************************
Created by:  Henrik Linder
Creation date: 2008-12-22
Description: Check if the given user can use the given billing code. (Currently no user-specific checks.
-------------------------------------------------------------
Mofified by:  Henrik Linder
Modification date: 2009-09-30
Description: Added check to see if this user can use the billing code
-------------------------------------------------------------
Mofified by:  Erik Norell
Modification date: 2009-12-02
Description: Added follwoing functions:
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF
The FetchStatement in ODBC would otherwise return false.
************************************************************/
	@iBillingCode		nvarchar(128)
	,@iUserName			nvarchar(510)	= NULL
	,@iDomain			nvarchar(510)	= NULL
AS
BEGIN
	DECLARE @CurrentTimestamp datetime
	SET @CurrentTimestamp = getdate()

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	IF @iBillingCode IS NULL OR LEN(@iBillingCode) = 0
		RETURN(0)

	IF NOT EXISTS (SELECT 1 FROM tbl_client_billing	WHERE cb_code = @iBillingCode AND cb_active = 1 AND cb_type = 1)
		RETURN (100036)

	IF NOT EXISTS (SELECT 1 FROM tbl_client_billing	WHERE cb_code = @iBillingCode AND ISNULL(cb_active_date,'20000101') < @CurrentTimestamp)
		RETURN (100037)

	IF NOT EXISTS (SELECT 1 FROM tbl_client_billing	WHERE cb_code = @iBillingCode AND ISNULL(cb_deactive_date,'99991231') > @CurrentTimestamp)
		RETURN (100038)



	IF  EXISTS (SELECT 1 FROM tbl_property
		WHERE propertyGroup = 'ClientBilling'
		AND propertyName = 'cbLimitMode'
		AND propertyValueNumeric > 0)
	BEGIN
		DECLARE @CurrentBillingCodeId bigint
	
		SELECT @CurrentBillingCodeId = cb_id
		FROM tbl_client_billing	
		WHERE cb_code = @iBillingCode AND cb_active = 1 AND cb_type = 1


		DECLARE @cbc TABLE (cb_id bigint, Rights int)

		INSERT @cbc
		EXEC sp_client_billing_get_for_user
			@iUserName				= @iUserName
			,@iDomain				= @iDomain
			,@iRights				= 1 -- only "use" rights is necesarry now
			,@iIncludeFolders		= 0
			,@iIncludeBillingCodes	= 1
			,@iVerbose				= 0


		IF NOT EXISTS (SELECT 1 FROM @cbc WHERE cb_id = @CurrentBillingCodeId)
			RETURN (100062) --	User is not authorised to use this Billing Code


	END

	RETURN (0)

END
GO

IF OBJECT_ID('sp_ticket_register_new_chk') IS NOT NULL
	DROP PROCEDURE sp_ticket_register_new_chk
GO

CREATE PROCEDURE sp_ticket_register_new_chk
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-18
Description: Check if a ticket can be registered to tbl_ticket_log
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-08-31
Description: Added support for scan and fax
************************************************************/
	@iPrinterId			varchar(64)
	,@iQueueId			varchar(64)		= NULL
	,@iJobName			nvarchar(510)	= NULL
	,@iUserName			nvarchar(510)
	,@iDomain			nvarchar(510)
	,@iJobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
	,@iPagesBW			int
	,@iPagesColor		int
	,@iPaperSize		tinyint
	,@iDuplex			bit
	,@iSize				int = 0
	,@iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL
	,@iPricePlan		varchar(64)		= NULL
	,@iTicketPrice		int				= NULL
	,@iBillingCode		nvarchar(128)	= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	
	-- Checks

	-- 1. Billing Code
	EXEC @ReturnStatus = sp_client_billing_validate @iBillingCode	= @iBillingCode
													,@iUserName		= @iUserName
													,@iDomain		= @iDomain
	IF @ReturnStatus <> 0
		RETURN (@ReturnStatus)

	-- 2. Page count
	IF @iPagesBW + @iPagesColor <= 0
		RETURN (100039)

	-- 3. Price >= 0
	IF ISNULL(@iTicketPrice,0) < 0
		RETURN (100040)

	-- 4. PrinterId. (active and network printer)
	IF NOT EXISTS (SELECT 1 FROM tbl_printer WHERE printerId = @iPrinterId AND adminStatus <> 3 AND printerType = 0)
		RETURN (100041)

	-- 5. JobType
	IF @iJobType NOT IN (1,2,3,4)
		RETURN (100042)

	-- 6. Does queue match printer?
	IF LEN(ISNULL(@iQueueId,'')) > 0
		IF NOT EXISTS (SELECT 1 FROM tbl_queue_printer_map WHERE mapPhyPrinter = @iPrinterId AND mapQueue = @iQueueId)
			RETURN (100043)

--	-- 7. JobType fax not implemented
--	IF @iJobType = 3
--		RETURN (100044)
--
--	-- 8. JobType scan not implemented
--	IF @iJobType = 4
--		RETURN (100045)

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO
IF OBJECT_ID('sp_report_user_get') IS NOT NULL
	DROP PROCEDURE sp_report_user_get
GO

CREATE PROCEDURE sp_report_user_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-24
Description: Get user id of a user in tbl_report_users. Option to create this user if non-existing 
************************************************************/
	@iUserName				nvarchar(510)
	,@iDomain				nvarchar(510)
	,@iCreateIfNotExists	bit = 1
	,@oUserId				int			OUTPUT
AS
BEGIN


	SELECT @oUserId = UserId
	FROM tbl_report_users
	WHERE UserName = @iUserName
	AND	Domain = @iDomain

	IF @oUserId IS NULL AND @iCreateIfNotExists = 1
	BEGIN
		INSERT tbl_report_users
		(UserName, Domain, RegDate)
		VALUES
		(@iUserName, @iDomain, getdate())

		SELECT @oUserId  = SCOPE_IDENTITY()

	END


	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_report_group_get_recursive') IS NOT NULL
	DROP PROCEDURE sp_report_group_get_recursive
GO

CREATE PROCEDURE sp_report_group_get_recursive
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-11-24
Description:  Given group or umbrella id, get all subgroups recursively
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupId				int = NULL
	,@iUmbrellaId			int = NULL
	,@iCrossUmbrella		bit = 1	
	,@iSilent				bit = 0
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Check input params

	IF @iUmbrellaId IS NOT NULL AND @iGroupId IS NOT NULL
		RETURN	(100302) --	Cannot specify both group and umbrella.

	IF @iUmbrellaId IS NULL AND @iGroupId IS NULL
		RETURN	(100308) --	Must specify either group or umbrella.


	IF @iUmbrellaId IS NOT NULL
		AND NOT EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE ISNULL(@iUmbrellaId,UmbrellaId) = UmbrellaId)
		RETURN (100300) --	Umbrella does not exist


	IF @iGroupId IS NOT NULL
		AND NOT EXISTS (SELECT * FROM vw_report_group WHERE ISNULL(@iGroupId,GroupId) = GroupId)
		RETURN (100301) --	Group does not exist

	-- do stuff

	IF object_id('tempdb..#groups') IS NULL
		CREATE TABLE #groups (GroupId int)


	IF @iUmbrellaId IS NOT NULL
	BEGIN
		IF @iCrossUmbrella = 1
			INSERT #groups (GroupId)
			SELECT DISTINCT 
				GroupId 
			FROM vw_report_group_display
			WHERE RootUmbrellaId = @iUmbrellaId

		ELSE
			INSERT #groups (GroupId)
			SELECT DISTINCT 
				GroupId 
			FROM vw_report_group_display
			WHERE UmbrellaId = @iUmbrellaId
				AND UmbrellaId = RootUmbrellaId
	END
	ELSE -- GroupId specified
	BEGIN

		SELECT @iUmbrellaId = UmbrellaId FROM vw_report_group WHERE GroupId = @iGroupId;
		
		WITH a (GroupId) AS
			(SELECT @iGroupId
			UNION ALL
			SELECT GroupChildId FROM tbl_report_group_group gg
			INNER JOIN a
				ON	a.GroupId = gg.GroupParentId)
		INSERT #groups (GroupId)
		SELECT DISTINCT
			gd.GroupId 
		FROM vw_report_group_display gd
		INNER JOIN a ON a.GroupId = gd.GroupId
		WHERE (@iCrossUmbrella = 1 AND RootUmbrellaId = @iUmbrellaId)
			OR (@iCrossUmbrella = 0 AND UmbrellaId = @iUmbrellaId AND UmbrellaId = RootUmbrellaId)

	END

	IF @iSilent = 0
		SELECT GroupId FROM #groups




	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_printservice_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_printservice_ins
GO

CREATE PROCEDURE sp_cirrato_printservice_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-16
Description:  Insert xml data for print diversion
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iTicketId			varchar(64)
	,@iJobTargetId		uniqueidentifier
	,@iJobData			nvarchar(max)


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- checks
	-- ticket exists?
	IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iticketId)
		RETURN (100004)

	-- ticket has feature = 4?
	IF NOT EXISTS (SELECT 1 FROM tbl_ticket_feature WHERE ticketFeatureTicket = @iticketId and ticketFeatureFeature=4)
		RETURN (100150) -- Ticket does not have feature 4 (TF_PRINTSERVICE_LOCK)

	-- target exists?
	IF NOT EXISTS (SELECT 1 FROM tbl_cirrato_printservice_target WHERE targetId = @iJobTargetId)
		RETURN (100151) -- Print service target does not exist


	-- do stuff

	INSERT tbl_cirrato_printservice (ticketId, jobTarget,jobData)
	VALUES (@iTicketId, @iJobTargetId, @iJobData)


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_printservice_target_get') IS NOT NULL
	DROP PROCEDURE sp_cirrato_printservice_target_get
GO

CREATE PROCEDURE sp_cirrato_printservice_target_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-18
Description: 
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 
Description: 
************************************************************/
	@iTargetId			uniqueidentifier = NULL
AS
BEGIN

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int

	SELECT
		*
	FROM tbl_cirrato_printservice_target
	WHERE ISNULL(@iTargetId,targetId) = targetId
	ORDER BY targetName

	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_client_billing_chk') IS NOT NULL
	DROP PROCEDURE sp_client_billing_chk
GO

CREATE PROCEDURE sp_client_billing_chk
/************************************************************
Created by:  Henrik Linder
Creation date: 2008-12-22
Description: Return any warning messages for a given node
************************************************************/
	@icb_id			bigint
AS
BEGIN

	CREATE TABLE #Warning (ErrorNo int, SeverityId int)

	DECLARE @cb_parentId bigint
			,@cb_name	 nvarchar(510)

	SELECT TOP 1
			@cb_parentId	= cb_parentId
		   ,@cb_name		= cb_name
	FROM tbl_client_billing
	WHERE cb_id = @icb_id


	-- Check for duplicate names in same node
	IF EXISTS ( SELECT 1 FROM
				tbl_client_billing
				WHERE cb_id			<> @icb_id
				AND @cb_parentId	= cb_parentId
				AND @cb_name		= cb_name
				AND cb_type			=1 )
	INSERT #Warning (ErrorNo, SeverityId) VALUES(200000,1)
	
--  sample of multiple messages:
--	INSERT #Warning (ErrorNo, SeverityId) VALUES(200001,1)
--	INSERT #Warning (ErrorNo, SeverityId) VALUES(200002,2)
--	INSERT #Warning (ErrorNo, SeverityId) VALUES(200003,1)
--	INSERT #Warning (ErrorNo, SeverityId) VALUES(200004,16)

	SELECT * FROM #Warning

	DROP TABLE #Warning

	RETURN (0)

END
GO

IF OBJECT_ID('sp_client_billing_del') IS NOT NULL
	DROP PROCEDURE sp_client_billing_del
GO

CREATE PROCEDURE sp_client_billing_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2008-12-18
Description: Delete a node or billing code
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2008-12-22
Description: Do not allow root node to be deleted
************************************************************/
	@icb_id			bigint
AS
BEGIN

	-- Return error if user tries to delete root node
	IF (SELECT cb_ParentId FROM tbl_client_billing WHERE cb_id = @icb_id) = 0
		RETURN 100003

	-- Delete current node/billing code and direct children billing codes
	UPDATE tbl_client_billing
		SET cb_type = cb_type + 10
	WHERE (cb_id = @icb_id AND cb_type IN (1,0))
	OR (cb_parentId = @icb_id AND cb_type=1)

	-- Delete all underlying nodes
	DECLARE @children table (cb_id bigint)
	DECLARE @cb_id bigint

	INSERT @children (cb_id)
	SELECT cb_id 
	FROM tbl_client_billing
	WHERE cb_parentId = @icb_id AND cb_type=0

	WHILE EXISTS(SELECT 1 FROM @children)
	BEGIN
		SELECT TOP 1 @cb_id = cb_id FROM @children
		EXEC sp_client_billing_del @cb_id
		DELETE @children WHERE cb_id = @cb_id 
	END


	RETURN (0)

END
GO

IF OBJECT_ID('sp_client_billing_enabled_for_grouplist') IS NOT NULL
	DROP PROCEDURE sp_client_billing_enabled_for_grouplist
GO

CREATE PROCEDURE sp_client_billing_enabled_for_grouplist
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-30
Description: Given a list of groups that the user is a member of, indicate if the user is allowed to use CB at all.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupList			varchar(8000)
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Check global setting (row missing = do not limit use)
	IF NOT EXISTS 
			(SELECT 1 FROM tbl_property 
			WHERE propertyGroup = 'ClientBilling' 
			AND propertyName = 'cbLimitMode'
			AND propertyValueNumeric > 0)
		RETURN (0)


	-- Get list of groups that have CB enabled
	CREATE TABLE #EnabledGroups (GroupName nvarchar(512) COLLATE DATABASE_DEFAULT)
	INSERT #EnabledGroups (GroupName)
	SELECT
		propertyValue
	FROM tbl_property 
	WHERE PropertyGroup = 'ClientBilling'
	AND propertyName LIKE 'cbAllowUseGroup%'
	AND LEN(LTRIM(RTRIM(propertyValue))) > 0


	-- No groups = everyone can use CB
	IF NOT EXISTS (SELECT 1 FROM #EnabledGroups)
		RETURN (0)


	-- split incoming grouplist

	CREATE TABLE #CurrentUserGroups (GroupName nvarchar(512) COLLATE DATABASE_DEFAULT)

	IF LEFT(@iGroupList,1) <> '\' SET @iGroupList = '\' + @iGroupList

	INSERT #CurrentUserGroups (GroupName)
	SELECT ValueTypeId 
	FROM  dbo.fn_value_list_parse (@iGroupList)	
	WHERE LEN(LTRIM(RTRIM(ValueTypeId))) > 0

	IF NOT EXISTS
		(SELECT * FROM #EnabledGroups eg
		INNER JOIN #CurrentUserGroups cg
			ON LOWER(eg.GroupName) = LOWER(cg.GroupName))
		RETURN (100046) -- User is not authorised to use Client Billing





	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_client_billing_get_for_user') IS NOT NULL
	DROP PROCEDURE sp_client_billing_get_for_user
GO

CREATE PROCEDURE sp_client_billing_get_for_user
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-30
Description: Get list of valid billing codes for the user, given the requested rights
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUserName				nvarchar(510)
	,@iDomain				nvarchar(510)
	,@iRights				int = 1 -- 1=Use CB, 2=..., 4=...
	,@iIncludeFolders		bit = 0
	,@iIncludeBillingCodes	bit = 1
	,@iVerbose				bit = 1 -- Return only client billing IDs, or full details about the codes?
	,@iIncludeAllFolders	bit = 1
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int
	DECLARE @CurrentTimestamp		datetime
	SET		@CurrentTimestamp		= getdate()


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	DECLARE @Type TABLE ([Type] smallint)

	IF @iIncludeFolders = 1			INSERT @Type ([Type]) VALUES (0)
	IF @iIncludeBillingCodes = 1	INSERT @Type ([Type]) VALUES (1)



	DECLARE @cb  TABLE 	(cb_id	bigint
						,Rights int)

	-- Check if cbLimitMode = 0 (if so, all codes are allowed)

	IF NOT EXISTS (SELECT 1 FROM tbl_property
		WHERE propertyGroup = 'ClientBilling'
		AND propertyName = 'cbLimitMode'
		AND propertyValueNumeric > 0)

	BEGIN
		INSERT @cb (cb_id, Rights)
		SELECT
			cb_id
			,@iRights
		FROM tbl_client_billing cb
		INNER JOIN @Type t
			ON cb.cb_Type = t.Type
		WHERE 	ISNULL(cb_active_date,'20000101') <= @CurrentTimestamp
		AND		ISNULL(cb_deactive_date,'99991231') >= @CurrentTimestamp
		AND		cb_active = 1
	END
	ELSE

	BEGIN -- limitMode = 1 or 2


		-- Get codes for directly assigned user rights
		INSERT @cb (cb_id, Rights)
		SELECT 
			cb_id
			,ur.Rights
		FROM tbl_client_billing cb
		INNER JOIN 	tbl_client_billing_user_rights ur
			ON cb.cb_id = ClientBillingId
			AND ur.Rights & @iRights > 0		-- Position 1 = allow CB code use
			AND		ISNULL(ur.StartDate,'20000101') <= @CurrentTimestamp
			AND		ISNULL(ur.EndDate,'99991231') >= @CurrentTimestamp
		INNER JOIN tbl_report_users u
			ON u.UserId = ur.UserId
		WHERE	u.UserName = @iUserName
		AND		u.Domain = @iDomain
		AND		ISNULL(cb_active_date,'20000101') <= @CurrentTimestamp
		AND		ISNULL(cb_deactive_date,'99991231') >= @CurrentTimestamp
		AND		cb_active = 1

--		UNION -- ta med mappar, s�tt right = 0
		IF @iIncludeAllFolders = 1
			INSERT @cb (cb_id, Rights)
			SELECT 
				cb_id
				,0
			FROM tbl_client_billing cb
			WHERE cb_type = 0
			AND		cb_active = 1
			AND		cb_parentId = 0

		-- TODO:
		-- Get codes for assigned group rights
		-- Get codes for assigned umbrella rights

	END;



	-- Add descendants to each node recursively 
	WITH RecTopCB (cb_id, Rights) AS 
		(
		SELECT cb.cb_id, c.Rights FROM tbl_client_billing cb
		INNER JOIN @cb c
			ON c.cb_id = cb.cb_parentId

		UNION ALL
		SELECT cb.cb_id, RecTopCB.Rights FROM tbl_client_billing cb
		INNER JOIN RecTopCB
			ON RecTopCB.cb_id = cb.cb_parentId
		)
	INSERT @cb (cb_id, Rights)
	SELECT cb_id, Rights FROM RecTopCB


	-- Aggregate rights and remove duplicates (may happen if rights are specified both on user and groups basis, for example)
	CREATE TABLE #cb	(cb_id	bigint
						,Rights int)


	INSERT #cb (cb_id, Rights)
	SELECT
		c.cb_id
		,SUM(c.Rights)
	FROM @cb c
	INNER JOIN tbl_client_billing cb
		ON c.cb_id = cb.cb_id
	INNER JOIN @Type t
		ON cb.cb_Type = t.Type
	WHERE t.Type = 0 or Rights > 0
	GROUP BY c.cb_id

	-- Return results
	IF @iVerbose = 0
		SELECT DISTINCT cb_id, Rights FROM #cb
	ELSE
	BEGIN
		EXEC @ReturnStatus = sp_client_billing_get_sub
		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 OR @ReturnStatus <> 0
			GOTO PROC_ERROR
	END

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)


	PROC_ERROR:

	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_client_billing_get_sub') IS NOT NULL
	DROP PROCEDURE sp_client_billing_get_sub
GO

CREATE PROCEDURE sp_client_billing_get_sub
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-01
Description: Given list of cb ids, return details about them
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF object_id('tempdb..#cb') IS NULL
		RETURN (100047) -- Client Billing get sub - #cb table must be created first



	SELECT
		cb.cb_id Id
		,cb_parentId ParentId
		,cb_type [Type]
		,cb_active Active
		,cb_code Code
		,cb_name [Name]
		,cb_comment Comment
		,cb_creator_name CreatorName
		,cb_creator_domain CreatorDomain
		,cb_creation_date CreationDate
		,cb_active_date StartDate
		,cb_deactive_date EndDate
		,CAST(1 AS bit) AS ValidForCurrentUser
		,cbChosen.Rights
	FROM tbl_client_billing cb
	INNER JOIN #cb cbChosen
		ON cb.cb_id = cbChosen.cb_id
	ORDER BY cb_code

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_client_billing_ins') IS NOT NULL
	DROP PROCEDURE sp_client_billing_ins
GO

CREATE PROCEDURE sp_client_billing_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2008-12-18
Description: Insert a new node or billing code
-------------------------------------------------------------
Mofified by:  Henrik Linder
Modification date: 2009-01-26
Description: Do not allow duplicate region names under the same parent.
-------------------------------------------------------------
Mofified by:  Henrik Linder
Modification date: 2009-03-12
Description: Do not allow empty names.
************************************************************/
		 @icb_parentId bigint
		,@icb_type smallint
		,@icb_code nvarchar (128) = NULL
		,@icb_name nvarchar (510)
		,@icb_comment nvarchar (510) = NULL
		,@icb_creator_name nvarchar (510)
		,@icb_creator_domain nvarchar (510)
AS
BEGIN

	IF EXISTS ( SELECT 1 FROM
				tbl_client_billing
				WHERE cb_code = @icb_code
				AND cb_type IN (0,1))
	BEGIN
		RETURN (100001)	-- f�r ej s�tta id som anv�nds p� annat h�ll
	END


	IF EXISTS ( SELECT 1 FROM
				tbl_client_billing
				WHERE cb_name = @icb_name
				AND cb_type = 0
				AND cb_parentId = @icb_parentId)
	BEGIN
		RETURN (100010)	-- Do not allow duplicate region names under the same parent.
	END

	IF LEN(@icb_name) = 0
		RETURN (100030)
	
	INSERT tbl_client_billing
		(cb_parentId
		,cb_active
		,cb_type
		,cb_code
		,cb_name
		,cb_comment
		,cb_creator_name
		,cb_creator_domain
		,cb_creation_date
		,cb_active_date
		,cb_deactive_date)
	VALUES 		
		(@icb_parentId
		,1
		,@icb_type
		,ISNULL(@icb_code,'')
		,@icb_name
		,ISNULL(@icb_comment,'')
		,@icb_creator_name
		,@icb_creator_domain
		,CURRENT_TIMESTAMP
		,NULL
		,NULL)

	-- Return any warning messages to client
	EXEC sp_client_billing_chk @@IDENTITY

	RETURN (0)

END
GO

IF OBJECT_ID('sp_client_billing_node_get_path') IS NOT NULL
	DROP PROCEDURE sp_client_billing_node_get_path
GO

CREATE PROCEDURE sp_client_billing_node_get_path
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-05
Description:  Get full path of a CB node
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iClientBillingId			bigint
	,@iSeparator				nvarchar(510)	= ' / '	
	,@oPath						nvarchar(510)	OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Basic checks
	IF NOT EXISTS (SELECT 1 FROM tbl_client_billing	WHERE cb_id = @iClientBillingId AND cb_active = 1 AND cb_type IN (0,1))
		RETURN (100036)

	-- Get the path
	SET @oPath = NULL;
	
	WITH RecTopCB (cb_id, rowno, cbpath ) AS 
		(SELECT cb.cb_parentId, 1, cast(cb.cb_name as nvarchar(512)) FROM tbl_client_billing cb WHERE cb.cb_id = @iClientBillingId
		UNION ALL
		SELECT 
			cb.cb_parentId
			,RecTopCB.rowno+1
			,CONVERT(nvarchar(512),cb.cb_name + ' / ' +RecTopCB.cbpath  )
		FROM tbl_client_billing cb 
		INNER JOIN RecTopCB
			ON cb.cb_id = RecTopCB.cb_id)
	SELECT @oPath = cbpath FROM RecTopCB WHERE cb_id = 0


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_client_billing_node_get_users') IS NOT NULL
	DROP PROCEDURE sp_client_billing_node_get_users
GO

CREATE PROCEDURE sp_client_billing_node_get_users
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-02
Description:  Get all users and their access rights to a given CB node
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iClientBillingId bigint
	,@iUserName				nvarchar(510)	= NULL
	,@iDomain				nvarchar(510)	= NULL
	,@iRights				int				
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Basic checks
	IF NOT EXISTS (SELECT 1 FROM tbl_client_billing	WHERE cb_id = @iClientBillingId AND cb_active = 1 AND cb_type IN (0,1))
		RETURN (100036)

	-- Only return results if CB limiting is enabled
	IF EXISTS (SELECT 1 FROM tbl_property
		WHERE propertyGroup = 'ClientBilling'
		AND propertyName = 'cbLimitMode'
		AND propertyValueNumeric > 0)
	BEGIN

		-- Get node and all ancestors
		DECLARE @cb  TABLE 	(cb_id	bigint);

		WITH RecTopCB (cb_id) AS 
			(SELECT cb.cb_parentId FROM tbl_client_billing cb WHERE cb.cb_id = @iClientBillingId
			UNION ALL
			SELECT cb.cb_parentId FROM tbl_client_billing cb 
			INNER JOIN RecTopCB
				ON cb.cb_id = RecTopCB.cb_id)
		INSERT @cb (cb_id)
		SELECT cb_id FROM RecTopCB
		UNION
		SELECT @iClientBillingId

		-- Get combined rights for these
		SELECT 
			u.UserId
			,u.UserName
			,u.Domain
			,SUM(ur.Rights) Rights
			,CASE WHEN DirectAccess.ClientBillingId IS NULL THEN 1 ELSE 0 END AS Inherited
		FROM @cb cb
		INNER JOIN tbl_client_billing_user_rights ur
			ON cb.cb_id = ur.ClientBillingId
		INNER JOIN tbl_report_users u
			ON u.UserId = ur.UserId
		LEFT JOIN tbl_client_billing_user_rights DirectAccess
			ON cb.cb_id = ur.ClientBillingId
			AND DirectAccess.UserId = ur.UserId
			AND DirectAccess.ClientBillingId = @iClientBillingId
		WHERE ISNULL(@iUserName, u.UserName) = u.UserName
			AND ISNULL(@iDomain, u.Domain) = u.Domain
			AND ur.Rights & @iRights > 0
		GROUP BY
			u.UserId
			,u.UserName
			,u.Domain
			,DirectAccess.ClientBillingId
		ORDER BY 
			u.Domain
			,u.UserName

	END



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_client_billing_node_get_user_rights') IS NOT NULL
	DROP PROCEDURE sp_client_billing_node_get_user_rights
GO

CREATE PROCEDURE sp_client_billing_node_get_user_rights
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-02
Description:  Return the rights of a given user on a given node
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iClientBillingId		bigint
	,@iUserName				nvarchar(510)
	,@iDomain				nvarchar(510)
	,@oRights				int				OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oRights = 0

	DECLARE @cb TABLE	(UserId		int
						,UserName	nvarchar(510)
						,Domain		nvarchar(510)
						,Rights		int
						,Inherited	bit)

	INSERT @cb
	EXEC @ReturnStatus = sp_client_billing_node_get_users	
		@iClientBillingId	= @iClientBillingId
		,@iUserName			= @iUserName
		,@iDomain			= @iDomain
		,@iRights			= 7 -- include all types of rights in the result

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	SELECT @oRights = ISNULL(Rights,0) FROM @cb


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_client_billing_search') IS NOT NULL
	DROP PROCEDURE sp_client_billing_search
GO

CREATE PROCEDURE sp_client_billing_search
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-11
Description: Search for billing codes / nodes
-------------------------------------------------------------
Mofified by:  Henrik Linder
Modification date: 2009-07-21
Description: Added result limit
-------------------------------------------------------------
Mofified by:  Henrik Linder
Modification date: 2009-09-30
Description: Added checks
	* Only list codes that this user can use
	* Only list codes that are currently active 
************************************************************/
	@iParentId	bigint			= NULL
	,@iType		smallint		= NULL
	,@iCode		nvarchar (128)	= NULL
	,@iName		nvarchar (510)	= NULL
	,@iComment	nvarchar (510)	= NULL
	,@iUserName	nvarchar (510)	= NULL -- currently logged in user
	,@iDomain	nvarchar (510)	= NULL -- currently logged in user
	,@iResultCount int			= 100
AS
BEGIN
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF @iCode IS NULL SET @iCode = '%'
	ELSE SET @iCode = '%' + UPPER(@iCode) + '%'

	IF @iName IS NULL SET @iName = '%'
	ELSE SET @iName = '%' + UPPER(@iName) + '%'

	IF @iComment IS NULL SET @iComment = '%'
	ELSE SET @iComment = '%' + UPPER(@iComment) + '%'

	-- Handle returning of correct types
	DECLARE @Type TABLE ([Type] smallint)
	DECLARE @iIncludeFolders bit, @iIncludeBillingCodes bit

		SET @iIncludeFolders = 0
		SET @iIncludeBillingCodes = 0

	IF @iType IS NULL
	BEGIN
		INSERT @Type ([Type]) VALUES (0)
		INSERT @Type ([Type]) VALUES (1)
		SET @iIncludeFolders = 1
		SET @iIncludeBillingCodes = 1
	END
	ELSE
	BEGIN
		INSERT @Type ([Type]) VALUES (@iType)

		IF @iType = 0
			SET @iIncludeFolders = 1
		ELSE
			SET @iIncludeBillingCodes = 1
	END

	-- Check which codes this user can use
	DECLARE @cbAllowed TABLE (cb_id bigint, Rights int)
	INSERT @cbAllowed 
	EXEC sp_client_billing_get_for_user
		@iUserName				= @iUserName
		,@iDomain				= @iDomain
		,@iRights				= 1 -- only "use" rights is necesarry now
		,@iIncludeFolders		= @iIncludeFolders
		,@iIncludeBillingCodes	= @iIncludeBillingCodes
		,@iVerbose				= 0 

	-- Return results
	SELECT TOP(@iResultCount)
		cb.cb_id Id
		,cb_parentId ParentId
		,cb_type [Type]
		,cb_active Active
		,cb_code Code
		,cb_name [Name]
		,cb_comment Comment
		,cb_creator_name CreatorName
		,cb_creator_domain CreatorDomain
		,cb_creation_date CreationDate
		,cb_active_date StartDate
		,cb_deactive_date EndDate
		,CAST(1 AS bit) AS ValidForCurrentUser
		,cba.Rights
	FROM tbl_client_billing cb
	INNER JOIN @Type t
		ON cb.cb_type = t.[Type]
	INNER JOIN @cbAllowed cba
		ON cba.cb_id = cb.cb_id
	WHERE ISNULL(@iParentId, cb_parentId) = cb_parentId
		AND UPPER(cb_code) LIKE @iCode
		AND UPPER(cb_name) LIKE @iName
		AND UPPER(cb_comment) LIKE @iComment
	ORDER BY cb_code

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

END
GO

IF OBJECT_ID('sp_client_billing_search_simple') IS NOT NULL
	DROP PROCEDURE sp_client_billing_search_simple
GO

CREATE PROCEDURE sp_client_billing_search_simple
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-21
Description: Search for billing codes / nodes
-------------------------------------------------------------
Mofified by:  Henrik Linder
Modification date: 2009-09-30
Description: Added checks
	* Only list codes that this user can use
	* Only list codes that are currently active 
************************************************************/
	@iParentId	bigint			= NULL
	,@iType		smallint		= NULL
	,@iSearchString	nvarchar (510)
	,@iUserName	nvarchar (510)	= NULL -- currently logged in user
	,@iDomain	nvarchar (510)	= NULL -- currently logged in user
	,@iResultCount int			= 100
AS
BEGIN
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	SET @iSearchString = '%' + UPPER(@iSearchString) + '%'


	-- Handle returning of correct types
	DECLARE @Type TABLE ([Type] smallint)
	DECLARE @iIncludeFolders bit, @iIncludeBillingCodes bit

		SET @iIncludeFolders = 0
		SET @iIncludeBillingCodes = 0

	IF @iType IS NULL
	BEGIN
		INSERT @Type ([Type]) VALUES (0)
		INSERT @Type ([Type]) VALUES (1)
		SET @iIncludeFolders = 1
		SET @iIncludeBillingCodes = 1
	END
	ELSE
	BEGIN
		INSERT @Type ([Type]) VALUES (@iType)

		IF @iType = 0
			SET @iIncludeFolders = 1
		ELSE
			SET @iIncludeBillingCodes = 1
	END

	



	-- Check which codes this user can use
	DECLARE @cbAllowed TABLE (cb_id bigint, Rights int)
	INSERT @cbAllowed 
	EXEC sp_client_billing_get_for_user
		@iUserName				= @iUserName
		,@iDomain				= @iDomain
		,@iRights				= 1 -- only "use" rights is necesarry now
		,@iIncludeFolders		= @iIncludeFolders
		,@iIncludeBillingCodes	= @iIncludeBillingCodes
		,@iVerbose				= 0 


	-- Return results
	SELECT TOP(@iResultCount)
		cb.cb_id Id
		,cb_parentId ParentId
		,cb_type [Type]
		,cb_active Active
		,cb_code Code
		,cb_name [Name]
		,cb_comment Comment
		,cb_creator_name CreatorName
		,cb_creator_domain CreatorDomain
		,cb_creation_date CreationDate
		,cb_active_date StartDate
		,cb_deactive_date EndDate
		,CAST(1 AS bit) AS ValidForCurrentUser
		,cba.Rights
	FROM tbl_client_billing cb
	INNER JOIN @Type t
		ON cb.cb_type = t.[Type]
	INNER JOIN @cbAllowed cba
		ON cba.cb_id = cb.cb_id
	WHERE ISNULL(@iParentId, cb_parentId) = cb_parentId
		AND (UPPER(cb_code) LIKE @iSearchString
		OR UPPER(cb_name) LIKE @iSearchString
		OR UPPER(cb_comment) LIKE @iSearchString)
	ORDER BY cb_code


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

END
GO

IF OBJECT_ID('sp_client_billing_upd') IS NOT NULL
	DROP PROCEDURE sp_client_billing_upd
GO

CREATE PROCEDURE sp_client_billing_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2008-12-18
Description: Change a node or billing code
-------------------------------------------------------------
Mofified by:  Henrik Linder
Modification date: 2009-03-12
Description: Do not allow empty names.
************************************************************/
	@icb_id			bigint
	,@icb_code		nvarchar (128) = NULL
	,@icb_name		nvarchar (510)
	,@icb_comment	nvarchar (510) = NULL
AS
BEGIN

	IF EXISTS ( SELECT 1 FROM
				tbl_client_billing
				WHERE cb_id <> @icb_id
				AND cb_code = @icb_code
				AND cb_type IN (0,1))
	BEGIN
		RETURN (100000)	-- f�r ej s�tta id som anv�nds p� annat h�ll
	END

	IF LEN(@icb_name) = 0
		RETURN (100030)

	
	UPDATE tbl_client_billing
	SET 
		cb_code = ISNULL(@icb_code,cb_code)
		,cb_name = ISNULL(@icb_name, cb_name)
		,cb_comment = ISNULL(@icb_comment, cb_comment)
	WHERE cb_id = @icb_id

	-- Return any warning messages to client
	EXEC sp_client_billing_chk @icb_id

	RETURN (0)

END
GO

IF OBJECT_ID('sp_client_billing_user_rights_del') IS NOT NULL
	DROP PROCEDURE sp_client_billing_user_rights_del
GO

CREATE PROCEDURE sp_client_billing_user_rights_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-01
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iClientBillingId		bigint
	,@iUserName				nvarchar(510)
	,@iDomain				nvarchar(510)
	,@iRegUserName			nvarchar(510)	= NULL
	,@iRegDomain			nvarchar(510)	= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS (SELECT * FROM tbl_client_billing WHERE cb_id = @iClientBillingId)
		RETURN (100036) --	Billing code does not exist


	DECLARE @UserId int, @RegUserId int
	EXEC @ReturnStatus = sp_report_user_get	@iUserName				= @iUserName
											,@iDomain				= @iDomain
											,@iCreateIfNotExists	= 1
											,@oUserId				= @UserId OUTPUT
	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	IF NOT EXISTS (SELECT * FROM tbl_client_billing_user_rights WHERE UserId = @UserId AND ClientBillingId = @iClientBillingId)	
		RETURN (100061)	-- Billing Code does not have User right for user


	DELETE tbl_client_billing_user_rights
	WHERE UserId = @UserId AND ClientBillingId = @iClientBillingId

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)

END
GO

IF OBJECT_ID('sp_client_billing_user_rights_del_by_id') IS NOT NULL
	DROP PROCEDURE sp_client_billing_user_rights_del_by_id
GO

CREATE PROCEDURE sp_client_billing_user_rights_del_by_id
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-01
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iClientBillingId		bigint
	,@iUserId				int
	,@iRegUserName			nvarchar(510)	= NULL
	,@iRegDomain			nvarchar(510)	= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS (SELECT * FROM tbl_client_billing WHERE cb_id = @iClientBillingId)
		RETURN (100036) --	Billing code does not exist


--	DECLARE @RegUserId int
--	EXEC @ReturnStatus = sp_report_user_get	@iUserName				= @iRegUserName
--											,@iDomain				= @iRegDomain
--											,@iCreateIfNotExists	= 1
--											,@oUserId				= @RegUserId OUTPUT
--	SET @ErrorNo = @@ERROR
--	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
--		GOTO PROC_ERROR
--
--	IF @iUserId = @RegUserId
--		RETURN ()


	IF NOT EXISTS (SELECT * FROM tbl_client_billing_user_rights WHERE UserId = @iUserId AND ClientBillingId = @iClientBillingId)	
		RETURN (100061)	-- Billing Code does not have User right for user


	DELETE tbl_client_billing_user_rights
	WHERE UserId = @iUserId AND ClientBillingId = @iClientBillingId

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)

END
GO

IF OBJECT_ID('sp_client_billing_user_rights_ins') IS NOT NULL
	DROP PROCEDURE sp_client_billing_user_rights_ins
GO

CREATE PROCEDURE sp_client_billing_user_rights_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-01
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iClientBillingId		bigint
	,@iUserName				nvarchar(510)
	,@iDomain				nvarchar(510)
	,@iRights				int
	,@iIsRecursive			bit				= 1
	,@iStartDate			datetime		= NULL
	,@iEndDate				datetime		= NULL
	,@iRegUserName			nvarchar(510)	= NULL
	,@iRegDomain			nvarchar(510)	= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS (SELECT * FROM tbl_client_billing WHERE cb_id = @iClientBillingId)
		RETURN (100036) --	Billing code does not exist


	DECLARE @UserId int, @RegUserId int
	EXEC @ReturnStatus = sp_report_user_get	@iUserName				= @iUserName
											,@iDomain				= @iDomain
											,@iCreateIfNotExists	= 1
											,@oUserId				= @UserId OUTPUT
	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	IF EXISTS (SELECT * FROM tbl_client_billing_user_rights WHERE UserId = @UserId AND ClientBillingId = @iClientBillingId)	
		RETURN (100048) --	Billing Code / User right already exists


	IF @iRegUserName IS NOT NULL AND @iRegDomain IS NOT NULL
	BEGIN
		EXEC @ReturnStatus = sp_report_user_get	@iUserName				= @iRegUserName
												,@iDomain				= @iRegDomain
												,@iCreateIfNotExists	= 1
												,@oUserId				= @RegUserId OUTPUT
		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 OR @ReturnStatus <> 0
			GOTO PROC_ERROR
	END

	INSERT tbl_client_billing_user_rights
		(ClientBillingId
		,UserId
		,Rights
		,IsRecursive
		,StartDate
		,EndDate
		,RegUser
		,RegDate)
	SELECT
		@iClientBillingId
		,@UserId
		,@iRights
		,@iIsRecursive
		,@iStartDate
		,@iEndDate
		,@RegUserId
		,getdate()


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)

END
GO

IF OBJECT_ID('sp_client_billing_validate') IS NOT NULL
	DROP PROCEDURE sp_client_billing_validate
GO

CREATE PROCEDURE sp_client_billing_validate
/************************************************************
Created by:  Henrik Linder
Creation date: 2008-12-22
Description: Check if the given user can use the given billing code. (Currently no user-specific checks.
-------------------------------------------------------------
Mofified by:  Henrik Linder
Modification date: 2009-09-30
Description: Added check to see if this user can use the billing code
-------------------------------------------------------------
Mofified by:  Erik Norell
Modification date: 2009-12-02
Description: Added follwoing functions:
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF
The FetchStatement in ODBC would otherwise return false.
************************************************************/
	@iBillingCode		nvarchar(128)
	,@iUserName			nvarchar(510)	= NULL
	,@iDomain			nvarchar(510)	= NULL
AS
BEGIN
	DECLARE @CurrentTimestamp datetime
	SET @CurrentTimestamp = getdate()

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	IF @iBillingCode IS NULL OR LEN(@iBillingCode) = 0
		RETURN(0)

	IF NOT EXISTS (SELECT 1 FROM tbl_client_billing	WHERE cb_code = @iBillingCode AND cb_active = 1 AND cb_type = 1)
		RETURN (100036)

	IF NOT EXISTS (SELECT 1 FROM tbl_client_billing	WHERE cb_code = @iBillingCode AND ISNULL(cb_active_date,'20000101') < @CurrentTimestamp)
		RETURN (100037)

	IF NOT EXISTS (SELECT 1 FROM tbl_client_billing	WHERE cb_code = @iBillingCode AND ISNULL(cb_deactive_date,'99991231') > @CurrentTimestamp)
		RETURN (100038)



	IF  EXISTS (SELECT 1 FROM tbl_property
		WHERE propertyGroup = 'ClientBilling'
		AND propertyName = 'cbLimitMode'
		AND propertyValueNumeric > 0)
	BEGIN
		DECLARE @CurrentBillingCodeId bigint
	
		SELECT @CurrentBillingCodeId = cb_id
		FROM tbl_client_billing	
		WHERE cb_code = @iBillingCode AND cb_active = 1 AND cb_type = 1


		DECLARE @cbc TABLE (cb_id bigint, Rights int)

		INSERT @cbc
		EXEC sp_client_billing_get_for_user
			@iUserName				= @iUserName
			,@iDomain				= @iDomain
			,@iRights				= 1 -- only "use" rights is necesarry now
			,@iIncludeFolders		= 0
			,@iIncludeBillingCodes	= 1
			,@iVerbose				= 0


		IF NOT EXISTS (SELECT 1 FROM @cbc WHERE cb_id = @CurrentBillingCodeId)
			RETURN (100062) --	User is not authorised to use this Billing Code


	END

	RETURN (0)

END
GO

IF OBJECT_ID('sp_client_errors_get') IS NOT NULL
	DROP PROCEDURE sp_client_errors_get
GO

CREATE PROCEDURE sp_client_errors_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-18
Description: Get recent errors for a client, given IP and/or username
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-09-01
Description: Added multi-language support
************************************************************/
	@iUserName			nvarchar(510)	= NULL
	,@iIP				varchar(64)		= NULL
	,@iTimeLimit		int				= 60 -- only list events for last x minutes
	,@iLanguageId		char(2)			= 'en'
AS
BEGIN

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CutOffDate				datetime

	IF @iUserName IS NULL AND @iIP IS NULL
		RETURN (100016)


	SET @CutOffDate = DATEADD(n, -1 * @iTimeLimit, getdate())



	SELECT TOP 1000
		t.logJobName JobName
		,t.loguserName UserName
		,t.logdateEvent
		,t.logEventMajor
		,t.logEventMinor
		,dbo.verboseTicketLogByLanguage(t.logEventMajor,t.logEventMinor, @iLanguageId)  EventVerbose
		,sa.AdviceText
	FROM tbl_ticket_log t
	LEFT JOIN tbl_support_advice sa
		ON sa.SourceTable = 'tbl_ticket_log'
		AND sa.Level1 = t.logEventMajor
		AND sa.Level2 = t.logEventMinor
		AND sa.LanguageId = @iLanguageId
	WHERE (t.loguserName = @iUserName
		OR logoriginatingIp = @iIP)
		AND logdateEvent >= @CutOffDate
		AND NOT (logEventMajor = 2 AND logEventMinor = 1) -- exclude Print OK 
			-- do not display errors if the job has been printed successfully:
		AND NOT EXISTS (SELECT 1 FROM tbl_ticket_log t1 
						WHERE t1.logticketId = t.logticketId AND t1.logEventMajor = 2 AND t1.logEventMinor = 1) 

	ORDER BY t.logdateEvent DESC, sa.SortOrder ASC

	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_client_session_search') IS NOT NULL
	DROP PROCEDURE sp_client_session_search
GO

CREATE PROCEDURE sp_client_session_search
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-16
Description: Search for client sessions
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-06
Description: Default to only show last 7 days. Top 100 instead of top 1000.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-09-01
Description: Added multilingual support
************************************************************/
	@isearchString			nvarchar(128)
	,@ionlyActiveSessions	bit				= 0 
	,@istartDate			datetime		= NULL
	,@iendDate				datetime		= '99991231'
	-- below are used if user wants to refine results of original search --
	,@iuserName				nvarchar(510)	= NULL
	,@isessionIp			varchar(64)		= NULL
	,@iLanguageId			char(2) = 'en'

AS
BEGIN

	DECLARE	@ErrorNo			int
			,@searchString			nvarchar(128)

	IF LEN(@isearchString) = 0
		RETURN (100008)

	IF @istartDate IS NULL
		SET @istartDate = DATEADD(d, -7, getdate())

	SET @searchString = '%' + @isearchString + '%'

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #sessionold (
		csessionId					bigint
		,csessionIp					varchar
		,csessionUser				nvarchar(510) COLLATE DATABASE_DEFAULT
		,csessionDomain				nvarchar(510) COLLATE DATABASE_DEFAULT
		,csessionCirratoVersion		varchar(64)
		,csessionType				smallint
		,csessionDate				datetime
		,csessionclientBillingCode	nvarchar	(510) COLLATE DATABASE_DEFAULT
		,csessionActive				bit
		,SessionEventVerbose		varchar(128) COLLATE DATABASE_DEFAULT)

	CREATE TABLE #sessionactive (
		csessionId					bigint
		,csessionIp					varchar
		,csessionUser				nvarchar(510) COLLATE DATABASE_DEFAULT
		,csessionDomain				nvarchar(510) COLLATE DATABASE_DEFAULT
		,csessionCirratoVersion		varchar(64)
		,csessionType				smallint
		,csessionDate				datetime
		,csessionclientBillingCode	nvarchar	(510) COLLATE DATABASE_DEFAULT
		,csessionActive				bit
		,SessionEventVerbose		varchar(128) COLLATE DATABASE_DEFAULT)

	-- Select tickets to display

	INSERT #sessionold
	Select TOP 100
			s.logcsessionId
			,s.logcsessionIp
			,s.logcsessionUser
			,s.logcsessionDomain
			,s.logcsessionCirratoVersion
			,s.logcsessionType
			,s.logcsessionDate
			,s.logcsessionClientBillingCode
			,0 as csessionActive
			,dbo.verboseClientSessionEventByLanguage(logcsessionEvent, logcsessionKerberosEnabled, @iLanguageId) SessionEventVerbose
	from tbl_cirrato_client_session_log s
	where(	s.logcsessionIp	LIKE @searchString
		 OR s.logcsessionUser	LIKE @searchString)
		AND (s.logcsessionDate	>= @istartDate)
		AND (s.logcsessionDate	<= @iendDate)
		AND (@iuserName		 IS NULL OR s.logcsessionUser  = @iuserName)
		AND (@isessionIp IS NULL OR s.logcsessionIp = @isessionIp)
	ORDER BY logcsessionDate DESC



	INSERT #sessionactive
	Select	TOP 100
			s.csessionId
			,s.csessionIp
			,s.csessionUser
			,s.csessionDomain
			,s.csessionCirratoVersion
			,s.csessionType
			,s.csessionDate
			,s.csessionClientBillingCode
			,1 as csessionActive
			,NULL SessionEventVerbose
	from tbl_cirrato_client_session s 
	where(	s.csessionIp	LIKE @searchString
		 OR s.csessionUser	LIKE @searchString)
		AND (@istartDate	 IS NULL OR s.csessionDate	>= @istartDate)
		AND (@iendDate		 IS NULL OR s.csessionDate	<= @iendDate)
		AND (@iuserName		 IS NULL OR s.csessionUser  = @iuserName)
		AND (@isessionIp IS NULL OR s.csessionIp = @isessionIp)
--		AND s.csessionDate NOT IN (SELECT csessionDate FROM #session)
	ORDER BY csessionDate DESC


	UPDATE so
		SET csessionActive = 1
	FROM #sessionold so	
	INNER JOIN #sessionactive sa
		ON so.csessionDate = sa.csessionDate


	INSERT #sessionold
	SELECT * FROM #sessionactive WHERE csessionDate NOT IN (SELECT csessionDate FROM #sessionold)

		

	SET @ErrorNo = @@ERROR

	SELECT * FROM #sessionold

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_cpt_session_get_info') IS NOT NULL
	DROP PROCEDURE sp_cpt_session_get_info
GO

CREATE PROCEDURE sp_cpt_session_get_info
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-08
Description: Get information about current cpy session
------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
	@iSessionId			varchar(64)

AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	IF NOT EXISTS( SELECT 1 FROM tbl_cirrato_cpt_session WHERE cpt_id = @iSessionId)
		RETURN (300001)


	UPDATE tbl_cirrato_cpt_session
		SET cpt_lastSeen = getdate()
	WHERE cpt_id = @iSessionId


	 SELECT * FROM tbl_cirrato_cpt_session WHERE cpt_id = @iSessionId

	SET @ReturnStatus = 0



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ReturnStatus)


	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_cpt_session_refresh') IS NOT NULL
	DROP PROCEDURE sp_cpt_session_refresh
GO

CREATE PROCEDURE sp_cpt_session_refresh
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-04-14
Description: Refresh session
------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
	@iSessionId			varchar(64)

AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	IF NOT EXISTS( SELECT 1 FROM tbl_cirrato_cpt_session WHERE cpt_id = @iSessionId)
		RETURN (300001)


	UPDATE tbl_cirrato_cpt_session
		SET cpt_lastSeen = getdate()
	WHERE cpt_id = @iSessionId

	SET @ReturnStatus = 0



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ReturnStatus)


	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_diagnostics_generic_select') IS NOT NULL
	DROP PROCEDURE sp_diagnostics_generic_select
GO

CREATE PROCEDURE sp_diagnostics_generic_select
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-07
Description:  Execute arbitrary select query. Do not allow queries that modify data.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iQuery			varchar(8000)
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- do stuff
	DECLARE @QueryUpper varchar(8000)
	SET @QueryUpper = UPPER(@iQuery)

	IF CHARINDEX('UPDATE', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed
	IF CHARINDEX('DROP', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed
	IF CHARINDEX('ALTER', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed
	IF CHARINDEX('TRUNCATE', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed
	IF CHARINDEX('CREATE', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed
	IF CHARINDEX('INSERT', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed
	IF CHARINDEX('DELETE', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed
	IF CHARINDEX('EXEC', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed
	IF CHARINDEX('sp_', @QueryUpper) > 0 RETURN(101001) -- Only SELECT queries allowed


	BEGIN TRY
		 EXEC(@iQuery)
	END TRY
	BEGIN CATCH
		RETURN (ERROR_NUMBER())
	END CATCH


	



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_diagnostics_job_status') IS NOT NULL
	DROP PROCEDURE sp_diagnostics_job_status
GO

CREATE PROCEDURE sp_diagnostics_job_status
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-07
Description:  Get as much info as possible about what jobs have been run and when
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iBit			bit = 0
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF



	DECLARE @j TABLE
		(Job nvarchar(510)
		,LastRun datetime
		,Outcome nvarchar(510)
		,NextRun datetime	
		,SortOrder int)


	-- tbl_property
	INSERT @j (Job, LastRun, Outcome, SortOrder)

	SELECT 'Quota refill', propertyDate, NULL, 10 FROM tbl_property WHERE propertyName = 'LastRun' AND propertyGroup = 'CirratoWallet'
	UNION
	SELECT 'JobsQueueCutOff', propertyDate, NULL, 30 FROM tbl_property WHERE propertyName = 'JobsQueueCutOff' AND propertyGroup = 'Reports'
	UNION	
	SELECT 'JobsDetailCutOff', propertyDate, NULL, 20 FROM tbl_property WHERE propertyName = 'JobsDetailCutOff' AND propertyGroup = 'Reports'






	SELECT Job, LastRun, Outcome FROM @j ORDER BY SortOrder

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_directory_monitor_config_get') IS NOT NULL
	DROP PROCEDURE sp_directory_monitor_config_get
GO

CREATE PROCEDURE sp_directory_monitor_config_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-25
Description:  Get one or all settings
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iDirectoryId			int			= NULL
	,@iDirectoryType		tinyint		= NULL
	,@iNTDomain				varchar(64) = '%'
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT 
		*
	FROM tbl_directory_monitor_config
	WHERE	ISNULL(@iDirectoryId, DirectoryId) = DirectoryId
		AND ISNULL(@iDirectoryType, DirectoryType) = DirectoryType
		AND NTDomain LIKE @iNTDomain
			
	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_generic_query') IS NOT NULL
	DROP PROCEDURE sp_generic_query
GO

CREATE PROCEDURE sp_generic_query
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-11-09
Description:  Execute arbitrary query.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iQuery			varchar(8000)
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	BEGIN TRY
		 EXEC(@iQuery)
	END TRY
	BEGIN CATCH
		RETURN (ERROR_NUMBER())
	END CATCH


	



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_get_tickets_sub') IS NOT NULL
	DROP PROCEDURE sp_get_tickets_sub
GO

CREATE PROCEDURE sp_get_tickets_sub
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-13
Description: Get tickets for a set of queues (for display in Web)
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-01-29
Description: Changed criteria for follow-print
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-17
Description: Get proper outcome of historic jobs
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-04
Description: Get proper latest outcome of historic jobs
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-11
Description: Increase performance
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-01
Description: Additional columns
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-15
Description: Added authIp and calculated column HasOwner
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-21
Description: Removed check on ticketRuleStatus after discussion with Erik.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-29
Description: Changed conditions for isFollowPrint flag.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-05-05
Description: Return additional fields.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-11
Description: Added DeleteAfterPrint field.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-12
Description: UserName field hiding for ownerless jobs moved to WebGUI.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-23
Description: Always output authIp = ''.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-24
Description: Ticket 835 - do not limit active jobs listing to 100.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-25
Description: New field: RequireBillingCode.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-07-14
Description: New field: PaperSize, NumCopies.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-08-06
Description: Added optional input parameter Priceplan. If given, prices for active tickets without price will be calculated.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-09-11
Description: Added support to filter by ticket model and FP/non-FP. Model filter only for active tickets. 
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-09-16
Description: Added support for PrintDivert flag. 
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added support for listing jobs that are compatible with a specific printer
************************************************************/
	@iruleStatus			smallint = 0
	,@iincludeActive		bit = 1
	,@iincludeOld			bit = 0
	,@iPricePlanId			varchar(64) = NULL
	,@iModelId				varchar(64) = NULL
	,@iCompatiblePrinterId	varchar(64) = NULL
	,@iIncludeFPJobs		bit = 1
	,@iIncludeNonFPJobs		bit = 1
	,@iLanguageId			char(2)	= 'en'
AS
BEGIN



-- tbl_ticket.ticketRuleStatus=0 inneb�r att alla kan se den, 1 = bara admin kan se
-- 1 = jobbet "l�st" (kan ej skrivas ut), 0 = ol�st = vanligt


DECLARE  @tinfo TABLE
	(ticketId varchar(64), QueueId varchar(64), JobName nvarchar(510), username nvarchar(510), queueName nvarchar(510)
	,printerName nvarchar(510)
	,queuePrinterName nvarchar(510)
	,imageurl varchar(100)
	,[Time] datetime
	,Pages int, JobSize int, Color varchar(3), duplex varchar(3), ticketStatus nvarchar(100)
	,isFollowPrint bit, ticketActive bit, allowJobAction bit
	,clientBillingCode nvarchar(100), PricePlan varchar(64), TicketPrice float(53), DocumentTypeVerbose varchar(100)
	,finalEventMinor smallint, finalTicketStatus varchar(64)
	,FollowPrintQueueId varchar(64)
	,OriginatingIp varchar(64)
	,ClientIp varchar(64)
	,authIp varchar(64)
	,HasOwner bit
	,ticketStatusNumeric smallint
	,ticketAdminStatus smallint
	,ticketNewStatus smallint
	,ticketRuleStatus smallint
	,deleteAfterPrint smallint
	,RequireBillingCode bit
	,PaperSize int
	,NumCopies smallint
	,BWPages int
	,ColorPages int
	,PrintDivert bit)

INSERT @tinfo
Select --TOP 100
	t.ticketId as 'ticketId'
	,t.QueueId as 'queueId'
	,t.jobName as 'JobName'
-- Hiding logic moved to WebGUI joblist control
--	,CASE WHEN t.authIP IS NOT NULL AND t.ticketRuleStatus = 1 THEN '<i>No owner</i>'
--			ELSE t.username 
--	END as 'username'
	,t.username
	,q.queueName as queueName
	,p.printerName as printerName
	,ISNULL(q.queueName, p.printerName) as queuePrinterName
	,(case upper(right(t.jobName,4)) 
		when '.DOC' then '~/images/icon-word.gif' 
		when '.XLS' then '~/images/icon-xls.gif'
		when '.PDF' then '~/images/icon-pdf.gif' 
		when '.PPT' then '~/images/icon-ppt.gif' 
		when '.TXT' then '~/images/icon-txt.gif'
		else '~/images/icon-none.gif' end) as 'imageurl'
	,t.dateCreated as 'Time' 
	,t.pages as 'Pages'
	,t.jobSize as 'JobSize'
	,(case t.color when 1 then 'No' else 'Yes' end) as Color
	,(case t.duplex when 1 then 'No' else 'Yes' end) as duplex
	,dbo.verboseTicketStatusByLanguage(ticketStatus, @iLanguageId) + ' ' 
		+ dbo.verboseTicketAdminStatusByLanguage(t.ticketAdminStatus, @iLanguageId) + ' ' 
		+ dbo.verboseRuleStatusByLanguage(ticketRuleStatus, @iLanguageId) + ' ' 
		+ case when ISNULL(ticketNewStatus,0) = 0 THEN ''
		else '(' + dbo.verboseTicketNewStatusByLanguage(ticketNewStatus, @iLanguageId) + ')' end
		as ticketStatus
	,cast(case when (t.queueId <> t.fprintQ ) OR (q.queueType = 3 ) then '1'
		else '0' end as varchar(10)) as isFollowPrint
	,1 as ticketActive
	,CAST(CASE WHEN t.ticketStatus IN(2, 7) THEN 1 ELSE 0 END AS bit) as allowJobAction
	,clientBillingCode
	,pricePlan
	,ticketPrice
	,dbo.verboseDocumentTypeByLanguage(t.jobName, @iLanguageId) AS DocumentTypeVerbose
	,NULL AS finalEventMinor
	,NULL AS finalTicketStatus
	,t.fprintQ
	,t.originatingIp
	,t.clientIp
	,ISNULL(t.authIp,'') authIp
	,CASE WHEN t.authIP IS NOT NULL AND t.ticketRuleStatus = 1 THEN 0 ELSE 1 END as HasOwner
	,ticketStatus AS ticketStatusNumeric 
	,ticketAdminStatus 
	,ticketNewStatus 
	,ticketRuleStatus 
	,deleteAfterPrint
	,CASE WHEN rbc.ticketFeatureTicket IS NOT NULL THEN 1 ELSE 0 END	AS RequireBillingCode
	,paper
	,numCopies
	,LoggedBWPages
	,LoggedColorPages
	,CASE WHEN pd.ticketFeatureTicket IS NOT NULL THEN 1 ELSE 0 END	AS PrintDivert
from tbl_ticket t 
join #tickets t1
	on t1.ticketId = t.ticketId
	and t1.ticketActive = 1
left outer join tbl_printer p
	on t.printerId = p.printerId
left outer join tbl_queue q
	on t.queueId = q.queueId
left outer join tbl_ticket_feature rbc
	on rbc.ticketFeatureTicket = t.ticketId
	and rbc.ticketFeatureFeature = 3 -- cb_lock
left outer join tbl_ticket_feature pd
	on pd.ticketFeatureTicket = t.ticketId
	and pd.ticketFeatureFeature = 4 -- TF_PRINTSERVICE_LOCK
WHERE --ISNULL(@iModelId, ISNULL(t.ticketModel,'')) = ISNULL(t.ticketModel,'')
	@iCompatiblePrinterId IS NULL 
--	OR t.ticketModel = ''
	OR t.ticketModel IN (SELECT ModelId FROM vw_printer_model_compatible WHERE PrinterId = @iCompatiblePrinterId)

--where
--	t.ticketRuleStatus <= @iruleStatus;
--	AND @iincludeActive = 1


	-- Calculate prices if priceplan is given
	-----------------------------------------

	IF @iPricePlanId IS NOT NULL
	BEGIN 
		CREATE TABLE #Prices
		(JobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
		,PaperSize			tinyint
		,Color				bit
		,Duplex				bit
		,TicketPrice		float)

		DECLARE @cTicketId				varchar(64)
				,@cPaperSize			int
				,@cPages				int
				,@cColor				varchar(3) -- Yes / No
				,@cDuplex				varchar(3)  
				,@cLoggedBWPages		int
				,@cLoggedColorPages		int

				-- goes into priceplan calc
				,@oPagesBW		int
				,@oPagesColor	int
				,@oPaperSize	tinyint
				,@oDuplex		bit

				,@TicketPrice		float
				,@MinTicketPrice	float
				,@MaxTicketPrice	float
				,@ReturnStatus		int


		INSERT #Prices
		EXEC @ReturnStatus = sp_priceplan_get_explicit @iPricePlanId = @iPricePlanId

		IF @ReturnStatus <> 0 GOTO FETCH_OLD

		DECLARE curTicketsWithoutPrice CURSOR FOR
		SELECT ticketId, papersize, pages, color, duplex, BWPages, ColorPages FROM @tinfo WHERE ticketPrice IS NULL

		OPEN curTicketsWithoutPrice
		FETCH NEXT FROM curTicketsWithoutPrice INTO @cTicketId, @cPaperSize, @cPages, @cColor, @cDuplex, @cLoggedBWPages, @cLoggedColorPages

		WHILE @@FETCH_STATUS = 0
		BEGIN

			EXEC sp_ticket_get_structured_pageinfo
					@iPaperSize				= @cPaperSize
					,@iPages				= @cPages
					,@iColor				= @cColor
					,@iDuplex				= @cDuplex
					,@iLoggedBWPages		= @cLoggedBWPages
					,@iLoggedColorPages		= @cLoggedColorPages
					,@oPagesBW				= @oPagesBW		OUTPUT
					,@oPagesColor			= @oPagesColor	OUTPUT
					,@oPaperSize			= @oPaperSize	OUTPUT
					,@oDuplex				= @oDuplex		OUTPUT

			EXEC sp_priceplan_get_ticket_price
					@iPricePlanId		= @iPricePlanId
					,@iJobType			= 1 -- print
					,@iPagesBW			= @oPagesBW
					,@iPagesColor		= @oPagesColor
					,@iPaperSize		= @oPaperSize
					,@iDuplex			= @oDuplex
					,@oTicketPrice		= @TicketPrice		OUTPUT
					,@oMinTicketPrice	= @MinTicketPrice	OUTPUT
					,@oMaxTicketPrice	= @MaxTicketPrice	OUTPUT
			
			UPDATE @tinfo SET ticketPrice = @TicketPrice WHERE ticketId = @cTicketId


			FETCH NEXT FROM curTicketsWithoutPrice INTO @cTicketId, @cPaperSize, @cPages, @cColor, @cDuplex, @cLoggedBWPages, @cLoggedColorPages

		END
				
		CLOSE curTicketsWithoutPrice
		DEALLOCATE curTicketsWithoutPrice


	END

	-- Insert old tickets
	-------------------------------------
	FETCH_OLD:
	INSERT @tinfo
	SELECT TOP 100 
		t.logticketId
		,t.logqueueId
		,t.logjobName
		,t.loguserName
		,q.queueName
		,p.printerName
		,ISNULL(p.printerName,q.queueName) as queuePrinterName
		,(case upper(right(t.logjobName,4)) 
			when '.DOC' then '~/images/icon-word.gif' 
			when '.XLS' then '~/images/icon-xls.gif'
			when '.PDF' then '~/images/icon-pdf.gif' 
			when '.PPT' then '~/images/icon-ppt.gif' 
			when '.TXT' then '~/images/icon-txt.gif'
			else '~/images/icon-none.gif' end) as 'imageurl'
		,t.logdateCreated [Time]
		,t.logpages
		,t.logJobSize
		,(case t.logcolor when 1 then 'No' else 'Yes' end) as Color
		,(case t.logduplex when 1 then 'No' else 'Yes' end) as duplex
		,dbo.fn_translate('ClosedJob', @iLanguageId) + ' - ' + dbo.verboseTicketLogByLanguage(0,t.logEventMinor, @iLanguageId)  ticketStatus
		,cast(case when t.logqueueId <> t.logfprintQ then '1'
			else '0' end as varchar(10)) as isFollowPrint
		,0 AS ticketActive
		,0 AS allowJobAction
		,t.logclientBillingCode
		,t.logPricePlan
		,t.logTicketPrice
		,dbo.verboseDocumentTypeByLanguage(t.logjobName, @iLanguageId) AS DocumentTypeVerbose
		,t.logEventMinor 
		,t.logEventMinor  finalTicketStatus
		,t.logfprintQ
		,t.logoriginatingIp
		,t.logclientIp
		,'' -- logAuthIp ????
		,1 -- HasOwner
		,NULL AS ticketStatusNumeric 
		,NULL AS ticketAdminStatus 
		,NULL AS ticketNewStatus 
		,0 AS ticketRuleStatus 
		,NULL AS deleteAfterPrint
		,0 AS RequireBillingCode
		,t.logpaper
		,0 --t.logNumCopies
		,t.logLoggedColorPages
		,t.logLoggedBWPages
		,NULL AS PrintDivert
	FROM #tickets t1
	INNER JOIN tbl_ticket_log t
		on t.logticketId = t1.ticketId
		AND t.logDateEvent = t1.DateEvent
		AND t.logEventMinor NOT BETWEEN 20 AND 24 -- These are all related to the outcome of the debit
	LEFT OUTER JOIN tbl_queue q
		on q.queueId = t.logqueueId
	left outer join tbl_printer p
		on t.logprinterId = p.printerId


	-- Return results
	-------------------------------------
	select * from @tinfo

	WHERE (isFollowPrint = 0 AND @iIncludeNonFPJobs = 1)
		OR (isFollowPrint = 1 AND @iIncludeFPJobs = 1)


	order by
	/* ticketActive desc,*/ [Time] desc


	RETURN (0)

END
GO

IF OBJECT_ID('sp_information_window_get') IS NOT NULL
	DROP PROCEDURE sp_information_window_get
GO

CREATE PROCEDURE sp_information_window_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-17
Description: Get information popup window data
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-03-12
Description: Get more information
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-07
Description: Fix for getting queue information (printer status verbose column was missing in temp table)
************************************************************/
	@iInfoTypeGroup			char(3)
	,@iObjectId				varchar(64)		
	,@iCurrentUser			nvarchar(510) = NULL
	,@iAccessLevel			int
	,@iLanguageId			char(2) = 'en'
AS
BEGIN
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF
	DECLARE @ReturnStatus	INT
			,@ErrorNo		INT

	CREATE TABLE #properties
	(PropertyName			varchar(100)
	,PropertyValue			nvarchar(510)
	,SortOrder				int
	,AccessLevelRequired	int
	,Obfuscatable			bit)

	DECLARE @DoObfuscate bit
	SET @DoObfuscate = 1


	IF @iInfoTypeGroup = 'QUE'
	BEGIN
		CREATE TABLE #queue
		(QueueId					varchar(64)		COLLATE DATABASE_DEFAULT
		,QueueName					nvarchar(510)	COLLATE DATABASE_DEFAULT
		,RegionPath					nvarchar(510)	COLLATE DATABASE_DEFAULT
		,Location					nvarchar(510)	COLLATE DATABASE_DEFAULT
		,QueueStatusVerbose			varchar(64)		COLLATE DATABASE_DEFAULT
		,PrinterStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
		,ErrorTime					datetime
		,LastCheck					int
		,DisplayText				nvarchar(200)	COLLATE DATABASE_DEFAULT
		,PhysicalStatusSeverity		int
		,PhysicalStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
		,NewStatusVerbose			varchar(64)		COLLATE DATABASE_DEFAULT
		,HighestSmartAlarmLevel		int
		,SmartAlarmCount			int	
		,HighestTotalAlarmLevel		int
		,PrinterIP					varchar(64)		COLLATE DATABASE_DEFAULT
		,PrinterId					varchar(64)		COLLATE DATABASE_DEFAULT
		,PrinterName					nvarchar(510)	COLLATE DATABASE_DEFAULT
		,ModelName					nvarchar(512)	COLLATE DATABASE_DEFAULT
		,JobCount					int
		,RegionId					bigint
		,AdminComment				nvarchar(510)	COLLATE DATABASE_DEFAULT
		,OfflineReason				nvarchar(256)	COLLATE DATABASE_DEFAULT
		,PagesPerMinuteBWSingle		real
		,PagesPerMinuteColorSingle	real
		,PagesPerMinuteBWDuplex		real
		,PagesPerMinuteColorDuplex	real)

		EXEC @ReturnStatus = sp_queue_get_overview @iqueueId = @iObjectId, @iSilent = 1

		IF (SELECT COUNT(1) FROM #queue) = 0
			EXEC @ReturnStatus = sp_queue_get_overview @iqueueId = @iObjectId, @iSilent = 1, @iqueueType = '3'

		-- Example:
		--SET @DoObfuscate = CASE WHEN (SELECT TOP 1 QueueName FROM #queue WHERE QueueId = @iObjectId) = @iCurrentUser AND @iAccessLevel = 2 THEN 1 ELSE 0 END

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Queue Name',@iLanguageId), QueueName, 10, 0, 0 FROM #queue

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Location',@iLanguageId), Location, 20, 0, 0 FROM #queue

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Region',@iLanguageId), RegionPath, 30, 0, 0 FROM #queue

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Jobs',@iLanguageId), JobCount, 40, 0, 0 FROM #queue


		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Display Text',@iLanguageId), DisplayText, 50, 0, 0 FROM #queue

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Offline Reason',@iLanguageId), OfflineReason, 60, 0, 0 FROM #queue


		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Speed B/W Single',@iLanguageId), PagesPerMinuteBWSingle, 100, 0, 0 FROM #queue

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Speed B/W Duplex',@iLanguageId), PagesPerMinuteColorSingle, 110, 0, 0 FROM #queue

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Speed Color Single',@iLanguageId), PagesPerMinuteBWDuplex, 120, 0, 0 FROM #queue

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Speed Color Duplex',@iLanguageId), PagesPerMinuteColorDuplex, 130, 0, 0 FROM #queue



		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Admin Comment',@iLanguageId), AdminComment, 200, 4, 0 FROM #queue
	END


	IF @iInfoTypeGroup = 'PRI'
	BEGIN

		CREATE TABLE #printer
			(PrinterId					varchar(64)		COLLATE DATABASE_DEFAULT
			,PrinterName				nvarchar(510)	COLLATE DATABASE_DEFAULT
			,RegionPath					nvarchar(510)	COLLATE DATABASE_DEFAULT
			,Location					nvarchar(510)	COLLATE DATABASE_DEFAULT
			,ErrorTime					datetime
			,LastCheck					int
			,DisplayText				nvarchar(200)	COLLATE DATABASE_DEFAULT
			,PrinterStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
			,PhysicalStatusSeverity		int
			,PhysicalStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
			,HighestSmartAlarmLevel			int	-- Smart alarms
			,SmartAlarmCount					int	 -- No of smart alarms at the highest level of the printer!
			,RegionId					bigint
			,HighestTotalAlarmLevel		int -- MAX(PhysicalStatusSeverity, HighestAlarmLevel)
			,JobCount					int
			,PrinterIP					varchar(64)		COLLATE DATABASE_DEFAULT
			,ModelName					nvarchar(512)	COLLATE DATABASE_DEFAULT
			,AdminComment				nvarchar(510)	COLLATE DATABASE_DEFAULT
			,OfflineReason				nvarchar(256)	COLLATE DATABASE_DEFAULT)

		EXEC @ReturnStatus = sp_monitoring_get_printer_status @iprinterId = @iObjectId, @iSilent = 1

		IF (SELECT COUNT(1) FROM #printer) = 0
	 		EXEC @ReturnStatus = sp_monitoring_get_printer_status @iprinterId = @iObjectId, @iSilent = 1, @iprinterType = '1'


		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Name',@iLanguageId), PrinterName, 10, 0, 0 FROM #printer

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Location',@iLanguageId), Location, 20, 0, 0 FROM #printer

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Region',@iLanguageId), RegionPath, 30, 0, 0 FROM #printer

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Jobs',@iLanguageId), JobCount, 40, 0, 0 FROM #printer


		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Display Text',@iLanguageId), DisplayText, 50, 0, 0 FROM #printer

		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Offline Reason',@iLanguageId), OfflineReason, 60, 0, 0 FROM #printer



		INSERT #properties(PropertyName,PropertyValue,SortOrder,AccessLevelRequired,Obfuscatable)
		SELECT TOP 1 dbo.fn_translate('Admin Comment',@iLanguageId), AdminComment, 100, 4, 0 FROM #printer
	END



	SELECT 
		PropertyName
		,CASE WHEN Obfuscatable = 1 AND @DoObfuscate = 1 THEN '<i>'+dbo.fn_translate('Hidden',@iLanguageId)+'</i>' ELSE PropertyValue END AS PropertyValue
	FROM #properties
	WHERE @iAccessLevel >= AccessLevelRequired
	ORDER BY SortOrder

	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_install_log_search') IS NOT NULL
	DROP PROCEDURE sp_install_log_search
GO

CREATE PROCEDURE sp_install_log_search
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-25
Description: Search for install log history
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-06
Description: Default to only show last 7 days.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-09-02
Description: Added multilingual support.
************************************************************/
	@iSearchString			nvarchar(128)
	,@iStartDate			datetime		= NULL
	,@iEndDate				datetime		= '99991231'
	-- below are used if user wants to refine results of original search --
	,@iClientIp				varchar(64)		= NULL
	,@iLanguageId			char(2)			= 'en'
AS
BEGIN

	DECLARE	@ErrorNo			int
			,@searchString			nvarchar(128)

	IF LEN(@iSearchString) = 0
		RETURN (100008)

	IF @iStartDate IS NULL
		SET @iStartDate = DATEADD(d, -7, getdate())

	SET @searchString = '%' + @iSearchString + '%'

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF



	SELECT TOP 100
		installClientIp									ClientIP
		,installLogBegin								InstallBegin
		,installLogQueueId								QueueId
		,dbo.verboseInstallSpecialByLanguage(installLogSpecial, @iLanguageId)	InstallLogSpecialVerbose
		,dbo.verboseInstallMethodByLanguage(installLogIm, @iLanguageId)			InstallMethodVerbose
		,dbo.verboseOperatingSystem(null, installLogMajorOs, installLogMinorOs, installLogMajorSp, installLogMinorSp, installLogArch) OperatingSystemVerbose
		,dbo.verboseInstallResultByLanguage(i.installLogResult, @iLanguageId)	InstallResultVerbose
		,i.installLogResult								InstallResult
		,q.queueName									QueueName
		,d.driverFileVersion							DriverFileVersion
		,d.driverFileComment							DriverFileComment
	from tbl_install_log i
	LEFT OUTER JOIN tbl_queue q
		ON i.installLogQueueID = q.queueId
	LEFT OUTER JOIN tbl_driver_file d
		on d.driverFileId = i.installLogDriverFileId
	WHERE	i.installClientIp LIKE @searchString
			AND (i.installLogBegin	>= @iStartDate)
			AND (i.installLogBegin <= @iEndDate)
			AND	(@iClientIp		IS NULL OR i.installClientIp = @iClientIp)

	SET @ErrorNo = @@ERROR


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_localprinter_get_tickets') IS NOT NULL
	DROP PROCEDURE sp_localprinter_get_tickets
GO

CREATE PROCEDURE sp_localprinter_get_tickets
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-14
Description: Get tickets for a local printer (for display in Web)
************************************************************/
	@iprinterId			varchar(64) 
	,@iruleStatus		smallint = 0
AS
BEGIN
Select 
	t.ticketId as 'ticketId'
	,t.QueueId as 'QueueId'
	,t.jobName as 'JobName'
	,t.username as 'username'
	,(case upper(right(t.jobName,4)) 
		when '.DOC' then 'images/icon-word.gif' 
		when '.XLS' then 'images/icon-xls.gif'
		when '.PDF' then 'images/icon-pdf.gif' 
		when '.PPT' then 'images/icon-ppt.gif' 
		else 'images/icon-txt.gif' end) as 'imageurl'
	,t.dateCreated as 'Time' 
	,t.pages as 'Pages'
	,t.jobSize as 'JobSize'
	,(case t.color when 1 then 'No' else 'Yes' end) as Color
	,(case t.duplex when 1 then 'No' else 'Yes' end) as duplex
	,dbo.verboseTicketStatus(ticketStatus) + ' ' 
		+ dbo.verboseTicketAdminStatus(t.ticketAdminStatus) + ' ' 
		+ dbo.verboseRuleStatus(ticketRuleStatus) + ' ' 
		+ case when ISNULL(ticketNewStatus,0) = 0 THEN ''
		else '(' + dbo.verboseTicketNewStatus(ticketNewStatus) + ')' end
		as ticketStatus
	,'0' isFollowPrint
	,clientBillingCode

from tbl_ticket t 
where
	t.printerId = @iprinterId
	and t.ticketRuleStatus <= @iruleStatus
order by t.dateCreated


	RETURN (0)

END
GO

IF OBJECT_ID('sp_localregion_get_children') IS NOT NULL
	DROP PROCEDURE sp_localregion_get_children
GO

CREATE PROCEDURE sp_localregion_get_children
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-19
Description: List children of a local region. Option to include printers in listing
************************************************************/
	@iparentRegionId			int		= 0
	,@iincludeQueues	bit				= 0 --todo
	,@iincludePrinters	bit				= 0 
	,@iincludeHidden		bit			= 1 
AS
BEGIN

	DECLARE	@ReturnStatus			int

	-- Return error if an invalid region is supplied
	IF NOT EXISTS(SELECT 1 FROM tbl_lregion where lregionId = @iparentRegionId or @iparentRegionId = 0)
		RETURN (100009)


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	select
		cast(lregionId as varchar(64)) Identifier
		,lregionName [Name]
		,lregionActive Active
		,1 [Type]
		,2 SortOrder
		,NULL -- phy status
		,NULL -- new status
		,NULL -- model name
		,NULL -- comment
		,NULL -- location
	from tbl_lregion r
	where r.lregionParentId = @iparentRegionId
		and lregionActive = 1
	UNION
	
	SELECT
		p.printerId
		,p.printerName
		,1 Active
		,3 [Type] -- 1 = Region, 2=queue, 3=printer
		,3 SortOrder
		,dbo.verbosePrinterPhysicalStatus(p.physStatus, p.snmpCheck)
		,dbo.verbosePrinterNewStatus(p.printernewstatus)
		,m.modelName	--PrinterModelName
		,p.printerComment
		,p.printerLocation
	FROM tbl_printer p
	LEFT JOIN tbl_model m
		on m.modelId = p.printerModel
	WHERE p.printerType  = 1 -- 1=Local printer
		AND p.adminStatus <> 3 -- 3 = deleted
		AND p.region = @iparentRegionId
		AND @iincludePrinters = 1
		AND ((@iincludeHidden = 1) or p.printerHidden = 0)

--	SELECT
--		queueId
--		,queueName
--		,1 Active
--		,2
--		,3 SortOrder
--		,dbo.verbosePrinterPhysicalStatus(p.physStatus)
--		,dbo.verbosePrinterNewStatus(p.printernewstatus)
--		,m.modelName	--PrinterModelName
--		,q.queueComment
--		,q.queueLocation
--	FROM tbl_queue q
--	INNER JOIN tbl_queue_printer_map map -- m�ste joina denna v�g, q.queueRegion ger EJ r�tt resultat.
--		ON q.queueId = map.mapqueue
--	INNER JOIN tbl_printer p
--		ON p.printerId = map.mapphyprinter
--	LEFT JOIN tbl_model m
--		on q.queueModelId = m.modelId
--	WHERE --q.queueRegion = @iparentRegionId
--		p.region = @iparentRegionId
--		AND @iincludeQueues = 1
--		AND q.queueType < 3
--		AND q.queueStatus < 3 -- ej borttagen k�
--		AND p.printerType  = 1 -- 1=Local printer

	ORDER BY SortOrder,[Type], [Name] 

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_log_trim_do') IS NOT NULL
	DROP PROCEDURE sp_log_trim_do
GO

CREATE PROCEDURE sp_log_trim_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-03-04
Description: Perform log trim (to be called from scheduled job)
************************************************************/

AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime
			,@UserPrintFull				int
			,@UserPrintPartial			int
			,@UserPrintFullCutOff				datetime
			,@UserPrintPartialCutOff			datetime

	SET @ReturnStatus = 0
	SET @CurrentTimestamp = getdate()

--	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
--	SET ANSI_WARNINGS OFF

	-- Fetch data before running
	------------------------------------------------------------------------
	SET @UserPrintFull = dbo.fn_property_get_numeric('UserPrintFull');
	IF @UserPrintFull IS NULL
		RETURN (100022)
	SET @UserPrintFullCutOff = DATEADD(d, -1*@UserPrintFull, @CurrentTimestamp)

	SET @UserPrintPartial = dbo.fn_property_get_numeric('UserPrintPartial');
	IF @UserPrintPartial IS NULL
		RETURN (100023)
	SET @UserPrintPartialCutOff = DATEADD(d, -1*@UserPrintPartial, @CurrentTimestamp)


	-- RUN
	------------------------------------------------------------------------


	-- User print --
	CREATE TABLE #ticket (ticketId varchar(64),dateEvent datetime);

	-- Partial delete (keep only latest entry for each ticket)
	IF (@UserPrintPartial > 0)
	BEGIN
		WITH a (ticketId, eventDate, RowNo) AS
			(SELECT 
				logTicketId
				,logdateEvent
				,ROW_NUMBER() OVER (PARTITION BY logTicketId ORDER BY logdateEvent DESC)
			FROM tbl_ticket_log WHERE logdateEvent < @UserPrintPartialCutOff)
		DELETE t
		FROM tbl_ticket_log t
		INNER JOIN a
			ON a.ticketId = t.logticketId
			AND a.eventDate = t.logdateEvent
			AND a.RowNo <> 1;
	END

	-- Full delete
	IF (@UserPrintFull > 0)
		DELETE tbl_ticket_log
		WHERE logticketId IN (SELECT logticketId FROM tbl_ticket_log WHERE logdateEvent < @UserPrintFullCutOff)


	-- User Sensitive --



	RETURN (0)


	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_monitoring_component_status') IS NOT NULL
	DROP PROCEDURE sp_monitoring_component_status
GO

CREATE PROCEDURE sp_monitoring_component_status
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-04-21
Description: Get heartbeat status for different Cirrato components
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-24
Description: Adjusted Handover point conditions
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-08-13
Description: Ticket 75 - addtional components are monitored:
				* Active Directory
				* ODBC Card database
				* PayEx Connection
				* PayExExtIdDatabase
				* VDMS inactivity _warning_
************************************************************/
	-- Components to include
	@iIncludeCirratoServer				bit = 1
	,@iIncludeMonitoringService			bit = 1
	,@iIncludeHandoverPoints			bit = 1
	,@iIncludeActiveDirectory			bit = 1
	,@iIncludeODBCCardDatabase			bit = 1
	,@iIncludePayExConnection			bit = 1
	,@iIncludePayExExtIdDatabase		bit = 1
	,@iIncludeVDMSInactivityWarning 	bit = 1

	-- Severity levels to include:
	,@iIncludeOK					bit = 1
	,@iIncludeWarning				bit = 1
	,@iIncludeError					bit = 1
	,@iSilent						bit = 0
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @ErrorNo = 0
	SET @ReturnStatus = 0
	SET @CurrentTimestamp = getdate()

	DECLARE	 @CirratoServerErrorThreshold		int
			,@MonitoringServiceErrorThreshold	int
			,@HandoverPointErrorThreshold		int

	SET @CirratoServerErrorThreshold = dbo.fn_property_get_numeric('CirratoServerErrorThreshold');
	IF @CirratoServerErrorThreshold IS NULL
		RETURN (100070)

	SET @MonitoringServiceErrorThreshold = dbo.fn_property_get_numeric('MonitoringServiceErrorThreshold');
	IF @MonitoringServiceErrorThreshold IS NULL
		RETURN (100071)

	SET @HandoverPointErrorThreshold = dbo.fn_property_get_numeric('HandoverPointErrorThreshold');
	IF @HandoverPointErrorThreshold IS NULL
		RETURN (100072)



	DECLARE @Severities TABLE (Severity smallint);
	IF @iIncludeOK = 1		INSERT @Severities (Severity) VALUES (0)
	IF @iIncludeWarning = 1 INSERT @Severities (Severity) VALUES (1)
	IF @iIncludeError = 1	INSERT @Severities (Severity) VALUES (2)



	IF OBJECT_ID('tempdb..#component_status') IS NULL
		CREATE TABLE #component_status
		(ComponentType				char(3)			COLLATE DATABASE_DEFAULT
		,ComponentId				varchar(64)		COLLATE DATABASE_DEFAULT
		,ComponentName				nvarchar(510)	COLLATE DATABASE_DEFAULT
		,HeartBeat					datetime
		,TimeSinceHeartBeat			int -- seconds
		,ErrorNumber				int
		,Severity					smallint		-- 0 = OK, 1 = warning, 2 = error
		,ComponentLoad				int				
		,ComponentMessage			nvarchar(256)	COLLATE DATABASE_DEFAULT
		,SortOrder					int)

	-- Gather statistics for components
	-----------------------------------

	-- Cirrato Server
	IF @iIncludeCirratoServer = 1
		INSERT #component_status
			(ComponentType				
			,ComponentId				
			,ComponentName				
			,HeartBeat					
			,TimeSinceHeartBeat			
			,ErrorNumber				
			,Severity					
			,ComponentLoad								
			,ComponentMessage
			,SortOrder)
		SELECT
			'SRV'				
			,NULL
			,'Cirrato Server'
			,propertyDate -- HeartBeat					
			,DATEDIFF(s, propertyDate, @CurrentTimestamp) -- TimeSinceHeartBeat			
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) > @CirratoServerErrorThreshold THEN 100050 ELSE 0 END AS ErrorNumber				
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) > @CirratoServerErrorThreshold THEN 2 ELSE 0 END AS Severity					
			,NULL AS ComponentLoad								
			,NULL AS ComponentMessage
			,10 AS SortOrder
		FROM tbl_property 
		WHERE propertyName='dbServerHeartbeat' 

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 GOTO PROC_ERROR


	-- Cirrato Monitoring Service
	IF @iIncludeMonitoringService = 1
		INSERT #component_status
			(ComponentType				
			,ComponentId				
			,ComponentName				
			,HeartBeat					
			,TimeSinceHeartBeat			
			,ErrorNumber				
			,Severity					
			,ComponentLoad								
			,ComponentMessage
			,SortOrder)
		SELECT
			'MON'				
			,NULL
			,'Monitoring Service'
			,propertyDate -- HeartBeat					
			,DATEDIFF(s, propertyDate, @CurrentTimestamp) -- TimeSinceHeartBeat			
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) > @MonitoringServiceErrorThreshold THEN 100052 ELSE 0 END AS ErrorNumber				
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) > @MonitoringServiceErrorThreshold THEN 2 ELSE 0 END AS Severity					
			,NULL AS ComponentLoad								
			,NULL AS ComponentMessage
			,30 AS SortOrder
		FROM tbl_property 
		WHERE propertyName='dbMonKeepalive'

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 GOTO PROC_ERROR

	-- Handover Points
		IF @iIncludeHandoverPoints = 1
			INSERT #component_status
				(ComponentType				
				,ComponentId				
				,ComponentName				
				,HeartBeat					
				,TimeSinceHeartBeat			
				,ErrorNumber				
				,Severity					
				,ComponentLoad								
				,ComponentMessage
				,SortOrder)
			SELECT
				'HPT'				
				,handoverPointId AS ComponentId
				,handoverPointName
				,handoverPointcheck -- HeartBeat					
				,DATEDIFF(s, handOverPointLastCheck, @CurrentTimestamp) -- TimeSinceHeartBeat		
				,CASE WHEN (handOverPointCheck is NULL or (handOverPointCheck is not NULL and handOverPointLastCheck > dateadd(s,-1*@HandoverPointErrorThreshold,getDate()))) THEN 0 ELSE 100054 END AS ErrorNumber
				,CASE WHEN (handOverPointCheck is NULL or (handOverPointCheck is not NULL and handOverPointLastCheck > dateadd(s,-1*@HandoverPointErrorThreshold,getDate()))) THEN 0 ELSE 2 END AS Severity
				,NULL AS ComponentLoad								
				,NULL AS ComponentMessage
				,20 AS SortOrder
			FROM tbl_handover_point 
			WHERE handoverPointPort <> 0

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 GOTO PROC_ERROR


--en skickar server en f�rfr�gan till hop
--[10:39:47] Erik Norell says: "hej, hur m�r du"
--[10:39:54] Erik Norell says: d� s�tts "handoverPointCheck " till getdate
--[10:39:58] Erik Norell says: sen n�r HOP svarar den m�r bra
--[10:40:03] Erik Norell says: d� s�tts handoverpointcheck till NULL igen
--


	--	Active Directory
	IF @iIncludeActiveDirectory = 1
		INSERT #component_status
			(ComponentType				
			,ComponentId				
			,ComponentName				
			,HeartBeat					
			,TimeSinceHeartBeat			
			,ErrorNumber				
			,Severity					
			,ComponentLoad								
			,ComponentMessage
			,SortOrder)
		SELECT
			'ACD'							-- ComponentType
			,''								-- ComponentId
			,'Active Directory' 			-- ComponentName				
			,propertyDate					-- HeartBeat					
			,DATEDIFF(s, propertyDate, @CurrentTimestamp) -- TimeSinceHeartBeat			
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 100056 ELSE 0 END AS ErrorNumber				
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 2 ELSE 0 END AS Severity		
			,NULL AS ComponentLoad								
			,NULL AS ComponentMessage			
			,40		--SortOrder
		FROM tbl_property
		WHERE propertyName = 'serverMonitorAd' AND propertyValueNumeric <> 0 -- 0 = avst�ngt

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 GOTO PROC_ERROR


	--	ODBC Card database
	IF @iIncludeODBCCardDatabase = 1
		INSERT #component_status
			(ComponentType				
			,ComponentId				
			,ComponentName				
			,HeartBeat					
			,TimeSinceHeartBeat			
			,ErrorNumber				
			,Severity					
			,ComponentLoad								
			,ComponentMessage
			,SortOrder)
		SELECT
			'CBD'							-- ComponentType
			,''								-- ComponentId
			,'ODBC Card Database' 			-- ComponentName				
			,propertyDate					-- HeartBeat					
			,DATEDIFF(s, propertyDate, @CurrentTimestamp) -- TimeSinceHeartBeat			
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 100057 ELSE 0 END AS ErrorNumber				
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 2 ELSE 0 END AS Severity		
			,NULL AS ComponentLoad								
			,NULL AS ComponentMessage			
			,50		--SortOrder
		FROM tbl_property
		WHERE propertyName = 'serverMonitorOdbcCard' AND propertyValueNumeric <> 0 -- 0 = avst�ngt

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 GOTO PROC_ERROR



	--	PayEx Connection
	IF @iIncludePayExConnection = 1
		INSERT #component_status
			(ComponentType				
			,ComponentId				
			,ComponentName				
			,HeartBeat					
			,TimeSinceHeartBeat			
			,ErrorNumber				
			,Severity					
			,ComponentLoad								
			,ComponentMessage
			,SortOrder)
		SELECT
			'PEC'							-- ComponentType
			,''								-- ComponentId
			,'PayEx Connection' 			-- ComponentName				
			,propertyDate					-- HeartBeat					
			,DATEDIFF(s, propertyDate, @CurrentTimestamp) -- TimeSinceHeartBeat			
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 100058 ELSE 0 END AS ErrorNumber				
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 2 ELSE 0 END AS Severity		
			,NULL AS ComponentLoad								
			,NULL AS ComponentMessage			
			,60		--SortOrder
		FROM tbl_property
		WHERE propertyName = 'serverMonitorPayExConnection' AND propertyValueNumeric <> 0 -- 0 = avst�ngt

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 GOTO PROC_ERROR

	--	PayExExtIdDatabase
	IF @iIncludePayExExtIdDatabase = 1
		INSERT #component_status
			(ComponentType				
			,ComponentId				
			,ComponentName				
			,HeartBeat					
			,TimeSinceHeartBeat			
			,ErrorNumber				
			,Severity					
			,ComponentLoad								
			,ComponentMessage
			,SortOrder)
		SELECT
			'PED'							-- ComponentType
			,''								-- ComponentId
			,'PayEx ExtId Database' 			-- ComponentName				
			,propertyDate					-- HeartBeat					
			,DATEDIFF(s, propertyDate, @CurrentTimestamp) -- TimeSinceHeartBeat			
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 100059 ELSE 0 END AS ErrorNumber				
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 2 ELSE 0 END AS Severity		
			,NULL AS ComponentLoad								
			,NULL AS ComponentMessage			
			,70		--SortOrder
		FROM tbl_property
		WHERE propertyName = 'serverMonitorPayExExtIdDatabase' AND propertyValueNumeric <> 0 -- 0 = avst�ngt

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 GOTO PROC_ERROR

	--	VDMS inactivity _warning_
	IF @iIncludeVDMSInactivityWarning = 1
		INSERT #component_status
			(ComponentType				
			,ComponentId				
			,ComponentName				
			,HeartBeat					
			,TimeSinceHeartBeat			
			,ErrorNumber				
			,Severity					
			,ComponentLoad								
			,ComponentMessage
			,SortOrder)
		SELECT
			'VDW'							-- ComponentType
			,''								-- ComponentId
			,'VDMS Activity' 				-- ComponentName				
			,propertyDate					-- HeartBeat					
			,DATEDIFF(s, propertyDate, @CurrentTimestamp) -- TimeSinceHeartBeat			
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 100049 ELSE 0 END AS ErrorNumber				
			,CASE WHEN DATEDIFF(s, propertyDate, @CurrentTimestamp) - 10 > propertyValueNumeric THEN 1 ELSE 0 END AS Severity		
			,NULL AS ComponentLoad								
			,NULL AS ComponentMessage			
			,80		--SortOrder
		FROM tbl_property
		WHERE propertyName = 'serverMonitorVDMS' AND propertyValueNumeric <> 0 -- 0 = avst�ngt

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 GOTO PROC_ERROR


	-- Delete rows that the caller does not want
	--------------------------------------------
	DELETE #component_status
	WHERE Severity NOT IN (SELECT Severity FROM @Severities)


	-- Return dataset if requested
	------------------------------
	IF @iSilent = 0
		SELECT * FROM #component_status
		ORDER BY Severity DESC, SortOrder, ComponentName

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 GOTO PROC_ERROR


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)


	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_monitoring_get_printer_status') IS NOT NULL
	DROP PROCEDURE sp_monitoring_get_printer_status
GO

CREATE PROCEDURE sp_monitoring_get_printer_status
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-04
Description: Get printer status overview
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-13
Description: Additions so that this can be used in queue manager pages too
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-24
Description: Added status count output parameters
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-12
Description: Return stop reason
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-23
Description: Added support for hidden printers
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-25
Description: Added support for SNMP turned off
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-25
Description: Fixed multiple listing of printers with more than one open event.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
************************************************************/
	@iincludeOK			bit = 1
	,@iincludeWarnings	bit = 1
	,@iincludeErrors	bit = 1
	,@iusername			nvarchar(510)	= NULL
	,@iprinterIP		varchar(100)	= NULL
	,@iprinterName		nvarchar(510)	= NULL
	,@ibrandId			varchar(64)		= NULL
	,@imodelId			varchar(64)		= NULL
	,@iprinterId		varchar(64)		= NULL
	,@iprinterType		char(1)			= '0'  -- 0 = network printer, 1 = localprinter.
	,@iSilent			bit				= 0 
	,@iHiddenPrinterUser	nvarchar(510)	= NULL
	,@oOKCount			int				= NULL OUTPUT
	,@oWarningCount		int				= NULL OUTPUT
	,@oErrorCount		int				= NULL OUTPUT
	,@iCalculateRegionPath	bit			= 1
	,@iLanguageId		char(2)			= 'en'
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT	@oOKCount			= NULL
			,@oWarningCount		= NULL
			,@oErrorCount		= NULL

	IF OBJECT_ID('tempdb..#printer') IS NULL
	CREATE TABLE #printer
	(PrinterId					varchar(64)		COLLATE DATABASE_DEFAULT
	,PrinterName				nvarchar(510)	COLLATE DATABASE_DEFAULT
	,RegionPath					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,Location					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,ErrorTime					datetime
	,LastCheck					int
	,DisplayText				nvarchar(200)	COLLATE DATABASE_DEFAULT
	,PrinterStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
	,PhysicalStatusSeverity		int
	,PhysicalStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
	,HighestSmartAlarmLevel		int	-- Smart alarms
	,SmartAlarmCount			int	 -- No of smart alarms at the highest level of the printer!
	,RegionId					bigint
	,HighestTotalAlarmLevel		int -- MAX(PhysicalStatusSeverity, HighestAlarmLevel)
	,JobCount					int
	,PrinterIP					varchar(64)		COLLATE DATABASE_DEFAULT
	,ModelName					nvarchar(512)	COLLATE DATABASE_DEFAULT
	,AdminComment				nvarchar(510)	COLLATE DATABASE_DEFAULT
	,OfflineReason				nvarchar(256)	COLLATE DATABASE_DEFAULT);


	WITH OpenPrinterStatus (PrinterId, EventStartDate) AS
	(SELECT
		statopenPrinterId
		,MIN(statopenFirstDetected)
	FROM tbl_event_status_open
	GROUP BY statopenPrinterId)
	INSERT #printer
		(PrinterId				
		,PrinterName				
		,RegionPath				
		,Location			
		,ErrorTime		
		,LastCheck			
		,DisplayText		
		,PrinterStatusVerbose	
		,PhysicalStatusSeverity		
		,PhysicalStatusVerbose
		,RegionId
		,JobCount
		,PrinterIP
		,ModelName
		,AdminComment)
	SELECT 
		p.PrinterID as 'PrinterId'
		,max(p.printerName) as 'Printer Name'

		,CASE WHEN @iCalculateRegionPath = 1 THEN
				CASE	WHEN @iprinterType = '0' THEN max(dbo.GetAbsoluteRegion(p.region))
						WHEN @iprinterType = '1' THEN max(dbo.GetAbsoluteLocalRegion(p.region)) END 
			ELSE NULL END as 'RegionPath'
		,max(p.printerLocation) as 'Location'
		,e.EventStartDate as 'Error Time'
		,STR(datediff(minute,max(p.printerLastCheck),getdate())) LastCheck
		,p.printerDisplayText as 'Display Text'

		,dbo.verbosePrinterAggregatedStatusByLanguage(ISNULL(MAX(p.adminStatus),0), ISNULL(MAX(p.printerNewStatus),0), @iLanguageId) AS PrinterStatusVerbose
--		,dbo.verbosePrinterAdmStatus(MAX(p.adminStatus)) + ' ' 
--			+ case when ISNULL(MAX(p.printerNewStatus),0) = 0 THEN ''
--				else '(' + dbo.verbosePrinterNewStatus(MAX(p.printerNewStatus)) + ')' end	PrinterStatusVerbose

		,dbo.fn_printer_physical_status_severity(max(p.PhysStatus), ISNULL(MAX(p.snmpCheck),'0')) PhysicalStatusSeverity
		,dbo.verbosePrinterPhysicalStatusByLanguage(max(p.PhysStatus), ISNULL(MAX(p.snmpCheck),'0'), @iLanguageId) PhysicalStatusVerbose
		,MAX(p.region)
		,COUNT(t.ticketId)
		,MAX(p.printerIp)
		,MAX(m.modelName)
		,MAX(p.printerAdminComment)
	from tbl_printer p 
	left join tbl_model m on p.printerModel =m.modelId 
	left join tbl_region r on p.region=r.regionId 
--	left join tbl_lregion lr on p.region=lr.lregionId 
--	left join tbl_event_status_open e on p.printerId = e.statopenPrinterId AND statOpenPhysStatus = 1
	left join OpenPrinterStatus e on e.PrinterId = p.printerId
	left join tbl_queue_printer_map map	on map.mapPhyPrinter = p.printerId
	left join tbl_ticket t	on t.queueId = map.mapQueue
	where	(@iusername IS NULL OR t.userName LIKE @iusername)
			AND (@iprinterIP IS NULL OR p.printerIp LIKE @iprinterIP)
			AND (@iprinterName IS NULL OR p.printerName LIKE @iprinterName)
			AND (@ibrandId IS NULL OR m.modelBrandId = @ibrandId)
			AND (@imodelId IS NULL OR m.modelId = @imodelId)
			AND (@iprinterId IS NULL OR p.printerId = @iprinterId)

			AND p.adminStatus < 3
			AND p.printerType = @iprinterType

			AND ((printerHidden = 0) OR
				(@iHiddenPrinterUser IS NULL OR t.userName = @iHiddenPrinterUser))

	group by p.printerId, p.printerDisplayText , e.EventStartDate



	-- Smart alarms support
	-----------------------------------------------------------------------------

	-- Get All Current Smart Alarms
	CREATE TABLE #queuesmartalarms
		(AlarmTypeId		int				-- what type of alarm? 1 = job takes too long, 2 = max no of jobs in queue exceeded
		,AlarmSeverityId	int				-- 1 = warning, 2 = error
		,AlarmArea			int				-- 1=job, 2=queue, 3=printer
		,AlarmDescription	varchar(128)	COLLATE DATABASE_DEFAULT-- Verbose alarm description 
		,JobName			nvarchar(510)	COLLATE DATABASE_DEFAULT-- related ticket and queue (NULL if N/A)
		,TicketId			varchar(64)		COLLATE DATABASE_DEFAULT
		,QueueName			nvarchar(510)	COLLATE DATABASE_DEFAULT
		,QueueId			varchar(64)		COLLATE DATABASE_DEFAULT
		,NumericArg			int
		,UserName			nvarchar(510)	COLLATE DATABASE_DEFAULT)

	CREATE TABLE #printersmartalarms 
		(PrinterId			varchar(64)		COLLATE DATABASE_DEFAULT
		,AlarmSeverityId	int
		,AlarmCount			int
		,AlarmRank			int)

	INSERT #queuesmartalarms
	EXEC @ReturnStatus = sp_smartalarms_get_alarms		@iincludeWarnings	= 1 --@iincludeWarnings
														,@iincludeErrors	= 1 --@iincludeErrors

	SET @ErrorNo = @@ERROR
	IF @ReturnStatus <> 0 OR @ErrorNo <> 0
		GOTO PROC_ERROR;


	-- Get the highest severity per printer and the number of alarms with that severity
	WITH a (AlarmSeverityId, PrinterId, AlarmCount) AS
		(SELECT
			qa.AlarmSeverityId
			,map.mapPhyPrinter
			,COUNT(1)
		FROM #queuesmartalarms qa
		INNER JOIN tbl_queue_printer_map map
		ON map.mapQueue = qa.QueueId
		GROUP BY qa.AlarmSeverityId, map.mapPhyPrinter)
	INSERT #printersmartalarms
		(AlarmRank, AlarmSeverityId, PrinterId, AlarmCount)
	SELECT
		ROW_NUMBER() OVER(PARTITION BY PrinterId ORDER BY AlarmSeverityId DESC) AS RowNo
		,AlarmSeverityId
		,PrinterId
		,AlarmCount
	FROM a
	ORDER BY PrinterId, AlarmSeverityId DESC


	-- Merge tables
	UPDATE p
	SET p.HighestSmartAlarmLevel = psa.AlarmSeverityId
		,p.SmartAlarmCount = psa.AlarmCount
	FROM #printer p
	INNER JOIN #printersmartalarms psa
		ON p.PrinterId = psa.PrinterId
		AND psa.AlarmRank = 1

	UPDATE #printer
	SET HighestTotalAlarmLevel = 
			CASE WHEN PhysicalStatusSeverity > ISNULL(HighestSmartAlarmLevel,0) THEN PhysicalStatusSeverity
				 ELSE ISNULL(HighestSmartAlarmLevel,0) 
			END


	-- Return results
	SELECT	@oOKCount = COUNT(*) FROM #printer WHERE HighestTotalAlarmLevel = 0
	SELECT	@oWarningCount = COUNT(*) FROM #printer WHERE HighestTotalAlarmLevel = 1
	SELECT	@oErrorCount = COUNT(*) FROM #printer WHERE HighestTotalAlarmLevel = 2

	IF @iSilent = 0
		SELECT * FROM #printer
		WHERE (@iincludeOK = 1 AND (PhysicalStatusSeverity IN( 0,-1) AND ISNULL(HighestSmartAlarmLevel,0) = 0))
		OR (@iincludeWarnings = 1 AND (PhysicalStatusSeverity = 1 OR ISNULL(HighestSmartAlarmLevel,0) = 1))
		OR (@iincludeErrors = 1 AND (PhysicalStatusSeverity = 2 OR ISNULL(HighestSmartAlarmLevel,0) = 2))




	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)


	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_papersize_get') IS NOT NULL
	DROP PROCEDURE sp_papersize_get
GO

CREATE PROCEDURE sp_papersize_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-07
Description: Get information about a single or all paper sizes
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iPaperSize		int		= NULL


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	SELECT
	*
	FROM tbl_papersize
	WHERE ISNULL(@iPaperSize,PaperSize) = PaperSize
	ORDER BY PaperSize


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_priceplan_get_explicit') IS NOT NULL
	DROP PROCEDURE sp_priceplan_get_explicit
GO

CREATE PROCEDURE sp_priceplan_get_explicit
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-08
Description: Get actual calculated prices for a priceplan
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-04
Description: Fix for determining if a papersize is priced abs or rel.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-11
Description: Fix for changed column order in priceplan row
************************************************************/
	@iPricePlanId		varchar(64)
--	,@iJobType			int = NULL
--	,@iPaperSize		smallint = NULL
--	,@iDuplex			bit = NULL
--	,@iColor			bit = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF;


	IF NOT EXISTS (SELECT 1 FROM tbl_cirrato_priceplan WHERE cppId = @iPricePlanId)
		RETURN (100060)


	DECLARE @ThisPlan TABLE
		(RowId varchar(64)
		,PricePlanid varchar(64)
		,RowName nvarchar(64)
		,Type smallint
		,PaperSize smallint
		,Cost float
		,SubType smallint)

	INSERT @ThisPlan
	SELECT  
		cprId
		,cprPlanid
		,cprRowName
		,cprType
		,cprValue
		,cprCost
		,cprTypeSubtype
	FROM tbl_cirrato_priceplan_row r1 WHERE r1.cprPlanId = @iPricePlanId;

	DECLARE @DuplexMultiplier float
			,@ColorMultiplier float
			,@CopyMultiplier float
			,@ScanMultiplier float
			,@FaxMultiplier float

	SELECT @DuplexMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 2
	SELECT @ColorMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 3
	SELECT @CopyMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 4
	SELECT @ScanMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 5
	SELECT @FaxMultiplier = ISNULL(Cost,1) FROM @ThisPlan WHERE Type = 6;

	DECLARE @Prices TABLE (
		PaperSize smallint
		,BWSimplex float
		,BWDuplex  float
		,ColorSimplex float
		,ColorDuplex float
		,CopyBWSimplex float
		,CopyBWDuplex float
		,CopyColorSimplex float
		,CopyColorDuplex float
		,ScanBW float
		,ScanColor float);



	WITH PaperSizes (PaperSize, PricePlanType) AS
		(SELECT DISTINCT
			PaperSize
			,CASE WHEN EXISTS(SELECT * FROM @ThisPlan r2 
				WHERE r2.PaperSize = r1.PaperSize 
				AND ISNULL(r2.SubType,0) = 0) THEN 'rel' ELSE 'abs'  END
--				AND r2.SubType IS NOT NULL) THEN 'abs' ELSE 'rel' END
		FROM @ThisPlan r1 )
	INSERT @Prices
	SELECT 
		p.PaperSize

		,BasePrice.Cost						BWSimplex
		,BasePrice.Cost * @DuplexMultiplier BWDuplex	
		,BasePrice.Cost * @ColorMultiplier	ColorSimplex	
		,BasePrice.Cost * @ColorMultiplier * @DuplexMultiplier ColorDuplex	

		,BasePrice.Cost * @CopyMultiplier CopyBWSimplex
		,BasePrice.Cost * @DuplexMultiplier * @CopyMultiplier CopyBWDuplex	
		,BasePrice.Cost * @ColorMultiplier * @CopyMultiplier CopyColorSimplex	
		,BasePrice.Cost * @ColorMultiplier * @DuplexMultiplier * @CopyMultiplier CopyColorDuplex	

		,BasePrice.Cost * @ScanMultiplier ScanBW
		,BasePrice.Cost * @ScanMultiplier * @ColorMultiplier ScanColor
	FROM PaperSizes p
	INNER JOIN @ThisPlan BasePrice
		ON BasePrice.PaperSize = p.PaperSize
		AND BasePrice.Type IN (0, 1)
	WHERE p.PricePlanType = 'rel'

	UNION

	SELECT 
		p.PaperSize
		,BWSimplex.Cost BWSimplex
		,BWDuplex.Cost BWDuplex 
		,ColorSimplex.Cost ColorSimplex
		,ColorDuplex.Cost ColorDuplex

		,CopyBWSimplex.Cost CopyBWSimplex
		,CopyBWDuplex.Cost CopyBWDuplex
		,CopyColorSimplex.Cost
		,CopyColorDuplex.Cost

		,ScanBW.Cost ScanBW
		,ScanColor.Cost ScanColor
	FROM PaperSizes p

	LEFT JOIN @ThisPlan BWSimplex
		ON BWSimplex.PaperSize = p.PaperSize AND BWSimplex.Type = 1 AND BWSimplex.SubType = 10
	LEFT JOIN @ThisPlan BWDuplex
		ON BWDuplex.PaperSize = p.PaperSize AND BWDuplex.Type = 1 AND BWDuplex.SubType = 11
	LEFT JOIN @ThisPlan ColorSimplex
		ON ColorSimplex.PaperSize = p.PaperSize AND ColorSimplex.Type = 1 AND ColorSimplex.SubType = 12
	LEFT JOIN @ThisPlan ColorDuplex
		ON ColorDuplex.PaperSize = p.PaperSize AND ColorDuplex.Type = 1 AND ColorDuplex.SubType = 13

	LEFT JOIN @ThisPlan CopyBWSimplex
		ON CopyBWSimplex.PaperSize = p.PaperSize AND CopyBWSimplex.Type = 1 AND CopyBWSimplex.SubType = 20
	LEFT JOIN @ThisPlan CopyBWDuplex
		ON CopyBWDuplex.PaperSize = p.PaperSize AND CopyBWDuplex.Type = 1 AND CopyBWDuplex.SubType = 21
	LEFT JOIN @ThisPlan CopyColorSimplex
		ON CopyColorSimplex.PaperSize = p.PaperSize AND CopyColorSimplex.Type = 1 AND CopyColorSimplex.SubType = 22
	LEFT JOIN @ThisPlan CopyColorDuplex
		ON CopyColorDuplex.PaperSize = p.PaperSize AND CopyColorDuplex.Type = 1 AND CopyColorDuplex.SubType = 23

	LEFT JOIN @ThisPlan ScanBW
		ON ScanBW.PaperSize = p.PaperSize AND ScanBW.Type = 1 AND ScanBW.SubType = 30
	LEFT JOIN @ThisPlan ScanColor
		ON ScanColor.PaperSize = p.PaperSize AND ScanColor.Type = 1 AND ScanColor.SubType = 31

	WHERE p.PricePlanType = 'abs'


	-- Final output:

	SELECT
		1 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,0 AS Color
		,0 AS Duplex
		,BWSimplex Price
	FROM @Prices
	UNION 
	SELECT
		1 AS JobType
		,PaperSize	
		,0 AS Color
		,1 AS Duplex
		,BWDuplex Price
	FROM @Prices
	UNION 
	SELECT
		1 AS JobType
		,PaperSize	
		,1 AS Color
		,0 AS Duplex
		,ColorSimplex Price
	FROM @Prices

	UNION 
	SELECT
		1 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,1 AS Color
		,1 AS Duplex
		,ColorDuplex Price
	FROM @Prices

	UNION 
	SELECT
		2 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,0 AS Color
		,0 AS Duplex
		,CopyBWSimplex Price
	FROM @Prices
	UNION 
	SELECT
		2 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,0 AS Color
		,1 AS Duplex
		,CopyBWDuplex Price
	FROM @Prices
	UNION 
	SELECT
		2 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,1 AS Color
		,0 AS Duplex
		,CopyColorSimplex Price
	FROM @Prices
	UNION 
	SELECT
		2 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,1 AS Color
		,1 AS Duplex
		,CopyColorDuplex Price
	FROM @Prices
	UNION 
	SELECT
		4 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,0 AS Color
		,0 AS Duplex
		,ScanBW Price
	FROM @Prices
	UNION 
	SELECT
		4 AS JobType -- 1=print, 2=copy, 3=fax, 4=scan (enum JobType)
		,PaperSize	
		,1 AS Color
		,0 AS Duplex
		,ScanColor Price
	FROM @Prices

	ORDER BY 1,2,3,4


--SELECT @DuplexMultiplier DuplexMultiplier
--	 ,@ColorMultiplier ColorMultiplier
--	 ,@CopyMultiplier CopyMultiplier
--	 ,@ScanMultiplier ScanMultiplier
--	 ,@FaxMultiplier FaxMultiplier

--		SELECT * FROM @ThisPlan
--		SELECT * FROM @Prices

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_priceplan_get_range') IS NOT NULL
	DROP PROCEDURE sp_priceplan_get_range
GO

CREATE PROCEDURE sp_priceplan_get_range
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description: Given a price plan calculate Max, Min price per job type [print, copy, scan, fax]
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iPricePlanId		varchar(64)
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF;

	DECLARE @Prices TABLE
	(JobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
	,PaperSize			tinyint
	,Color				bit
	,Duplex				bit
	,TicketPrice		float)

	INSERT @Prices
	EXEC @ReturnStatus = sp_priceplan_get_explicit @iPricePlanId = @iPricePlanId

	IF @ReturnStatus <> 0
		RETURN (@ReturnStatus)


	SELECT
		JobType
		,MIN(TicketPrice) AS MinimumTicketPrice
		,MAX(TicketPrice) AS MaximumTicketPrice
	FROM @Prices
	GROUP BY JobType
	ORDER BY JobType

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_priceplan_get_ticket_price') IS NOT NULL
	DROP PROCEDURE sp_priceplan_get_ticket_price
GO

CREATE PROCEDURE sp_priceplan_get_ticket_price
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-13
Description: Given a price plan and job details, calculate the price
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-04
Description: Added min/max price for a one-page ticket of given JobType in the current priceplan.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-06
Description: Added option to use pre-calculated priceplans. Useful if this function is called multiple times with same PricePlan.
************************************************************/
	@iPricePlanId		varchar(64)
	,@iJobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
	,@iPagesBW			int
	,@iPagesColor		int
	,@iPaperSize		tinyint
	,@iDuplex			bit
	,@oTicketPrice		float	OUTPUT
	,@oMinTicketPrice	float	OUTPUT
	,@oMaxTicketPrice	float	OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@PriceBW				float
			,@PriceColor			float


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF;

	SET @oTicketPrice	 = NULL
	SET @oMinTicketPrice = NULL
	SET @oMaxTicketPrice = NULL

	DECLARE @Prices TABLE
	(JobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
	,PaperSize			tinyint
	,Color				bit
	,Duplex				bit
	,TicketPrice		float)

	IF object_id('tempdb..#Prices') IS NULL -- calculate prices for the priceplan
	BEGIN
		INSERT @Prices
		EXEC @ReturnStatus = sp_priceplan_get_explicit @iPricePlanId = @iPricePlanId

		IF @ReturnStatus <> 0
			RETURN (@ReturnStatus)
		END
	ELSE
	BEGIN -- priceplan is precalculates
		INSERT @Prices
		SELECT * FROM #Prices
	END

	-- if papersize is explicit, get it, otherwise use default price (papersize = 0)

	SELECT TOP 1
		@PriceBW = TicketPrice * (cast (@iPagesBW as float))
	FROM @Prices WHERE	
		JobType = @iJobType
		AND Duplex = @iDuplex
		AND Color = 0
		AND (PaperSize = @iPaperSize
			OR PaperSize = 0)
	ORDER BY PaperSize DESC

	SELECT TOP 1
		@PriceColor = TicketPrice * (cast (@iPagesColor as float))
	FROM @Prices WHERE	
		JobType = @iJobType
		AND Duplex = @iDuplex
		AND Color = 1
		AND (PaperSize = @iPaperSize
			OR PaperSize = 0)
	ORDER BY PaperSize DESC


	SET @oTicketPrice = ISNULL(@PriceBW,0) + ISNULL(@PriceColor,0)


	-- Return min/max price
	SELECT
		@oMinTicketPrice	= MIN(TicketPrice)
		,@oMaxTicketPrice	= MAX(TicketPrice)
	FROM @Prices
	WHERE JobType = @iJobType
	GROUP BY JobType


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_printerbrand_get') IS NOT NULL
	DROP PROCEDURE sp_printerbrand_get
GO

CREATE PROCEDURE sp_printerbrand_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-09
Description: Get all printer brands currently in system
************************************************************/

AS
BEGIN

	DECLARE @ErrorNo int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT 
		 brandId
		,brandName
		,brandComment
	 FROM tbl_brand
	ORDER BY brandName



	SET @ErrorNo = @@ERROR

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_printermodel_get') IS NOT NULL
	DROP PROCEDURE sp_printermodel_get
GO

CREATE PROCEDURE sp_printermodel_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-09
Description: Get printer models, optionally by brand
************************************************************/
	@ibrandId varchar(64)	 = NULL
AS
BEGIN

	DECLARE @ErrorNo int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT 
		modelId
		,modelBrandId brandId
		,modelName
		,modelComment
	 FROM tbl_model
	WHERE modelVisible = 1
	AND (modelBrandId = @ibrandId
		OR @ibrandId IS NULL)
	ORDER BY modelName


	SET @ErrorNo = @@ERROR

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_printer_get_id_by_ip') IS NOT NULL
	DROP PROCEDURE sp_printer_get_id_by_ip
GO

CREATE PROCEDURE sp_printer_get_id_by_ip
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-04-20
Description: Get the id of a printer given its IP
-------------------------------------------------------------
Created by:  Henrik Linder
Creation date: 2009-09-30
Description: Get the id of a printer given its IP
************************************************************/
	@iPrinterIP			varchar(64)
	,@oPrinterId		varchar(64) OUTPUT
AS
BEGIN


	SELECT @oPrinterId = NULL

	SELECT @oPrinterId = printerId FROM tbl_printer WHERE printerIp = @iPrinterIP AND adminStatus < 3

	IF @oPrinterId IS NULL
		RETURN (100015)

	RETURN (0)

END
GO

IF OBJECT_ID('sp_printer_get_info') IS NOT NULL
	DROP PROCEDURE sp_printer_get_info
GO

CREATE PROCEDURE sp_printer_get_info
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-13
Description: Get basic information about a printer
------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
	@iPrinterId			varchar(64)

AS
BEGIN


	IF NOT EXISTS( SELECT 1 FROM tbl_printer WHERE printerId = @iPrinterId AND adminStatus <> 3) -- 3 = deleted
		RETURN (100015)


	SELECT * FROM tbl_printer WHERE printerId = @iPrinterId
	RETURN (0)

END
GO

IF OBJECT_ID('sp_printer_get_name') IS NOT NULL
	DROP PROCEDURE sp_printer_get_name
GO

CREATE PROCEDURE sp_printer_get_name
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-12
Description: Get the name of a printer
************************************************************/
	@iprinterId			varchar(64) = NULL
	,@oprinterName		nvarchar(510) OUTPUT
AS
BEGIN

	SELECT @oprinterName = NULL

	IF NOT EXISTS( SELECT 1 FROM tbl_printer WHERE printerId = @iprinterId)
		RETURN (100015)

	SELECT @oprinterName = printerName FROM tbl_printer WHERE printerId = @iprinterId


	RETURN (0)

END
GO

IF OBJECT_ID('sp_printer_get_queues') IS NOT NULL
	DROP PROCEDURE sp_printer_get_queues
GO

CREATE PROCEDURE sp_printer_get_queues
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-13
Description: Get queues belonging to a printer
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-23
Description: Do not list deleted queues
************************************************************/
	@iprinterId			varchar(64)

AS
BEGIN


	IF NOT EXISTS( SELECT 1 FROM tbl_printer WHERE printerId = @iprinterId AND adminStatus <> 3) -- 3 = deleted
		RETURN (100015)


	SELECT q.* FROM tbl_queue q 
	INNER JOIN tbl_queue_printer_map map
		ON map.mapQueue = q.queueId
	WHERE map.mapPhyPrinter = @iprinterId
		AND q.queueStatus < 3
	RETURN (0)

END
GO

IF OBJECT_ID('sp_printer_get_tickets') IS NOT NULL
	DROP PROCEDURE sp_printer_get_tickets
GO

CREATE PROCEDURE sp_printer_get_tickets
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-13
Description: Get tickets for a printer (for display in Web)
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
************************************************************/
	@iprinterId				varchar(64) 
	,@iruleStatus			smallint		= 0
	,@iIncludeActive		bit				= 1
	,@iIncludeOld			bit				= 0
	,@iStartDate			datetime		= '20000101'
	,@iEndDate				datetime		= '99991231'
	,@iLanguageId			char(2)			= 'en'
AS
BEGIN
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE @ReturnStatus INT

	CREATE TABLE #queues (queueId varchar(64) COLLATE DATABASE_DEFAULT ) 

	INSERT #queues (queueId) 
	select mapQueue from tbl_queue_printer_map
	where mapPhyPrinter = @iprinterId


	CREATE TABLE #tickets (	ticketId		varchar(64)	COLLATE DATABASE_DEFAULT
							,ticketActive	bit
							,DateEvent datetime)

	IF (@iIncludeActive = 1)
		INSERT #tickets (ticketId, ticketActive) 
		SELECT t.ticketId, 1
		FROM tbl_ticket t
		JOIN #queues q
			on q.queueId = t.queueId


	IF (@iIncludeOld = 1)
	BEGIN
		INSERT #tickets (ticketId, ticketActive, DateEvent)
		Select TOP 100 t.logticketId, 0, MAX(logdateEvent)
		from tbl_ticket_log t
		where	t.logprinterId = @iprinterId
				AND t.logdateEvent BETWEEN @iStartDate AND @iEndDate
				AND t.logticketId NOT IN (SELECT ticketId FROM tbl_ticket)
		GROUP BY t.logticketId
		ORDER BY MAX(logdateEvent) DESC
	END



	EXEC @ReturnStatus = sp_get_tickets_sub @iruleStatus = @iruleStatus, @iLanguageId = @iLanguageId

	DROP TABLE #queues
	DROP TABLE #tickets

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ReturnStatus)

END
GO

IF OBJECT_ID('sp_printer_snmp_refresh') IS NOT NULL
	DROP PROCEDURE sp_printer_snmp_refresh
GO

CREATE PROCEDURE sp_printer_snmp_refresh
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-04-14
Description: Refresh SNMP status for a single printer, or all printers if PrinterId is null
------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
	@iPrinterId			varchar(64) = NULL

AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF (@iPrinterId IS NOT NULL AND NOT EXISTS(SELECT 1 FROM tbl_printer where printerId = @iPrinterId))
		RETURN (100015)	--Printer does not exist.


	IF @iPrinterId IS NOT NULL
	BEGIN
		UPDATE tbl_printer SET printerNextCheck = getdate() WHERE printerId = @iPrinterId
	END
	ELSE
	BEGIN
		UPDATE tbl_printer SET printerNextCheck = getdate()
	END



	SET @ReturnStatus = 0



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ReturnStatus)


	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_property_get') IS NOT NULL
	DROP PROCEDURE sp_property_get
GO

CREATE PROCEDURE sp_property_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Get all values of a property (or properties, if Group is not given and name occurs in multiple groups)
------------------------------------------------------------
Modified by: Henrik Linder 
Modification date: 2009-09-08
Description: Get results when propertyname only is given, and propertyGroup IS NULL in the table
************************************************************/
	@iPropertyGroup				varchar(64)		= NULL
	,@iPropertyName				varchar(64)		= NULL
AS
BEGIN

	DECLARE @ErrorNo int

	IF @ipropertyName IS NOT NULL AND NOT EXISTS (SELECT 1 FROM tbl_property WHERE propertyName = @ipropertyName)
		RETURN (100035)

	SELECT
		*	
	FROM tbl_property
	WHERE ISNULL(@ipropertyName, propertyName) = propertyName
	AND ISNULL(@iPropertyGroup, ISNULL(propertyGroup,'')) = ISNULL(propertyGroup,'')

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_property_ins') IS NOT NULL
	DROP PROCEDURE sp_property_ins
GO

CREATE PROCEDURE sp_property_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-03
Description: Insert a new property
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-03
Description: Added property group parameter
************************************************************/
	@ipropertyGroup				varchar(64)		= NULL
	,@ipropertyName				varchar(64)
	,@ipropertyValue			nvarchar(510)	= NULL
	,@ipropertyValueNumeric		int				= NULL
	,@ipropertyValueDate		datetime		= NULL
	,@ipropertyCreatedBy		nvarchar(510)
	,@ipropertyDescription		varchar(100)	= NULL
AS
BEGIN

	DECLARE @ErrorNo int

	IF EXISTS (SELECT 1 FROM tbl_property WHERE propertyName = @ipropertyName)
		RETURN (100011)


	INSERT tbl_property 
		(propertyGroup
		,propertyName
		,propertyValue
		,propertyChangedBy
		,propertyValueNumeric
		,propertyValueDate
		,propertyDescription)
	VALUES
		(@ipropertyGroup
		,@ipropertyName
		,@ipropertyValue
		,@ipropertyCreatedBy
		,@ipropertyValueNumeric
		,@ipropertyValueDate
		,@ipropertyDescription)


	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_property_missing_get') IS NOT NULL
	DROP PROCEDURE sp_property_missing_get
GO

CREATE PROCEDURE sp_property_missing_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-08
Description: List all missing properties (WIP)
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iMinSeverity			int		= 0


AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- do stuff
--
--declare @props table(propertyName varchar	(64)
--					,propertyGroup varchar	(64)
--					,propertyDescription varchar	(100)
--					,propertyImportance int)
--
--INSERT @props 
--SELECT propertyName,propertyGroup,propertyDescription FROM tbl_property




	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_property_upd') IS NOT NULL
	DROP PROCEDURE sp_property_upd
GO

CREATE PROCEDURE sp_property_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Update a property value
------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
	@ipropertyGroup				varchar(64)		= NULL
	,@ipropertyName				varchar(64)
	,@ipropertyValue			nvarchar(510)	= NULL
	,@ipropertyValueNumeric		int				= NULL
	,@ipropertyValueDate		datetime		= NULL
	,@ipropertyChangedBy		nvarchar(510)	= NULL
	,@ipropertyDescription		varchar(100)	= NULL
AS
BEGIN

	DECLARE @ErrorNo int

	IF NOT EXISTS (SELECT 1 FROM tbl_property WHERE propertyName = @ipropertyName)
		RETURN (100035)

	UPDATE tbl_property
	SET propertyGroup			= ISNULL(@ipropertyGroup, propertyGroup)
		,propertyValue			= ISNULL(@ipropertyValue, propertyValue)
		,propertyValueNumeric	= ISNULL(@ipropertyValueNumeric, propertyValueNumeric)
		,propertyValueDate		= ISNULL(@ipropertyValueDate, propertyValueDate)
		,propertyChangedBy		= ISNULL(@ipropertyChangedBy, propertyChangedBy)
		,propertyDescription	= ISNULL(@ipropertyDescription, propertyDescription)
	WHERE propertyName = @ipropertyName

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_queue_admin_action_do') IS NOT NULL
	DROP PROCEDURE sp_queue_admin_action_do
GO

CREATE PROCEDURE sp_queue_admin_action_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-11
Description: Start, stop, or pause a queue / printer
************************************************************/
	@iqueueId				varchar(64)
	,@iuser					nvarchar (256)
	,@idomain				nvarchar (256)
	,@itransIP				varchar(256)
	,@ireason				nvarchar(510)	 = NULL
	,@iqueueAction			varchar(7)
AS
BEGIN

	DECLARE @ErrorNo int
			,@transAct int

	IF @iqueueAction = 'STOP' SET @transAct = 1
	IF @iqueueAction = 'START' SET @transAct = 2
	IF @iqueueAction = 'PAUSE' SET @transAct = 3
	IF @iqueueAction = 'RESTART' SET @transAct = 4

 	IF @iqueueAction = 'STOP' AND @ireason IS NULL
		RETURN (100013)

	IF @transAct IS NULL
		RETURN (100014)

	IF NOT EXISTS (SELECT 1 FROM tbl_queue WHERE queueId = @iqueueId AND queueStatus < 3)
		AND NOT EXISTS (SELECT 1 FROM tbl_printer WHERE printerId = @iqueueId AND adminStatus < 3)
		RETURN (100005)

--	Reason kan l�ggas till in i tbl_printer ????


	UPDATE tbl_queue
		SET queueNewStatus = @transAct
	WHERE queueId = @iqueueId


	UPDATE tbl_printer
		SET printerNewStatus = @transAct
	WHERE printerId = @iqueueId


	INSERT tbl_transaction
			(transAffId
			,transAct
			,transText
			,transUser
			,transDomain
			,transIP)
	VALUES (@iqueueId						--	transAffId
			,@transAct						--	transAct
			,ISNULL(@ireason,'')			--	transText
			,@iuser							--	transUser
			,@idomain						--	transDomain
			,@itransIP)						--	transIP

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_queue_get_name') IS NOT NULL
	DROP PROCEDURE sp_queue_get_name
GO

CREATE PROCEDURE sp_queue_get_name
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-30
Description: Get the name of a queue
************************************************************/
	@iqueueId			varchar(64) = NULL
	,@oqueueName		nvarchar(510) OUTPUT
AS
BEGIN

	SELECT @oqueueName = NULL

	IF NOT EXISTS( SELECT 1 FROM tbl_queue WHERE queueId = @iqueueId)
		RETURN (100005)

	SELECT @oqueueName = queueName FROM tbl_queue WHERE queueId = @iqueueId


	RETURN (0)

END
GO

IF OBJECT_ID('sp_queue_get_overview') IS NOT NULL
	DROP PROCEDURE sp_queue_get_overview
GO

CREATE PROCEDURE sp_queue_get_overview
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-09
Description: Get an overview of all active queues
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-19
Description: Added option to choose queue type
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-12
Description: Return print speed and stop reason
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-23
Description: Added support for hidden queues
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-25
Description: Added support for SNMP turned off
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-22
Description: Ticket 96 / Show queue, not printer, model
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-15
Description: Added multi-language support
************************************************************/
	@iincludeOK			bit = 1
	,@iincludeWarnings	bit = 1
	,@iincludeErrors	bit = 1
	,@iusername			nvarchar(510)	= NULL
	,@iprinterIP		varchar(100)	= NULL
	,@iqueueName		nvarchar(510)	= NULL
	,@ibrandId			varchar(64)		= NULL
	,@imodelId			varchar(64)		= NULL
	,@iqueueId			varchar(64)		= NULL
	,@iqueueType		smallint		= 1 -- 1 = Regular queue, 3 = FollowPrint Queue
	,@iSilent			bit				= 0 
	,@iHiddenQueueUser	nvarchar(510)	= NULL
	,@iLanguageId		char(2)			= 'en'
AS
BEGIN
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@CurrentTimestamp			datetime
	
	IF OBJECT_ID('tempdb..#queue') IS NULL
	CREATE TABLE #queue
	(QueueId					varchar(64)		COLLATE DATABASE_DEFAULT
	,QueueName					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,RegionPath					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,Location					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,QueueStatusVerbose			varchar(64)		COLLATE DATABASE_DEFAULT
	,PrinterStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
	,ErrorTime					datetime
	,LastCheck					int
	,DisplayText				nvarchar(200)	COLLATE DATABASE_DEFAULT
	,PhysicalStatusSeverity		int
	,PhysicalStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
	,NewStatusVerbose			varchar(64)		COLLATE DATABASE_DEFAULT
	,HighestSmartAlarmLevel		int
	,SmartAlarmCount			int	
	,HighestTotalAlarmLevel		int
	,PrinterIP					varchar(64)		COLLATE DATABASE_DEFAULT
	,PrinterId					varchar(64)		COLLATE DATABASE_DEFAULT
	,PrinterName					nvarchar(510)	COLLATE DATABASE_DEFAULT
	,ModelName					nvarchar(512)	COLLATE DATABASE_DEFAULT
	,JobCount					int
	,RegionId					bigint
	,AdminComment				nvarchar(510)	COLLATE DATABASE_DEFAULT
	,OfflineReason				nvarchar(256)	COLLATE DATABASE_DEFAULT
	,PagesPerMinuteBWSingle		real
	,PagesPerMinuteColorSingle	real
	,PagesPerMinuteBWDuplex		real
	,PagesPerMinuteColorDuplex	real)


	CREATE TABLE #smartalarmsaggregatequeue
	(QueueId				varchar(64)		COLLATE DATABASE_DEFAULT
	,HighestAlarmSeverityId int
	,AlarmCount				int)


	INSERT #queue
		(QueueId	
		,PrinterIP
		,PrinterId
		,PrinterName
		,QueueName
		,ModelName
		,JobCount				
		,RegionPath				
		,Location			
		,QueueStatusVerbose
		,PrinterStatusVerbose
		,PhysicalStatusSeverity		
		,PhysicalStatusVerbose
		,NewStatusVerbose
		,RegionId
		,AdminComment
		,OfflineReason
		,PagesPerMinuteBWSingle		
		,PagesPerMinuteColorSingle	
		,PagesPerMinuteBWDuplex		
		,PagesPerMinuteColorDuplex)
	SELECT 
		q.queueid as 'queueid'
		,max(p.printerIp) as 'PrinterIp'
		,max(p.printerId) as 'PrinterId'
		,max(p.printerName) 
		,max(q.queuename) as 'QueueName'
		,max(l.modelName) as 'Model'
		,count(t.ticketId) as 'JobCount'
		,max(dbo.GetAbsoluteRegion(q.queueRegion))as 'Region'
		,max(q.queueLocation) as 'Location' -- max(p.printerLocation) as 'Location'
		,dbo.verbosePrinterAggregatedStatusByLanguage(ISNULL(MAX(q.queueStatus),0), ISNULL(MAX(q.queueNewStatus),0), @iLanguageId) AS QueueStatusVerbose
		,dbo.verbosePrinterAggregatedStatusByLanguage(ISNULL(MAX(p.adminStatus),0), ISNULL(MAX(p.printerNewStatus),0), @iLanguageId) AS PrinterStatusVerbose
		,dbo.fn_printer_physical_status_severity(max(p.PhysStatus), ISNULL(MAX(p.snmpCheck),'0')) -- PhysicalStatusSeverity
		,dbo.verbosePrinterPhysicalStatusByLanguage(max(p.PhysStatus), ISNULL(MAX(p.snmpCheck),'0'), @iLanguageId)
		,dbo.verbosePrinterNewStatusByLanguage(max(p.printernewstatus), @iLanguageId)
		,MAX(p.region) RegionId
		,MAX(q.queueAdminComment) AdminComment
		,MAX(q.OfflineReason)
		,MAX(PagesPerMinuteBWSingle)		
		,MAX(PagesPerMinuteColorSingle)	
		,MAX(PagesPerMinuteBWDuplex)		
		,MAX(PagesPerMinuteColorDuplex)
	from tbl_queue q 
	left join  tbl_queue_printer_map m on q.queueid= m.mapqueue
	left join tbl_printer p on p.printerid = m.mapphyprinter 
	left join tbl_model l on q.queueModelId = l.modelId
	left join tbl_region r on p.region=r.regionId  
	left join tbl_ticket t on t.queueid=q.queueId  
	where (@iusername IS NULL OR t.userName LIKE @iusername)
			AND (@iprinterIP IS NULL OR p.printerIp LIKE @iprinterIP)
			AND (@iqueueName IS NULL OR q.queueName LIKE @iqueueName)
			AND (@ibrandId IS NULL OR l.modelBrandId = @ibrandId)
			AND (@imodelId IS NULL OR l.modelId = @imodelId)
			AND (@iqueueId IS NULL OR q.queueId = @iqueueId)
			AND q.queueType = @iqueueType
			AND q.queueStatus < 3 
			AND ((queueHidden = 0) OR
				(@iHiddenQueueUser IS NULL OR t.userName = @iHiddenQueueUser))
	group by q.queueid


	-- Smart alarms
	--------------------------------------------------------------------------
	EXEC @ReturnStatus = sp_smartalarms_aggregate_by_queue -- result is avail in #smartalarmsaggregatequeue

	SET @ErrorNo = @@ERROR
	IF @ReturnStatus <> 0 OR @ErrorNo <> 0
		GOTO PROC_ERROR;

	UPDATE q
	SET q.HighestSmartAlarmLevel = qsa.HighestAlarmSeverityId
		,q.SmartAlarmCount = qsa.AlarmCount
	FROM #queue q
	INNER JOIN #smartalarmsaggregatequeue qsa
		ON q.QueueId = qsa.QueueId

	UPDATE #queue
	SET HighestTotalAlarmLevel = 
			CASE WHEN PhysicalStatusSeverity > ISNULL(HighestSmartAlarmLevel,0) THEN PhysicalStatusSeverity
				 ELSE ISNULL(HighestSmartAlarmLevel,0) 
			END



	--	Return results
	IF @iSilent = 0
		SELECT * FROM #queue
		WHERE (@iincludeOK = 1 AND HighestTotalAlarmLevel = 0)
		OR (@iincludeWarnings = 1 AND HighestTotalAlarmLevel = 1)
		OR (@iincludeErrors = 1 AND HighestTotalAlarmLevel = 2)
		ORDER BY QueueName



	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_queue_get_related_queues_by_printer') IS NOT NULL
	DROP PROCEDURE sp_queue_get_related_queues_by_printer
GO

CREATE PROCEDURE sp_queue_get_related_queues_by_printer
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-09
Description: Get queues that are related to the given printer, 
			 i.e in same folder and of same make
************************************************************/
	@iprinterId			varchar(64) = NULL
AS
BEGIN

	DECLARE @queueId varchar(64)
			,@ReturnStatus int	

	SELECT TOP 1 @queueId = mapQueue
	FROM tbl_queue_printer_map qpm
	WHERE qpm.mapPhyPrinter = @iprinterId
	ORDER BY mapQueue

	EXEC @ReturnStatus = sp_queue_get_related_queues_by_queue @queueId


	RETURN @ReturnStatus

END
GO

IF OBJECT_ID('sp_queue_get_related_queues_by_queue') IS NOT NULL
	DROP PROCEDURE sp_queue_get_related_queues_by_queue
GO

CREATE PROCEDURE sp_queue_get_related_queues_by_queue
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-09
Description: Get queues that are related to the given queue, 
			 i.e in same folder and of same make
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-03
Description: Do not include deleted queues (queuestatus = 3)
************************************************************/
	@iqueueId			varchar(64) = NULL
	,@iincludeSelf		bit = 0
AS
BEGIN

	
	SELECT b.queueId, b.queueName 
	FROM 
	(select * from tbl_queue q1
		join tbl_model m1
		on q1.queueModelId = m1.modelId) a
	join 	
	(select * from tbl_queue q1
	join tbl_model m1
		on q1.queueModelId = m1.modelId) b
	on a.modelBrandId = b.modelBrandId
		and a.queueRegion = b.queueRegion
		and a.queueId <> b.queueId
		and a.queueId = @iqueueId
	where b.queueStatus <> 3
	
	UNION

	select queueId, queueName 
	from tbl_queue q
	where q.queueId = @iqueueId AND @iincludeSelf = 1	

	ORDER BY queueName

	RETURN (0)

END
GO

IF OBJECT_ID('sp_queue_get_tickets') IS NOT NULL
	DROP PROCEDURE sp_queue_get_tickets
GO

CREATE PROCEDURE sp_queue_get_tickets
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-13
Description: Get tickets for a queue (for display in Web)
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-19
Description: Added options to include old tickets and to limit by date
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
************************************************************/
	@iqueueId					varchar(64) 
	,@iruleStatus				smallint		= 0
	,@iIncludeActiveTickets		bit				= 1 
	,@iIncludeOldTickets		bit				= 0 
	,@istartDate				datetime		= '20000101'
	,@iendDate					datetime		= '99990101'
	,@iLanguageId				char(2)			= 'en'
AS
BEGIN
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE @ReturnStatus INT


	CREATE TABLE #tickets (	ticketId		varchar(64)	COLLATE DATABASE_DEFAULT
							,ticketActive	bit
							,DateEvent datetime)

	IF (@iIncludeActiveTickets = 1)
		INSERT #tickets (ticketId, ticketActive) 
		SELECT t.ticketId, 1
		FROM tbl_ticket t
		where t.queueId = @iqueueId


	IF (@iIncludeOldTickets = 1)
		INSERT #tickets (ticketId, ticketActive,DateEvent)
		Select TOP 100 t.logticketId, 0, MAX(logdateEvent)
		from tbl_ticket_log t
		where
			(t.logqueueId = @iqueueId)
			AND t.logticketId NOT IN (SELECT ticketId FROM tbl_ticket)
			AND t.logdateEvent >= @istartDate
			AND t.logdateEvent <= @iendDate
		GROUP BY t.logticketId
		ORDER BY MAX(logdateEvent) DESC



	EXEC @ReturnStatus = sp_get_tickets_sub @iruleStatus = @iruleStatus, @iLanguageId = @iLanguageId

	DROP TABLE #tickets

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ReturnStatus)

END
GO

IF OBJECT_ID('sp_queue_install') IS NOT NULL
	DROP PROCEDURE sp_queue_install
GO

CREATE PROCEDURE sp_queue_install
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-22
Description: Install a queue on a client machine
************************************************************/
	@iqueueId				varchar(64)
	,@iuser					nvarchar (256)
	,@idomain				nvarchar (256)
	,@itransIP				varchar(256)
AS
BEGIN

	DECLARE @ErrorNo int


	IF NOT EXISTS (SELECT 1 FROM tbl_queue WHERE queueId = @iqueueId AND queueStatus < 3)
		RETURN (100005)

	INSERT tbl_transaction
			(transAffId
			,transAct
			,transText
			,transUser
			,transDomain
			,transIP)
	VALUES (@iqueueId	--	transAffId
			,9			--	transAct. -- 9 = installera k�
			,''			--	transText
			,@iuser		--	transUser
			,@idomain	--	transDomain
			,@itransIP)	--	transIP

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_queue_remove') IS NOT NULL
	DROP PROCEDURE sp_queue_remove
GO

CREATE PROCEDURE sp_queue_remove
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-11
Description: Remove a queue from a client machine
************************************************************/
	@iqueueId				varchar(64)
	,@iuser					nvarchar (256)
	,@idomain				nvarchar (256)
	,@itransIP				varchar(256)
AS
BEGIN

	DECLARE @ErrorNo int


	IF NOT EXISTS (SELECT 1 FROM tbl_queue WHERE queueId = @iqueueId AND queueStatus < 3)
		RETURN (100005)

	INSERT tbl_transaction
			(transAffId
			,transAct
			,transText
			,transUser
			,transDomain
			,transIP)
	VALUES (@iqueueId	--	transAffId
			,10			--	transAct. 
			,''			--	transText
			,@iuser		--	transUser
			,@idomain	--	transDomain
			,@itransIP)	--	transIP

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_queue_search') IS NOT NULL
	DROP PROCEDURE sp_queue_search
GO

CREATE PROCEDURE sp_queue_search
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-12
Description: Search for queues given queue name
************************************************************/
	@iqueueName			nvarchar(510) 
AS
BEGIN

	
	SELECT	b.queueId
			,b.queueName
			,'full/path/to/queue/' fullPath --to do
	FROM tbl_queue b
	WHERE b.queueName LIKE '%' + @iqueueName + '%'


	RETURN (0)

END
GO

IF OBJECT_ID('sp_queue_speed_upd') IS NOT NULL
	DROP PROCEDURE sp_queue_speed_upd
GO

CREATE PROCEDURE sp_queue_speed_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-20
Description: Calculate printing speeds per queue (to be called from scheduled job)
************************************************************/

AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@PrintStartDate			datetime
			,@PrintEndDate				datetime
			,@DefaultPaperSize			int
			,@RunId						int
		
	SET @ReturnStatus = 0

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Fetch data before running
	------------------------------------------------------------------------
	SET @DefaultPaperSize = dbo.fn_property_get_numeric('DefaultPaperSize');

	SELECT 	TOP 1
			@PrintStartDate	= PrintEndDate
	FROM tbl_queue_speed_run_log
	ORDER BY RunId DESC

	IF @PrintStartDate IS NULL SET @PrintStartDate = '20000101'

	SET @PrintEndDate = getdate()

	INSERT tbl_queue_speed_run_log (RunStartDate, PrintStartDate, PrintEndDate)
	VALUES (@PrintEndDate, @PrintStartDate, @PrintEndDate)

	SET @RunId = @@IDENTITY

	-- TEST:
--	SET @PrintStartDate = '20081101'
--	SET @PrintEndDate = '20081102'


	-- Calculate statistics since last run
	------------------------------------------------------------------------

	-- Only count jobs that have a print speed between 1 and 60 pages per minute


	DECLARE @jobs TABLE (QueueId varchar(64), Pages int, Duration int, Color smallint, Duplex smallint, PaperSize int)

	-- Insert jobs with data from printer driver only
	-- !! Commented out because this data is unreliable - prints with more than 1 page per sheet are not indicated, giving wrong statistics. !!
--	INSERT @jobs
--	SELECT
--			t.logQueueId
--			,SUM(logpages)
--			,SUM(datediff(s,logdateBegan, logdateFinished))
--			,t.logcolor
--			,t.logduplex
--			,t.logpaper
--	FROM tbl_ticket_log t
--	WHERE t.logEventMajor = 2 
--		AND t.logEventMinor = 1
--		AND logdateEvent > @PrintStartDate
--		AND logdateEvent <= @PrintEndDate -- there is an index on logdateEvent that we can use
--		AND datediff(s,logdateBegan, logdateFinished) > 0
--		AND t.logLoggedBWPages = 0 
--		AND t.logLoggedColorPages = 0
--		AND cast(logpages as real) / (cast(datediff(s,logdateBegan, logdateFinished) as real)/60.0) BETWEEN 1 AND 60
--	GROUP BY
--		t.logQueueId
--		,t.logcolor
--		,t.logduplex
--		,t.logpaper


	-- Insert BW jobs with data from SNMP monitoring
	INSERT @jobs
	SELECT
			t.logQueueId
			,SUM(logLoggedBWPages)
			,ROUND ( SUM(datediff(s,logdateBegan, logdateFinished) 
				* (cast(logLoggedBWPages as real) / 
					(cast(logLoggedBWPages as real) + cast(logLoggedColorPages as real)))
				),0)
			,1
			,t.logduplex
			,t.logpaper
	FROM tbl_ticket_log t
	WHERE t.logEventMajor = 2 
		AND t.logEventMinor = 1
		AND logdateEvent > @PrintStartDate
		AND logdateEvent <= @PrintEndDate -- there is an index on logdateEvent that we can use
		AND datediff(s,logdateBegan, logdateFinished) > 0
		AND t.logLoggedBWPages <> 0 
		AND cast(logLoggedBWPages as real) / (cast(datediff(s,logdateBegan, logdateFinished) as real)/60.0) BETWEEN 1 AND 60
	GROUP BY
		t.logQueueId
		,t.logcolor
		,t.logduplex
		,t.logpaper

	-- Insert color jobs with data from SNMP monitoring
	INSERT @jobs
	SELECT
			t.logQueueId
			,SUM(logLoggedColorPages)
			,ROUND ( SUM(datediff(s,logdateBegan, logdateFinished) 
				* (cast(logLoggedColorPages as real) / 
					(cast(logLoggedBWPages as real) + cast(logLoggedColorPages as real)))
				),0)
			,2
			,t.logduplex
			,t.logpaper
	FROM tbl_ticket_log t
	WHERE t.logEventMajor = 2 
		AND t.logEventMinor = 1
		AND logdateEvent > @PrintStartDate
		AND logdateEvent <= @PrintEndDate -- there is an index on logdateEvent that we can use
		AND datediff(s,logdateBegan, logdateFinished) > 0
		AND t.logLoggedColorPages <> 0 
		AND cast(logLoggedColorPages as real) / (cast(datediff(s,logdateBegan, logdateFinished) as real)/60.0) BETWEEN 1 AND 60
	GROUP BY
		t.logQueueId
		,t.logcolor
		,t.logduplex
		,t.logpaper


	-- Sum up
	INSERT tbl_queue_speed_status_log
		(RunId
		,QueueId
		,Pages
		,Duration
		,Color
		,Duplex
		,PaperSize)
	SELECT
		@RunId
		,t.QueueId
		,SUM(Pages)
		,SUM(Duration)
		,t.Color
		,t.Duplex
		,t.PaperSize
	FROM @jobs t
	GROUP BY
		t.QueueId
		,t.Color
		,t.Duplex
		,t.PaperSize

	IF @@ERROR <> 0 
	BEGIN
		SET @ErrorNo = 100017
		GOTO PROC_ERROR
	END



	-- Update accumulated statistics (insert new where previous missing)
	------------------------------------------------------------------------
	
	UPDATE qss
	SET qss.Pages = qss.Pages + qsr.Pages
		,qss.Duration = qss.Duration + qsr.Duration
	FROM tbl_queue_speed_status qss
	INNER JOIN tbl_queue_speed_status_log qsr
		ON qss.QueueId = qsr.QueueId
		AND qss.Color = qsr.Color
		AND qss.Duplex = qsr.Duplex
		AND qss.PaperSize = qsr.PaperSize
	WHERE qsr.RunId = @RunId

	IF @@ERROR <> 0 
	BEGIN
		SET @ErrorNo = 100018
		GOTO PROC_ERROR
	END

	INSERT tbl_queue_speed_status
		(QueueId
		,Pages
		,Duration
		,Color
		,Duplex
		,PaperSize)
	SELECT 
		qsr.QueueId
		,qsr.Pages
		,qsr.Duration
		,qsr.Color
		,qsr.Duplex
		,qsr.PaperSize
	FROM tbl_queue_speed_status_log qsr
	LEFT OUTER JOIN tbl_queue_speed_status qss
		ON qss.QueueId = qsr.QueueId
		AND qss.Color = qsr.Color
		AND qss.Duplex = qsr.Duplex
		AND qss.PaperSize = qsr.PaperSize
	WHERE qsr.RunId = @RunId
	AND qss.QueueId IS NULL

	IF @@ERROR <> 0 
	BEGIN
		SET @ErrorNo = 100019
		GOTO PROC_ERROR
	END;


	-- Update queue table with chosen subset of statistics
	------------------------------------------------------------------------

	DECLARE @qss TABLE (QueueId varchar(64), Pages bigint, Duration bigint, ColorBool bit , DuplexBool bit)

	INSERT @qss
	SELECT
		QueueId
		,SUM(Pages)
		,SUM(Duration)
		,CASE WHEN Color=2 THEN 1 ELSE 0 END
		,CASE WHEN Duplex=2 THEN 1 ELSE 0 END
	FROM tbl_queue_speed_status
--	WHERE PaperSize = @DefaultPaperSize
	GROUP BY	QueueId
				,CASE WHEN Color=2 THEN 1 ELSE 0 END	-- 0=Unknown, 1 = BW, 2=Color
				,CASE WHEN Duplex=2 THEN 1 ELSE 0 END	-- 0=Unknown, 1=nej, >1 = ja
	HAVING SUM(Pages) >= 1000
		AND SUM(Duration) > 0


	UPDATE q
		SET q.pagesPerMinuteBWSingle = cast(qss.Pages as real) / (cast(qss.Duration as real) / 60.0)
	FROM tbl_queue q
	INNER JOIN @qss qss
		ON q.QueueId = qss.QueueId
	WHERE qss.ColorBool = 0
		AND qss.DuplexBool = 0

	UPDATE q
		SET q.pagesPerMinuteColorSingle = cast(qss.Pages as real) / (cast(qss.Duration as real) / 60.0)
	FROM tbl_queue q
	INNER JOIN @qss qss
		ON q.QueueId = qss.QueueId
	WHERE qss.ColorBool = 1
		AND qss.DuplexBool = 0

	UPDATE q
		SET q.pagesPerMinuteBWDuplex = cast(qss.Pages as real) / (cast(qss.Duration as real) / 60.0)
	FROM tbl_queue q
	INNER JOIN @qss qss
		ON q.QueueId = qss.QueueId
	WHERE qss.ColorBool = 0
		AND qss.DuplexBool = 1

	UPDATE q
		SET q.pagesPerMinuteColorDuplex = cast(qss.Pages as real) / (cast(qss.Duration as real) / 60.0)
	FROM tbl_queue q
	INNER JOIN @qss qss
		ON q.QueueId = qss.QueueId
	WHERE qss.ColorBool = 1
		AND qss.DuplexBool = 1


	IF @@ERROR <> 0 
	BEGIN
		SET @ErrorNo = 100020
		GOTO PROC_ERROR
	END


	-- Update job run time
	------------------------------------------------------------------------
	UPDATE tbl_queue_speed_run_log
	SET RunEndDate = getdate()
	WHERE RunId = @RunId

	IF @@ERROR <> 0 
	BEGIN
		SET @ErrorNo = 100021
		GOTO PROC_ERROR
	END


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (0)


	PROC_ERROR:
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_region_get_children') IS NOT NULL
	DROP PROCEDURE sp_region_get_children
GO

CREATE PROCEDURE sp_region_get_children
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-21
Description: List children of a region. Option to include queues and/or printers in listing
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-09-07
Description: Added listing of printers + clickable maps columns.
************************************************************/
	@iparentRegionId			int		= 0
	,@iincludeQueues	bit				= 0 
	,@iincludePrinters	bit				= 0  -- todo
	,@iincludeHidden		bit			= 1  -- show hidden queues/printers?

AS
BEGIN

	DECLARE	@ReturnStatus			int

	-- Return error if an invalid region is supplied
	IF NOT EXISTS(SELECT 1 FROM tbl_region where regionId = @iparentRegionId or @iparentRegionId = 0)
		RETURN (100009)


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	select
		cast(regionId as varchar(64)) Identifier
		,regionName [Name]
		,regionActive Active
		,1 [Type]
		,2 SortOrder
		,NULL -- phy status
		,NULL -- new status
		,NULL -- model name
		,NULL -- comment
		,NULL -- location
		,regionSortOrder
		,regionMapFile
		,regionParentMapShape
		,regionParentMapCoords
		,NULL AS PrinterMapPosX
		,NULL AS PrinterMapPosY
	from tbl_region r
	where r.regionParentId = @iparentRegionId
		and regionActive = 1
	UNION
	
	SELECT
		queueId
		,queueName
		,1 Active
		,2 [Type]
		,3 SortOrder
		,dbo.verbosePrinterPhysicalStatus(p.physStatus, p.snmpCheck)
		,dbo.verbosePrinterNewStatus(p.printernewstatus)
		,m.modelName	--PrinterModelName
		,q.queueComment
		,q.queueLocation
		,NULL AS regionSortOrder
		,NULL AS regionMapFile
		,NULL AS regionParentMapShape
		,NULL AS regionParentMapCoords
		,NULL AS PrinterMapPosX
		,NULL AS PrinterMapPosY
	FROM tbl_queue q
	INNER JOIN tbl_queue_printer_map map -- m�ste joina denna v�g, q.queueRegion ger EJ r�tt resultat.
		ON q.queueId = map.mapqueue
	INNER JOIN tbl_printer p
		ON p.printerId = map.mapphyprinter
	LEFT JOIN tbl_model m
		on q.queueModelId = m.modelId
	WHERE --q.queueRegion = @iparentRegionId
		p.region = @iparentRegionId
		AND @iincludeQueues = 1
		AND q.queueType < 3
		AND q.queueStatus < 3 -- ej borttagen k�
		AND ((@iincludeHidden = 1) or q.queueHidden = 0)


	UNION
	
	SELECT
		PrinterId
		,PrinterName
		,1 Active
		,3 [Type]
		,4 SortOrder
		,dbo.verbosePrinterPhysicalStatus(p.PhysicalStatus, p.SNMPCheck)
		,dbo.verbosePrinterNewStatus(p.NewStatus)
		,p.ModelName	--PrinterModelName
		,p.Comment
		,p.Location
		,NULL AS regionSortOrder
		,NULL AS regionMapFile
		,NULL AS regionParentMapShape
		,NULL AS regionParentMapCoords
		,p.PrinterMapPosX
		,p.PrinterMapPosY
	FROM vw_printer_full p
	WHERE --q.queueRegion = @iparentRegionId
		p.RegionId = @iparentRegionId
		AND @iincludePrinters = 1
		AND p.printerType = 0 -- network printer
		AND p.adminStatus < 3 -- ej borttagen skrivare
		AND ((@iincludeHidden = 1) or p.Hidden = 0)

	ORDER BY [Type] -- show regions before queues

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_region_get_children_web') IS NOT NULL
	DROP PROCEDURE sp_region_get_children_web
GO

CREATE PROCEDURE sp_region_get_children_web
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-21
Description: List children of a region. Option to include queues and/or printers in listing
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-02-07
Description: Do not list FP queues if @iincludeQueues = 0
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-09-07
Description: Added listing of printers + clickable maps columns.
************************************************************/
	@iparentRegionId		int		= 0
	,@iincludeQueues		bit		= 0 
	,@iincludePrinters		bit		= 0  
	,@iincludeFollowPrint	bit		= 0
	,@iincludeHidden		bit		= 1 -- show hidden queues/printers?
	,@iExtendedStatus		bit		= 0
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	-- Return error if an invalid region is supplied
	IF NOT EXISTS(SELECT 1 FROM tbl_region where regionId = @iparentRegionId or @iparentRegionId IN(-1,0)) 
		RETURN (100009)


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #children
	(Identifier			varchar(64)		COLLATE DATABASE_DEFAULT
	,[Name]				nvarchar(510)
	,Active				bit
	,[Type]				int	-- 1 = region, 2 = queue, 3 = FP queue
	,SortOrder			int
	,PrinterPhysicalStatusVerbose	varchar(64) COLLATE DATABASE_DEFAULT NULL
	,PrinterNewStatusVerbose		varchar(64)	COLLATE DATABASE_DEFAULT NULL
	,PrinterModelName				nvarchar(512) COLLATE DATABASE_DEFAULT NULL
	,QueueComment					nvarchar(510) COLLATE DATABASE_DEFAULT NULL
	,QueueLocation					nvarchar(510) COLLATE DATABASE_DEFAULT NULL
	,RegionSortOrder				int NULL
	,RegionMapFile					nvarchar(256)	COLLATE DATABASE_DEFAULT NULL
	,RegionParentMapShape			varchar(10)		COLLATE DATABASE_DEFAULT NULL
	,RegionParentMapCoords			varchar(8000)	COLLATE DATABASE_DEFAULT NULL
	,PrinterMapPosX					int NULL
	,PrinterMapPosY					int NULL)

	IF ( @iparentRegionId = -1 AND @iincludeFollowPrint = 1) -- FP-regionen har id = -1 (s�tts i Web)
	BEGIN
		INSERT #children (Identifier, [Name], Active, [Type], SortOrder)
		SELECT
			queueId
			,queueName
			,1 Active
			,3
			,1	--SortOrder
		FROM tbl_queue q
		WHERE q.queueType = 3
			AND q.queueStatus < 3
			AND @iincludeQueues = 1
			AND ((@iincludeHidden = 1) or q.queueHidden = 0)
	END
	ELSE
	BEGIN -- vanlig region
		INSERT #children (Identifier, [Name], Active, [Type], SortOrder, PrinterPhysicalStatusVerbose,
			PrinterNewStatusVerbose, PrinterModelName, QueueComment, QueueLocation,
			RegionSortOrder, RegionMapFile, RegionParentMapShape, RegionParentMapCoords, PrinterMapPosX, PrinterMapPosY)

		EXEC @ReturnStatus = sp_region_get_children  @iparentRegionId		= @iparentRegionId
													,@iincludeQueues		= @iincludeQueues
													,@iincludePrinters		= @iincludePrinters
													,@iincludeHidden		= @iincludeHidden

		SET @ErrorNo = @@ERROR
		IF @ReturnStatus <> 0 or @ErrorNo <> 0 
			GOTO PROC_ERROR

		IF ( @iparentRegionId = 0 AND @iincludeFollowPrint = 1
			AND EXISTS(SELECT 1 FROM tbl_queue WHERE queueType = 3 AND queueStatus < 3 )) -- returnera rad f�r FP-regionen
		BEGIN
			INSERT #children (Identifier, [Name], Active, [Type], SortOrder)
			VALUES (-1, 'Follow Print', 1, 1, 1)
		END
	END


	IF @iExtendedStatus = 0
		SELECT * FROM #children
		ORDER BY SortOrder,[Type], [Name] 
	ELSE
	BEGIN
		CREATE TABLE #printer
		(PrinterId					varchar(64)		COLLATE DATABASE_DEFAULT
		,PrinterName				nvarchar(510)	COLLATE DATABASE_DEFAULT
		,RegionPath					nvarchar(510)	COLLATE DATABASE_DEFAULT
		,Location					nvarchar(510)	COLLATE DATABASE_DEFAULT
		,ErrorTime					datetime
		,LastCheck					int
		,DisplayText				nvarchar(200)	COLLATE DATABASE_DEFAULT
		,PrinterStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
		,PhysicalStatusSeverity		int
		,PhysicalStatusVerbose		varchar(64)		COLLATE DATABASE_DEFAULT
		,HighestSmartAlarmLevel		int	-- Smart alarms
		,SmartAlarmCount			int	 -- No of smart alarms at the highest level of the printer!
		,RegionId					bigint
		,HighestTotalAlarmLevel		int -- MAX(PhysicalStatusSeverity, HighestAlarmLevel)
		,JobCount					int
		,PrinterIP					varchar(64)		COLLATE DATABASE_DEFAULT
		,ModelName					nvarchar(512)	COLLATE DATABASE_DEFAULT
		,AdminComment				nvarchar(510)	COLLATE DATABASE_DEFAULT
		,OfflineReason				nvarchar(256)	COLLATE DATABASE_DEFAULT);

		DECLARE @OKCount int, @WarningCount int, @ErrorCount int
		EXEC @ReturnStatus = sp_monitoring_get_printer_status	@iSilent		= 1
																,@iCalculateRegionPath = 0
																,@oOKCount		= @OKCount		OUTPUT
																,@oWarningCount	= @WarningCount OUTPUT
																,@oErrorCount	= @ErrorCount	OUTPUT

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 OR @ReturnStatus <> 0
			GOTO PROC_ERROR

		SELECT
			c.*
			,p.RegionPath
			,p.Location
			,p.ErrorTime					
			,p.LastCheck					
			,p.DisplayText				
			,p.PrinterStatusVerbose		
			,p.PhysicalStatusSeverity		
			,p.PhysicalStatusVerbose		
			,p.HighestSmartAlarmLevel		
			,p.SmartAlarmCount			
			,p.HighestTotalAlarmLevel		
			,p.JobCount					
			,p.PrinterIP					
			,p.ModelName					
			,p.AdminComment				
			,p.OfflineReason
		FROM #children c
		LEFT JOIN #printer p
			ON p.PrinterId = c.Identifier
		ORDER BY SortOrder,[Type], [Name] 

	END

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (0)

	PROC_ERROR:
		IF @ErrorNo = 0
			SET @ErrorNo = @ReturnStatus

		RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_region_get_descendants') IS NOT NULL
	DROP PROCEDURE sp_region_get_descendants
GO

CREATE PROCEDURE sp_region_get_descendants
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-17
Description: Get all descendants of a region. 
************************************************************/
	@iregionId			bigint			= 0
	,@iincludeSelf		bit				= 0 

AS
BEGIN

	DECLARE	@ReturnStatus			int

	-- Return error if an invalid region is supplied
	IF NOT EXISTS(SELECT 1 FROM tbl_region where regionId = @iregionId AND regionActive = 1)
		RETURN (100009)


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	create table #tolist (RegionId int)
	create table #descendants (RegionId int)

	IF @iincludeSelf = 1
		INSERT #descendants (RegionId) VALUES(@iregionId)

	INSERT #tolist (RegionId)
	SELECT regionId FROM tbl_region where regionParentId = @iregionId AND regionActive = 1

	INSERT #descendants (RegionId)
	SELECT regionId FROM tbl_region where regionParentId = @iregionId AND regionActive = 1

	DECLARE @cRegion bigint

	WHILE EXISTS (SELECT 1 FROM #tolist)
	BEGIN
		SELECT TOP 1 @cRegion = RegionId FROM #tolist

		INSERT #tolist (RegionId)
		SELECT regionId FROM tbl_region where regionParentId = @cRegion AND regionActive = 1

		INSERT #descendants (RegionId)
		SELECT regionId FROM tbl_region where regionParentId = @cRegion AND regionActive = 1

		DELETE #tolist WHERE RegionId = @cRegion
	END

	SELECT RegionId FROM #descendants ORDER BY RegionId

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_region_get_map_info') IS NOT NULL
	DROP PROCEDURE sp_region_get_map_info
GO

CREATE PROCEDURE sp_region_get_map_info
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-07
Description:  Get region info for displaying region with map, precv/next buttons, etc
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRegionId			bigint
	,@iCircularBrowsing bit = 1 -- indicate if prev button on first region should point to last region, and the same for last region.

AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE		@SortOrder			int
				,@PrevRegionId		bigint
				,@PrevRegionName	nvarchar(256)
				,@NextRegionId		bigint
				,@NextRegionName	nvarchar(256)
				,@RegionPath		nvarchar(255)
				,@ParentRegionId	int

	IF NOT EXISTS ( SELECT 1 FROM vw_region WHERE regionId = @iRegionId AND regionActive = 1)
		RETURN(100009) -- Region not found


	SELECT 
		@SortOrder = ISNULL(regionSortOrder,100) 
		,@ParentRegionId = regionParentId
	FROM vw_region WHERE regionId = @iRegionId AND regionActive = 1
 
	-- Prev region
	-------------------------------------------------
	SELECT TOP 1
				@PrevRegionId	= regionId	
				,@PrevRegionName = regionName
	FROM vw_region 
	WHERE regionSortOrder <= @SortOrder
		AND regionId <> @iRegionId
		AND regionActive = 1
		AND regionParentId = @ParentRegionId
	ORDER BY regionSortOrder DESC

	IF @PrevRegionId IS NULL AND @iCircularBrowsing = 1
		SELECT TOP 1
					@PrevRegionId	= regionId	
					,@PrevRegionName = regionName
		FROM vw_region 
		WHERE regionId <> @iRegionId
			AND regionActive = 1
			AND regionParentId = @ParentRegionId
		ORDER BY regionSortOrder DESC

	-- Next region
	-------------------------------------------------
	SELECT TOP 1
				@NextRegionId	= regionId	
				,@NextRegionName = regionName
	FROM vw_region 
	WHERE regionSortOrder >= @SortOrder
		AND regionId <> @iRegionId
		AND regionActive = 1
		AND regionParentId = @ParentRegionId
	ORDER BY regionSortOrder ASC


	IF @NextRegionId IS NULL AND @iCircularBrowsing = 1
		SELECT TOP 1
				@NextRegionId	= regionId	
				,@NextRegionName = regionName
		FROM vw_region 
		WHERE regionId <> @iRegionId
			AND regionSortOrder <= @SortOrder
			AND regionActive = 1
			AND regionParentId = @ParentRegionId
		ORDER BY regionSortOrder ASC


	SELECT @RegionPath = dbo.GetAbsoluteRegion(@iRegionId)

	-- ut
	
	SELECT
		regionId				RegionId
		,regionParentId			ParentRegionId
		,regionName				RegionName
		,regionSortOrder		SortOrder
		,regionMapFile			MapFile
		,regionParentMapShape	ParentMapShape
		,regionParentMapCoords	ParentMapCoords

		,@PrevRegionId			PrevRegionId
		,@PrevRegionName		PrevRegionName
		,@NextRegionId			NextRegionId
		,@NextRegionName		NextRegionName
		,@RegionPath			AbsolutePathVerbose
	from tbl_region
	WHERE regionId = @iRegionId AND regionActive = 1

--RegionPath



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_region_get_path') IS NOT NULL
	DROP PROCEDURE sp_region_get_path
GO

CREATE PROCEDURE sp_region_get_path
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-21
Description: Given a region id, return the full path, i.e. '1/12/83'
************************************************************/
	@iregionId			bigint		
	,@oregionPath		varchar(128) OUTPUT
AS
BEGIN

	SET @oregionPath = NULL
	DECLARE	@ReturnStatus			int

	-- Return error if an invalid region is supplied
	IF NOT EXISTS(SELECT 1 FROM tbl_region where regionId = @iregionId)
		RETURN (100009)


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT @oregionPath = dbo.fn_region_get_path(@iregionId, '/');

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON



END
GO

IF OBJECT_ID('sp_region_get_path_by_verbose_path') IS NOT NULL
	DROP PROCEDURE sp_region_get_path_by_verbose_path
GO

CREATE PROCEDURE sp_region_get_path_by_verbose_path
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-22
Description: Given a verbose region  path. i.e. 'Sweden/Stockholm/Kista',
			 return the full numeric path, i.e. '1/12/83' 
			(as long as there is a match, would return '1/12' if Kista is not a region under Stockholm)
************************************************************/
	@iverbosePath		nvarchar(510)
	,@iexactMatch		bit = 1	-- exact match of region names required?
	,@oregionPath		varchar(128) OUTPUT
AS
BEGIN

	SET @oregionPath = ''

	DECLARE	@ReturnStatus			int
			,@cRegionName			nvarchar(128)
			,@cRowId				int
			,@cRegionId				bigint
			,@padding				varchar(1)

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #regions
	(RowId int
	,RegionName nvarchar(128) COLLATE DATABASE_DEFAULT)

	IF @iexactMatch = 1 SET @padding = ''
	ELSE SET @padding = '%'



	INSERT #regions (RowId, RegionName)
	SELECT RowId, ValueTypeId FROM dbo.fn_value_list_parse ('/' + @iverbosePath) --('/111/233/3444')



	SELECT @cRegionId = 0

	WHILE EXISTS(SELECT 1 FROM #regions)
	BEGIN
		SELECT TOP 1 
			@cRegionName = RegionName 
			,@cRowId = RowId
		FROM #regions
		ORDER BY RowId

		SET @cRegionName = @padding + @cRegionName + @padding

		SELECT	TOP 1
				@oregionPath = @oregionPath + '/' + ISNULL(CAST(regionId AS VARCHAR(64)),'')
				,@cRegionId = regionId
		FROM tbl_region where regionParentId = @cRegionId
		AND regionName LIKE @cRegionName



		DELETE #regions WHERE RowId = @cRowId
	END
	
	IF LEN(@oregionPath) > 0
		SET @oregionPath = RIGHT(@oregionPath,LEN(@oregionPath)-1)


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON
END
GO

IF OBJECT_ID('sp_scheduled_job_run') IS NOT NULL
	DROP PROCEDURE sp_scheduled_job_run
GO

CREATE PROCEDURE sp_scheduled_job_run
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-14
Description:	Run all jobs that should be run. This SP is called from dptsrv.exe.
				Currently only supports daily jobs.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-10
Description: Added IsRunning flag.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iOverrideDate			datetime		= NULL
	,@iDebug					bit				= 0
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE @CurrentTimestamp datetime
	SET @CurrentTimestamp = ISNULL(@iOverrideDate, getdate())

	-- If IsRunning=1 and LastRun is more than 24 hours ago, the flag is probably wrong - set it to 0
	UPDATE tbl_scheduled_job SET IsRunning=0 WHERE DATEDIFF(hh,LastRun,@CurrentTimestamp) > 24


	-- Get jobs with interval = 1 = daily 
	DECLARE @cJobId int, @cExecSP sysname

	DECLARE curJobs CURSOR READ_ONLY FOR

	SELECT JobId, ExecSP from tbl_scheduled_job
		WHERE Interval = 1
		AND ISNULL(StartDate, '20000101') <= @CurrentTimestamp
		AND ISNULL(EndDate, '99991231') > @CurrentTimestamp
		AND IsActive = 1
		AND IsDeleted = 0
		AND IsRunning = 0
		AND CONVERT(char(8), ISNULL(LastRun,'20000101'), 112) < CONVERT(char(8), @CurrentTimestamp, 112)
		AND (DATEPART(hh, @CurrentTimestamp) * 60 + DATEPART(mi, @CurrentTimestamp)) >= RunOffset
	ORDER BY RunOffset

	OPEN curJobs

	DECLARE @RunStart				datetime
			,@RunEnd				datetime
			,@OuterReturnStatus		int 
			,@InnerReturnStatus		int
			,@JobExecSQL			nvarchar(1000)


	FETCH NEXT FROM curJobs INTO @cJobId, @cExecSP

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @JobExecSQL = 'EXEC @ReturnStatus = ' + @cExecSP
		SET @RunStart = getdate()

		IF @iDebug = 1
			PRINT 'Excuting jobid ' + cast(@cJobId as varchar(20)) + ': ' + @JobExecSQL

		BEGIN TRY
			UPDATE tbl_scheduled_job SET LastRun = @RunStart, IsRunning = 1 WHERE JobId = @cJobId

			EXEC @OuterReturnStatus = sp_executesql @JobExecSQL, N'@ReturnStatus int OUTPUT', @ReturnStatus = @InnerReturnStatus OUTPUT

			INSERT tbl_scheduled_job_run_log (JobId, RunStartDate, RunEndDate, ReturnStatus, ReturnStatusMessage)
			SELECT @cJobId, @RunStart, getdate(), @InnerReturnStatus, CAST(@OuterReturnStatus AS nvarchar(20))


			UPDATE tbl_scheduled_job SET IsRunning = 0 WHERE JobId = @cJobId
		END TRY
		BEGIN CATCH
			INSERT tbl_scheduled_job_run_log (JobId, RunStartDate, RunEndDate, ReturnStatus, ReturnStatusMessage)
			SELECT @cJobId, @RunStart, getdate(), ERROR_NUMBER(), 
				LEFT(ISNULL(ERROR_PROCEDURE(),'') + ':' + CAST(ISNULL(ERROR_LINE(),0) AS NVARCHAR(20)) + ' ' + ISNULL(ERROR_MESSAGE(),''), 512)

			UPDATE tbl_scheduled_job SET LastRun = @RunStart, IsRunning = 0 WHERE JobId = @cJobId
		END CATCH


		FETCH NEXT FROM curJobs INTO @cJobId, @cExecSP
	END


	CLOSE curJobs
	DEALLOCATE curJobs

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_smartalarms_aggregate_by_queue') IS NOT NULL
	DROP PROCEDURE sp_smartalarms_aggregate_by_queue
GO

CREATE PROCEDURE sp_smartalarms_aggregate_by_queue
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-09
Description: For all queues, get the number of smartalarms at the highest level
			(results will be available in table #smartalarmsaggregatequeue)
************************************************************/
	@iincludeWarnings	bit = 1
	,@iincludeErrors	bit = 1
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@JobDurationWarningLimit	int
			,@JobDurationErrorLimit		int
			,@QueueJobCountWarningLimit	int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	SET @CurrentTimestamp = GETDATE()
	SET @ErrorNo = 0
	

	

	CREATE TABLE #queuealarms
	(AlarmTypeId		int				
	,AlarmSeverityId	int				
	,AlarmArea			int				
	,AlarmDescription	varchar(128)	COLLATE DATABASE_DEFAULT
	,JobName			nvarchar(510)	COLLATE DATABASE_DEFAULT
	,TicketId			varchar(64)		COLLATE DATABASE_DEFAULT
	,QueueName			nvarchar(510)	COLLATE DATABASE_DEFAULT
	,QueueId			varchar(64)		COLLATE DATABASE_DEFAULT
	,NumericArg			int
	,UserName			nvarchar(510)	COLLATE DATABASE_DEFAULT)		


	INSERT #queuealarms
	EXEC @ReturnStatus = sp_smartalarms_get_alarms
							@iincludeWarnings	= @iincludeWarnings
							,@iincludeErrors	= @iincludeErrors

	SET @ErrorNo = @@ERROR
	IF @ReturnStatus <> 0 OR @ErrorNo <> 0
		GOTO PROC_ERROR;



	-- Aggregate by queue
	WITH a (QueueId, AlarmSeverityId, AlarmCount, AlarmRank)
	AS
	(SELECT QueueId
			,AlarmSeverityId
			,COUNT(*)
			,ROW_NUMBER() OVER (PARTITION BY QueueId ORDER BY AlarmSeverityId DESC)	
	FROM #queuealarms GROUP BY QueueId, AlarmSeverityId)
	INSERT #smartalarmsaggregatequeue
	SELECT a.QueueId
		,a.AlarmSeverityId
		,a.AlarmCount
	FROM a 
	WHERE AlarmRank = 1
	ORDER BY QueueId, AlarmRank


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	DROP TABLE #queuealarms

	RETURN (@ReturnStatus)


	PROC_ERROR:
	DROP TABLE #queuealarms
	IF @ReturnStatus <> 0 SET @ErrorNo = @ReturnStatus
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_smartalarms_get_alarms') IS NOT NULL
	DROP PROCEDURE sp_smartalarms_get_alarms
GO

CREATE PROCEDURE sp_smartalarms_get_alarms
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-03
Description: Get current alarms
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-09
Description: Include username column
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-15
Description: Added multi-language support
************************************************************/
	@iincludeWarnings	bit			= 1
	,@iincludeErrors	bit			= 1
	,@iLanguageId		char(2)		= 'en'
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int
			,@JobDurationWarningLimit	int
			,@JobDurationErrorLimit		int
			,@QueueJobCountWarningLimit	int
			,@CurrentTimestamp			datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT @JobDurationWarningLimit		= dbo.fn_property_get_numeric ('smartAlarmJobDurationWarning')
			,@JobDurationErrorLimit		= dbo.fn_property_get_numeric ('smartAlarmJobDurationError')
			,@QueueJobCountWarningLimit = dbo.fn_property_get_numeric ('smartAlarmQueueJobCountWarning')

	SET @CurrentTimestamp = GETDATE()
	SET @ErrorNo = 0
	
	IF @JobDurationWarningLimit IS NULL
		OR @JobDurationErrorLimit IS NULL
		OR @QueueJobCountWarningLimit IS NULL
	RETURN (100012)
	

	CREATE TABLE #alarms
	(AlarmTypeId		int				-- what type of alarm? 1 = job takes too long, 2 = max no of jobs in queue exceeded
	,AlarmSeverityId	int				-- 1 = warning, 2 = error
	,AlarmArea			int				-- 1=job, 2=queue, 3=printer
	,AlarmDescription	varchar(128)	COLLATE DATABASE_DEFAULT-- Verbose alarm description 
	,JobName			nvarchar(510)	COLLATE DATABASE_DEFAULT-- related ticket and queue (NULL if N/A)
	,TicketId			varchar(64)		COLLATE DATABASE_DEFAULT
	,QueueName			nvarchar(510)	COLLATE DATABASE_DEFAULT
	,QueueId			varchar(64)		COLLATE DATABASE_DEFAULT
	,NumericArg			int
	,UserName			nvarchar(510)	COLLATE DATABASE_DEFAULT)	



	-----------------------------------------------------
	-- Job takes too long - warning
	IF @iincludeWarnings = 1
	BEGIN
		INSERT #alarms 
			(AlarmTypeId
			,AlarmSeverityId
			,AlarmArea
			,AlarmDescription
			,JobName
			,TicketId
			,QueueName
			,QueueId
			,NumericArg
			,UserName)
		SELECT 
			 1		-- AlarmTypeId
			,1		-- AlarmSeverityId
			,1		-- AlarmArea
			,NULL	-- AlarmDescription
			,t.JobName
			,t.TicketId
			,q.QueueName
			,t.QueueId
			,DATEDIFF(n, t.dateBegan, @CurrentTimestamp) -- minutes this job has been printing
			,t.userName
		FROM tbl_ticket t
		INNER JOIN tbl_queue q
			on q.queueId = t.queueId
		WHERE t.ticketStatus = 6 -- Printing
			and DATEDIFF(n, t.dateBegan, @CurrentTimestamp) > @JobDurationWarningLimit
			and DATEDIFF(n, t.dateBegan, @CurrentTimestamp) <= @JobDurationErrorLimit
	END
	-----------------------------------------------------
	-- Job takes too long - error
	IF @iincludeErrors = 1
	BEGIN
		INSERT #alarms 
			(AlarmTypeId
			,AlarmSeverityId
			,AlarmArea
			,AlarmDescription
			,JobName
			,TicketId
			,QueueName
			,QueueId
			,NumericArg
			,UserName)
		SELECT 
			 1		-- AlarmTypeId
			,2		-- AlarmSeverityId
			,1		-- AlarmArea
			,NULL	-- AlarmDescription
			,t.JobName
			,t.TicketId
			,q.QueueName
			,t.QueueId
			,DATEDIFF(n, t.dateBegan, @CurrentTimestamp)
			,t.userName
		FROM tbl_ticket t
		INNER JOIN tbl_queue q
			on q.queueId = t.queueId
		WHERE t.ticketStatus = 6 -- Printing
			and DATEDIFF(n, t.dateBegan, @CurrentTimestamp) > @JobDurationErrorLimit;
	END
	-----------------------------------------------------
	-- Queue no. items limit warning
	IF @iincludeWarnings = 1
	BEGIN
		WITH qc (queueId, ticketCount) AS
			(SELECT queueId, Count(*) FROM tbl_ticket 
			GROUP BY queueId 
			HAVING Count(*) > @QueueJobCountWarningLimit)
		INSERT #alarms 
			(AlarmTypeId
			,AlarmSeverityId
			,AlarmArea
			,AlarmDescription
			,QueueName
			,QueueId
			,NumericArg
			,JobName)
		SELECT 
			 2		-- AlarmTypeId
			,1		-- warning
			,2		-- AlarmArea = queue
			,NULL	-- AlarmDescription
			,q.queueName
			,qc.queueId
			,qc.ticketCount
			,NULL--'No. of jobs:'
		FROM qc
		INNER JOIN tbl_queue q
			ON q.queueId = qc.queueId
		WHERE q.queueType = 1 -- only normal queues
	END

	-----------------------------------------------------
	--	Update table with static texts
	UPDATE a
		SET a.AlarmDescription = at.AlarmDescription
	FROM #alarms a
	inner join tbl_smartalarm_type at
		on a.AlarmTypeId		= at.AlarmTypeId
		and a.AlarmSeverityId	= at.AlarmSeverityId
		and a.AlarmArea			= at.AlarmArea
	WHERE at.LanguageId = @iLanguageId



	SELECT * FROM #alarms
	ORDER BY AlarmSeverityId DESC, AlarmTypeId, AlarmArea, QueueName, JobName

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_smartalarms_get_alarms_by_printer') IS NOT NULL
	DROP PROCEDURE sp_smartalarms_get_alarms_by_printer
GO

CREATE PROCEDURE sp_smartalarms_get_alarms_by_printer
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-05
Description: Get current alarms for a single printer
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-15
Description: Added multi-language support
************************************************************/
	@iincludeWarnings	bit = 1
	,@iincludeErrors	bit = 1
	,@iprinterId		varchar(64) 
	,@iLanguageId		char(2)		= 'en'
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int



	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	CREATE TABLE #queue (QueueId varchar(64) COLLATE DATABASE_DEFAULT)
	INSERT #queue (QueueId)
	SELECT mapQueue FROM tbl_queue_printer_map WHERE mapPhyPrinter = @iprinterId



	CREATE TABLE #alarms
	(AlarmTypeId		int				-- what type of alarm? 1 = job takes too long, 2 = max no of jobs in queue exceeded
	,AlarmSeverityId	int				-- 1 = warning, 2 = error
	,AlarmArea			int				-- 1=job, 2=queue, 3=printer
	,AlarmDescription	varchar(128)	COLLATE DATABASE_DEFAULT-- Verbose alarm description 
	,JobName			nvarchar(510)	COLLATE DATABASE_DEFAULT-- related ticket and queue (NULL if N/A)
	,TicketId			varchar(64)		COLLATE DATABASE_DEFAULT
	,QueueName			nvarchar(510)	COLLATE DATABASE_DEFAULT
	,QueueId			varchar(64)		COLLATE DATABASE_DEFAULT
	,NumericArg			int
	,UserName			nvarchar(510)	COLLATE DATABASE_DEFAULT)	


	INSERT #alarms
	EXEC sp_smartalarms_get_alarms
		@iincludeWarnings	= @iincludeWarnings
		,@iincludeErrors	= @iincludeErrors
		,@iLanguageId		= @iLanguageId



	SELECT a.* FROM #alarms a
	INNER JOIN #queue q
		ON a.QueueId = q.QueueId
	ORDER BY AlarmSeverityId DESC, AlarmTypeId, AlarmArea, QueueName, JobName

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_smartalarms_get_alarms_by_queue') IS NOT NULL
	DROP PROCEDURE sp_smartalarms_get_alarms_by_queue
GO

CREATE PROCEDURE sp_smartalarms_get_alarms_by_queue
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-03-09
Description: Get current alarms for a single queue
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-15
Description: Added multi-language support
************************************************************/
	@iincludeWarnings	bit = 1
	,@iincludeErrors	bit = 1
	,@iQueueId			varchar(64) 
	,@iLanguageId		char(2)		= 'en'
AS
BEGIN

	DECLARE	@ErrorNo					int
			,@ReturnStatus				int



	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	CREATE TABLE #queue (QueueId varchar(64) COLLATE DATABASE_DEFAULT)
	INSERT #queue (QueueId)
	VALUES(@iQueueId)



	CREATE TABLE #alarms
	(AlarmTypeId		int				-- what type of alarm? 1 = job takes too long, 2 = max no of jobs in queue exceeded
	,AlarmSeverityId	int				-- 1 = warning, 2 = error
	,AlarmArea			int				-- 1=job, 2=queue, 3=printer
	,AlarmDescription	varchar(128)	COLLATE DATABASE_DEFAULT-- Verbose alarm description 
	,JobName			nvarchar(510)	COLLATE DATABASE_DEFAULT-- related ticket and queue (NULL if N/A)
	,TicketId			varchar(64)		COLLATE DATABASE_DEFAULT
	,QueueName			nvarchar(510)	COLLATE DATABASE_DEFAULT
	,QueueId			varchar(64)		COLLATE DATABASE_DEFAULT
	,NumericArg			int
	,UserName			nvarchar(510)	COLLATE DATABASE_DEFAULT)


	INSERT #alarms
	EXEC sp_smartalarms_get_alarms
		@iincludeWarnings	= @iincludeWarnings
		,@iincludeErrors	= @iincludeErrors
		,@iLanguageId		= @iLanguageId




	SELECT a.* FROM #alarms a
	INNER JOIN #queue q
		ON a.QueueId = q.QueueId
	ORDER BY AlarmSeverityId DESC, AlarmTypeId, AlarmArea, QueueName, JobName

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (@ErrorNo)
END
GO
IF OBJECT_ID('sp_terminal_allow_login') IS NOT NULL
	DROP PROCEDURE sp_terminal_allow_login
GO

CREATE PROCEDURE sp_terminal_allow_login
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-15
Description: Detemine if cpt terminal login is allowed from given IP address
-------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-17
Description: Also check tbl_printer, if not found in tbl_fprint_map
************************************************************/
	@iTerminalIP			varchar(64)
	,@oPrinterIP			varchar(64)	OUTPUT
	,@oPrinterId			varchar(64) OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oPrinterIP = NULL
	SET @oPrinterId = NULL


	SELECT 
		@oPrinterIP = p.printerIp
		,@oPrinterId = p.printerId
	FROM tbl_fprint_map fp  
	INNER JOIN tbl_printer p
		ON p.printerIp = fp.fprintMapPrn
		AND p.adminStatus <> 3
		AND p.printerType = 0
	WHERE fp.fprintMapIp = @iTerminalIP

	IF @oPrinterId IS NULL
	BEGIN
		SELECT 
			@oPrinterIP = p.printerIp
			,@oPrinterId = p.printerId
		FROM tbl_printer p
		WHERE p.printerIp = @iTerminalIP
		AND p.adminStatus <> 3
		AND p.printerType = 0

	END



	IF @oPrinterId IS NULL
		RETURN (300007)

--	IF NOT EXISTS (SELECT 1 FROM tbl_fprint_map fp  
--					INNER JOIN tbl_printer p
--					ON p.printerIp = fp.fprintMapPrn
--					AND p.adminStatus <> 3
--					WHERE
--					fp.fprintMapIp = @iTerminalIP)
--		RETURN (300007)



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_tickets_get_by_ip') IS NOT NULL
	DROP PROCEDURE sp_tickets_get_by_ip
GO

CREATE PROCEDURE sp_tickets_get_by_ip
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-17
Description: Get tickets by IP
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
	@ioriginatingIp			varchar(64)
	,@iincludeActive		bit				= 0 
	,@iincludeOld			bit				= 0 
	,@iLanguageId			char(2)			= 'en'
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@searchString			nvarchar(128)

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #tickets (	ticketId		varchar(64)	COLLATE DATABASE_DEFAULT
							,ticketActive	bit
							,DateEvent datetime)



	CREATE INDEX ix1 ON #tickets (ticketId, ticketActive)

	-- 
	-- 
	IF @iincludeActive = 1
	BEGIN
		INSERT #tickets (ticketId, ticketActive)
		SELECT --TOP 100 
		t.ticketId, 1
		from tbl_ticket t 
		where t.originatingIp = @ioriginatingIp
		ORDER BY dateSort DESC
	END

	IF @iincludeOld = 1
	BEGIN
		INSERT #tickets (ticketId, ticketActive, DateEvent)
		Select TOP 100 t.logticketId, 0, MAX(logdateEvent)
		from tbl_ticket_log t
		where t.logoriginatingIp = @ioriginatingIp
				AND t.logticketId NOT IN (SELECT ticketId FROM tbl_ticket)
		GROUP BY t.logticketId
		ORDER BY MAX(logdateEvent) DESC
	END


	



	-- Get overview of selected tickets

		EXEC @ReturnStatus = sp_get_tickets_sub @iincludeActive = @iincludeActive, @iincludeOld = @iincludeOld, @iLanguageId = @iLanguageId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_tickets_get_by_ticketid') IS NOT NULL
	DROP PROCEDURE sp_tickets_get_by_ticketid
GO

CREATE PROCEDURE sp_tickets_get_by_ticketid
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-17
Description: Get info about a single ticket
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 
Description:  
************************************************************/
	@iTicketId			varchar(64)
	,@iLanguageId		char(2)			= 'en'
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@searchString			nvarchar(128)



	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	CREATE TABLE #tickets (	ticketId		varchar(64)	COLLATE DATABASE_DEFAULT
							,ticketActive	bit
							,DateEvent datetime)



	CREATE INDEX ix1 ON #tickets (ticketId, ticketActive)


	INSERT #tickets (ticketId, ticketActive)
	SELECT --TOP 100 
	t.ticketId, 1
	from tbl_ticket t 
	where ticketId = @iTicketId
	ORDER BY dateSort DESC


	IF NOT EXISTS (SELECT 1 FROM #tickets)
		RETURN (100152) -- Ticket does not exist or is not active


	-- Get overview of selected tickets
	EXEC @ReturnStatus = sp_get_tickets_sub 
		@iincludeActive	= 1
		,@iincludeOld	= 0
		,@iLanguageId	= @iLanguageId




	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_tickets_get_by_user') IS NOT NULL
	DROP PROCEDURE sp_tickets_get_by_user
GO

CREATE PROCEDURE sp_tickets_get_by_user
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-17
Description: Get tickets by username 
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-28
Description: If job is unauthenticated and has authIP - do not show if username = current user. 
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-15
Description: Ticket 105 / option to match un-owned jobs by username. 
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-08-06
Description: Added support for providing an optional priceplan. 
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
************************************************************/
	@iuserName				nvarchar(510)	
	,@iincludeActive		bit				= 0 
	,@iincludeOld			bit				= 0 
	,@iCurrentIP			varchar(64)		= NULL -- the currently logged in user!
	,@iIncludeTakeableJobs	bit				= 0
	,@iMatchByUser			bit				= 0
	,@iPricePlanId			varchar(64)		= NULL
	,@iLanguageId			char(2)			= 'en'
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@searchString			nvarchar(128)



	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #tickets (	ticketId		varchar(64)	COLLATE DATABASE_DEFAULT
							,ticketActive	bit
							,DateEvent datetime)



	CREATE INDEX ix1 ON #tickets (ticketId, ticketActive)

	-- 
	-- 
	IF @iincludeActive = 1
	BEGIN
		INSERT #tickets (ticketId, ticketActive)
		SELECT --TOP 100 
		t.ticketId, 1
		from tbl_ticket t 
		where 
		(authIP IS NULL AND userName = @iuserName)
		OR (
			@iIncludeTakeableJobs = 1
			AND
				(
					(userName = @iuserName AND @iMatchByUser = 1)
					OR
					(t.authIp = @iCurrentIP)
				)
		)

--	-- (owner ok OCH user = user)
--	--ELLER (
--		-- (owner ej satt & incl takeable jobs) och 
--			--(
--			--	(user = user OCH matchbyUser =1) 
--			--	eller
--			--	(CurrentIp = authIp )
--			--)
--	--)


		ORDER BY dateSort DESC
	END

	IF @iincludeOld = 1
	BEGIN
		INSERT #tickets (ticketId, ticketActive, DateEvent)
		Select TOP 100 t.logticketId, 0, MAX(logdateEvent)
		from tbl_ticket_log t
		where	loguserName = @iuserName
				AND t.logticketId NOT IN (SELECT ticketId FROM tbl_ticket)
		GROUP BY t.logticketId
		ORDER BY MAX(logdateEvent) DESC
	END



	-- Get overview of selected tickets
	EXEC @ReturnStatus = sp_get_tickets_sub 
		@iruleStatus		= @iIncludeTakeableJobs
		,@iincludeActive	= @iincludeActive
		,@iincludeOld		= @iincludeOld
		,@iPricePlanId		= @iPricePlanId
		,@iLanguageId		= @iLanguageId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_tickets_get_fp_by_user_printer') IS NOT NULL
	DROP PROCEDURE sp_tickets_get_fp_by_user_printer
GO

CREATE PROCEDURE sp_tickets_get_fp_by_user_printer
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-09-11
Description: Get FP tickets by username/domain and printer. 
Model of given printer must match the model of the job for the job to be listed.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added support for listing jobs that are compatible with a specific printer
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 
Description:  
************************************************************/
	@iUserName				nvarchar(510)	
	,@iDomain				nvarchar(510)	
	,@iPrinterId			varchar(64)
	,@iPricePlanId			varchar(64)		= NULL
	,@iLanguageId			char(2)			= 'en'
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@searchString			nvarchar(128)



	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE @ModelId varchar(64)

	IF NOT EXISTS( SELECT 1 FROM tbl_printer WHERE printerId = @iPrinterId)
	RETURN (100015)

	SELECT @ModelId = printerModel FROM tbl_printer WHERE printerId = @iPrinterId



	CREATE TABLE #tickets (	ticketId		varchar(64)	COLLATE DATABASE_DEFAULT
							,ticketActive	bit
							,DateEvent datetime)



	CREATE INDEX ix1 ON #tickets (ticketId, ticketActive)


	INSERT #tickets (ticketId, ticketActive)
	SELECT --TOP 100 
	t.ticketId, 1
	from tbl_ticket t 
	where userName = @iUserName
		AND userDomain = @iDomain
	-- h�r ligger annars kod f�r att inkludera take-able jobs.
	ORDER BY dateSort DESC






	-- Get overview of selected tickets
	EXEC @ReturnStatus = sp_get_tickets_sub 
		@iruleStatus		= 0 -- @iIncludeTakeableJobs
		,@iincludeActive	= 1
		,@iincludeOld		= 0
		,@iPricePlanId		= @iPricePlanId
--		,@iModelId			= @ModelId
		,@iCompatiblePrinterId = @iPrinterId
		,@iIncludeFPJobs	= 1
		,@iIncludeNonFPJobs	= 0
		,@iLanguageId		= @iLanguageId



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_tickets_get_related_queues') IS NOT NULL
	DROP PROCEDURE sp_tickets_get_related_queues
GO

CREATE PROCEDURE sp_tickets_get_related_queues
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-20
Description: Given a list of tickets, get related queues
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-22
Description: Ticket 61 / Do not include the queue the ticket is in
************************************************************/
	@iticketList			varchar(8000)
AS
BEGIN

	DECLARE	@ErrorNo			int
			,@ReturnStatus			int
			,@cqueueId			varchar(64)

	DECLARE curTickets CURSOR FOR
			SELECT DISTINCT t2.queueId FROM dbo.fn_value_list_parse(',' + @iticketList) t1
			INNER JOIN tbl_ticket t2
				ON t1.ValueTypeId = t2.ticketId

	CREATE TABLE #queue (queueId varchar(64) COLLATE DATABASE_DEFAULT
						,queueName nvarchar(510) COLLATE DATABASE_DEFAULT)

	OPEN curTickets

	FETCH NEXT FROM curTickets INTO @cqueueId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		INSERT #queue (queueId, queueName)
		EXEC sp_queue_get_related_queues_by_queue @iqueueId = @cqueueId, @iincludeSelf = 0
		FETCH NEXT FROM curTickets INTO @cqueueId
	END
	CLOSE curTickets
	DEALLOCATE curTickets

	SELECT DISTINCT queueId, queueName FROM #queue ORDER BY queueName


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	SET @ErrorNo = @@ERROR


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_ticket_action_ins') IS NOT NULL
	DROP PROCEDURE sp_ticket_action_ins
GO

CREATE PROCEDURE sp_ticket_action_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-19
Description: Perform an action on a ticket
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-15
Description: Added transtext parameter and checks for transact = 14 (change billing code)
************************************************************/
	@iticketId				varchar(64)
	,@itransAct				smallint -- vilken action som ska tas
	,@iuser					nvarchar (256)
	,@idomain				nvarchar (256)
	,@itransIP				varchar(256) = ''
	,@itransText			nvarchar(510) = ''
AS
BEGIN

	DECLARE @ErrorNo int
			,@CurrentTimestamp datetime
			,@ReturnStatus int

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iticketId)
		RETURN (100004)

--	IF NOT EXISTS (SELECT 1 FROM tbl_queue WHERE queueId = @iqueueId)
--		RETURN (100005)

--	IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iticketId AND ticketStatus IN(2, 7)) -- Ready or Paused
--		RETURN (100006)

--	IF NOT EXISTS (SELECT 1 FROM tbl_ticket 
--					WHERE ticketId = @iticketId
--					AND (@iisAdmin=1 OR (userName = @iuser AND userDomain = @idomain))) 
--		RETURN (100007)


	-- ETR_CHANGE_BILLING_CODE = 14 check
	IF @itransAct = 14 AND LEN(@itransText) > 0
	BEGIN

		EXEC @ReturnStatus = sp_client_billing_validate @iBillingCode	= @itransText
														,@iUserName		= @iuser
														,@iDomain		= @idomain

		IF @ReturnStatus <> 0
			RETURN (@ReturnStatus)

	END

	UPDATE tbl_ticket SET ticketNewStatus = @itransAct WHERE ticketId = @iticketId


	INSERT tbl_transaction
			(transAffId
			,transAct
			,transText
			,transUser
			,transDomain
			,transIP)
	VALUES (@iticketId	--	transAffId
			,@itransAct	--	transAct. 
			,@itransText--	transText
			,@iuser		--	transUser
			,@idomain	--	transDomain
			,@itransIP)	--	transIP

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_ticket_change_owner') IS NOT NULL
	DROP PROCEDURE sp_ticket_change_owner
GO

CREATE PROCEDURE sp_ticket_change_owner
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-04-15
Description: Change the owner of a ticket
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-15
Description: Ticket 105 / remove originating IP check
************************************************************/
	@iTicketId				varchar(64)
	,@iUser					nvarchar (256) -- who made the change
	,@iDomain				nvarchar (256)
	,@iTransIP				varchar(64)
	,@iNewUser				nvarchar (256) -- New owner of ticket
	,@iNewDomain			nvarchar (256)
	,@iOnlyIfUnassigned		bit = 0 -- 1 = do not reassign if ticket has owner 
	,@iVerifyAgainstIP		varchar(64) = NULL
AS
BEGIN

	DECLARE @ErrorNo int

	IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iTicketId)
		RETURN (100004)



	IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iTicketId AND ticketStatus IN(2, 7)) -- Ready or Paused
		RETURN (100006)


	IF @iOnlyIfUnassigned = 1
		IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iTicketId AND authIP IS NOT NULL AND ticketRuleStatus = 1)
			RETURN (0)

--	IF @iVerifyAgainstIP IS NOT NULL 
--		AND NOT EXISTS (SELECT 1 FROM tbl_ticket 
--						WHERE ticketId = @iTicketId 
--						AND authIP IS NOT NULL 
--						AND ticketRuleStatus = 1 
--						AND authIp = @iVerifyAgainstIP)
--	RETURN (0)



	IF LEN(@iNewUser) = 0
		RETURN (100033)

	IF LEN(@iNewDomain) = 0
		RETURN (100034)

	DECLARE @transtext nvarchar(510)
	SET @transtext = @iNewUser + '@' + UPPER(@iNewDomain)
	


	UPDATE tbl_ticket SET ticketNewStatus = 12 WHERE ticketId = @iTicketId


	INSERT tbl_transaction
			(transAffId
			,transAct
			,transText
			,transUser
			,transDomain
			,transIP)
	VALUES (@iTicketId	--	transAffId
			,12			--	transAct. 11 = move ticket
			,@transtext			--	transText
			,@iUser		--	transUser
			,@iDomain	--	transDomain
			,@iTransIP)	--	transIP

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_ticket_get_structured_pageinfo') IS NOT NULL
	DROP PROCEDURE sp_ticket_get_structured_pageinfo
GO

CREATE PROCEDURE sp_ticket_get_structured_pageinfo
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-06
Description:  Given mix of pages, pagescolor, pagesbw, color, duplex - calculate actual characteristics of ticket
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iPaperSize				int
	,@iPages				int
	,@iColor				varchar(3)	-- Yes / No
	,@iDuplex				varchar(3)  -- Yes / No
	,@iLoggedBWPages		int
	,@iLoggedColorPages		int

	,@oPagesBW				int			OUTPUT
	,@oPagesColor			int			OUTPUT
	,@oPaperSize			tinyint		OUTPUT
	,@oDuplex				bit			OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int

	SET @oPagesBW		= NULL
	SET @oPagesColor	= NULL
	SET @oPaperSize		= NULL
	SET @oDuplex		= NULL


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Color / BW
	IF @iLoggedBWPages = 0 AND @iLoggedColorPages = 0
	BEGIN
		IF @iColor = 'Yes'
		BEGIN
			SET @oPagesColor = @iPages
			SET @oPagesBW = 0
		END
		ELSE
		BEGIN
			SET @oPagesColor = 0
			SET @oPagesBW = @iPages
		END
	END
	ELSE
	BEGIN
		SET @oPagesBW = @iLoggedBWPages
		SET @oPagesColor = @iLoggedColorPages
	END

	-- Duplex
	IF @iDuplex = 'Yes'
		SET @oDuplex = 1
	ELSE
		SET @oDuplex = 0

	-- PaperSize
	IF @iPaperSize BETWEEN 0 AND 255
		SET @oPaperSize = @iPaperSize
	ELSE
		SET @oPaperSize = 0

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_ticket_has_owner') IS NOT NULL
	DROP PROCEDURE sp_ticket_has_owner
GO

CREATE PROCEDURE sp_ticket_has_owner
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-04-16
Description: Check if ticket has owner
************************************************************/
	@iTicketId				varchar(64)
	,@oHasOwner				int	OUTPUT
AS
BEGIN

	DECLARE @ErrorNo int

	SET @oHasOwner = 1

	IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iTicketId)
		RETURN (100004)


	IF EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iTicketId AND authIP IS NOT NULL AND ticketRuleStatus = 1)
		SET @oHasOwner = 0

	RETURN (0)
END
GO

IF OBJECT_ID('sp_ticket_history') IS NOT NULL
	DROP PROCEDURE sp_ticket_history
GO

CREATE PROCEDURE sp_ticket_history
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-15
Description: Get chain of events for a certain ticket
************************************************************/
	@iticketId				varchar(64)
	,@ilimit				int = 50
AS
BEGIN

	DECLARE @ErrorNo int
			,@IsActive bit

	IF	NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iticketId)
		AND NOT EXISTS (SELECT 1 FROM tbl_ticket_log WHERE logticketId = @iticketId)
		RETURN (100004)



	SELECT TOP (@ilimit)
	t.logDateEvent
	,t.logqueueId
	,q.queueName	
	,t.logEventMajor
	,t.logEventMinor
	,dbo.verboseTicketLog(NULL,t.logEventMinor) logEventMinorVerbose
	,logText
	FROM tbl_ticket_log t
	LEFT OUTER JOIN tbl_queue q
		ON t.logqueueId = q.queueId

	WHERE t.logticketId = @iticketId
	and not (t.logEventMajor = 2 and t.logEventMinor = 2)
	ORDER BY t.logDateEvent DESC

	RETURN (0)
END
GO

IF OBJECT_ID('sp_ticket_move') IS NOT NULL
	DROP PROCEDURE sp_ticket_move
GO

CREATE PROCEDURE sp_ticket_move
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-12
Description: Move a ticket to another queue
************************************************************/
	@iticketId				varchar(64)
	,@iqueueId				varchar(64) 
	,@iuser					nvarchar (256)
	,@idomain				nvarchar (256)
--	,@iisAdmin				tinyint = 0
AS
BEGIN

	DECLARE @ErrorNo int

	IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iticketId)
		RETURN (100004)

	IF NOT EXISTS (SELECT 1 FROM tbl_queue WHERE queueId = @iqueueId)
		RETURN (100005)

	IF NOT EXISTS (SELECT 1 FROM tbl_ticket WHERE ticketId = @iticketId AND ticketStatus IN(2, 7)) -- Ready or Paused
		RETURN (100006)

--	IF NOT EXISTS (SELECT 1 FROM tbl_ticket 
--					WHERE ticketId = @iticketId
--					AND (@iisAdmin=1 OR (userName = @iuser AND userDomain = @idomain))) 
--		RETURN (100007)

	UPDATE tbl_ticket SET ticketNewStatus = 11 WHERE ticketId = @iticketId


	INSERT tbl_transaction
			(transAffId
			,transAct
			,transText
			,transUser
			,transDomain
			,transIP)
	VALUES (@iticketId	--	transAffId
			,11			--	transAct. 11 = move ticket
			,''			--	transText
			,@iuser		--	transUser
			,@idomain	--	transDomain
			,@iqueueId)	--	transIP

	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_ticket_register_dn') IS NOT NULL
	DROP PROCEDURE sp_ticket_register_dn
GO

CREATE PROCEDURE sp_ticket_register_dn
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-05
Description:  Specify the distingushed name of the user of a ticket
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iTicketId	varchar(64)
	,@iDn       nvarchar(512)
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	DECLARE @DnId int

	SELECT @DnId = DnId FROM tbl_dn WHERE Dn = @iDn

	IF @DnId IS NULL
	BEGIN
		INSERT tbl_dn (Dn) VALUES(@iDn)
		SET @DnId = SCOPE_IDENTITY()
	END


	UPDATE tbl_ticket
	SET DnId = @DnId
	WHERE ticketId = @iTicketId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_ticket_register_new') IS NOT NULL
	DROP PROCEDURE sp_ticket_register_new
GO

CREATE PROCEDURE sp_ticket_register_new
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-18
Description: Register a ticket directly to tbl_ticket_log
------------------------------------------------------------
Modified by: Henrik Linder 
Modification date: 2009-07-07
Description: Ticket price in SEK * 1000, not SEK * 100.
------------------------------------------------------------
Modified by: Henrik Linder 
Modification date: 2009-08-05
Description: TicketId is given as input param instead of generated by SP.
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-08-31
Description: Added support for scan and fax
************************************************************/
	@iPrinterId			varchar(64)
	,@iQueueId			varchar(64)		= NULL
	,@iJobName			nvarchar(510)	= NULL
	,@iTicketId			varchar(64)
	,@iUserName			nvarchar(510)
	,@iDomain			nvarchar(510)
	,@iJobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
	,@iPagesBW			int
	,@iPagesColor		int
	,@iPaperSize		tinyint
	,@iDuplex			bit
	,@iSize				int = 0
	,@iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL
	,@iPricePlan		varchar(64)		= NULL
	,@iTicketPrice		int				= NULL
	,@iText				nvarchar(1024)
	,@iBillingCode		nvarchar(128)	= NULL
	,@oTicketId			varchar(64) OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	
	-- Check input parameters
	--------------------------------------------------------

	EXEC @ReturnStatus = sp_ticket_register_new_chk		@iPrinterId		=	@iPrinterId
														,@iQueueId		=	@iQueueId
														,@iJobName		=	@iJobName
														,@iUserName		=	@iUserName
														,@iDomain		=	@iDomain
														,@iJobType		=	@iJobType
														,@iPagesBW		=	@iPagesBW
														,@iPagesColor	=	@iPagesColor
														,@iPaperSize	=	@iPaperSize
														,@iDuplex		=	@iDuplex
														,@iSize			=	@iSize
														,@iStartDate	=	@iStartDate
														,@iEndDate		=	@iEndDate
														,@iPricePlan	=	@iPricePlan
														,@iTicketPrice	=	@iTicketPrice
														,@iBillingCode	=	@iBillingCode

	IF @ReturnStatus <> 0
		RETURN (@ReturnStatus)


	-- Insert row
	--------------------------------------------------------

	-- Prepare Row fields from input params
	DECLARE 	@EventMajor		smallint		
				,@EventMinor	smallint		

	IF (@iJobType = 1)
	BEGIN 
		SET @EventMajor = 2
		SET @EventMinor = 1
	END

	IF (@iJobType = 2)
	BEGIN 
		SET @EventMajor = 4
		SET @EventMinor = 10
	END

	-- Event minor as per function verbose Ticket Log. Major as in copy (above)
	IF (@iJobType = 3) -- fax
	BEGIN 
		SET @EventMajor = 4
		SET @EventMinor = 12
	END

	IF (@iJobType = 4) -- scan
	BEGIN 
		SET @EventMajor = 4
		SET @EventMinor = 11
	END

	DECLARE @CurrentTimestamp datetime
	SET @CurrentTimestamp = getdate()


	DECLARE	@Duplex			smallint
			,@Color			smallint
			,@TicketPrice	float


	SET @Color = CASE WHEN @iPagesBW = 0 THEN 2 ELSE 1 END	-- 0=Unknown, 1 = BW, 2=Color
	SET @Duplex = CASE WHEN @iDuplex = 1 THEN 2 ELSE 1 END	-- 0=Unknown, 1=nej, >1 = ja

	SET @TicketPrice = CAST(ISNULL(@iTicketPrice,0) AS float) / 1000.0	

	-- Actual insert
	SET @oTicketId = UPPER(@iTicketId) --UPPER(NEWID())

	INSERT tbl_ticket_log
		(logticketId
		,logqueueId
		,logprinterId
		,logjobName
		,loguserName
		,loguserDomain
		,logjobSize
		,logpages
		,logpaper
		,logduplex
		,logcolor
		,logdateEvent
		,logdateCreated
		,logdateSort
		,logdateBegan
		,logdateFinished
		,logsentBytes
		,logsentPages
		,logclientId
		,logclientIp
		,logEventMajor
		,logEventMinor
		,logData
		,logText
		,logfprintQ
		,logticketDriver
		,logticketModel
		,logLoggedColorPages
		,logLoggedBWPages
		,logpricePlan
		,logTicketPrice
		,logoriginatingIp
		,logDocumentTypeId
		,logclientBillingCode)
	VALUES
	(
		@oTicketId				--logticketId
		,ISNULL(@iQueueId,'')	--logqueueId
		,@iPrinterId			--logprinterId
		,ISNULL(@iJobName,'')	--logjobName
		,@iUserName				--loguserName
		,@iDomain				--loguserDomain
		,ISNULL(@iSize,0)		--logjobSize
		,@iPagesBW + @iPagesColor		--logpages
		,@iPaperSize			--logpaper
		,@Duplex				--logduplex
		,@Color					--logcolor
		,@CurrentTimestamp		--logdateEvent
		,@CurrentTimestamp		--logdateCreated
		,@CurrentTimestamp		--logdateSort
		,@iStartDate			--logdateBegan
		,@iEndDate				--logdateFinished
		,''						--logsentBytes
		,''						--logsentPages
		,''						--logclientId
		,''						--logclientIp
		,@EventMajor			--logEventMajor
		,@EventMinor			--logEventMinor
		,''						--logData
		,ISNULL(@iText,'')		--logText
		,''						--logfprintQ
		,''						--logticketDriver
		,''						--logticketModel
		,@iPagesColor			--logLoggedColorPages
		,@iPagesBW				--logLoggedBWPages
		,ISNULL(@iPricePlan,'')			--logpricePlan
		,@TicketPrice			--logTicketPrice
		,''						--logoriginatingIp
		,0						--logDocumentTypeId
		,@iBillingCode			--logclientBillingCode
	)


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_ticket_register_new_chk') IS NOT NULL
	DROP PROCEDURE sp_ticket_register_new_chk
GO

CREATE PROCEDURE sp_ticket_register_new_chk
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-18
Description: Check if a ticket can be registered to tbl_ticket_log
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-08-31
Description: Added support for scan and fax
************************************************************/
	@iPrinterId			varchar(64)
	,@iQueueId			varchar(64)		= NULL
	,@iJobName			nvarchar(510)	= NULL
	,@iUserName			nvarchar(510)
	,@iDomain			nvarchar(510)
	,@iJobType			tinyint -- 1=print, 2=copy, 3=fax, 4=scan
	,@iPagesBW			int
	,@iPagesColor		int
	,@iPaperSize		tinyint
	,@iDuplex			bit
	,@iSize				int = 0
	,@iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL
	,@iPricePlan		varchar(64)		= NULL
	,@iTicketPrice		int				= NULL
	,@iBillingCode		nvarchar(128)	= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	
	-- Checks

	-- 1. Billing Code
	EXEC @ReturnStatus = sp_client_billing_validate @iBillingCode	= @iBillingCode
													,@iUserName		= @iUserName
													,@iDomain		= @iDomain
	IF @ReturnStatus <> 0
		RETURN (@ReturnStatus)

	-- 2. Page count
	IF @iPagesBW + @iPagesColor <= 0
		RETURN (100039)

	-- 3. Price >= 0
	IF ISNULL(@iTicketPrice,0) < 0
		RETURN (100040)

	-- 4. PrinterId. (active and network printer)
	IF NOT EXISTS (SELECT 1 FROM tbl_printer WHERE printerId = @iPrinterId AND adminStatus <> 3 AND printerType = 0)
		RETURN (100041)

	-- 5. JobType
	IF @iJobType NOT IN (1,2,3,4)
		RETURN (100042)

	-- 6. Does queue match printer?
	IF LEN(ISNULL(@iQueueId,'')) > 0
		IF NOT EXISTS (SELECT 1 FROM tbl_queue_printer_map WHERE mapPhyPrinter = @iPrinterId AND mapQueue = @iQueueId)
			RETURN (100043)

--	-- 7. JobType fax not implemented
--	IF @iJobType = 3
--		RETURN (100044)
--
--	-- 8. JobType scan not implemented
--	IF @iJobType = 4
--		RETURN (100045)

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_ticket_search') IS NOT NULL
	DROP PROCEDURE sp_ticket_search
GO

CREATE PROCEDURE sp_ticket_search
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-15
Description: Search for tickets
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-01-31
Description: Top 100 instead of Top 1000
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-03-11
Description: Increase performance
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
************************************************************/
	@isearchString			nvarchar(128)
	,@ionlyActiveTickets	bit				= 0 
	,@istartDate			datetime		= NULL
	,@iendDate				datetime		= NULL
	-- below are used if user wants to refine results of original search --
	,@ijobName				nvarchar(510)	= NULL
	,@iuserName				nvarchar(510)	= NULL
	,@ioriginatingIp		varchar(64)		= NULL
	,@iLanguageId			char(2)			= 'en'
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@searchString			nvarchar(128)

	IF LEN(@isearchString) = 0
		RETURN (100008)

	IF @istartDate IS NULL
		SET @istartDate = '20000101'

	SET @searchString = '%' + @isearchString + '%'

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #tickets (	ticketId		varchar(64)	COLLATE DATABASE_DEFAULT
							,ticketActive	bit
							,DateEvent datetime)

	CREATE INDEX ix1 ON #tickets (ticketId, ticketActive,DateEvent)

	-- Select tickets to display
	INSERT #tickets (ticketId, ticketActive)
	Select --TOP 100 
	t.ticketId, 1
	from tbl_ticket t 
	where(t.jobName LIKE @searchString
		OR t.originatingIp LIKE @searchString
		OR userName LIKE @searchString)
--		AND (@istartDate	 IS NULL OR t.dateCreated	>= @istartDate)
--		AND (@iendDate		 IS NULL OR t.dateCreated	<= @iendDate)
--		AND (@iuserName		 IS NULL OR t.userName		= @iuserName)
--		AND (@ijobName		 IS NULL OR t.jobName		= @ijobName)
--		AND (@ioriginatingIp IS NULL OR t.originatingIp = @ioriginatingIp)
	ORDER BY dateSort DESC

	
	IF (@ionlyActiveTickets = 0)
	INSERT #tickets (ticketId, ticketActive,DateEvent)
	Select TOP 100 t.logticketId, 0, MAX(logdateEvent)
	from tbl_ticket_log t   --WITH (INDEX(ixTicketLogSearch, ixTicketLogSearch1))
	where
		(t.logjobName LIKE @searchString
		OR t.logoriginatingIp LIKE @searchString
		OR t.loguserName LIKE @searchString)
--		AND (@istartDate	 IS NULL OR t.logdateCreated	>= @istartDate)
--		AND (@iendDate		 IS NULL OR t.logdateCreated	<= @iendDate)
--		AND (@iuserName		 IS NULL OR t.loguserName		= @iuserName)
--		AND (@ijobName		 IS NULL OR t.logjobName		= @ijobName)
--		AND (@ioriginatingIp IS NULL OR t.logoriginatingIp = @ioriginatingIp)
		AND t.logticketId NOT IN (SELECT ticketId FROM tbl_ticket)
		AND t.logdateEvent >= @istartDate
	GROUP BY t.logticketId
	ORDER BY MAX(logdateEvent) DESC
	--SELECT COUNT(1) FROM #tickets


	-- Get overview of selected tickets
	IF @ionlyActiveTickets = 1
		EXEC @ReturnStatus = sp_get_tickets_sub @iincludeActive = 1, @iincludeOld = 0, @iLanguageId = @iLanguageId
	ELSE
		EXEC @ReturnStatus = sp_get_tickets_sub @iincludeActive = 1, @iincludeOld = 1, @iLanguageId = @iLanguageId



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_ticket_send_message') IS NOT NULL
	DROP PROCEDURE sp_ticket_send_message
GO

CREATE PROCEDURE sp_ticket_send_message
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-03-12
Description: Send a message to a ticket owner
************************************************************/
	@iticketId				varchar(64)
	,@iuser					nvarchar (256)
	,@idomain				nvarchar (256)
	,@imessage				nvarchar(510)	 
AS
BEGIN

	DECLARE @ErrorNo int


 	IF LEN(@imessage) = 0 OR @imessage IS NULL
		RETURN (100031)

	IF NOT EXISTS(SELECT 1 FROM tbl_ticket WHERE ticketId = @iticketId)
		RETURN (100032)




	INSERT tbl_transaction
			(transAffId
			,transAct
			,transText
			,transUser
			,transDomain)
	VALUES (@iticketId						--	transAffId
			,8								--	transAct
			,@imessage						--	transText
			,@iuser							--	transUser
			,@idomain)						--	transDomain


	SELECT @ErrorNo = @@ERROR

	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_typeof_id') IS NOT NULL
	DROP PROCEDURE sp_typeof_id
GO

CREATE PROCEDURE sp_typeof_id
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-02-13
Description: Given an ID, return the type (Queue, Printer, Ticket, etc)
************************************************************/
	@iId				varchar(64) = NULL
	,@otype				varchar(10) OUTPUT
AS
BEGIN

	SELECT @otype = NULL

	IF @otype IS NULL
		IF  EXISTS( SELECT 1 FROM tbl_queue WHERE queueId = @iId)
			SELECT @otype = 'QUEUE'
	IF @otype IS NULL
		IF  EXISTS( SELECT 1 FROM tbl_printer WHERE printerId = @iId)
			SELECT @otype = 'PRINTER'

	IF @otype IS NULL
		IF  EXISTS( SELECT 1 FROM tbl_ticket WHERE ticketId = @iId)
			SELECT @otype = 'TICKET_A'

	IF @otype IS NULL
		IF  EXISTS( SELECT 1 FROM tbl_ticket_log WHERE logticketId = @iId)
			SELECT @otype = 'TICKET_O'


	RETURN (0)

END
GO

IF OBJECT_ID('sp_vdms_search') IS NOT NULL
	DROP PROCEDURE sp_vdms_search
GO

CREATE PROCEDURE sp_vdms_search
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-19
Description: Search for VDMS
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-04-06
Description: Default to only show last 7 days. Top 100 instead of top 1000.
************************************************************/
	@isearchString			nvarchar(128)
	,@ionlyActiveSessions	bit				= 0 
	,@istartDate			datetime		= NULL
	,@iendDate				datetime		= '99991231'
	-- below are used if user wants to refine results of original search --
	,@iuserName				nvarchar(510)	= NULL
	,@isessionIp			varchar(64)		= NULL

AS
BEGIN

	DECLARE	@ErrorNo			int
			,@searchString			nvarchar(128)

	IF LEN(@isearchString) = 0
		RETURN (100008)

	IF @istartDate IS NULL
		SET @istartDate = DATEADD(d, -7, getdate())

	SET @searchString = '%' + @isearchString + '%'

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF



	Select	TOP 100
			vsUser [User]
			,vsDomain Domain
			,vsIp IP
			,vsPricePlan PricePlan
			,vsDateLastSeen DateLastSeen
			,vsDateLogin DateLogin
			,1 as Active
	from tbl_vdms_loginsession s 
	where(	s.vsIp	LIKE @searchString
		 OR s.vsUser	LIKE @searchString)
		AND (s.vsDateLogin	>= @istartDate)
		AND (s.vsDateLogin	<= @iendDate)
		AND (@iuserName		 IS NULL OR s.vsUser  = @iuserName)
		AND (@isessionIp IS NULL OR s.vsIp = @isessionIp)
	
	UNION 
	Select	TOP 100
			lvsUser 
			,lvsDomain 
			,lvsIp 
			,lvsPricePlan 
			,lvsDateLastSeen
			,lvsDateLogin
			,0 as vsActive
	from tbl_vdms_loginsession_log s 
	where(	s.lvsIp	LIKE @searchString
		 OR s.lvsUser	LIKE @searchString)
		AND (s.lvsDateLogin	>= @istartDate)
		AND (s.lvsDateLogin	<= @iendDate)
		AND (@iuserName		 IS NULL OR s.lvsUser  = @iuserName)
		AND (@isessionIp IS NULL OR s.lvsIp = @isessionIp)

	ORDER BY vsDateLogin DESC

	SET @ErrorNo = @@ERROR


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_wallet_search') IS NOT NULL
	DROP PROCEDURE sp_wallet_search
GO

CREATE PROCEDURE sp_wallet_search
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-01-19
Description: Search for wallets / history ("Quota")
************************************************************/
	@isearchString			nvarchar(128)
	,@ionlyActiveWallets	bit				= 0 -- ej implementerat �nnu
	,@istartDate			datetime		= NULL
	,@iendDate				datetime		= NULL
	-- below are used if user wants to refine results of original search --
	,@iuserName				nvarchar(510)	= NULL
	,@isessionIp			varchar(64)		= NULL
	,@iLanguageId			char(2)			= 'en'

AS
BEGIN

	DECLARE	@ErrorNo			int
			,@searchString			nvarchar(128)

	IF LEN(@isearchString) = 0
		RETURN (100008)

	SET @searchString = '%' + @isearchString + '%'

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF;



	SELECT	TOP 1000
			wUser [User]
			,wDomain Domain
			,wDomain + '\' + wUser UserDomain
			,CURRENT_TIMESTAMP EventDate
			,dbo.fn_translate('CurrentBalance', @iLanguageId) + ':' EventTypeVerbose
			,wTotal Credits
			,wReserved ReservedCredits
			,CAST(wTotal as varchar(20)) 
				+ ' (' + CAST(wReserved as varchar(20)) + ' '+dbo.fn_translate('reserved', @iLanguageId) +')' AS CreditBalanceVerbose
			,1 as Active
			,NULL As AdditionalInformation
	from tbl_cirrato_wallet w 
	where  (w.wUser	LIKE @searchString)
		AND (@iuserName		 IS NULL OR w.wUser  = @iuserName)
	
	UNION 
	
	SELECT	TOP 1000
			wLogUser [User]
			,wLogDomain Domain
			,wLogDomain + '\' + wLogUser UserDomain
			,wLogTransDate EventDate
			,dbo.verboseWalletLogEventByLanguage(wLogEvent, @iLanguageId) EventTypeVerbose
			,wLogTransAmount Credits
			,NULL ReservedCredits
			,CAST(wLogTransAmount as varchar(20)) CreditBalanceVerbose
			,0 as Active
			,jobName AdditionalInformation
	from tbl_cirrato_wallet_log w 
	left outer join (SELECT DISTINCT ticketId, jobName FROM tbl_ticket
		UNION
		SELECT DISTINCT logticketId, logjobName FROM tbl_ticket_log) t
		on w.wLogTicketId = t.ticketId

	where --(	s.vsIp	LIKE @searchString
		  (w.wLogUser	LIKE @searchString)
		AND (@istartDate	 IS NULL OR w.wLogTransDate	>= @istartDate)
		AND (@iendDate		 IS NULL OR w.wLogTransDate	<= @iendDate)
		AND (@iuserName		 IS NULL OR w.wLogUser  = @iuserName)
--		AND (@isessionIp IS NULL OR s.vsIp = @isessionIp)


	ORDER BY [User] ASC, EventDate DESC

	SET @ErrorNo = @@ERROR


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ErrorNo)
END
GO

IF OBJECT_ID('sp_report_queue_regiondepth_cache_refresh') IS NOT NULL
	DROP PROCEDURE sp_report_queue_regiondepth_cache_refresh
GO

CREATE PROCEDURE sp_report_queue_regiondepth_cache_refresh
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Recalculate queue region paths at different levels
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-10
Description: Delete instead of truncate.
************************************************************/
	@iDepth smallint = 10
AS
BEGIN

	DELETE tbl_report_queue_regiondepth_cache

	DECLARE @i int 
		,@ErrorNo int
	SET @i = 0
	SET @ErrorNo = 0

	WHILE @i <= @iDepth
	BEGIN
		-- queuesprinters
		INSERT tbl_report_queue_regiondepth_cache
			(QueueId
			,Depth
			,RegionPath)
		SELECT
			CAST(q.queueId AS uniqueidentifier)
			,@i
--			,dbo.fn_region_get_partial_path_verbose(q.queueRegion, @i)
			,dbo.fn_region_get_part_path_verbose(q.queueRegion, @i)
		FROM tbl_queue q

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100100
			GOTO PROC_ERROR
		END

		-- Network printers
		INSERT tbl_report_queue_regiondepth_cache
			(QueueId
			,Depth
			,RegionPath)
		SELECT
			CAST(p.printerId AS uniqueidentifier)
			,@i
			,dbo.fn_region_get_partial_path_verbose(p.region, @i)
		FROM tbl_printer p
		WHERE p.printerType = 0


		-- Local printers
		INSERT tbl_report_queue_regiondepth_cache
			(QueueId
			,Depth
			,RegionPath)
		SELECT
			CAST(p.printerId AS uniqueidentifier)
			,@i
			,dbo.fn_lregion_get_partial_path_verbose(p.region, @i)
		FROM tbl_printer p
		WHERE p.printerType = 1


		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100101
			GOTO PROC_ERROR
		END

		SET @i = @i +1
	END


	RETURN (0)


	PROC_ERROR:

	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_report_cache_refresh') IS NOT NULL
	DROP PROCEDURE sp_report_cache_refresh
GO

CREATE PROCEDURE sp_report_cache_refresh
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Refresh caches:
				* Queues
				* Printers
				* Printer / Queue mappings (??)
				* Regions
				* Models
				* Brands
				* Status cache
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-06-01
Description: Added PrinterCount to model and brand tables.
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-10
Description: Delete instead of truncate.
************************************************************/

AS
BEGIN


	-- Queue
	-------------------------------------------------------------
	DELETE tbl_report_queue_cache
	INSERT  tbl_report_queue_cache
		(QueueId
		,QueueName
		,QueueType
		,PrinterId
		,ParentRegionId)
	SELECT
		CAST(q.queueId AS uniqueidentifier)
		,q.queueName
		,q.queueType
		,CAST(m.mapPhyPrinter AS uniqueidentifier)
		,q.queueRegion
--		,r.regionParentId
	FROM tbl_queue q
--	INNER JOIN tbl_region r
--		on r.regionId = q.queueRegion
	LEFT JOIN tbl_queue_printer_map m
		ON m.mapQueue = q.queueId
	WHERE LEN(q.queueId) = 36
		AND LEN(m.mapPhyPrinter) = 36
	UNION
	SELECT
		CAST(p.printerId AS uniqueidentifier)
		,p.printerName
		,NULL										AS QueueType
		,CAST(p.printerId AS uniqueidentifier)		AS PrinterId
		,p.region + 1000000
--		,r.lregionParentId + 1000000
	FROM tbl_printer p 
--	INNER JOIN tbl_lregion r
--		on r.lregionId = p.region
	WHERE printerType = 1
	AND LEN(p.printerId) = 36

	-- Printer
	-------------------------------------------------------------
	DELETE tbl_report_printer_cache
	INSERT tbl_report_printer_cache
		(PrinterId
		,PrinterName
		,PrinterType
		,PrinterComment
		,ModelId
		,Hidden
		,ParentRegionId)
	SELECT
		p.printerId
		,p.printerName
		,p.printerType
		,p.printerComment
		,p.printerModel
		,p.printerHidden
		,CASE WHEN p.printerType = 1 THEN p.region + 1000000 ELSE p.region END AS ParentRegionId
	FROM tbl_printer p
	WHERE LEN (p.printerId) = 36
	AND LEN (p.printerModel) = 36


	-- Status cache
	-------------------------------------------------------------
	DELETE tbl_report_status_cache
	DECLARE @i int, @j int
	DECLARE @Verbose nvarchar(510)
	SET @i = 0


	WHILE @i < 100
	BEGIN


		-- verbosePrinterPhysicalStatus = 1 --
		SET @Verbose = dbo.verbosePrinterPhysicalStatus(@i, 1)
		IF ISNULL(@Verbose,cast(@i as varchar(510))) <> cast(@i as varchar(510))
		INSERT tbl_report_status_cache (StatusTypeId, StatusMajor, StatusMinor, StatusVerbose) VALUES (1,@i,NULL, @Verbose)
	



		SET @j = 0
		WHILE @j < 100
		BEGIN
			-- loop for statii with 2 levels

		SET @j = @j + 1
		END


	SET @i = @i + 1
	END

	


	-- Model
	-------------------------------------------------------------
	DELETE tbl_report_model_cache
	INSERT tbl_report_model_cache
		(ModelId
		,BrandId
		,ModelName)
	SELECT
		CAST(modelId as uniqueidentifier)
		,CAST(modelBrandId as uniqueidentifier)
		,modelName
	FROM tbl_model
	WHERE LEN(modelId) = 36
		AND LEN(modelBrandId) = 36


	UPDATE m
		SET m.PrinterCount = (SELECT COUNT(1) FROM tbl_report_printer_cache p WHERE p.ModelId = m.ModelId)
	FROM tbl_report_model_cache m


	-- Brand
	-------------------------------------------------------------
	DELETE tbl_report_brand_cache
	INSERT tbl_report_brand_cache
		(BrandId
		,BrandName)
	SELECT
		CAST(brandId as uniqueidentifier)
		,brandName
	FROM tbl_brand
	WHERE LEN(brandId) = 36

	UPDATE b
		SET b.PrinterCount = 
			(SELECT COUNT(1) FROM tbl_report_printer_cache p 
			INNER JOIN tbl_report_model_cache m
				ON p.ModelId = m.ModelId
			WHERE m.BrandId = b.BrandId)
	FROM tbl_report_brand_cache b

	-- Region
	-------------------------------------------------------------
	DELETE tbl_report_region_cache
	INSERT tbl_report_region_cache
		(RegionId
		,ParentRegionId
		,RegionName
		,RegionGUID)
	SELECT
		regionId
		,regionParentId
		,regionName
		,NEWID()
	FROM tbl_region WHERE regionActive = 1
	UNION
	SELECT
		lregionId + 1000000
		,lregionParentId + 1000000
		,lregionName
		,NEWID()
	FROM tbl_lregion WHERE lregionActive = 1

	RETURN (0)





END
GO


IF OBJECT_ID('sp_report_jobs_detail_calc_do') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_detail_calc_do
GO

CREATE PROCEDURE sp_report_jobs_detail_calc_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Calculate detailed job stats since last run
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-17
Description: Added billing code field
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-19
Description: Added copy jobs
(see comments of sp report_jobs_queue_calc_do for table of combinations)
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-07-06
Description: Adaption for DeleteAfterPrint = false option
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-10
Description: Delete instead of truncate.
************************************************************/
	@iReset bit = 0					-- 1 = delete all data and recalculate from scratch
AS
BEGIN

	DECLARE @ReturnStatus	INT
		,@ErrorNo			INT
		,@StartDate			datetime
		,@EndDate			datetime
		,@CurrentTimestamp  datetime

	SET @ReturnStatus = 0
	SET @ErrorNo = 0
	SET @EndDate = convert(char(8), getdate(), 112) -- end date is last midnight
	SET @CurrentTimestamp = getdate()

	SET @StartDate = dbo.fn_property_get_date('JobsDetailCutOff')
	IF @StartDate IS NULL
		RETURN (100111)

	IF @iReset = 1
	BEGIN
		SET @StartDate = '20000101'
		BEGIN TRY
			TRUNCATE TABLE tbl_report_jobs_detail
		END TRY
		BEGIN CATCH
			DELETE tbl_report_jobs_detail
		END CATCH
		--DELETE tbl_report_users
	END

	IF @EndDate <= @StartDate
		RETURN (100112)

--	Debug
--	SET @StartDate = '20080915'
--	SET @EndDate = '20080916'


	-- Update users table with any new users since last run
	----------------------------------------------------------------------

	INSERT tbl_report_users
		(UserName
		,Domain
		,RegDate)
	SELECT DISTINCT
		ISNULL(loguserName,'NoUser')
		,ISNULL(loguserDomain,'NoDomain')
		,@CurrentTimestamp
	FROM tbl_ticket_log t
	LEFT OUTER JOIN tbl_report_users u
		ON u.UserName = t.loguserName
		AND u.Domain = t.loguserDomain
	WHERE t.logEventMajor = 2 
		AND t.logEventMinor IN (1, 6, 10)
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND u.UserName IS NULL
		AND u.Domain IS NULL


	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100113
		GOTO PROC_ERROR
	END


	-- Make sure only tickets with ONE final status flag is included (otherwise, tbl_report_jobs_detail PK will be violated)
	----------------------------------------------------------------------
	DECLARE @Tickets TABLE (TicketId varchar(64) COLLATE DATABASE_DEFAULT)

	INSERT @Tickets(TicketId)
	SELECT 
		t.logticketId
	FROM tbl_ticket_log t
	WHERE
		( ( t.logEventMajor = 2 AND t.logEventMinor = 1 AND LEN(t.logPrinterId) = 36 AND LEN(t.logQueueId) = 36 ) -- print
		OR (t.logEventMajor = 2 AND t.logEventMinor = 6 AND LEN(t.logQueueId) = 36) -- print ext
		OR (t.logEventMajor = 4 AND t.logEventMinor = 10 AND LEN(t.logPrinterId) = 36) ) -- copy
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND (LEN(t.logfprintQ) = 36 OR LEN(t.logfprintQ) = 0)
	GROUP BY t.logticketId
	HAVING COUNT(*) = 1



	-- Client Billing
	----------------------------------------------------------------------
	DECLARE @cb TABLE (BillingCodeId bigint, BillingCode nvarchar(128))

	INSERT @cb
	SELECT
		MAX(cb_id)
		,cb_code
	FROM tbl_client_billing
	GROUP BY cb_code

	--

	-- Printer / queue cache. "Primary" queue per printer. For now, only determined by MIN function.
	----------------------------------------------------------------------
	DECLARE @pq TABLE (PrinterId varchar(64), QueueId uniqueidentifier)
	INSERT @pq
	SELECT
		mapPhyPrinter
		,CAST(MIN(mapQueue) as uniqueidentifier)
	FROM tbl_queue_printer_map GROUP BY mapPhyPrinter

	-- local printers:
	INSERT @pq 
	SELECT DISTINCT 
		printerId
		,cast(printerId as uniqueidentifier)
	FROM tbl_printer
	WHERE printerId NOT IN (SELECT PrinterId FROM @pq)


	-- Transfer relevant data from ticket log to report job detail table
	----------------------------------------------------------------------

	-- 1. Jobs that have queue id
	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --
	INSERT tbl_report_jobs_detail
		(TicketId
		,JobDate
		,JobName
		,UserId
		,QueueId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,PaperType
		,Duplex
		,Size
		,PagesBW
		,PagesColor
		,TicketPrice
		,BillingCodeId
		,DnId)
	SELECT
		CAST(t.logTicketId AS uniqueidentifier)			AS TicketId
		,MIN(t.logdateEvent)									AS JobDate
		,MIN(t.logjobName)									AS JobName
		,MIN(u.UserId)										AS UserId
		,CASE WHEN LEN(MIN(logqueueId)) = 36 THEN MIN(logqueueId) ELSE 
			-- queue lookup using printerId:
			(SELECT CAST(MIN(mapQueue) as uniqueidentifier) FROM tbl_queue_printer_map m WHERE mapPhyPrinter = CAST(MIN(logPrinterId) as varchar(64)))
		END												AS QueueId
--		,CAST(t.logQueueId AS uniqueidentifier)			AS QueueId

		,CASE WHEN LEN(MAX(t.logfprintQ)) = 36 
			THEN CAST(MAX(t.logfprintQ) AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
--		,CAST(t.logfprintQ AS uniqueidentifier)			AS FollowPrintQueueId
		,0												AS IsLocalPrinter
		,CASE	WHEN MIN(t.logEventMinor) IN (1, 6) THEN 1
				WHEN MIN(t.logEventMinor) = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN MIN(t.logfprintQ) = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,MIN(t.logpaper)										AS PaperType
		,CASE WHEN MIN(t.logduplex) > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,MIN(t.logjobSize)									AS Size

		,CASE WHEN SUM(t.logLoggedBWPages) = 0 AND SUM(t.logLoggedColorPages) = 0
			THEN
				CASE WHEN MIN(t.logcolor) = 2 THEN 0 ELSE SUM(t.logpages) END -- logcolor: 0=Unknown, 1 = BW, 2=Color
			ELSE 
				SUM(t.logLoggedBWPages)
			END											AS PagesBW

		,CASE WHEN SUM(t.logLoggedBWPages) = 0 AND SUM(t.logLoggedColorPages) = 0
			THEN
				CASE WHEN MIN(t.logcolor) <> 2 THEN 0 ELSE SUM(t.logpages) END -- logcolor: 0=Unknown, 1 = BW, 2=Color
			ELSE 
				SUM(t.logLoggedColorPages)
			END											AS PagesColor
		,SUM(t.logTicketPrice)								AS TicketPrice
		,CASE WHEN LEN(MIN(cb.BillingCode)) = 0 OR MIN(cb.BillingCode) IS NULL THEN -1 ELSE MIN(cb.BillingCodeId) END AS BillingCodeId
		,MAX(t.DnId)
	FROM tbl_ticket_log t
	INNER JOIN tbl_report_users u
		ON u.UserName = t.loguserName
		AND u.Domain = t.loguserDomain
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	LEFT JOIN @cb cb
		ON cb.BillingCode = t.logclientBillingCode
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND LEN(t.logTicketId) = 36
		AND LEN(t.logQueueId) = 36
		--AND LEN(t.logfprintQ) = 36 
	GROUP BY t.logTicketId

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100114
		GOTO PROC_ERROR
	END



	-- 2. Jobs without queue id
	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --
	INSERT tbl_report_jobs_detail
		(TicketId
		,JobDate
		,JobName
		,UserId
		,QueueId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,PaperType
		,Duplex
		,Size
		,PagesBW
		,PagesColor
		,TicketPrice
		,BillingCodeId
		,DnId)
	SELECT
		CAST(t.logTicketId AS uniqueidentifier)			AS TicketId
		,t.logdateEvent									AS JobDate
		,t.logjobName									AS JobName
		,u.UserId										AS UserId
		,pq.QueueId										AS QueueId
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0												AS IsLocalPrinter
		,CASE	WHEN t.logEventMinor IN (1, 6) THEN 1
				WHEN t.logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,t.logpaper										AS PaperType
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logjobSize									AS Size

		,CASE WHEN t.logLoggedBWPages = 0 AND t.logLoggedColorPages = 0
			THEN
				CASE WHEN t.logcolor = 2 THEN 0 ELSE t.logpages END -- logcolor: 0=Unknown, 1 = BW, 2=Color
			ELSE 
				t.logLoggedBWPages
			END											AS PagesBW

		,CASE WHEN t.logLoggedBWPages = 0 AND t.logLoggedColorPages = 0
			THEN
				CASE WHEN t.logcolor <> 2 THEN 0 ELSE t.logpages END -- logcolor: 0=Unknown, 1 = BW, 2=Color
			ELSE 
				t.logLoggedColorPages
			END											AS PagesColor
		,t.logTicketPrice								AS TicketPrice
		,CASE WHEN LEN(cb.BillingCode) = 0 OR cb.BillingCode IS NULL THEN -1 ELSE cb.BillingCodeId END AS BillingCodeId
		,t.DnId
	FROM tbl_ticket_log t
	INNER JOIN tbl_report_users u
		ON u.UserName = t.loguserName
		AND u.Domain = t.loguserDomain
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	INNER JOIN @pq pq
		ON pq.PrinterId = t.logPrinterId
	LEFT JOIN @cb cb
		ON cb.BillingCode = t.logclientBillingCode
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND LEN(t.logTicketId) = 36
		AND LEN(t.logQueueId) = 0
		--AND LEN(t.logfprintQ) = 36 

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100114
		GOTO PROC_ERROR
	END



	-- Save date range for next run
	----------------------------------------------------------------------

	EXEC @ReturnStatus = sp_property_upd @ipropertyName = 'JobsDetailCutOff', @ipropertyValueDate = @EndDate


	RETURN (@ReturnStatus)


	PROC_ERROR:

	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_report_jobs_queue_calc_do') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_queue_calc_do
GO

CREATE PROCEDURE sp_report_jobs_queue_calc_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-06
Description: Calculate aggregate job stats since last run
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-05-17
Description: Do not include jobs with more than one final status flag
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-18
Description: Do not exclude jobs with empty logfprintQ 
			AND fix for copy jobs (previously not included)

-- print job: eventmajor = 2, eventminor = 1. b�de printerid och queueid �r satt.
-- print job external: eventmajor = 2, eventminor = 6. Dessa har ej printerId satt, men queueid. (Detta �r jobb som utf�rdes n�r server var nere, klient skickade upp i efterhand)
-- copy job: eventmajor  = 4, eventminor = 10. dessa har printerId, men ej queueid.
-- scan job:
-- fax job: 
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-10
Description: Delete instead of truncate.
************************************************************/
	@iReset bit = 0					-- 1 = delete all data and recalculate from scratch
AS
BEGIN

	DECLARE @ReturnStatus	INT
		,@ErrorNo			INT
		,@StartDate			datetime
		,@EndDate			datetime

	SET @ReturnStatus = 0
	SET @ErrorNo = 0
	SET @EndDate = convert(char(8), getdate(), 112) -- end date is last midnight


	SET @StartDate = dbo.fn_property_get_date('JobsQueueCutOff')
	IF @StartDate IS NULL
		RETURN (100102)

	IF @iReset = 1
	BEGIN
		SET @StartDate = '20000101'
		BEGIN TRY
			TRUNCATE TABLE tbl_report_jobs_queue
		END TRY
		BEGIN CATCH
			DELETE tbl_report_jobs_queue
		END CATCH

	END

	IF @EndDate <= @StartDate
		RETURN (100110)

--	Debug
--	SET @StartDate = '20080915'
--	SET @EndDate = '20080916'

	-- Make sure only tickets with ONE final status flag is included (otherwise, tbl_report_jobs_detail PK will be violated)
	DECLARE @Tickets TABLE (TicketId varchar(64) COLLATE DATABASE_DEFAULT)

	INSERT @Tickets(TicketId)
	SELECT 
		t.logticketId
	FROM vw_ticket_log_report_calc t
	WHERE
		( ( t.logEventMajor = 2 AND t.logEventMinor = 1 AND LEN(t.logPrinterId) = 36 AND LEN(t.logQueueId) = 36 ) -- print
		OR (t.logEventMajor = 2 AND t.logEventMinor = 6 AND LEN(t.logQueueId) = 36) -- print ext
		OR (t.logEventMajor = 4 AND t.logEventMinor = 10 AND LEN(t.logPrinterId) = 36) ) -- copy
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND (LEN(t.logfprintQ) = 36 OR LEN(t.logfprintQ) = 0)
	GROUP BY t.logticketId
	HAVING COUNT(*) = 1


	DECLARE @jobs TABLE
		(JobDay					datetime NOT NULL
		,QueueId				uniqueidentifier NULL
		,FollowPrintQueueId		uniqueidentifier NULL
		,IsLocalPrinter			bit NOT NULL
		,JobType				tinyint NOT NULL	--(1=print, 2=copy, 3=fax, 4=scan)
		,IsFollowPrint			bit NOT NULL
		,Color					bit NOT NULL
		,Duplex					bit NOT NULL
		,PaperType				smallint NOT NULL
		,Size					bigint NOT NULL 
		,Pages					int NOT NULL
		,JobCount				int NOT NULL
		,TicketPrice			float NULL)


	-- Jobs without SNMP
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	


		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId

--		,CASE WHEN LEN(t.logQueueId) = 36 
--			THEN CAST(t.logQueueId AS uniqueidentifier)	
--			ELSE -- anv�nd printerid som queueId
--				CASE WHEN LEN(t.logPrinterId) = 36 
--							THEN CAST(t.logPrinterId AS uniqueidentifier)
--				ELSE NULL END
--			END								AS QueueId


--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		AS Color		-- 0=Unknown, 1 = BW, 2=Color
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,SUM(t.logjobSize)								AS Size
		,SUM(t.logpages)									AS Pages
		,Count(*)										AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
--	WHERE t.logEventMajor = 2 
--		AND t.logEventMinor IN (1, 6, 10)
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages = 0 
		AND t.logLoggedColorPages = 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId	
--		,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper									

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100103
			GOTO PROC_ERROR
		END


	-- B/W ONLY jobs with SNMP
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	
		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId
--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,0												AS Color		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,SUM(t.logjobSize)								AS Size
		,SUM(t.logLoggedBWPages)						AS Pages
		,Count(*)										AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages <> 0 
		AND t.logLoggedColorPages = 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId								
		--,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper		

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100104
			GOTO PROC_ERROR
		END

	-- Color ONLY jobs with SNMP
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	
		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId
--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,1												AS Color		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,SUM(t.logjobSize)								AS Size
		,SUM(t.logLoggedColorPages)						AS Pages
		,Count(*)										AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages = 0 
		AND t.logLoggedColorPages <> 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId								
		--,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper		

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100105
			GOTO PROC_ERROR
		END


	-- Mixed jobs with SNMP / BW side. Mixed jobs get JobCount and JobSize added to this row
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	
		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId
--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,0												AS Color		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,SUM(t.logjobSize)								AS Size
		,SUM(t.logLoggedBWPages)						AS Pages
		,Count(*)										AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages <> 0 
		AND t.logLoggedColorPages <> 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId								
		--,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper		

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100106
			GOTO PROC_ERROR
		END

	-- Mixed jobs with SNMP / Color side
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	
		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId
--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter	
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,1												AS Color		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,0												AS Size
		,SUM(t.logLoggedColorPages)						AS Pages
		,0												AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages <> 0 
		AND t.logLoggedColorPages <> 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId								
		--,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper		

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100107
		GOTO PROC_ERROR
	END

	-- Mark local printers
	-- (Jobs from local printers have their printerId as queueId)
	----------------------------------------------------------------------
	UPDATE @jobs SET IsLocalPrinter = 1
	WHERE QueueId IN (SELECT printerId FROM tbl_printer WHERE printerType = 1)

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100108
		GOTO PROC_ERROR
	END

	-- Assign queueid when current value is printerId
	----------------------------------------------------------------------

	UPDATE j
		SET QueueId = (SELECT CAST(MIN(mapQueue) as uniqueidentifier) FROM tbl_queue_printer_map m WHERE mapPhyPrinter = CAST(QueueId as varchar(64)))
	FROM @jobs j
	INNER JOIN tbl_queue_printer_map m
		ON m.mapPhyPrinter = CAST(QueueId as varchar(64))

	-- Sum up and insert into statistics table
	----------------------------------------------------------------------


	INSERT tbl_report_jobs_queue
		(JobDay
		,QueueId
--		,PrinterId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,Color
		,Duplex
		,PaperType
		,Size
		,Pages
		,JobCount
		,TicketPrice)
	SELECT 
		JobDay
		,QueueId
--		,PrinterId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,Color
		,Duplex
		,PaperType
		,SUM(Size)
		,SUM(Pages)
		,SUM(JobCount)
		,SUM(TicketPrice)
	FROM @jobs
	GROUP BY
		JobDay
		,QueueId
--		,PrinterId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,Color
		,Duplex
		,PaperType

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100109
		GOTO PROC_ERROR
	END

	EXEC @ReturnStatus = sp_property_upd @ipropertyName = 'JobsQueueCutOff', @ipropertyValueDate = @EndDate


	RETURN (@ReturnStatus)


PROC_ERROR:

RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_report_region_get_descendants') IS NOT NULL
	DROP PROCEDURE sp_report_region_get_descendants
GO

CREATE PROCEDURE sp_report_region_get_descendants
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-22
Description:	Get all descendants of a REPORT region (NOT THE SAME AS REGULAR CIRRATO REGIONS / LOCAL REGIONS).
				Result also includes given parent region.
				NULL = list every region
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRegionId			bigint		= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- do stuff

	DECLARE @Regions TABLE (RegionId bigint);

	IF @iRegionId IS NOT NULL
	BEGIN
		 WITH Regions (RegionId, ParentRegionId) AS
			 (SELECT RegionId, ParentRegionId FROM tbl_report_region_cache WHERE RegionId = @iRegionId
			 UNION ALL
			SELECT rc.RegionId, rc.ParentRegionId 
			FROM tbl_report_region_cache rc
			INNER JOIN Regions r
				ON rc.ParentRegionId = r.RegionId)
		INSERT @Regions (RegionId)
		SELECT RegionId FROM Regions;
	END
	ELSE
	BEGIN
		INSERT @Regions (RegionId)
		SELECT RegionId FROM tbl_report_region_cache	
	END

	SELECT * FROM @Regions



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_batch_do') IS NOT NULL
	DROP PROCEDURE sp_report_batch_do
GO

CREATE PROCEDURE sp_report_batch_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Run all parts of the nightly batch. To be called from SQL Server Agent.
			 Do not run more often than once a day.
************************************************************/
AS
BEGIN

	DECLARE @ReturnStatus	INT
		,@ErrorNo			INT

	SET @ReturnStatus = 0
	SET @ErrorNo = 0


	-- Region depth cache refresh
	-----------------------------------------------------------------
	EXEC @ReturnStatus = sp_report_queue_regiondepth_cache_refresh

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR

	-- Other cache refresh
	-----------------------------------------------------------------
	EXEC @ReturnStatus = sp_report_cache_refresh

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	-- Job aggregate calculation
	-----------------------------------------------------------------
	EXEC @ReturnStatus = sp_report_jobs_queue_calc_do

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	-- Job detail calculation
	-----------------------------------------------------------------
	EXEC @ReturnStatus = sp_report_jobs_detail_calc_do

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	RETURN(0)

PROC_ERROR:

	IF @ErrorNo = 0
		SET @ErrorNo = @ReturnStatus

	RAISERROR(@ErrorNo, 16, 1)

	RETURN(@ErrorNo)

END
GO

IF OBJECT_ID('sp_report_billingcode_tree_get') IS NOT NULL
	DROP PROCEDURE sp_report_billingcode_tree_get
GO

CREATE PROCEDURE sp_report_billingcode_tree_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-17
Description: Billing codes in date range. Aggregated by Billing Code, including regions for treeview display.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-27
Description: Updated and re-written to conform to new report input parameter standard.
************************************************************/
	 @iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL

	,@iIncludeLocal		bit				= NULL
	,@iIncludeNetwork	bit				= NULL

	,@iIncludeSimplex	bit				= NULL
	,@iIncludeDuplex	bit				= NULL
--	,@iIncludeBW		bit				= NULL
--	,@iIncludeColor		bit				= NULL

	,@iIncludePrint		bit				= NULL
	,@iIncludeCopy		bit				= NULL
	,@iIncludeScan		bit				= NULL
	,@iIncludeFax		bit				= NULL

	,@iPaperType		smallint		= NULL

	,@iUserName			nvarchar(510)	= NULL
	,@iDomain			nvarchar(510)	= NULL
	,@iRegionId			bigint			= NULL -- mappa mot tbl_report_region_cache
	--,@iBillingCodeId	bigint			= NULL
	,@iLanguageId		char(2)			= NULL
AS
BEGIN


	-- Default values don't work when calling from SSRS, so we have to do it here:
	----------------------------------------------------------------------------------------
	SET @iStartDate			= ISNULL(@iStartDate, '20000101')
	SET @iEndDate			= ISNULL(@iEndDate, '99991231')

	SET @iIncludeLocal		= ISNULL(@iIncludeLocal, 1)
	SET @iIncludeNetwork	= ISNULL(@iIncludeNetwork, 1)

	SET @iIncludeSimplex	= ISNULL(@iIncludeSimplex, 1)
	SET @iIncludeDuplex		= ISNULL(@iIncludeDuplex, 1)
--	SET @iIncludeBW			= ISNULL(@iIncludeBW, 1)
--	SET @iIncludeColor		= ISNULL(@iIncludeColor, 1)

	SET @iIncludePrint		= ISNULL(@iIncludePrint, 1)
	SET @iIncludeCopy		= ISNULL(@iIncludeCopy, 1)
	SET @iIncludeScan		= ISNULL(@iIncludeScan, 1)
	SET @iIncludeFax		= ISNULL(@iIncludeFax, 1)

	SET @iLanguageId		= ISNULL(@iLanguageId,'en')


	-- Get requested subregions:
	----------------------------------------------------------------------------------------
	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	DECLARE @Regions TABLE (RegionId bigint);
	INSERT @Regions (RegionId)
	EXEC @ReturnStatus = sp_report_region_get_descendants	@iRegionId = @iRegionId
	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR;


	-- Actual data retrieval:
	----------------------------------------------------------------------------------------
/*
-- Denna tar f�r l�ng tid. Skrivit om med tabellvariabel nedan.
	WITH BillingCodePages (BillingCodeId, PagesBW, PagesColor) AS
		(SELECT
			BillingCodeId
			,SUM(PagesBW)
			,SUM(PagesColor)
		FROM tbl_report_jobs_detail j
		WHERE JobDate BETWEEN @iStartDate AND @iEndDate
		AND ((j.Duplex = 1 AND @iIncludeDuplex = 1)
				OR (j.Duplex =0 AND @iIncludeSimplex = 1))
--		AND ((j.Color = 1 AND @iIncludeColor = 1)
--				OR (j.Color =0 AND @iIncludeBW = 1))
		AND ((j.IsLocalPrinter = 1 AND @iIncludeLocal = 1)
				OR (j.IsLocalPrinter =0 AND @iIncludeNetwork = 1))
		AND ((j.JobType = 1 AND @iIncludePrint = 1)
			OR (j.JobType = 2 AND @iIncludeCopy = 1)
			OR (j.JobType = 3 AND @iIncludeFax = 1)
			OR (j.JobType = 4 AND @iIncludeScan = 1))

		AND ISNULL(@iPaperType,PaperType) = PaperType

		GROUP BY BillingCodeId)
	SELECT
		cb.BillingCodeId
		,cb.ParentId
		,cb.BillingCode
		,cb.BillingCodeName
		,cbPages.PagesBW
		,cbPages.PagesColor
		,Type
	FROM vw_client_billing cb
	LEFT JOIN BillingCodePages cbPages
		ON cb.BillingCodeId = cbPages.BillingCodeId
	WHERE -- Do not include deleted _billing codes_  unless they have pages registered with them:
		(cb.Type IN (0,1, 10)) OR (cbPages.PagesBW IS NOT NULL OR cbPages.PagesColor IS NOT NULL)

*/



	DECLARE @CBPages TABLE (BillingCodeId bigint, PagesBW int, PagesColor int)

	INSERT @CBPages
	SELECT
		BillingCodeId
		,SUM(PagesBW)
		,SUM(PagesColor)
	FROM tbl_report_jobs_detail j
	WHERE JobDate BETWEEN @iStartDate AND @iEndDate
	AND ((j.Duplex = 1 AND @iIncludeDuplex = 1)
			OR (j.Duplex =0 AND @iIncludeSimplex = 1))
	AND ((j.IsLocalPrinter = 1 AND @iIncludeLocal = 1)
			OR (j.IsLocalPrinter =0 AND @iIncludeNetwork = 1))
	AND ((j.JobType = 1 AND @iIncludePrint = 1)
		OR (j.JobType = 2 AND @iIncludeCopy = 1)
		OR (j.JobType = 3 AND @iIncludeFax = 1)
		OR (j.JobType = 4 AND @iIncludeScan = 1))
	AND ISNULL(@iPaperType,PaperType) = PaperType
	GROUP BY BillingCodeId


	SELECT
		cb.BillingCodeId
		,cb.ParentId
		,cb.BillingCode
		,cb.BillingCodeNameVerbose BillingCodeName
		,cbPages.PagesBW
		,cbPages.PagesColor
		,CASE WHEN Type IN (0,10) THEN 'Normal' ELSE 'Region' END AS ObjectType
		,CASE WHEN cb.BillingCodeId < 0 THEN 100 ELSE 200 END AS SortOrder
	FROM vw_client_billing cb
	LEFT JOIN @CBPages cbPages
		ON cb.BillingCodeId = cbPages.BillingCodeId
	WHERE -- Do not include deleted _billing codes_  unless they have pages registered with them:
		(cb.Type IN (0,1, 10)) OR (cbPages.PagesBW IS NOT NULL OR cbPages.PagesColor IS NOT NULL)
	ORDER BY cb.BillingCodeName

-- sp_report_billingcode_tree_get

-- 14 Projekt Edvard tas bort: har ej sidor, ska ej med.
-- 15 Projekt Adam tas bort: har dock sidor, s� ska med.




	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)


END
GO

IF OBJECT_ID('sp_report_cache_refresh') IS NOT NULL
	DROP PROCEDURE sp_report_cache_refresh
GO

CREATE PROCEDURE sp_report_cache_refresh
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Refresh caches:
				* Queues
				* Printers
				* Printer / Queue mappings (??)
				* Regions
				* Models
				* Brands
				* Status cache
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-06-01
Description: Added PrinterCount to model and brand tables.
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-10
Description: Delete instead of truncate.
************************************************************/

AS
BEGIN


	-- Queue
	-------------------------------------------------------------
	DELETE tbl_report_queue_cache
	INSERT  tbl_report_queue_cache
		(QueueId
		,QueueName
		,QueueType
		,PrinterId
		,ParentRegionId)
	SELECT
		CAST(q.queueId AS uniqueidentifier)
		,q.queueName
		,q.queueType
		,CAST(m.mapPhyPrinter AS uniqueidentifier)
		,q.queueRegion
--		,r.regionParentId
	FROM tbl_queue q
--	INNER JOIN tbl_region r
--		on r.regionId = q.queueRegion
	LEFT JOIN tbl_queue_printer_map m
		ON m.mapQueue = q.queueId
	WHERE LEN(q.queueId) = 36
		AND LEN(m.mapPhyPrinter) = 36
	UNION
	SELECT
		CAST(p.printerId AS uniqueidentifier)
		,p.printerName
		,NULL										AS QueueType
		,CAST(p.printerId AS uniqueidentifier)		AS PrinterId
		,p.region + 1000000
--		,r.lregionParentId + 1000000
	FROM tbl_printer p 
--	INNER JOIN tbl_lregion r
--		on r.lregionId = p.region
	WHERE printerType = 1
	AND LEN(p.printerId) = 36

	-- Printer
	-------------------------------------------------------------
	DELETE tbl_report_printer_cache
	INSERT tbl_report_printer_cache
		(PrinterId
		,PrinterName
		,PrinterType
		,PrinterComment
		,ModelId
		,Hidden
		,ParentRegionId)
	SELECT
		p.printerId
		,p.printerName
		,p.printerType
		,p.printerComment
		,p.printerModel
		,p.printerHidden
		,CASE WHEN p.printerType = 1 THEN p.region + 1000000 ELSE p.region END AS ParentRegionId
	FROM tbl_printer p
	WHERE LEN (p.printerId) = 36
	AND LEN (p.printerModel) = 36


	-- Status cache
	-------------------------------------------------------------
	DELETE tbl_report_status_cache
	DECLARE @i int, @j int
	DECLARE @Verbose nvarchar(510)
	SET @i = 0


	WHILE @i < 100
	BEGIN


		-- verbosePrinterPhysicalStatus = 1 --
		SET @Verbose = dbo.verbosePrinterPhysicalStatus(@i, 1)
		IF ISNULL(@Verbose,cast(@i as varchar(510))) <> cast(@i as varchar(510))
		INSERT tbl_report_status_cache (StatusTypeId, StatusMajor, StatusMinor, StatusVerbose) VALUES (1,@i,NULL, @Verbose)
	



		SET @j = 0
		WHILE @j < 100
		BEGIN
			-- loop for statii with 2 levels

		SET @j = @j + 1
		END


	SET @i = @i + 1
	END

	


	-- Model
	-------------------------------------------------------------
	DELETE tbl_report_model_cache
	INSERT tbl_report_model_cache
		(ModelId
		,BrandId
		,ModelName)
	SELECT
		CAST(modelId as uniqueidentifier)
		,CAST(modelBrandId as uniqueidentifier)
		,modelName
	FROM tbl_model
	WHERE LEN(modelId) = 36
		AND LEN(modelBrandId) = 36


	UPDATE m
		SET m.PrinterCount = (SELECT COUNT(1) FROM tbl_report_printer_cache p WHERE p.ModelId = m.ModelId)
	FROM tbl_report_model_cache m


	-- Brand
	-------------------------------------------------------------
	DELETE tbl_report_brand_cache
	INSERT tbl_report_brand_cache
		(BrandId
		,BrandName)
	SELECT
		CAST(brandId as uniqueidentifier)
		,brandName
	FROM tbl_brand
	WHERE LEN(brandId) = 36

	UPDATE b
		SET b.PrinterCount = 
			(SELECT COUNT(1) FROM tbl_report_printer_cache p 
			INNER JOIN tbl_report_model_cache m
				ON p.ModelId = m.ModelId
			WHERE m.BrandId = b.BrandId)
	FROM tbl_report_brand_cache b

	-- Region
	-------------------------------------------------------------
	DELETE tbl_report_region_cache
	INSERT tbl_report_region_cache
		(RegionId
		,ParentRegionId
		,RegionName
		,RegionGUID)
	SELECT
		regionId
		,regionParentId
		,regionName
		,NEWID()
	FROM tbl_region WHERE regionActive = 1
	UNION
	SELECT
		lregionId + 1000000
		,lregionParentId + 1000000
		,lregionName
		,NEWID()
	FROM tbl_lregion WHERE lregionActive = 1

	RETURN (0)





END
GO


IF OBJECT_ID('sp_report_duplex_color_share') IS NOT NULL
	DROP PROCEDURE sp_report_duplex_color_share
GO

CREATE PROCEDURE sp_report_duplex_color_share
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-23
Description:  Get duplex/color given input params
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	 @iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL

	,@iIncludeLocal		bit				= NULL
	,@iIncludeNetwork	bit				= NULL

	,@iIncludeSimplex	bit				= NULL
	,@iIncludeDuplex	bit				= NULL
	,@iIncludeBW		bit				= NULL
	,@iIncludeColor		bit				= NULL

	,@iIncludePrint		bit				= NULL
	,@iIncludeCopy		bit				= NULL
	,@iIncludeScan		bit				= NULL
	,@iIncludeFax		bit				= NULL

	,@iPaperType		smallint		= NULL

	,@iRegionId			bigint			= NULL -- mappa mot tbl_report_region_cache
	,@iBillingCodeId	bigint			= NULL
	,@iLanguageId		char(2)			= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Default values don't work when calling from SSRS, so we have to do it here:
	----------------------------------------------------------------------------------------
	SET @iStartDate			= ISNULL(@iStartDate, '20000101')
	SET @iEndDate			= ISNULL(@iEndDate, '99991231')

	SET @iIncludeLocal		= ISNULL(@iIncludeLocal, 1)
	SET @iIncludeNetwork	= ISNULL(@iIncludeNetwork, 1)

	SET @iIncludeSimplex	= ISNULL(@iIncludeSimplex, 1)
	SET @iIncludeDuplex		= ISNULL(@iIncludeDuplex, 1)
	SET @iIncludeBW			= ISNULL(@iIncludeBW, 1)
	SET @iIncludeColor		= ISNULL(@iIncludeColor, 1)

	SET @iIncludePrint		= ISNULL(@iIncludePrint, 1)
	SET @iIncludeCopy		= ISNULL(@iIncludeCopy, 1)
	SET @iIncludeScan		= ISNULL(@iIncludeScan, 1)
	SET @iIncludeFax		= ISNULL(@iIncludeFax, 1)
	SET @iLanguageId		= ISNULL(@iLanguageId,'en')


	-- Get requested subregions:
	----------------------------------------------------------------------------------------
	DECLARE @Regions TABLE (RegionId bigint);
	INSERT @Regions (RegionId)
	EXEC @ReturnStatus = sp_report_region_get_descendants	@iRegionId = @iRegionId
	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	-- Actual data retrieval:
	----------------------------------------------------------------------------------------



	SELECT
		CASE WHEN Color = 1 THEN dbo.fn_translate('Colour', @iLanguageId) ELSE dbo.fn_translate('B/W', @iLanguageId) END AS Color
		,CASE WHEN Duplex = 1 THEN dbo.fn_translate('Duplex', @iLanguageId) ELSE dbo.fn_translate('Simplex', @iLanguageId) END AS Duplex
		,SUM(Pages) PagesTotal
	FROM tbl_report_jobs_queue j
	INNER JOIN tbl_report_queue_cache q
		ON j.QueueId = q.QueueId
	INNER JOIN @Regions r
		ON q.ParentRegionId = r.RegionId
	WHERE j.JobDay BETWEEN @iStartDate AND @iEndDate
	AND ((j.Duplex = 1 AND @iIncludeDuplex = 1)
			OR (j.Duplex =0 AND @iIncludeSimplex = 1))
	AND ((j.Color = 1 AND @iIncludeColor = 1)
			OR (j.Color =0 AND @iIncludeBW = 1))
	AND ((j.IsLocalPrinter = 1 AND @iIncludeLocal = 1)
			OR (j.IsLocalPrinter =0 AND @iIncludeNetwork = 1))
	AND ((j.JobType = 1 AND @iIncludePrint = 1)
		OR (j.JobType = 2 AND @iIncludeCopy = 1)
		OR (j.JobType = 3 AND @iIncludeFax = 1)
		OR (j.JobType = 4 AND @iIncludeScan = 1))
	AND ISNULL(@iPaperType,j.PaperType) = j.PaperType
	GROUP BY j.Color, j.Duplex


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_jobs_aggregate_user_get') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_aggregate_user_get
GO

CREATE PROCEDURE sp_report_jobs_aggregate_user_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-26
Description: Total jobs per queue, user within date rage
************************************************************/
	@iUserName		nvarchar(510)	= NULL
	,@iDomain		nvarchar(510)	= NULL
	,@iStartDate	datetime		= NULL
	,@iEndDate		datetime		= NULL

AS
BEGIN



	WITH c (UserId, QueueId, TotalSize, PagesBW, PagesColor, PagesTotal) AS (
		SELECT
			t.UserId
			,t.QueueId
			,SUM(t.Size)
			,SUM(t.PagesBW)
			,SUM(t.PagesColor)
			,SUM(t.PagesBW) + SUM(t.PagesColor) AS PagesTotal
		FROM tbl_report_jobs_detail t
		INNER JOIN tbl_report_users u
			ON u.UserId = t.UserId
		WHERE ISNULL(@iUserName,u.UserName) = UserName
			AND ISNULL(@iDomain,u.Domain) = Domain
			AND t.JobDate BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')
		GROUP BY
 			t.UserId
			,t.QueueId)
	SELECT 
			c.QueueId
			,c.TotalSize
			,c.PagesBW
			,c.PagesColor
			,c.PagesTotal
			,u.UserName
			,u.Domain
			,q.QueueName
			,p.PrinterName
			,p.PrinterId
		FROM c
		INNER JOIN tbl_report_users u
			ON c.UserId = u.UserId
		INNER JOIN tbl_report_queue_cache q
			ON c.QueueId = q.QueueId
		INNER JOIN tbl_report_printer_cache p
				ON p.PrinterId = q.PrinterId



--	SELECT 
--		* 
--	FROM vw_report_jobs_aggregate_user 
--	WHERE ISNULL(@iUserName,UserName) = UserName
--		AND ISNULL(@iDomain,Domain) = Domain
--		AND JobDate BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')

-- v1, l�ngsam:
--
--	SELECT 
--		QueueId
--		,QueueName
--		,PrinterId
--		,PrinterName
--		,UserName
--		,Domain
--		,SUM(PagesBW) PagesBW
--		,SUM(PagesColor) PagesColor
--		,SUM(PagesTotal) PagesTotal
--	FROM vw_report_jobs_detail t
--	WHERE ISNULL(@iUserName,UserName) = UserName
--		AND ISNULL(@iDomain,Domain) = Domain
--		AND JobDate BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')
--	GROUP BY 		
--		QueueId
--		,QueueName
--		,PrinterId
--		,PrinterName
--		,UserName
--		,Domain
--	ORDER BY QueueName, Domain, UserName
--
--	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END
GO

IF OBJECT_ID('sp_report_jobs_detail_billingcode_get') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_detail_billingcode_get
GO

CREATE PROCEDURE sp_report_jobs_detail_billingcode_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-17
Description: Billing codes in range
************************************************************/
	@iUserName		nvarchar(510)	= NULL
	,@iDomain		nvarchar(510)	= NULL
	,@iStartDate	datetime		= NULL
	,@iEndDate		datetime		= NULL

AS
BEGIN


	SELECT 
		t.QueueId
		,t.QueueName
		,t.PrinterName
		,t.PrinterId
		,t.BillingCodeId
		,cb.cb_code BillingCode
		,cb.cb_name	BillingCodeName
		,SUM(t.PagesBW) PagesBW
		,SUM(t.PagesColor) PagesColor
	FROM vw_report_jobs_detail t
	LEFT JOIN tbl_client_billing cb
		ON cb.cb_id = t.BillingCodeId
	WHERE ISNULL(@iUserName,UserName) = UserName
		AND ISNULL(@iDomain,Domain) = Domain
		AND JobDate BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')
	GROUP BY 
		t.QueueId
		,t.QueueName
		,t.PrinterName
		,t.PrinterId
		,t.BillingCodeId
		,cb.cb_code
		,cb.cb_name


	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END
GO

IF OBJECT_ID('sp_report_jobs_detail_calc_do') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_detail_calc_do
GO

CREATE PROCEDURE sp_report_jobs_detail_calc_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Calculate detailed job stats since last run
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-17
Description: Added billing code field
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-19
Description: Added copy jobs
(see comments of sp report_jobs_queue_calc_do for table of combinations)
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-07-06
Description: Adaption for DeleteAfterPrint = false option
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-10
Description: Delete instead of truncate.
************************************************************/
	@iReset bit = 0					-- 1 = delete all data and recalculate from scratch
AS
BEGIN

	DECLARE @ReturnStatus	INT
		,@ErrorNo			INT
		,@StartDate			datetime
		,@EndDate			datetime
		,@CurrentTimestamp  datetime

	SET @ReturnStatus = 0
	SET @ErrorNo = 0
	SET @EndDate = convert(char(8), getdate(), 112) -- end date is last midnight
	SET @CurrentTimestamp = getdate()

	SET @StartDate = dbo.fn_property_get_date('JobsDetailCutOff')
	IF @StartDate IS NULL
		RETURN (100111)

	IF @iReset = 1
	BEGIN
		SET @StartDate = '20000101'
		BEGIN TRY
			TRUNCATE TABLE tbl_report_jobs_detail
		END TRY
		BEGIN CATCH
			DELETE tbl_report_jobs_detail
		END CATCH
		--DELETE tbl_report_users
	END

	IF @EndDate <= @StartDate
		RETURN (100112)

--	Debug
--	SET @StartDate = '20080915'
--	SET @EndDate = '20080916'


	-- Update users table with any new users since last run
	----------------------------------------------------------------------

	INSERT tbl_report_users
		(UserName
		,Domain
		,RegDate)
	SELECT DISTINCT
		ISNULL(loguserName,'NoUser')
		,ISNULL(loguserDomain,'NoDomain')
		,@CurrentTimestamp
	FROM tbl_ticket_log t
	LEFT OUTER JOIN tbl_report_users u
		ON u.UserName = t.loguserName
		AND u.Domain = t.loguserDomain
	WHERE t.logEventMajor = 2 
		AND t.logEventMinor IN (1, 6, 10)
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND u.UserName IS NULL
		AND u.Domain IS NULL


	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100113
		GOTO PROC_ERROR
	END


	-- Make sure only tickets with ONE final status flag is included (otherwise, tbl_report_jobs_detail PK will be violated)
	----------------------------------------------------------------------
	DECLARE @Tickets TABLE (TicketId varchar(64) COLLATE DATABASE_DEFAULT)

	INSERT @Tickets(TicketId)
	SELECT 
		t.logticketId
	FROM tbl_ticket_log t
	WHERE
		( ( t.logEventMajor = 2 AND t.logEventMinor = 1 AND LEN(t.logPrinterId) = 36 AND LEN(t.logQueueId) = 36 ) -- print
		OR (t.logEventMajor = 2 AND t.logEventMinor = 6 AND LEN(t.logQueueId) = 36) -- print ext
		OR (t.logEventMajor = 4 AND t.logEventMinor = 10 AND LEN(t.logPrinterId) = 36) ) -- copy
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND (LEN(t.logfprintQ) = 36 OR LEN(t.logfprintQ) = 0)
	GROUP BY t.logticketId
	HAVING COUNT(*) = 1



	-- Client Billing
	----------------------------------------------------------------------
	DECLARE @cb TABLE (BillingCodeId bigint, BillingCode nvarchar(128))

	INSERT @cb
	SELECT
		MAX(cb_id)
		,cb_code
	FROM tbl_client_billing
	GROUP BY cb_code

	--

	-- Printer / queue cache. "Primary" queue per printer. For now, only determined by MIN function.
	----------------------------------------------------------------------
	DECLARE @pq TABLE (PrinterId varchar(64), QueueId uniqueidentifier)
	INSERT @pq
	SELECT
		mapPhyPrinter
		,CAST(MIN(mapQueue) as uniqueidentifier)
	FROM tbl_queue_printer_map GROUP BY mapPhyPrinter

	-- local printers:
	INSERT @pq 
	SELECT DISTINCT 
		printerId
		,cast(printerId as uniqueidentifier)
	FROM tbl_printer
	WHERE printerId NOT IN (SELECT PrinterId FROM @pq)


	-- Transfer relevant data from ticket log to report job detail table
	----------------------------------------------------------------------

	-- 1. Jobs that have queue id
	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --
	INSERT tbl_report_jobs_detail
		(TicketId
		,JobDate
		,JobName
		,UserId
		,QueueId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,PaperType
		,Duplex
		,Size
		,PagesBW
		,PagesColor
		,TicketPrice
		,BillingCodeId
		,DnId)
	SELECT
		CAST(t.logTicketId AS uniqueidentifier)			AS TicketId
		,MIN(t.logdateEvent)									AS JobDate
		,MIN(t.logjobName)									AS JobName
		,MIN(u.UserId)										AS UserId
		,CASE WHEN LEN(MIN(logqueueId)) = 36 THEN MIN(logqueueId) ELSE 
			-- queue lookup using printerId:
			(SELECT CAST(MIN(mapQueue) as uniqueidentifier) FROM tbl_queue_printer_map m WHERE mapPhyPrinter = CAST(MIN(logPrinterId) as varchar(64)))
		END												AS QueueId
--		,CAST(t.logQueueId AS uniqueidentifier)			AS QueueId

		,CASE WHEN LEN(MAX(t.logfprintQ)) = 36 
			THEN CAST(MAX(t.logfprintQ) AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
--		,CAST(t.logfprintQ AS uniqueidentifier)			AS FollowPrintQueueId
		,0												AS IsLocalPrinter
		,CASE	WHEN MIN(t.logEventMinor) IN (1, 6) THEN 1
				WHEN MIN(t.logEventMinor) = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN MIN(t.logfprintQ) = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,MIN(t.logpaper)										AS PaperType
		,CASE WHEN MIN(t.logduplex) > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,MIN(t.logjobSize)									AS Size

		,CASE WHEN SUM(t.logLoggedBWPages) = 0 AND SUM(t.logLoggedColorPages) = 0
			THEN
				CASE WHEN MIN(t.logcolor) = 2 THEN 0 ELSE SUM(t.logpages) END -- logcolor: 0=Unknown, 1 = BW, 2=Color
			ELSE 
				SUM(t.logLoggedBWPages)
			END											AS PagesBW

		,CASE WHEN SUM(t.logLoggedBWPages) = 0 AND SUM(t.logLoggedColorPages) = 0
			THEN
				CASE WHEN MIN(t.logcolor) <> 2 THEN 0 ELSE SUM(t.logpages) END -- logcolor: 0=Unknown, 1 = BW, 2=Color
			ELSE 
				SUM(t.logLoggedColorPages)
			END											AS PagesColor
		,SUM(t.logTicketPrice)								AS TicketPrice
		,CASE WHEN LEN(MIN(cb.BillingCode)) = 0 OR MIN(cb.BillingCode) IS NULL THEN -1 ELSE MIN(cb.BillingCodeId) END AS BillingCodeId
		,MAX(t.DnId)
	FROM tbl_ticket_log t
	INNER JOIN tbl_report_users u
		ON u.UserName = t.loguserName
		AND u.Domain = t.loguserDomain
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	LEFT JOIN @cb cb
		ON cb.BillingCode = t.logclientBillingCode
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND LEN(t.logTicketId) = 36
		AND LEN(t.logQueueId) = 36
		--AND LEN(t.logfprintQ) = 36 
	GROUP BY t.logTicketId

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100114
		GOTO PROC_ERROR
	END



	-- 2. Jobs without queue id
	--  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --
	INSERT tbl_report_jobs_detail
		(TicketId
		,JobDate
		,JobName
		,UserId
		,QueueId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,PaperType
		,Duplex
		,Size
		,PagesBW
		,PagesColor
		,TicketPrice
		,BillingCodeId
		,DnId)
	SELECT
		CAST(t.logTicketId AS uniqueidentifier)			AS TicketId
		,t.logdateEvent									AS JobDate
		,t.logjobName									AS JobName
		,u.UserId										AS UserId
		,pq.QueueId										AS QueueId
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0												AS IsLocalPrinter
		,CASE	WHEN t.logEventMinor IN (1, 6) THEN 1
				WHEN t.logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,t.logpaper										AS PaperType
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logjobSize									AS Size

		,CASE WHEN t.logLoggedBWPages = 0 AND t.logLoggedColorPages = 0
			THEN
				CASE WHEN t.logcolor = 2 THEN 0 ELSE t.logpages END -- logcolor: 0=Unknown, 1 = BW, 2=Color
			ELSE 
				t.logLoggedBWPages
			END											AS PagesBW

		,CASE WHEN t.logLoggedBWPages = 0 AND t.logLoggedColorPages = 0
			THEN
				CASE WHEN t.logcolor <> 2 THEN 0 ELSE t.logpages END -- logcolor: 0=Unknown, 1 = BW, 2=Color
			ELSE 
				t.logLoggedColorPages
			END											AS PagesColor
		,t.logTicketPrice								AS TicketPrice
		,CASE WHEN LEN(cb.BillingCode) = 0 OR cb.BillingCode IS NULL THEN -1 ELSE cb.BillingCodeId END AS BillingCodeId
		,t.DnId
	FROM tbl_ticket_log t
	INNER JOIN tbl_report_users u
		ON u.UserName = t.loguserName
		AND u.Domain = t.loguserDomain
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	INNER JOIN @pq pq
		ON pq.PrinterId = t.logPrinterId
	LEFT JOIN @cb cb
		ON cb.BillingCode = t.logclientBillingCode
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND LEN(t.logTicketId) = 36
		AND LEN(t.logQueueId) = 0
		--AND LEN(t.logfprintQ) = 36 

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100114
		GOTO PROC_ERROR
	END



	-- Save date range for next run
	----------------------------------------------------------------------

	EXEC @ReturnStatus = sp_property_upd @ipropertyName = 'JobsDetailCutOff', @ipropertyValueDate = @EndDate


	RETURN (@ReturnStatus)


	PROC_ERROR:

	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_report_jobs_detail_get') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_detail_get
GO

CREATE PROCEDURE sp_report_jobs_detail_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-14
Description: Get jobs for any or all users within date range
************************************************************/
	@iUserName		nvarchar(510)	= NULL
	,@iDomain		nvarchar(510)	= NULL
	,@iStartDate	datetime		= NULL
	,@iEndDate		datetime		= NULL

AS
BEGIN


	SELECT 
	*
	FROM vw_report_jobs_detail t
	WHERE ISNULL(@iUserName,UserName) = UserName
		AND ISNULL(@iDomain,Domain) = Domain
		AND JobDate BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')
	ORDER BY JobDate

	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END
GO

IF OBJECT_ID('sp_report_jobs_get_sub') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_get_sub
GO

CREATE PROCEDURE sp_report_jobs_get_sub
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-06
Description: Fetch report data, given a date range and queues
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 

************************************************************/
	@iStartDate				datetime
	,@iEndDate				datetime
AS
BEGIN


SELECT
	r.JobDay
	,r.QueueId
	,r.PrinterId
	,r.FollowPrintQueueId
	,r.JobType
	,r.IsFollowPrint
	,r.Color
	,r.Duplex
	,r.PaperType
	,r.Size
	,r.Pages
	,r.JobCount
	,p2.printerName				AS PrinterName
	,p2.printerLocation			AS PrinterLocation
	,p2.printerComment			AS PrinterComment
	,p2.printerModel			AS PrinterModel
FROM tbl_report_jobs r
INNER JOIN #printer p1
	ON r.PrinterId = p1.PrinterId
INNER JOIN tbl_printer p2
	ON r.PrinterId = p2.PrinterId
WHERE r.JobDay BETWEEN @iStartDate AND @iEndDate




	RETURN (0)

END
GO

IF OBJECT_ID('sp_report_jobs_queue_calc_do') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_queue_calc_do
GO

CREATE PROCEDURE sp_report_jobs_queue_calc_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-06
Description: Calculate aggregate job stats since last run
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-05-17
Description: Do not include jobs with more than one final status flag
------------------------------------------------------------
Modified by:  Henrik Linder
Modification date: 2009-06-18
Description: Do not exclude jobs with empty logfprintQ 
			AND fix for copy jobs (previously not included)

-- print job: eventmajor = 2, eventminor = 1. b�de printerid och queueid �r satt.
-- print job external: eventmajor = 2, eventminor = 6. Dessa har ej printerId satt, men queueid. (Detta �r jobb som utf�rdes n�r server var nere, klient skickade upp i efterhand)
-- copy job: eventmajor  = 4, eventminor = 10. dessa har printerId, men ej queueid.
-- scan job:
-- fax job: 
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-10
Description: Delete instead of truncate.
************************************************************/
	@iReset bit = 0					-- 1 = delete all data and recalculate from scratch
AS
BEGIN

	DECLARE @ReturnStatus	INT
		,@ErrorNo			INT
		,@StartDate			datetime
		,@EndDate			datetime

	SET @ReturnStatus = 0
	SET @ErrorNo = 0
	SET @EndDate = convert(char(8), getdate(), 112) -- end date is last midnight


	SET @StartDate = dbo.fn_property_get_date('JobsQueueCutOff')
	IF @StartDate IS NULL
		RETURN (100102)

	IF @iReset = 1
	BEGIN
		SET @StartDate = '20000101'
		BEGIN TRY
			TRUNCATE TABLE tbl_report_jobs_queue
		END TRY
		BEGIN CATCH
			DELETE tbl_report_jobs_queue
		END CATCH

	END

	IF @EndDate <= @StartDate
		RETURN (100110)

--	Debug
--	SET @StartDate = '20080915'
--	SET @EndDate = '20080916'

	-- Make sure only tickets with ONE final status flag is included (otherwise, tbl_report_jobs_detail PK will be violated)
	DECLARE @Tickets TABLE (TicketId varchar(64) COLLATE DATABASE_DEFAULT)

	INSERT @Tickets(TicketId)
	SELECT 
		t.logticketId
	FROM vw_ticket_log_report_calc t
	WHERE
		( ( t.logEventMajor = 2 AND t.logEventMinor = 1 AND LEN(t.logPrinterId) = 36 AND LEN(t.logQueueId) = 36 ) -- print
		OR (t.logEventMajor = 2 AND t.logEventMinor = 6 AND LEN(t.logQueueId) = 36) -- print ext
		OR (t.logEventMajor = 4 AND t.logEventMinor = 10 AND LEN(t.logPrinterId) = 36) ) -- copy
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate
		AND (LEN(t.logfprintQ) = 36 OR LEN(t.logfprintQ) = 0)
	GROUP BY t.logticketId
	HAVING COUNT(*) = 1


	DECLARE @jobs TABLE
		(JobDay					datetime NOT NULL
		,QueueId				uniqueidentifier NULL
		,FollowPrintQueueId		uniqueidentifier NULL
		,IsLocalPrinter			bit NOT NULL
		,JobType				tinyint NOT NULL	--(1=print, 2=copy, 3=fax, 4=scan)
		,IsFollowPrint			bit NOT NULL
		,Color					bit NOT NULL
		,Duplex					bit NOT NULL
		,PaperType				smallint NOT NULL
		,Size					bigint NOT NULL 
		,Pages					int NOT NULL
		,JobCount				int NOT NULL
		,TicketPrice			float NULL)


	-- Jobs without SNMP
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	


		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId

--		,CASE WHEN LEN(t.logQueueId) = 36 
--			THEN CAST(t.logQueueId AS uniqueidentifier)	
--			ELSE -- anv�nd printerid som queueId
--				CASE WHEN LEN(t.logPrinterId) = 36 
--							THEN CAST(t.logPrinterId AS uniqueidentifier)
--				ELSE NULL END
--			END								AS QueueId


--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		AS Color		-- 0=Unknown, 1 = BW, 2=Color
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,SUM(t.logjobSize)								AS Size
		,SUM(t.logpages)									AS Pages
		,Count(*)										AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
--	WHERE t.logEventMajor = 2 
--		AND t.logEventMinor IN (1, 6, 10)
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages = 0 
		AND t.logLoggedColorPages = 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId	
--		,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper									

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100103
			GOTO PROC_ERROR
		END


	-- B/W ONLY jobs with SNMP
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	
		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId
--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,0												AS Color		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,SUM(t.logjobSize)								AS Size
		,SUM(t.logLoggedBWPages)						AS Pages
		,Count(*)										AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages <> 0 
		AND t.logLoggedColorPages = 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId								
		--,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper		

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100104
			GOTO PROC_ERROR
		END

	-- Color ONLY jobs with SNMP
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	
		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId
--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,1												AS Color		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,SUM(t.logjobSize)								AS Size
		,SUM(t.logLoggedColorPages)						AS Pages
		,Count(*)										AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages = 0 
		AND t.logLoggedColorPages <> 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId								
		--,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper		

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100105
			GOTO PROC_ERROR
		END


	-- Mixed jobs with SNMP / BW side. Mixed jobs get JobCount and JobSize added to this row
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	
		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId
--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,0												AS Color		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,SUM(t.logjobSize)								AS Size
		,SUM(t.logLoggedBWPages)						AS Pages
		,Count(*)										AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages <> 0 
		AND t.logLoggedColorPages <> 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId								
		--,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper		

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100106
			GOTO PROC_ERROR
		END

	-- Mixed jobs with SNMP / Color side
	----------------------------------------------------------------------
	INSERT @jobs
	SELECT
		convert(char(8), t.logdateEvent, 112)			AS JobDay	
		,CASE WHEN LEN(t.logQueueId) = 36 
			THEN CAST(t.logQueueId AS uniqueidentifier)	
			ELSE NULL END								AS QueueId
--		,CASE WHEN LEN(t.logprinterId) = 36 
--				THEN CAST(t.logprinterId AS uniqueidentifier)	
--			ELSE NULL END								AS PrinterId	
		,CASE WHEN LEN(t.logfprintQ) = 36 
			THEN CAST(t.logfprintQ AS uniqueidentifier)	
			ELSE NULL END								AS FollowPrintQueueId	
		,0 AS IsLocalPrinter	
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								AS JobType 
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END	AS IsFollowPrint		
		,1												AS Color		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	AS Duplex		-- 0=Unknown, 1=nej, >1 = ja
		,t.logpaper										AS PaperType
		,0												AS Size
		,SUM(t.logLoggedColorPages)						AS Pages
		,0												AS JobCount
		,SUM(ISNULL(logTicketPrice,0.0))				AS TicketPrice
	FROM vw_ticket_log_report_calc t
	INNER JOIN @Tickets tt
		ON tt.TicketId = t.logTicketId
	WHERE ((t.logEventMajor = 2 AND t.logEventMinor IN (1, 6)) OR (t.logEventMajor = 4 AND t.logEventMinor = 10))
		AND t.logdateEvent > @StartDate
		AND t.logdateEvent <= @EndDate -- there is an index on logdateEvent that we can use
		AND t.logLoggedBWPages <> 0 
		AND t.logLoggedColorPages <> 0
	GROUP BY
		convert(char(8), t.logdateEvent, 112)		
		,t.logQueueId								
		--,t.logprinterId							
		,t.logfprintQ								
		,CASE	WHEN logEventMinor IN (1, 6) THEN 1
				WHEN logEventMinor = 10	THEN 2 
				ELSE 1 END								
		,CASE WHEN t.logfprintQ = '' THEN 0 ELSE 1 END			
		,CASE WHEN t.logcolor = 2 THEN 1 ELSE 0 END		
		,CASE WHEN t.logduplex > 1 THEN 1 ELSE 0 END	
		,t.logpaper		

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100107
		GOTO PROC_ERROR
	END

	-- Mark local printers
	-- (Jobs from local printers have their printerId as queueId)
	----------------------------------------------------------------------
	UPDATE @jobs SET IsLocalPrinter = 1
	WHERE QueueId IN (SELECT printerId FROM tbl_printer WHERE printerType = 1)

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100108
		GOTO PROC_ERROR
	END

	-- Assign queueid when current value is printerId
	----------------------------------------------------------------------

	UPDATE j
		SET QueueId = (SELECT CAST(MIN(mapQueue) as uniqueidentifier) FROM tbl_queue_printer_map m WHERE mapPhyPrinter = CAST(QueueId as varchar(64)))
	FROM @jobs j
	INNER JOIN tbl_queue_printer_map m
		ON m.mapPhyPrinter = CAST(QueueId as varchar(64))

	-- Sum up and insert into statistics table
	----------------------------------------------------------------------


	INSERT tbl_report_jobs_queue
		(JobDay
		,QueueId
--		,PrinterId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,Color
		,Duplex
		,PaperType
		,Size
		,Pages
		,JobCount
		,TicketPrice)
	SELECT 
		JobDay
		,QueueId
--		,PrinterId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,Color
		,Duplex
		,PaperType
		,SUM(Size)
		,SUM(Pages)
		,SUM(JobCount)
		,SUM(TicketPrice)
	FROM @jobs
	GROUP BY
		JobDay
		,QueueId
--		,PrinterId
		,FollowPrintQueueId
		,IsLocalPrinter
		,JobType
		,IsFollowPrint
		,Color
		,Duplex
		,PaperType

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0
	BEGIN
		SET @ErrorNo = 100109
		GOTO PROC_ERROR
	END

	EXEC @ReturnStatus = sp_property_upd @ipropertyName = 'JobsQueueCutOff', @ipropertyValueDate = @EndDate


	RETURN (@ReturnStatus)


PROC_ERROR:

RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_report_jobs_queue_color') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_queue_color
GO

CREATE PROCEDURE sp_report_jobs_queue_color
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-06
Description: Simple test 1
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 

************************************************************/
	@iStartDate				datetime = NULL
	,@iEndDate				datetime = NULL
	,@iRegionDepth			int = 0
AS
BEGIN

SET @iStartDate = ISNULL(@iStartDate, '20000101')
SET @iEndDate = ISNULL(@iEndDate, '99991231')
SET @iRegionDepth = ISNULL(@iRegionDepth, 0)

SELECT
	r.JobDay
	,r.QueueId
	,r.PageCountBW
	,r.PageCountColor
	,q.queueName				AS QueueName
	,dbo.fn_region_get_partial_path_verbose(q.queueRegion, @iRegionDepth) FullRegionPathVerbose
FROM vw_report_jobs_queue_color r
INNER JOIN tbl_queue q
	ON r.QueueId = q.QueueId
WHERE r.JobDay BETWEEN @iStartDate AND @iEndDate
ORDER BY 
	r.JobDay
	,r.QueueId	


	RETURN (0)

END
GO
IF OBJECT_ID('sp_report_jobs_queue_region_pages_color_get') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_queue_region_pages_color_get
GO

CREATE PROCEDURE sp_report_jobs_queue_region_pages_color_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-14
Description: Get pages by date and queue with region information
************************************************************/
	 @iStartDate	datetime		= NULL
	,@iEndDate		datetime		= NULL

AS
BEGIN



	WITH q (QueueId, PagesBW, PagesColor, PagesTotal) AS
		(select 
			q.QueueId
			,SUM(q.PageCountBW)
			,SUM(q.PageCountColor)
			,SUM(q.PageCountBW) + SUM(q.PageCountColor)
		from vw_report_jobs_queue_color q
		WHERE JobDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231') 
		GROUP BY
		q.QueueId)
	select 
		q.QueueId
		,qc.QueueName
		,q.PagesBW
		,q.PagesColor
		,q.PagesTotal
		,NULL RegionId --MAX(qc.RegionId)	AS RegionId
		,qc.ParentRegionId
		,r2.RegionGUID AS ParentRegionGUID
		,'Queue' AS ObjectType
	FROM q
	INNER JOIN tbl_report_queue_cache qc
		ON q.QueueId = qc.QueueId
	LEFT JOIN tbl_report_region_cache r2
		ON qc.ParentRegionId = r2.RegionId

	UNION
	SELECT
		r1.RegionGUID
		,r1.regionName
		,0
		,0
		,0
		,r1.RegionId
		,r1.ParentRegionId
		,r2.RegionGUID AS ParentRegionGUID
		,'Region' AS ObjectType
	FROM tbl_report_region_cache r1
	LEFT JOIN tbl_report_region_cache r2
		ON r1.ParentRegionId = r2.RegionId






-- GAMLA: ger x kolumner med regioninfo
--	WITH q (JobDay, QueueId, Pages) AS
--		(select 
--			q.JobDay
--			,q.QueueId
--			,SUM(q.Pages)
--		from tbl_report_jobs_queue q
--		GROUP BY
--		q.JobDay
--		,q.QueueId)
--	select 
--		q.JobDay
--		,q.QueueId
--		,qc.QueueName
--		,q.Pages
--		,r0.RegionPath R0
--		,r1.RegionPath R1
--		,r2.RegionPath R2
--		,r3.RegionPath R3
--		,r4.RegionPath R4
--	from q
--	INNER JOIN tbl_report_queue_cache qc
--		ON q.QueueId = qc.QueueId
--	INNER JOIN tbl_report_queue_regiondepth_cache r0
--		ON q.QueueId = r0.QueueId AND r0.Depth = 0
--	INNER JOIN tbl_report_queue_regiondepth_cache r1
--		ON q.QueueId = r1.QueueId AND r1.Depth = 1
--	INNER JOIN tbl_report_queue_regiondepth_cache r2
--		ON q.QueueId = r2.QueueId AND r2.Depth = 2
--	INNER JOIN tbl_report_queue_regiondepth_cache r3
--		ON q.QueueId = r3.QueueId AND r3.Depth = 3
--	INNER JOIN tbl_report_queue_regiondepth_cache r4
--		ON q.QueueId = r4.QueueId AND r4.Depth = 4
--	WHERE
--		q.JobDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')
--	ORDER BY JobDay, QueueName

	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO

IF OBJECT_ID('sp_report_jobs_queue_region_pages_duplex_get') IS NOT NULL
	DROP PROCEDURE sp_report_jobs_queue_region_pages_duplex_get
GO

CREATE PROCEDURE sp_report_jobs_queue_region_pages_duplex_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-18
Description: Get simplex/duplex pages by date and queue with region information
************************************************************/
	 @iStartDate	datetime		= NULL
	,@iEndDate		datetime		= NULL

AS
BEGIN



	WITH q (QueueId, PagesSimplex, PagesDuplex, PagesTotal) AS
		(select 
			q.QueueId
			,SUM(q.PageCountSimplex)
			,SUM(q.PageCountDuplex)
			,SUM(q.PageCountSimplex) + SUM(q.PageCountDuplex)
		from vw_report_jobs_queue_duplex q
		WHERE JobDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231') 
		GROUP BY
		q.QueueId)
	select 
		q.QueueId
		,qc.QueueName
		,q.PagesSimplex
		,q.PagesDuplex
		,q.PagesTotal
		,NULL RegionId --MAX(qc.RegionId)	AS RegionId
		,qc.ParentRegionId
		,r2.RegionGUID AS ParentRegionGUID
		,'Queue' AS ObjectType
	FROM q
	INNER JOIN tbl_report_queue_cache qc
		ON q.QueueId = qc.QueueId
	LEFT JOIN tbl_report_region_cache r2
		ON qc.ParentRegionId = r2.RegionId


	UNION
	SELECT
		r1.RegionGUID
		,r1.regionName
		,0
		,0
		,0
		,r1.RegionId
		,r1.ParentRegionId
		,r2.RegionGUID AS ParentRegionGUID
		,'Region' AS ObjectType
	FROM tbl_report_region_cache r1
	LEFT JOIN tbl_report_region_cache r2
		ON r1.ParentRegionId = r2.RegionId






-- GAMLA: ger x kolumner med regioninfo
--	WITH q (JobDay, QueueId, Pages) AS
--		(select 
--			q.JobDay
--			,q.QueueId
--			,SUM(q.Pages)
--		from tbl_report_jobs_queue q
--		GROUP BY
--		q.JobDay
--		,q.QueueId)
--	select 
--		q.JobDay
--		,q.QueueId
--		,qc.QueueName
--		,q.Pages
--		,r0.RegionPath R0
--		,r1.RegionPath R1
--		,r2.RegionPath R2
--		,r3.RegionPath R3
--		,r4.RegionPath R4
--	from q
--	INNER JOIN tbl_report_queue_cache qc
--		ON q.QueueId = qc.QueueId
--	INNER JOIN tbl_report_queue_regiondepth_cache r0
--		ON q.QueueId = r0.QueueId AND r0.Depth = 0
--	INNER JOIN tbl_report_queue_regiondepth_cache r1
--		ON q.QueueId = r1.QueueId AND r1.Depth = 1
--	INNER JOIN tbl_report_queue_regiondepth_cache r2
--		ON q.QueueId = r2.QueueId AND r2.Depth = 2
--	INNER JOIN tbl_report_queue_regiondepth_cache r3
--		ON q.QueueId = r3.QueueId AND r3.Depth = 3
--	INNER JOIN tbl_report_queue_regiondepth_cache r4
--		ON q.QueueId = r4.QueueId AND r4.Depth = 4
--	WHERE
--		q.JobDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')
--	ORDER BY JobDay, QueueName

	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO

IF OBJECT_ID('sp_report_matrix_snmp_brandmodel') IS NOT NULL
	DROP PROCEDURE sp_report_matrix_snmp_brandmodel
GO

CREATE PROCEDURE sp_report_matrix_snmp_brandmodel
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-03
Description: Brand/model comparison
-------------------------------------------------------------
Modified by:  
Modification date: 
Description: 
************************************************************/
	 @iStartDate	datetime			= NULL
	,@iEndDate		datetime			= NULL
	,@iPhysicalStatus	varchar(100)	= NULL
AS
BEGIN

	DECLARE @PhysStatus TABLE (PhysicalStatus int)

	IF @iPhysicalStatus IS NOT NULL
		INSERT @PhysStatus SELECT CAST(ValueTypeId AS INT) FROM dbo.fn_value_list_parse(',' + @iPhysicalStatus)

	IF @@ROWCOUNT = 0
		INSERT @PhysStatus (PhysicalStatus)
		SELECT StatusMajor FROM tbl_report_status_cache WHERE StatusTypeId = 1

	DECLARE @TotalPrinterCount INT
	SELECT @TotalPrinterCount = COUNT(1) FROM tbl_report_printer_cache


	SELECT
		--convert(char(6), l.statlogFirstDetected, 112)		AS YearMonthNum
		cast(convert(char(6), l.statlogFirstDetected, 112) + '01' as datetime)		AS YearMonthDateTime
		,b.BrandName
		,b.PrinterCount										AS BrandPrinterCount
		,m.ModelName
		,m.PrinterCount										AS ModelPrinterCount
		,COUNT(*)											AS EventCount
		,SUM(datediff(s, l.statlogFirstDetected, l.statlogClosed))				AS StatusDuration
--		,sv.StatusVerbose AS PhysicalStatusVerbose
		,@TotalPrinterCount									AS TotalPrinterCount
	FROM tbl_event_status_log l
	INNER JOIN @PhysStatus st
		ON l.statlogPhysStatus = st.PhysicalStatus
	INNER JOIN tbl_report_printer_cache p
		ON CAST(l.statlogPrinterId AS uniqueidentifier) = p.PrinterId
	INNER JOIN tbl_report_model_cache m
		ON p.ModelId = m.ModelId
	INNER JOIN tbl_report_brand_cache b
		ON m.BrandId = b.BrandId
	WHERE l.statlogFirstDetected BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate, '99991231')


	GROUP BY 
		--convert(char(6), l.statlogFirstDetected, 112)
		--l.statlogFirstDetected
		cast(convert(char(6), l.statlogFirstDetected, 112) + '01' as datetime)
		,b.BrandName
		,m.ModelName
--		,sv.StatusVerbose
		,b.PrinterCount
		,l.statlogPhysStatus
		,m.PrinterCount	

--	)
--	SELECT 
--		a.StatusDay
--		,a.PrinterId
--		,a.PhysicalStatus
--		,SUM(a.StatusDuration) AS TotalStatusDuration
--		,COUNT(1)			  AS StatusCount
--	FROM a
--	GROUP BY 
--		a.StatusDay
--		,a.PrinterId
--		,a.PhysicalStatus
--
END

GO
IF OBJECT_ID('sp_report_matrix_snmp_get') IS NOT NULL
	DROP PROCEDURE sp_report_matrix_snmp_get
GO

CREATE PROCEDURE sp_report_matrix_snmp_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-02
Description: Get data for the custom snmp event matrix report.
************************************************************/
	 @iStartDate	datetime			= NULL
	,@iEndDate		datetime			= NULL
	,@iPhysicalStatus	varchar(100)	= NULL

AS
BEGIN

	DECLARE @PhysStatus TABLE (PhysicalStatus int)

	IF @iPhysicalStatus IS NOT NULL
		INSERT @PhysStatus SELECT CAST(ValueTypeId AS INT) FROM dbo.fn_value_list_parse(',' + @iPhysicalStatus)

	IF @@ROWCOUNT = 0
		INSERT @PhysStatus (PhysicalStatus)
		SELECT StatusMajor FROM tbl_report_status_cache WHERE StatusTypeId = 1

	-- Fetch start / end date if NULL so we can report back to SSRS
	IF @iStartDate IS NULL
		SELECT @iStartDate  = MIN(StatusDay) FROM vw_report_matrix_snmp
	IF @iEndDate IS NULL
		SELECT @iEndDate  = MAX(StatusDay) FROM vw_report_matrix_snmp


	SELECT
		s.StatusDay
		,s.PrinterId
		,p.PrinterName
		,s.PhysicalStatus
		,sv.StatusVerbose AS PhysicalStatusVerbose
		,s.TotalStatusDuration
		,s.StatusCount
		,m.ModelId
		,m.ModelName
		,m.PrinterCount AS ModelPrinterCount
		,b.BrandId
		,b.BrandName
		,b.PrinterCount AS BrandPrinterCount
		,@iStartDate	AS StartDate
		,@iEndDate		AS EndDate
	FROM vw_report_matrix_snmp s
	INNER JOIN @PhysStatus st
		ON s.PhysicalStatus = st.PhysicalStatus
	INNER JOIN tbl_report_printer_cache p
		ON s.PrinterId = p.PrinterId
	INNER JOIN tbl_report_model_cache m
		ON p.ModelId = m.ModelId
	INNER JOIN tbl_report_brand_cache b
		ON m.BrandId = b.BrandId
	INNER JOIN tbl_report_status_cache sv
		ON sv.StatusMajor = s.PhysicalStatus
		AND StatusTypeId = 1
	WHERE s.StatusDay BETWEEN @iStartDate AND @iEndDate


	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO

IF OBJECT_ID('sp_report_matrix_usage_get') IS NOT NULL
	DROP PROCEDURE sp_report_matrix_usage_get
GO

CREATE PROCEDURE sp_report_matrix_usage_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-29
Description: Get data for the custom usage matrix report.
************************************************************/
	 @iStartDate	datetime		= NULL
	,@iEndDate		datetime		= NULL

AS
BEGIN

	SELECT
		JobDay
		,QueueId
		,QueueName
		,PrinterId
		,PrinterName
		,ModelId
		,ModelName
		,BrandId
		,BrandName
		,JobTypeC
		,JobTypeD
		,JobTypeCD
		,PrinterType
		,JobTypeFunctionVerbose
		,Color
		,Duplex
		,Pages
		,JobCount
		,TicketPrice
		,LocalPrinter
		,JobTypeFunction
	FROM vw_report_matrix_usage
	WHERE JobDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')


	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_report_printertype_share') IS NOT NULL
	DROP PROCEDURE sp_report_printertype_share
GO

CREATE PROCEDURE sp_report_printertype_share
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-27
Description:  Get share in no. pages networked vs. local printers.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	 @iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL


	,@iIncludeSimplex	bit				= NULL
	,@iIncludeDuplex	bit				= NULL
	,@iIncludeBW		bit				= NULL
	,@iIncludeColor		bit				= NULL

	,@iIncludePrint		bit				= NULL
	,@iIncludeCopy		bit				= NULL
	,@iIncludeScan		bit				= NULL
	,@iIncludeFax		bit				= NULL

	,@iPaperType		smallint		= NULL

-- ska ej vara med:
--	,@iUserName			nvarchar(510)	= NULL
--	,@iDomain			nvarchar(510)	= NULL
--	,@iRegionId			bigint			= NULL -- mappa mot tbl_report_region_cache
	,@iBillingCodeId	bigint			= NULL
	,@iLanguageId		char(2)			= NULL

AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Default values don't work when calling from SSRS, so we have to do it here:
	----------------------------------------------------------------------------------------
	SET @iStartDate			= ISNULL(@iStartDate, '20000101')
	SET @iEndDate			= ISNULL(@iEndDate, '99991231')


	SET @iIncludeSimplex	= ISNULL(@iIncludeSimplex, 1)
	SET @iIncludeDuplex		= ISNULL(@iIncludeDuplex, 1)
	SET @iIncludeBW			= ISNULL(@iIncludeBW, 1)
	SET @iIncludeColor		= ISNULL(@iIncludeColor, 1)

	SET @iIncludePrint		= ISNULL(@iIncludePrint, 1)
	SET @iIncludeCopy		= ISNULL(@iIncludeCopy, 1)
	SET @iIncludeScan		= ISNULL(@iIncludeScan, 1)
	SET @iIncludeFax		= ISNULL(@iIncludeFax, 1)

	SET @iLanguageId		= ISNULL(@iLanguageId,'en')




	-- Actual data retrieval:
	----------------------------------------------------------------------------------------
--	SELECT
--	'Local Printers' PrinterType
--	,4984 PagesTotal
--	UNION
--	SELECT
--	'Network Printers'
--	,1450


	SELECT
		CASE WHEN IsLocalPrinter = 1 THEN dbo.fn_translate('LocalPrinters', @iLanguageId) ELSE dbo.fn_translate('NetworkPrinters', @iLanguageId) END AS PrinterType
		,SUM(Pages) PagesTotal
	FROM tbl_report_jobs_queue j
--	INNER JOIN tbl_report_queue_cache q
--		ON j.QueueId = q.QueueId
--	INNER JOIN @Regions r
--		ON q.ParentRegionId = r.RegionId
	WHERE j.JobDay BETWEEN @iStartDate AND @iEndDate
	AND ((j.Duplex = 1 AND @iIncludeDuplex = 1)
			OR (j.Duplex =0 AND @iIncludeSimplex = 1))
	AND ((j.Color = 1 AND @iIncludeColor = 1)
			OR (j.Color =0 AND @iIncludeBW = 1))
--	AND ((j.IsLocalPrinter = 1 AND @iIncludeLocal = 1)
--			OR (j.IsLocalPrinter =0 AND @iIncludeNetwork = 1))
	AND ((j.JobType = 1 AND @iIncludePrint = 1)
		OR (j.JobType = 2 AND @iIncludeCopy = 1)
		OR (j.JobType = 3 AND @iIncludeFax = 1)
		OR (j.JobType = 4 AND @iIncludeScan = 1))
	AND ISNULL(@iPaperType,j.PaperType) = j.PaperType
	GROUP BY IsLocalPrinter






	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO
IF OBJECT_ID('sp_report_printer_snmp_detail_get') IS NOT NULL
	DROP PROCEDURE sp_report_printer_snmp_detail_get
GO

CREATE PROCEDURE sp_report_printer_snmp_detail_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-19
Description: Full SNMP listing for all printers and region information
************************************************************/
	 @iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL
	,@iPhysicalStatus	varchar(100)	= NULL
AS
BEGIN

	DECLARE @PhysStatus TABLE (PhysicalStatus int)

	IF @iPhysicalStatus IS NOT NULL
		INSERT @PhysStatus SELECT CAST(ValueTypeId AS INT) FROM dbo.fn_value_list_parse(',' + @iPhysicalStatus)

	IF @@ROWCOUNT = 0
		INSERT @PhysStatus (PhysicalStatus)
		SELECT StatusMajor FROM tbl_report_status_cache WHERE StatusTypeId = 1


	SELECT 
		s.PrinterId
		,s.PrinterName
		,s.PhysicalStatus
		,s.PhysicalStatusVerbose
		,s.StatusDay
		,s.StatusStart
		,s.StatusEnd
		,s.StatusDuration
		,s.ModelId
		,s.ModelName
		,s.BrandId
		,s.BrandName
		,r2.RegionGUID AS ParentRegionGUID
		,'Printer' AS ObjectType
	FROM vw_report_snmp s
	INNER JOIN @PhysStatus st
		ON s.PhysicalStatus = st.PhysicalStatus
	LEFT JOIN tbl_report_region_cache r2
		ON s.ParentRegionId = r2.RegionId
	LEFT JOIN tbl_report_queue_regiondepth_cache rd1
		ON s.PrinterId = rd1.QueueId AND rd1.Depth = 2
	LEFT JOIN tbl_report_queue_regiondepth_cache rd2
		ON s.PrinterId = rd2.QueueId AND rd2.Depth = 3
	WHERE s.StatusDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')


	UNION
	SELECT
		r1.RegionGUID						AS PrinterId
		,r1.regionName						AS PrinterName
		,NULL -- s.PhysicalStatus
		,NULL -- s.PhysicalStatusVerbose
		,NULL -- s.StatusDay
		,NULL -- s.StatusStart
		,NULL -- s.StatusEnd
		,NULL -- s.StatusDuration
		,NULL -- s.ModelId
		,NULL -- s.ModelName
		,NULL -- s.BrandId
		,NULL -- s.BrandName
		,r2.RegionGUID AS ParentRegionGUID
		,'Region' AS ObjectType
	FROM tbl_report_region_cache r1
	LEFT JOIN tbl_report_region_cache r2
		ON r1.ParentRegionId = r2.RegionId

	ORDER BY StatusDay, PrinterName

	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_report_print_volume_by_month') IS NOT NULL
	DROP PROCEDURE sp_report_print_volume_by_month
GO

CREATE PROCEDURE sp_report_print_volume_by_month
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-12
Description: 
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	 @iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL

	,@iIncludeLocal		bit				= NULL
	,@iIncludeNetwork	bit				= NULL

	,@iIncludeSimplex	bit				= NULL
	,@iIncludeDuplex	bit				= NULL
	,@iIncludeBW		bit				= NULL
	,@iIncludeColor		bit				= NULL

	,@iIncludePrint		bit				= NULL
	,@iIncludeCopy		bit				= NULL
	,@iIncludeFax		bit				= NULL
	,@iIncludeScan		bit				= NULL

	,@iPaperType		smallint		= NULL
	,@iRegionId			bigint			= NULL
	,@iBillingCodeId	bigint			= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Default values don't work when calling from SSRS, so we have to do it here:
	----------------------------------------------------------------------------------------
	SET @iStartDate			= ISNULL(@iStartDate, '20000101')
	SET @iEndDate			= ISNULL(@iEndDate, '99991231')

	SET @iIncludeLocal		= ISNULL(@iIncludeLocal, 1)
	SET @iIncludeNetwork	= ISNULL(@iIncludeNetwork, 1)

	SET @iIncludeSimplex	= ISNULL(@iIncludeSimplex, 1)
	SET @iIncludeDuplex		= ISNULL(@iIncludeDuplex, 1)
	SET @iIncludeBW			= ISNULL(@iIncludeBW, 1)
	SET @iIncludeColor		= ISNULL(@iIncludeColor, 1)

	SET @iIncludePrint		= ISNULL(@iIncludePrint, 1)
	SET @iIncludeCopy		= ISNULL(@iIncludeCopy, 1)
	SET @iIncludeFax		= ISNULL(@iIncludeFax, 1)
	SET @iIncludeScan		= ISNULL(@iIncludeScan, 1)



	-- Set up tables for quick joining on main report data table:
	----------------------------------------------------------------------------------------
	DECLARE @PrinterTypes		TABLE (PrinterType char(1))
	DECLARE @PrinterTypesBit	TABLE (IsLocalPrinter bit)
	DECLARE @JobTypes			TABLE (JobType tinyint)
	DECLARE @SimplexDuplex		TABLE (Duplex bit)
	DECLARE @BWColor			TABLE (Color bit)

	IF @iIncludeLocal = 1		INSERT @PrinterTypes (PrinterType) VALUES ('1')
	IF @iIncludeNetwork = 1		INSERT @PrinterTypes (PrinterType) VALUES ('0')
	IF @iIncludeLocal = 1		INSERT @PrinterTypesBit (IsLocalPrinter) VALUES (1)
	IF @iIncludeNetwork = 1		INSERT @PrinterTypesBit (IsLocalPrinter) VALUES (0)

	IF @iIncludePrint = 1		INSERT @JobTypes (JobType) VALUES (1)
	IF @iIncludeCopy = 1		INSERT @JobTypes (JobType) VALUES (2)
	IF @iIncludeFax = 1			INSERT @JobTypes (JobType) VALUES (3)
	IF @iIncludeScan = 1		INSERT @JobTypes (JobType) VALUES (4)	

	IF @iIncludeSimplex = 1		INSERT @SimplexDuplex (Duplex) VALUES (0)
	IF @iIncludeDuplex = 1		INSERT @SimplexDuplex (Duplex) VALUES (1)

	IF @iIncludeBW = 1			INSERT @BWColor (Color) VALUES (0)
	IF @iIncludeColor = 1		INSERT @BWColor (Color) VALUES (1)



	-- Actual data retrieval:
	----------------------------------------------------------------------------------------


	-- Vill ha ut  
		 -- YearMonth
		 -- BWPages
		 -- COlor Pages
		 -- Duplex Pages
		 -- Simplex Pages
		 -- Total Pages

	-- F� ut vilka regioner vi vill ha med 
	DECLARE @Regions TABLE (RegionId bigint);
	INSERT @Regions (RegionId)
	EXEC @ReturnStatus = sp_report_region_get_descendants	@iRegionId = @iRegionId
	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR



	SELECT
		convert(char(6), JobDay, 112) AS YearMonth
		,SUM(CASE WHEN j.Color = 0 THEN Pages ELSE 0 END) AS PagesBW
		,SUM(CASE WHEN j.Color = 1 THEN Pages ELSE 0 END) AS PagesColor
		,SUM(CASE WHEN j.Duplex = 0 THEN Pages ELSE 0 END) AS PagesSimplex
		,SUM(CASE WHEN j.Duplex = 1 THEN Pages ELSE 0 END) AS PagesDuplex
		,SUM(Pages) AS PagesTotal
	FROM tbl_report_jobs_queue j
	INNER JOIN tbl_report_queue_cache q
		ON j.QueueId = q.QueueId
	INNER JOIN @Regions r
		ON q.ParentRegionId = r.RegionId
	INNER JOIN @BWColor c
		ON c.Color = j.Color
	INNER JOIN @SimplexDuplex d
		ON d.Duplex = j.Duplex
	INNER JOIN @JobTypes jt
		ON j.JobType = jt.JobType
	INNER JOIN @PrinterTypesBit pt
		ON j.IsLocalPrinter = pt.IsLocalPrinter
	WHERE JobDay BETWEEN @iStartDate AND @iEndDate
		AND ISNULL(@iPaperType,PaperType) = PaperType
	GROUP BY convert(char(6), JobDay, 112)
	ORDER BY convert(char(6), JobDay, 112)





	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO
IF OBJECT_ID('sp_report_queue_aggregate_by_day_get') IS NOT NULL
	DROP PROCEDURE sp_report_queue_aggregate_by_day_get
GO

CREATE PROCEDURE sp_report_queue_aggregate_by_day_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-25
Description: Aggregate queue stats by day. One row per queue.
************************************************************/
	 @iStartDate	datetime		= NULL
	,@iEndDate		datetime		= NULL

AS
BEGIN



	WITH d (JobDay, QueueId, PagesSimplex, PagesDuplex, PagesTotal) AS
		(select 
			q.JobDay
			,q.QueueId
			,SUM(q.PageCountSimplex)
			,SUM(q.PageCountDuplex)
			,SUM(q.PageCountSimplex) + SUM(q.PageCountDuplex)
		from vw_report_jobs_queue_duplex q
		WHERE JobDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231') 
		GROUP BY
		q.JobDay, q.QueueId)
	,q (JobDay, QueueId, PagesBW, PagesColor, PagesTotal) AS
			(select 
				q.JobDay
				,q.QueueId
				,SUM(q.PageCountBW)
				,SUM(q.PageCountColor)
				,SUM(q.PageCountBW) + SUM(q.PageCountColor)
			from vw_report_jobs_queue_color q
			WHERE JobDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231') 
			GROUP BY
			q.JobDay, q.QueueId)
	select 
		q.JobDay
		,q.QueueId
		,qc.QueueName
		,p.PrinterId
		,p.PrinterName
		,m.ModelId
		,m.ModelName
		,b.BrandId
		,b.BrandName
		,q.PagesBW
		,q.PagesColor
		,d.PagesSimplex
		,d.PagesDuplex
		,q.PagesTotal
		,NULL RegionId --MAX(qc.RegionId)	AS RegionId
		,qc.ParentRegionId
		,r2.RegionGUID AS ParentRegionGUID
		,'Queue' AS ObjectType
	FROM q
	INNER JOIN d
		ON d.QueueId = q.QueueId AND d.JobDay = q.JobDay
	INNER JOIN tbl_report_queue_cache qc
		ON q.QueueId = qc.QueueId
	INNER JOIN tbl_report_printer_cache p
		ON qc.PrinterId = p.PrinterId
	INNER JOIN tbl_report_model_cache m
		ON p.ModelId = m.ModelId
	INNER JOIN tbl_report_brand_cache b
		ON m.BrandId = b.BrandId
	LEFT JOIN tbl_report_region_cache r2
		ON qc.ParentRegionId = r2.RegionId
	ORDER BY q.JobDay, qc.QueueName

--	UNION
--	SELECT
--		r1.RegionGUID
--		,r1.regionName
--		,0
--		,0
--		,0
--		,r1.RegionId
--		,r1.ParentRegionId
--		,r2.RegionGUID AS ParentRegionGUID
--		,'Region' AS ObjectType
--	FROM tbl_report_region_cache r1
--	LEFT JOIN tbl_report_region_cache r2
--		ON r1.ParentRegionId = r2.RegionId



	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_report_queue_regiondepth_cache_refresh') IS NOT NULL
	DROP PROCEDURE sp_report_queue_regiondepth_cache_refresh
GO

CREATE PROCEDURE sp_report_queue_regiondepth_cache_refresh
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-05-13
Description: Recalculate queue region paths at different levels
-------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-10
Description: Delete instead of truncate.
************************************************************/
	@iDepth smallint = 10
AS
BEGIN

	DELETE tbl_report_queue_regiondepth_cache

	DECLARE @i int 
		,@ErrorNo int
	SET @i = 0
	SET @ErrorNo = 0

	WHILE @i <= @iDepth
	BEGIN
		-- queuesprinters
		INSERT tbl_report_queue_regiondepth_cache
			(QueueId
			,Depth
			,RegionPath)
		SELECT
			CAST(q.queueId AS uniqueidentifier)
			,@i
--			,dbo.fn_region_get_partial_path_verbose(q.queueRegion, @i)
			,dbo.fn_region_get_part_path_verbose(q.queueRegion, @i)
		FROM tbl_queue q

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100100
			GOTO PROC_ERROR
		END

		-- Network printers
		INSERT tbl_report_queue_regiondepth_cache
			(QueueId
			,Depth
			,RegionPath)
		SELECT
			CAST(p.printerId AS uniqueidentifier)
			,@i
			,dbo.fn_region_get_partial_path_verbose(p.region, @i)
		FROM tbl_printer p
		WHERE p.printerType = 0


		-- Local printers
		INSERT tbl_report_queue_regiondepth_cache
			(QueueId
			,Depth
			,RegionPath)
		SELECT
			CAST(p.printerId AS uniqueidentifier)
			,@i
			,dbo.fn_lregion_get_partial_path_verbose(p.region, @i)
		FROM tbl_printer p
		WHERE p.printerType = 1


		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0
		BEGIN
			SET @ErrorNo = 100101
			GOTO PROC_ERROR
		END

		SET @i = @i +1
	END


	RETURN (0)


	PROC_ERROR:

	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_report_region_get_descendants') IS NOT NULL
	DROP PROCEDURE sp_report_region_get_descendants
GO

CREATE PROCEDURE sp_report_region_get_descendants
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-22
Description:	Get all descendants of a REPORT region (NOT THE SAME AS REGULAR CIRRATO REGIONS / LOCAL REGIONS).
				Result also includes given parent region.
				NULL = list every region
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRegionId			bigint		= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- do stuff

	DECLARE @Regions TABLE (RegionId bigint);

	IF @iRegionId IS NOT NULL
	BEGIN
		 WITH Regions (RegionId, ParentRegionId) AS
			 (SELECT RegionId, ParentRegionId FROM tbl_report_region_cache WHERE RegionId = @iRegionId
			 UNION ALL
			SELECT rc.RegionId, rc.ParentRegionId 
			FROM tbl_report_region_cache rc
			INNER JOIN Regions r
				ON rc.ParentRegionId = r.RegionId)
		INSERT @Regions (RegionId)
		SELECT RegionId FROM Regions;
	END
	ELSE
	BEGIN
		INSERT @Regions (RegionId)
		SELECT RegionId FROM tbl_report_region_cache	
	END

	SELECT * FROM @Regions



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO
IF OBJECT_ID('sp_report_snmp_counter_region_get') IS NOT NULL
	DROP PROCEDURE sp_report_snmp_counter_region_get
GO

CREATE PROCEDURE sp_report_snmp_counter_region_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-06
Description: SNMP Counter, highest value in time range
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-10
Description: Changed params to start and end date
************************************************************/
	 @iStartDate	datetime		= NULL
	 ,@iEndDate		datetime		= NULL

AS
BEGIN

	DECLARE @EndDate datetime
	SET @EndDate = '99991231';

	WITH CounterBWStart (PrinterId, CounterBW) AS
		(SELECT
			CAST(counterstatPrinterId AS uniqueidentifier)
			,MIN(counterstatCount)
		FROM tbl_counter_statistics
		WHERE counterstatType = 0
			AND counterstatChecked >= ISNULL(@iStartDate,'20000101')
		GROUP BY counterstatPrinterId)
	,CounterColorStart (PrinterId, CounterColor) AS
		(SELECT
			CAST(counterstatPrinterId AS uniqueidentifier)
			,MIN(counterstatCount)
		FROM tbl_counter_statistics
		WHERE counterstatType = 1
			AND counterstatChecked >= ISNULL(@iStartDate,'20000101')
		GROUP BY counterstatPrinterId)

	,CounterBWEnd (PrinterId, CounterBW) AS
		(SELECT
			CAST(counterstatPrinterId AS uniqueidentifier)
			,MAX(counterstatCount)
		FROM tbl_counter_statistics
		WHERE counterstatType = 0
			AND counterstatChecked <= ISNULL(@iEndDate,@EndDate)
		GROUP BY counterstatPrinterId)
	,CounterColorEnd (PrinterId, CounterColor) AS
		(SELECT
			CAST(counterstatPrinterId AS uniqueidentifier)
			,MAX(counterstatCount)
		FROM tbl_counter_statistics
		WHERE counterstatType = 1
			AND counterstatChecked <= ISNULL(@iEndDate,@EndDate)
		GROUP BY counterstatPrinterId)

	SELECT
		p.PrinterId
		,p.PrinterName

		,CASE WHEN ISNULL(bwEnd.CounterBW,0) - ISNULL(bwStart.CounterBW,0) < 0 THEN 0			
			ELSE ISNULL(bwEnd.CounterBW,0) - ISNULL(bwStart.CounterBW,0) END			PagesBW
		,CASE WHEN ISNULL(cEnd.CounterColor,0) - ISNULL(cStart.CounterColor,0) < 0 THEN 0
			ELSE ISNULL(cEnd.CounterColor,0) - ISNULL(cStart.CounterColor,0) END		PagesColor
		,NULL								RegionId
		,p.ParentRegionId					ParentRegionId
		,r2.RegionGUID						ParentRegionGUID
		,'Printer' AS ObjectType
	FROM tbl_report_printer_cache p
	LEFT JOIN CounterBWStart bwStart
		ON p.PrinterId = bwStart.PrinterId
	LEFT JOIN CounterColorStart cStart
		ON p.PrinterId = cStart.PrinterId
	LEFT JOIN CounterBWEnd bwEnd
		ON p.PrinterId = bwEnd.PrinterId
	LEFT JOIN CounterColorEnd cEnd
		ON p.PrinterId = cEnd.PrinterId

	LEFT JOIN tbl_report_region_cache r2
		ON p.ParentRegionId = r2.RegionId

	UNION
	SELECT
		r1.RegionGUID
		,r1.regionName
		,0
		,0
		,r1.RegionId
		,r1.ParentRegionId
		,r2.RegionGUID AS ParentRegionGUID
		,'Region' AS ObjectType
	FROM tbl_report_region_cache r1
	LEFT JOIN tbl_report_region_cache r2
		ON r1.ParentRegionId = r2.RegionId






-- GAMLA: ger x kolumner med regioninfo
--	WITH q (JobDay, QueueId, Pages) AS
--		(select 
--			q.JobDay
--			,q.QueueId
--			,SUM(q.Pages)
--		from tbl_report_jobs_queue q
--		GROUP BY
--		q.JobDay
--		,q.QueueId)
--	select 
--		q.JobDay
--		,q.QueueId
--		,qc.QueueName
--		,q.Pages
--		,r0.RegionPath R0
--		,r1.RegionPath R1
--		,r2.RegionPath R2
--		,r3.RegionPath R3
--		,r4.RegionPath R4
--	from q
--	INNER JOIN tbl_report_queue_cache qc
--		ON q.QueueId = qc.QueueId
--	INNER JOIN tbl_report_queue_regiondepth_cache r0
--		ON q.QueueId = r0.QueueId AND r0.Depth = 0
--	INNER JOIN tbl_report_queue_regiondepth_cache r1
--		ON q.QueueId = r1.QueueId AND r1.Depth = 1
--	INNER JOIN tbl_report_queue_regiondepth_cache r2
--		ON q.QueueId = r2.QueueId AND r2.Depth = 2
--	INNER JOIN tbl_report_queue_regiondepth_cache r3
--		ON q.QueueId = r3.QueueId AND r3.Depth = 3
--	INNER JOIN tbl_report_queue_regiondepth_cache r4
--		ON q.QueueId = r4.QueueId AND r4.Depth = 4
--	WHERE
--		q.JobDay BETWEEN ISNULL(@iStartDate,'20000101') AND ISNULL(@iEndDate,'99991231')
--	ORDER BY JobDay, QueueName

	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_report_top_printers_pages') IS NOT NULL
	DROP PROCEDURE sp_report_top_printers_pages
GO

CREATE PROCEDURE sp_report_top_printers_pages
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-22
Description:	Get top N printers + rest. Per printer: total pages, total bw, total color, total simplex, total duplex.
				Top N is sorted by Total Pages.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iTopN				int				= NULL

	,@iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL

	,@iIncludeLocal		bit				= NULL
	,@iIncludeNetwork	bit				= NULL

	,@iIncludeSimplex	bit				= NULL
	,@iIncludeDuplex	bit				= NULL
	,@iIncludeBW		bit				= NULL
	,@iIncludeColor		bit				= NULL

	,@iIncludePrint		bit				= NULL
	,@iIncludeCopy		bit				= NULL
	,@iIncludeScan		bit				= NULL
	,@iIncludeFax		bit				= NULL

	,@iPaperType		smallint		= NULL

--	,@iUserName			nvarchar(510)	= NULL
--	,@iDomain			nvarchar(510)	= NULL
	,@iRegionId			bigint			= NULL -- mappa mot tbl_report_region_cache
	,@iBillingCodeId	bigint			= NULL

AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Default values don't work when calling from SSRS, so we have to do it here:
	----------------------------------------------------------------------------------------
	SET @iTopN				= ISNULL(@iTopN,10)
	SET @iStartDate			= ISNULL(@iStartDate, '20000101')
	SET @iEndDate			= ISNULL(@iEndDate, '99991231')

	SET @iIncludeLocal		= ISNULL(@iIncludeLocal, 1)
	SET @iIncludeNetwork	= ISNULL(@iIncludeNetwork, 1)

	SET @iIncludeSimplex	= ISNULL(@iIncludeSimplex, 1)
	SET @iIncludeDuplex		= ISNULL(@iIncludeDuplex, 1)
	SET @iIncludeBW			= ISNULL(@iIncludeBW, 1)
	SET @iIncludeColor		= ISNULL(@iIncludeColor, 1)

	SET @iIncludePrint		= ISNULL(@iIncludePrint, 1)
	SET @iIncludeCopy		= ISNULL(@iIncludeCopy, 1)
	SET @iIncludeScan		= ISNULL(@iIncludeScan, 1)
	SET @iIncludeFax		= ISNULL(@iIncludeFax, 1)


	-- Set up tables for quick joining on main report data table:
	----------------------------------------------------------------------------------------
	DECLARE @PrinterTypes		TABLE (PrinterType char(1)) -- f�r join mot detaljtabell
	DECLARE @PrinterTypesBit	TABLE (IsLocalPrinter bit)	-- f�r join mot aggregerad tabell
	DECLARE @JobTypes			TABLE (JobType tinyint)
	DECLARE @SimplexDuplex		TABLE (Duplex bit)
	DECLARE @BWColor			TABLE (Color bit)			-- obs denna fungerar bara rakt av mot aggregerad tabell och vw_report_jobs_detail_n. 
															-- Detaljtabellen har b�de ColorPages och BWPages p� samma rad.

	IF @iIncludeLocal = 1		INSERT @PrinterTypes (PrinterType) VALUES ('1')
	IF @iIncludeNetwork = 1		INSERT @PrinterTypes (PrinterType) VALUES ('0')
	IF @iIncludeLocal = 1		INSERT @PrinterTypesBit (IsLocalPrinter) VALUES (1)
	IF @iIncludeNetwork = 1		INSERT @PrinterTypesBit (IsLocalPrinter) VALUES (0)

	IF @iIncludePrint = 1		INSERT @JobTypes (JobType) VALUES (1)
	IF @iIncludeCopy = 1		INSERT @JobTypes (JobType) VALUES (2)
	IF @iIncludeFax = 1			INSERT @JobTypes (JobType) VALUES (3)
	IF @iIncludeScan = 1		INSERT @JobTypes (JobType) VALUES (4)	

	IF @iIncludeSimplex = 1		INSERT @SimplexDuplex (Duplex) VALUES (0)
	IF @iIncludeDuplex = 1		INSERT @SimplexDuplex (Duplex) VALUES (1)

	IF @iIncludeBW = 1			INSERT @BWColor (Color) VALUES (0)
	IF @iIncludeColor = 1		INSERT @BWColor (Color) VALUES (1)

	-- Get requested subregions:
	----------------------------------------------------------------------------------------
	DECLARE @Regions TABLE (RegionId bigint);
	INSERT @Regions (RegionId)
	EXEC @ReturnStatus = sp_report_region_get_descendants	@iRegionId = @iRegionId
	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	-- Actual data retrieval:
	----------------------------------------------------------------------------------------


	SET @iTopN = @iTopN+ 1;

	WITH TopN (PrinterId, PagesBW, PagesColor, PagesSimplex, PagesDuplex, PagesTotal, IsOtherRow) AS
		(SELECT TOP (@iTopN) 
				p.PrinterId
				,SUM(CASE WHEN Color = 0 THEN Pages ELSE 0 END) AS PagesBW
				,SUM(CASE WHEN Color = 1 THEN Pages ELSE 0 END) AS PagesColor
				,SUM(CASE WHEN Duplex = 0 THEN Pages ELSE 0 END) AS PagesSimplex
				,SUM(CASE WHEN Duplex = 1 THEN Pages ELSE 0 END) AS PagesDuplex
				,SUM(Pages) PagesTotal
				,GROUPING(p.PrinterId) IsOtherRow
		FROM tbl_report_jobs_queue j
		INNER JOIN tbl_report_queue_cache q
			ON j.QueueId = q.QueueId
		INNER JOIN @Regions r
			ON q.ParentRegionId = r.RegionId
		INNER JOIN tbl_report_printer_cache p
			ON q.PrinterId = p.PrinterId
		WHERE JobDay BETWEEN @iStartDate AND @iEndDate
		AND ((j.Duplex = 1 AND @iIncludeDuplex = 1)
				OR (j.Duplex =0 AND @iIncludeSimplex = 1))
		AND ((j.Color = 1 AND @iIncludeColor = 1)
				OR (j.Color =0 AND @iIncludeBW = 1))
		AND ((j.IsLocalPrinter = 1 AND @iIncludeLocal = 1)
				OR (j.IsLocalPrinter =0 AND @iIncludeNetwork = 1))
		AND ((j.JobType = 1 AND @iIncludePrint = 1)
			OR (j.JobType = 2 AND @iIncludeCopy = 1)
			OR (j.JobType = 3 AND @iIncludeFax = 1)
			OR (j.JobType = 4 AND @iIncludeScan = 1))
		AND ISNULL(@iPaperType,j.PaperType) = j.PaperType

		GROUP BY p.PrinterId WITH ROLLUP
		ORDER BY PagesTotal DESC)
	,Others (PagesBW, PagesColor, PagesSimplex, PagesDuplex, PagesTotal) AS
		(SELECT 
			 SUM(CASE WHEN IsOtherRow=1 THEN PagesBW ELSE -1*PagesBW END)
			,SUM(CASE WHEN IsOtherRow=1 THEN PagesColor ELSE -1*PagesColor END)
			,SUM(CASE WHEN IsOtherRow=1 THEN PagesSimplex ELSE -1*PagesSimplex END)
			,SUM(CASE WHEN IsOtherRow=1 THEN PagesDuplex ELSE -1*PagesDuplex END)
			,SUM(CASE WHEN IsOtherRow=1 THEN PagesTotal ELSE -1*PagesTotal END)
		FROM TopN)
	SELECT
		t.PrinterId
		,p.PrinterName
		,PagesBW
		,PagesColor
		,PagesSimplex
		,PagesDuplex
		,PagesTotal
		,IsOtherRow
	FROM TopN t
	INNER JOIN tbl_report_printer_cache p
		ON t.PrinterId = p.PrinterId
	WHERE IsOtherRow = 0
	UNION	
	SELECT
		NULL
		,NULL
		,PagesBW
		,PagesColor
		,PagesSimplex
		,PagesDuplex
		,PagesTotal
		,1 AS IsOtherRow
	FROM Others t

ORDER BY t.IsOtherRow ASC, t.PagesTotal DESC


-- sp_report_top_printers_pages

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_top_users_pages') IS NOT NULL
	DROP PROCEDURE sp_report_top_users_pages
GO

CREATE PROCEDURE sp_report_top_users_pages
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-10-22
Description:	Get top N users + rest. Per user: total pages, total bw, total color, total simplex, total duplex.
				Top N is sorted by Total Pages.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iTopN				int				= NULL

	,@iStartDate		datetime		= NULL
	,@iEndDate			datetime		= NULL

	,@iIncludeLocal		bit				= NULL
	,@iIncludeNetwork	bit				= NULL

	,@iIncludeSimplex	bit				= NULL
	,@iIncludeDuplex	bit				= NULL
	,@iIncludeBW		bit				= NULL
	,@iIncludeColor		bit				= NULL

	,@iIncludePrint		bit				= NULL
	,@iIncludeCopy		bit				= NULL
	,@iIncludeScan		bit				= NULL
	,@iIncludeFax		bit				= NULL

	,@iPaperType		smallint		= NULL

	,@iUserName			nvarchar(510)	= NULL
	,@iDomain			nvarchar(510)	= NULL
	,@iRegionId			bigint			= NULL -- mappa mot tbl_report_region_cache
	,@iBillingCodeId	bigint			= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Default values don't work when calling from SSRS, so we have to do it here:
	----------------------------------------------------------------------------------------
	SET @iTopN				= ISNULL(@iTopN,10)

	SET @iStartDate			= ISNULL(@iStartDate, '20000101')
	SET @iEndDate			= ISNULL(@iEndDate, '99991231')

	SET @iIncludeLocal		= ISNULL(@iIncludeLocal, 1)
	SET @iIncludeNetwork	= ISNULL(@iIncludeNetwork, 1)

	SET @iIncludeSimplex	= ISNULL(@iIncludeSimplex, 1)
	SET @iIncludeDuplex		= ISNULL(@iIncludeDuplex, 1)
	SET @iIncludeBW			= ISNULL(@iIncludeBW, 1)
	SET @iIncludeColor		= ISNULL(@iIncludeColor, 1)

	SET @iIncludePrint		= ISNULL(@iIncludePrint, 1)
	SET @iIncludeCopy		= ISNULL(@iIncludeCopy, 1)
	SET @iIncludeScan		= ISNULL(@iIncludeScan, 1)
	SET @iIncludeFax		= ISNULL(@iIncludeFax, 1)


	-- Set up tables for quick joining on main report data table:
	----------------------------------------------------------------------------------------
	DECLARE @PrinterTypes		TABLE (PrinterType char(1)) -- f�r join mot detaljtabell
	DECLARE @PrinterTypesBit	TABLE (IsLocalPrinter bit)	-- f�r join mot aggregerad tabell
	DECLARE @JobTypes			TABLE (JobType tinyint)
	DECLARE @SimplexDuplex		TABLE (Duplex bit)
	DECLARE @BWColor			TABLE (Color bit) -- obs denna fungerar bara rakt av mot aggregerad tabell. Detaljtabell har b�de ColorPages och BWPages p� samma rad.

	IF @iIncludeLocal = 1		INSERT @PrinterTypes (PrinterType) VALUES ('1')
	IF @iIncludeNetwork = 1		INSERT @PrinterTypes (PrinterType) VALUES ('0')
	IF @iIncludeLocal = 1		INSERT @PrinterTypesBit (IsLocalPrinter) VALUES (1)
	IF @iIncludeNetwork = 1		INSERT @PrinterTypesBit (IsLocalPrinter) VALUES (0)

	IF @iIncludePrint = 1		INSERT @JobTypes (JobType) VALUES (1)
	IF @iIncludeCopy = 1		INSERT @JobTypes (JobType) VALUES (2)
	IF @iIncludeFax = 1			INSERT @JobTypes (JobType) VALUES (3)
	IF @iIncludeScan = 1		INSERT @JobTypes (JobType) VALUES (4)	

	IF @iIncludeSimplex = 1		INSERT @SimplexDuplex (Duplex) VALUES (0)
	IF @iIncludeDuplex = 1		INSERT @SimplexDuplex (Duplex) VALUES (1)

	IF @iIncludeBW = 1			INSERT @BWColor (Color) VALUES (0)
	IF @iIncludeColor = 1		INSERT @BWColor (Color) VALUES (1)


	-- Get requested subregions
	----------------------------------------------------------------------------------------
	DECLARE @Regions TABLE (RegionId bigint);
	INSERT @Regions (RegionId)
	EXEC @ReturnStatus = sp_report_region_get_descendants	@iRegionId = @iRegionId
	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	-- Actual data retrieval:
	----------------------------------------------------------------------------------------

	-- Vill ha ut

	-- username
	-- domain
	-- BWPages
	-- COlor Pages
	-- Duplex Pages
	-- Simplex Pages
	-- Total Pages

	-- obs: roll-up-raden �r totalt, inkluderar �ven de �vriga topN raderna

	SET @iTopN = @iTopN+ 1;

	WITH TopN (UserId, PagesBW, PagesColor, PagesSimplex, PagesDuplex, PagesTotal, IsOtherRow) AS
		(SELECT TOP (@iTopN) 
			UserId

--			,SUM(CASE WHEN @iIncludeBW=1 THEN PagesBW ELSE 0 END) PagesBW
--			,SUM(CASE WHEN @iIncludeColor=1 THEN PagesColor ELSE 0 END) PagesColor
--
--			,SUM(CASE WHEN j.Duplex = 0 THEN (CASE WHEN @iIncludeBW=1 THEN PagesBW ELSE 0 END) 
--					+ (CASE WHEN @iIncludeColor=1 THEN PagesColor ELSE 0 END)
--				 ELSE 0 END)  PagesSimplex
--			,SUM(CASE WHEN j.Duplex = 1 THEN (CASE WHEN @iIncludeBW=1 THEN PagesBW ELSE 0 END) 
--					+ (CASE WHEN @iIncludeColor=1 THEN PagesColor ELSE 0 END)
--				 ELSE 0 END)  PagesDuplex

			,SUM(CASE WHEN Color = 0 THEN Pages ELSE 0 END) AS PagesBW
			,SUM(CASE WHEN Color = 1 THEN Pages ELSE 0 END) AS PagesColor
			,SUM(CASE WHEN Duplex = 0 THEN Pages ELSE 0 END) AS PagesSimplex
			,SUM(CASE WHEN Duplex = 1 THEN Pages ELSE 0 END) AS PagesDuplex

			,SUM(Pages) PagesTotal
			,GROUPING(UserId) IsOtherRow
		FROM vw_report_jobs_detail_n j
		INNER JOIN tbl_report_queue_cache q
			ON j.QueueId = q.QueueId
		INNER JOIN @Regions r
			ON q.ParentRegionId = r.RegionId

--		INNER JOIN @SimplexDuplex d -- tar 12 sek att ha med denna. tar 0 sek att ha i WHERE-sats.
--			ON d.Duplex = j.Duplex

--		INNER JOIN @JobTypes jt -- tar 10 sek att ha med denna
--			ON j.JobType = jt.JobType

--		INNER JOIN @PrinterTypesBit pt
--			ON j.IsLocalPrinter = pt.IsLocalPrinter
		WHERE JobDate BETWEEN @iStartDate AND @iEndDate
		AND ((j.Duplex = 1 AND @iIncludeDuplex = 1)
				OR (j.Duplex =0 AND @iIncludeSimplex = 1))
		AND ((j.Color = 1 AND @iIncludeColor = 1)
				OR (j.Color =0 AND @iIncludeBW = 1))
		AND ((j.IsLocalPrinter = 1 AND @iIncludeLocal = 1)
				OR (j.IsLocalPrinter =0 AND @iIncludeNetwork = 1))
		AND ((j.JobType = 1 AND @iIncludePrint = 1)
			OR (j.JobType = 2 AND @iIncludeCopy = 1)
			OR (j.JobType = 3 AND @iIncludeFax = 1)
			OR (j.JobType = 4 AND @iIncludeScan = 1))
		AND ISNULL(@iPaperType,PaperType) = PaperType
		GROUP BY
			UserId WITH ROLLUP
		ORDER BY PagesTotal DESC)
	,Others (PagesBW, PagesColor, PagesSimplex, PagesDuplex, PagesTotal) AS
		(SELECT 
			 SUM(CASE WHEN IsOtherRow=1 THEN PagesBW ELSE -1*PagesBW END)
			,SUM(CASE WHEN IsOtherRow=1 THEN PagesColor ELSE -1*PagesColor END)
			,SUM(CASE WHEN IsOtherRow=1 THEN PagesSimplex ELSE -1*PagesSimplex END)
			,SUM(CASE WHEN IsOtherRow=1 THEN PagesDuplex ELSE -1*PagesDuplex END)
			,SUM(CASE WHEN IsOtherRow=1 THEN PagesTotal ELSE -1*PagesTotal END)
		FROM TopN)
	SELECT
		u.UserName
		,u.Domain
		,PagesBW
		,PagesColor
		,PagesSimplex
		,PagesDuplex
		,PagesTotal
		,IsOtherRow
	FROM TopN t
	INNER JOIN tbl_report_users u
		ON t.UserId = u.UserId
	WHERE IsOtherRow = 0
	UNION	
	SELECT
		NULL
		,NULL
		,PagesBW
		,PagesColor
		,PagesSimplex
		,PagesDuplex
		,PagesTotal
		,1 AS IsOtherRow
	FROM Others t

ORDER BY t.IsOtherRow ASC, t.PagesTotal DESC



--sp_report_top_users_pages @iIncludeBW = 0







	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO
IF OBJECT_ID('sp_report_user_get') IS NOT NULL
	DROP PROCEDURE sp_report_user_get
GO

CREATE PROCEDURE sp_report_user_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-24
Description: Get user id of a user in tbl_report_users. Option to create this user if non-existing 
************************************************************/
	@iUserName				nvarchar(510)
	,@iDomain				nvarchar(510)
	,@iCreateIfNotExists	bit = 1
	,@oUserId				int			OUTPUT
AS
BEGIN


	SELECT @oUserId = UserId
	FROM tbl_report_users
	WHERE UserName = @iUserName
	AND	Domain = @iDomain

	IF @oUserId IS NULL AND @iCreateIfNotExists = 1
	BEGIN
		INSERT tbl_report_users
		(UserName, Domain, RegDate)
		VALUES
		(@iUserName, @iDomain, getdate())

		SELECT @oUserId  = SCOPE_IDENTITY()

	END


	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO

IF OBJECT_ID('sp_report_user_get_details_by_id') IS NOT NULL
	DROP PROCEDURE sp_report_user_get_details_by_id
GO

CREATE PROCEDURE sp_report_user_get_details_by_id
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-05
Description: Get info about a user given the user id 
************************************************************/
	@iUserId				int			
AS
BEGIN


	IF NOT EXISTS(SELECT * FROM tbl_report_users
		WHERE UserId = @iUserId)
	RETURN (100080) --User does not exist


	SELECT * FROM tbl_report_users WHERE UserId = @iUserId


	RETURN (0)



END

GO

IF OBJECT_ID('sp_wallet_log_comment_get') IS NOT NULL
	DROP PROCEDURE sp_wallet_log_comment_get
GO

CREATE PROCEDURE sp_wallet_log_comment_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-24
Description: Add/get a comment for wallet log 
************************************************************/
	@iComment				nvarchar(512)
	,@iCreateIfNotExists	bit = 1
	,@oCommentId			int			OUTPUT
AS
BEGIN


	SELECT @oCommentId = CommentId
	FROM tbl_cirrato_wallet_log_comment
	WHERE Comment = @iComment

	IF @oCommentId IS NULL AND @iCreateIfNotExists = 1
	BEGIN
		INSERT tbl_cirrato_wallet_log_comment
		(Comment)
		VALUES
		(@iComment)

		SELECT @oCommentId  = SCOPE_IDENTITY()

	END


	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_get_date_info') IS NOT NULL
	DROP PROCEDURE sp_get_date_info
GO

CREATE PROCEDURE sp_get_date_info
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description:  Get information about a day
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iDate					datetime
	,@iFirstDayOfWeek		int = 1			-- vilken �r veckans f�rsta dag? 1 = m�ndag. SQL Server default �r annars 7 = s�ndag.
	,@oDayOfWeek			int				OUTPUT
	,@oDayOfMonth			int				OUTPUT
	,@oDayOfQuarter 		int				OUTPUT
	,@oDayOfHalfYear		int				OUTPUT
	,@oDayOfYear			int				OUTPUT
	,@oMonthDay				dt_monthday		OUTPUT
	,@oMonthNumber			int				OUTPUT


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET DATEFIRST @iFirstDayOfWeek -- SVERIGE dag1 = m�ndag. default �r annars 7 = s�ndag.


	declare @d datetime
			,@lastdayofyear datetime
			,@daysinyear int
			,@daysinfirsthalfyear int
			,@CurrentMonth int

	declare @currentYear char(4)


	set @d = @iDate
	--set @d = '20000101'

	--set @d = '20010630'
	--set @d = '20010701'

	--output
	declare
		@dayofweek int
		,@dayofmonth int
		,@dayofquarter int
		,@dayofhalfyear int
		,@dayofyear int

	SET @currentYear = left(convert(char(8), @d, 112), 4)
	SET @CurrentMonth = datepart (month, @d)

	SET @lastdayofyear = @currentYear + '1231'



	SELECT @dayofyear = datepart (dayofyear, @d) 

	SELECT @daysinyear = datepart (dayofyear, @lastdayofyear) 
	SELECT @daysinfirsthalfyear = @daysinyear - 184 -- andra halv�ret alltid 184 dagar


	if @dayofyear > @daysinfirsthalfyear
		set @dayofhalfyear = @dayofyear - @daysinfirsthalfyear
	else
		set @dayofhalfyear = @dayofyear

	set @dayofweek = datepart (weekday, @d) 

	declare @CurrentMonthFirstDay_Number int
			,@CurrentQuarterFirstDay_Number int
			,@CurrentMonthFirstDay datetime
			,@CurrentQuarterFirstDay datetime

	-- MONTH
	set @CurrentMonthFirstDay =  left(convert(char(8), @d, 112), 6) + '01'
	set @CurrentMonthFirstDay_Number = datepart(dayofyear, @CurrentMonthFirstDay)
	set @dayofmonth = @dayofyear - @CurrentMonthFirstDay_Number + 1


	-- QUARTER
	SET @CurrentQuarterFirstDay =
		CASE WHEN @CurrentMonth BETWEEN 1 AND 3 THEN @currentYear + '0101'
		 WHEN @CurrentMonth BETWEEN 4 AND 6 THEN @currentYear + '0401'
		 WHEN @CurrentMonth BETWEEN 7 AND 9 THEN @currentYear + '0701'
		 WHEN @CurrentMonth BETWEEN 10 AND 12 THEN @currentYear + '1001' END

	SET @CurrentQuarterFirstDay_Number = datepart(dayofyear, @CurrentQuarterFirstDay)
	set @dayofquarter = @dayofyear - @CurrentQuarterFirstDay_Number + 1



	-- OUTPUT RESULTS
--	select
--		@dayofweek dayofweek 
--		,@dayofmonth dayofmonth 
--		,@dayofquarter dayofquarter
--		,@dayofhalfyear dayofhalfyear
--		,@dayofyear dayofyear 
--	--	,@MonthDay
--	--	,@MonthNumber



	SELECT @oDayOfWeek		= @dayofweek	
		,@oDayOfMonth		= @dayofmonth
		,@oDayOfQuarter 	= @dayofquarter
		,@oDayOfHalfYear	= @dayofhalfyear
		,@oDayOfYear		= @dayofyear
		,@oMonthDay			= RIGHT(convert(char(8), @d, 112),4)
		,@oMonthNumber		= @CurrentMonth



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_rule_run_log_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_rule_run_log_ins
GO

CREATE PROCEDURE sp_cirrato_wallet_rule_run_log_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  Log daily loop error
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRuleId			int
	,@iRunDate			datetime		
	,@iRegDate			datetime = NULL
	,@iErrorNo			int


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF @iRegDate IS NULL
		SET @iRegDate = getdate()

	INSERT tbl_cirrato_wallet_rule_run_log
		(RuleId
		,RunDate
		,RegDate
		,ErrorNo)
	VALUES
		(@iRuleId
		,@iRunDate
		,@iRegDate
		,@iErrorNo)

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedules_get_active_by_day') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedules_get_active_by_day
GO

CREATE PROCEDURE sp_cirrato_wallet_schedules_get_active_by_day
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description:  Get all active schedules on a given day
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iDate					datetime
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF



	DECLARE 	
		@iFirstDayOfWeek		int 
		,@oDayOfWeek			int				
		,@oDayOfMonth			int				
		,@oDayOfQuarter 		int				
		,@oDayOfHalfYear		int				
		,@oDayOfYear			int				
		,@oMonthDay				dt_monthday		
		,@oMonthNumber			int				
		,@rs		int

	EXEC @ReturnStatus = sp_get_date_info
				@iDate				=	@iDate
				,@oDayOfWeek		=	@oDayOfWeek		OUTPUT
				,@oDayOfMonth		=	@oDayOfMonth	OUTPUT
				,@oDayOfQuarter		=	@oDayOfQuarter	OUTPUT
				,@oDayOfHalfYear	=	@oDayOfHalfYear OUTPUT
				,@oDayOfYear		=	@oDayOfYear		OUTPUT
				,@oMonthDay			=	@oMonthDay		OUTPUT
				,@oMonthNumber		=	@oMonthNumber	OUTPUT

	SET @ErrorNo = @@ERROR
	IF @ReturnStatus <> 0 RETURN (@ReturnStatus)
	IF @ErrorNo <> 0 RETURN (@ErrorNo)

--	SELECT
--		@rs	rs
--		,@oDayOfWeek		DayOfWeek
--		,@oDayOfMonth		DayOfMonth
--		,@oDayOfQuarter		DayOfQuarter
--		,@oDayOfHalfYear	DayOfHalfYear
--		,@oDayOfYear		DayOfYear
--		,@oMonthDay			MonthDay
--		,@oMonthNumber		MonthNumber


	DECLARE @Schedules TABLE (ScheduleId int, ScheduleTrigger varchar(10))

	DECLARE 
		@cScheduleId				int
		,@cPeriodicity				tinyint
		,@cOffsetType				tinyint
		,@cOffsetValue				int
		,@cPeriodStart				dt_monthday
		,@cPeriodEnd				dt_monthday
		,@DayOfChosenPeriodicity	int

--	-- simulera params fr�n schedule
--		--SET @cPeriodStart = '0901'
--		--SET @cPeriodEnd = '0715'
--		SET @cPeriodicity = 3 -- 0=daily,1=weekly,2=monthly,3=quarterly
--
--		SET @cOffsetType = 1 -- 0=dag, 1= m�n, 2 = tis, 3 = ons, 4 = tor, 5=fre, 6=l�r, 7=s�n
--		SET @cOffsetValue = 6 -- 3 = fj�rde m�ndagen
--	----------------------------------

	DECLARE curSchedules CURSOR FOR
	SELECT
		ScheduleId
		,Periodicity
		,OffsetType
		,OffsetValue
		,PeriodStart
		,PeriodEnd
	FROM tbl_cirrato_wallet_schedule WHERE IsDeleted = 0


	OPEN curSchedules

	FETCH NEXT FROM curSchedules INTO @cScheduleId, @cPeriodicity, @cOffsetType, @cOffsetValue, @cPeriodStart, @cPeriodEnd

	WHILE @@FETCH_STATUS = 0
	BEGIN
		---- CHECK ONE SCHEDULE -----
		IF @cPeriodicity = 0  SET @DayOfChosenPeriodicity = NULL -- occurs daily
		IF @cPeriodicity = 1  SET @DayOfChosenPeriodicity = @oDayOfWeek
		IF @cPeriodicity = 2  SET @DayOfChosenPeriodicity = @oDayOfMonth
		IF @cPeriodicity = 3  SET @DayOfChosenPeriodicity = @oDayOfQuarter
		IF @cPeriodicity = 4  SET @DayOfChosenPeriodicity = @oDayOfHalfYear
		IF @cPeriodicity = 5  SET @DayOfChosenPeriodicity = @oDayOfYear


		-- period check
		IF NOT (@oMonthDay BETWEEN ISNULL(@cPeriodStart,'0101') AND ISNULL(@cPeriodEnd,'1231'))
			GOTO FETCH_NEXT --print 'date out of period range SKIP TO NEXT SCHEDULE'


		IF @cPeriodicity IS NOT NULL
			BEGIN
			-- daily check
			IF @cPeriodicity = 0 
			BEGIN
				INSERT @Schedules VALUES(@cScheduleId, 'daily check')
				GOTO FETCH_NEXT --PRINT 'DAILY SCHEDULE. INSERT ROW AND GO TO NEXT SCHEDULE'
			END
			

			-- nth DAY check
			IF @cOffsetType = 0 AND @cOffsetValue = @DayOfChosenPeriodicity-1
			BEGIN
				INSERT @Schedules VALUES(@cScheduleId, 'nth day')
				GOTO FETCH_NEXT --PRINT 'nth day check ok. INSERT ROW AND GO TO NEXT SCHEDULE'
			END

			-- nth Monday/tue/etc check
			IF @oDayOfWeek = @cOffsetType -- 1 r�tt dag?
			BEGIN
				--PRINT 'correct day, check if it is the nth day'

				-- @DayOfChosenPeriodicity = vilket dagnummer �r det idag?

				-- 2 r�tt nummer i ordningen?
				--today is nth. n = 
				--SELECT @DayOfChosenPeriodicity / 7 AS nthDay


				IF @cOffsetValue = @DayOfChosenPeriodicity / 7
					INSERT @Schedules VALUES(@cScheduleId, 'nth mon,tue') -- PRINT 'nth day. INSERT ROW AND GO TO NEXT SCHEDULE'
	--			ELSE
	--				PRINT 'not nth day. SKIP TO NEXT SCHEDULE'

			END
		END -- end @cPeriodicity IS NOT NULL


		-- Custom Dates Check
		IF @cPeriodicity IS NULL
			IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_schedule_days WHERE MonthDay = @oMonthDay AND ScheduleId = @cScheduleId)
				INSERT @Schedules VALUES(@cScheduleId, 'custom')

		---- CHECK ONE SCHEDULE END -----
		FETCH_NEXT:
		FETCH NEXT FROM curSchedules INTO @cScheduleId, @cPeriodicity, @cOffsetType, @cOffsetValue, @cPeriodStart, @cPeriodEnd
	END

	CLOSE curSchedules
	DEALLOCATE curSchedules

	-- Return list
	SELECT ScheduleId FROM @Schedules


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO
IF OBJECT_ID('sp_cirrato_wallet_user_add_balance') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_user_add_balance
GO

CREATE PROCEDURE sp_cirrato_wallet_user_add_balance
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description:  Add balance to list of users
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-10
Description: Added more event types
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-13
Description: Exclude deleted users from
************************************************************/
	@iAmount				float = NULL
	,@iMultiplier			float = NULL
	,@iRuleId				int		= NULL		-- dessa ska anv�ndas f�r loggning och felrapportering
	,@iRunDate				datetime = NULL
	,@iFirstRun				bit = 0				-- if 1, only apply rule to users with tbl_cirrato_wallet.firstRun = NULL
	,@iComment				nvarchar(512) = NULL
	,@iUnDeleteUsers		bit = 0				-- if true, set IsDeleted = 0 for users. (used in webgui when adding user)
AS
BEGIN

	--	wEvent status types
	--	0 = job
	--	10 = add money [old webgui]
	--	11 = subtract money [old webgui]
	--	50 = batch run
	--	51 = initial balance (batch, ocks�)
	--	52 = manual adjustment
	--	98 = user created
	--	99 = user was deleted

	DECLARE	@ReturnStatus			int

	IF (@iAmount IS NULL AND @iMultiplier IS NULL)
			OR (@iAmount IS NOT NULL AND @iMultiplier IS NOT NULL)
		RETURN (100225) --	Either amount OR multiplier must be specified, not both.

	IF object_id('tempdb..#users') IS NULL
		RETURN (100201) --	This procedure must be called after creating temp table #users


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE @CommentId int
			,@TicketIdReplacement varchar(64)

	IF @iComment IS NOT NULL
	EXEC @ReturnStatus = sp_wallet_log_comment_get	@iComment = @iComment
													,@iCreateIfNotExists = 1
													,@oCommentId = @CommentId OUTPUT


	-- Log which users are new - so we can set Event accordingly
	--------------------------------------------------------------
	DECLARE @NewUsers TABLE (UserId int)
	-- New rows (to be created below)
	INSERT @NewUsers
	SELECT
		u.UserId
	FROM tbl_report_users u
	INNER JOIN #users u1
		ON u.UserId = u1.UserId
	LEFT JOIN tbl_cirrato_wallet w
		ON wUser = u.UserName
		AND wDomain = u.Domain
	WHERE w.wUser IS NULL

	-- create rows for Undeleted users

	INSERT @NewUsers
	SELECT wUserId
	FROM tbl_cirrato_wallet w
		INNER JOIN #users u1
			ON w.wUserId = u1.UserId
	WHERE w.IsDeleted = 1

	-- End log new users --
	-----------------------------------------------------------------


	IF @iFirstRun = 1
		DELETE #users WHERE UserId IN
		(SELECT u1.UserId 
		FROM #users u1
		INNER JOIN tbl_report_users  u2
			ON u1.UserId = u2.UserId
		INNER JOIN tbl_cirrato_wallet w
			ON w.wUser = u2.UserName
			AND w.wDomain = u2.Domain
		WHERE w.firstRun IS NOT NULL)

	IF @iUnDeleteUsers = 1
		UPDATE w
			SET IsDeleted = 0
		FROM tbl_cirrato_wallet w
		INNER JOIN #users u1
			ON w.wUserId = u1.UserId


	-- for each user,
		-- get username/domain from tbl_report_users
		-- create row in tbl_wallet if not exists
		-- update this row
		-- add row to tbl_cirrato_wallet_log

	IF @iRuleId IS NOT NULL
		SET @TicketIdReplacement = 'Batch run'
	ELSE
		SET @TicketIdReplacement = 'Manual adjustment'
	


	DECLARE @Event int
	SET @Event = 50	-- Batch run
	IF @iFirstRun = 1 SET @Event = 51	-- Initial balance
	IF @iRuleId IS NULL SET @Event = 52 -- Manual adjustment




	-- create rows for users not already in wallet
	INSERT tbl_cirrato_wallet
		(wUser
		,wDomain)
	SELECT
		u.UserName
		,u.Domain
	FROM tbl_report_users u
	INNER JOIN #users u1
		ON u.UserId = u1.UserId
	LEFT JOIN tbl_cirrato_wallet w
		ON wUser = u.UserName
		AND wDomain = u.Domain
	WHERE w.wUser IS NULL




	-- update rows & add log rows

	DECLARE @cUserId	int
			,@cUserName	nvarchar(510)
			,@cDomain	nvarchar(510)
			,@cNewUserId int
			,@ErrorNo	int
			,@NewBalance	float
			,@OldBalance	float


	DECLARE curUsers CURSOR FAST_FORWARD FOR
	SELECT
		u1.UserId
		,u.UserName
		,u.Domain
		,NewUsers.UserId
	FROM tbl_report_users u
	INNER JOIN #users u1
		ON u.UserId = u1.UserId
	INNER JOIN tbl_cirrato_wallet w
		ON w.wUserId = u1.UserId
		AND w.IsDeleted = 0
	LEFT JOIN @NewUsers NewUsers
		ON u1.UserId = NewUsers.UserId

	OPEN curUsers

	FETCH NEXT FROM curUsers INTO @cUserId, @cUserName, @cDomain, @cNewUserId

	WHILE @@FETCH_STATUS = 0
	BEGIN

		BEGIN TRANSACTION WalletTrans

			SELECT @OldBalance = wTotal FROM tbl_cirrato_wallet WHERE wUser = @cUserName AND wDomain = @cDomain

			-- Update balance
			IF @iAmount IS NOT NULL
			BEGIN
				UPDATE tbl_cirrato_wallet SET wTotal = wTotal + @iAmount WHERE wUser = @cUserName AND wDomain = @cDomain
				SET @ErrorNo = @@ERROR
				IF @ErrorNo <> 0 GOTO ERR
			END

			IF @iMultiplier IS NOT NULL
			BEGIN
				UPDATE tbl_cirrato_wallet SET wTotal = wTotal * @iMultiplier WHERE wUser = @cUserName AND wDomain = @cDomain
				SET @ErrorNo = @@ERROR
				IF @ErrorNo <> 0 GOTO ERR
			END

			SELECT @NewBalance = wTotal FROM tbl_cirrato_wallet WHERE wUser = @cUserName AND wDomain = @cDomain
			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 GOTO ERR

			-- Log operation
			INSERT tbl_cirrato_wallet_log
				(wLogId
				,wLogTicketId
				,wLogUser
				,wLogDomain
				,wLogDate
				,wLogTransDate
				,wLogTransAmount
				,wLogEvent
				,wRuleId
				,wRuleRunDate
				,wCommentId)
			VALUES
				(newid()
				,@TicketIdReplacement
				,@cUserName
				,@cDomain
				,getdate()
				,getdate()
				,@NewBalance - @OldBalance -- wLogTransAmount
				,CASE WHEN @cNewUserId IS NOT NULL THEN 98 ELSE @Event END --wLogEvent
				,@iRuleId
				,@iRunDate
				,@CommentId)
			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 GOTO ERR

		COMMIT TRANSACTION WalletTrans
		GOTO FETCH_NEXT

		ERR: 
		ROLLBACK TRANSACTION WalletTrans
		INSERT  tbl_cirrato_wallet_error
			(UserId
			,RuleId
			,RunDate
			,RegDate
			,Amount
			,Multiplier
			,ErrorNo)
		VALUES
			(@cUserId
			,@iRuleId
			,@iRunDate
			,getdate()
			,@iAmount
			,@iMultiplier
			,@ErrorNo)
	
		--
		
		FETCH_NEXT:
		FETCH NEXT FROM curUsers INTO @cUserId, @cUserName, @cDomain, @cNewUserId
	END

	CLOSE curUsers
	DEALLOCATE curUsers


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_umbrella_add_balance') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_umbrella_add_balance
GO

CREATE PROCEDURE sp_cirrato_wallet_umbrella_add_balance
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description: Add balance to all members of an umbrella 
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-24
Description: Updated with support for graph group structure
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUmbrellaId			int		
	,@iAmount				float = NULL
	,@iMultiplier			float = NULL
	,@iRuleId				int		= NULL		-- dessa ska anv�ndas f�r loggning och felrapportering
	,@iRunDate				datetime = NULL
	,@iFirstRun				bit = 0	
	,@iComment				nvarchar(512) = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
		,@CurrentTimestamp			datetime
		,@ErrorNo					int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM tbl_report_group_umbrella
		WHERE @CurrentTimestamp BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
		AND IsDeleted = 0)
	RETURN (100300) --	Umbrella does not exist


	-- Build list of users in Umbrella and put in temp table, then call procedure to assign quotas 

	CREATE TABLE #users (UserId int)

	EXEC @ReturnStatus = sp_cirrato_wallet_umbrella_get_users
		@iUmbrellaId		= @iUmbrellaId
		,@iCrossUmbrella	= 1
		,@iSilent			= 1

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance @iAmount			= @iAmount
															,@iMultiplier		= @iMultiplier
															,@iRuleId			= @iRuleId
															,@iRunDate			= @iRunDate
															,@iFirstRun			= @iFirstRun
															,@iComment			= @iComment

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_group_add_balance') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_group_add_balance
GO

CREATE PROCEDURE sp_cirrato_wallet_group_add_balance
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description: Add balance to all members of a group 
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-24
Description: Updated with support for graph group structure
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupId				int		
	,@iAmount				float = NULL
	,@iMultiplier			float = NULL
	,@iRuleId				int		= NULL		-- dessa ska anv�ndas f�r loggning och felrapportering
	,@iRunDate				datetime = NULL
	,@iFirstRun				bit = 0	
	,@iComment				nvarchar(512) = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
		,@CurrentTimestamp			datetime
		,@ErrorNo					int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM tbl_report_group
		WHERE @CurrentTimestamp BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
		AND IsDeleted = 0)
	RETURN (100301) --	Group does not exist


	-- Build list of users in group and subgroups, and put in temp table, then call procedure to assign quotas 

	CREATE TABLE #users (UserId int)

	EXEC @ReturnStatus = sp_cirrato_wallet_group_get_users
		@iGroupId = @iGroupId
		,@iRecursive = 1
		,@iCrossUmbrella = 1
		,@iSilent = 1


	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR



	EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance @iAmount			= @iAmount
															,@iMultiplier		= @iMultiplier
															,@iRuleId			= @iRuleId
															,@iRunDate			= @iRunDate
															,@iFirstRun			= @iFirstRun
															,@iComment			= @iComment

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_batch_day_do') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_batch_day_do
GO

CREATE PROCEDURE sp_cirrato_wallet_batch_day_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description:  
------------------------------------------------------------
Modified by: Execute all quota rules scheduled to run on a given day
Modification date:
Description:
************************************************************/
	@iDate			datetime
	,@iOnlyInitialBalance bit = 0

AS
BEGIN

	DECLARE	@ReturnStatus			int
		--	,@CurrentTimestamp datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	--SET @CurrentTimestamp  = getdate()

DECLARE	@cRuleId				int	
		,@cUmbrellaId			int		
		,@cGroupId				int	
		,@cAmount				float 
		,@cMultiplier			float 


	---------------------------------------------------------------------------------------------
	-- NEW USER RULES
	---------------------------------------------------------------------------------------------

	-- 1 cursor, alla rule med ScheduleId = NULL, order by SortOrder
	-- anropa GroupAdd / UmbrellaAdd med @iFirstRun = 1
	-- UPDATE tbl_cirrato_wallet SET firstRun = @iDate WHERE firstRun IS NULL

	DECLARE curRules CURSOR FOR
		SELECT RuleId, UmbrellaId, GroupId, Amount, Multiplier FROM tbl_cirrato_wallet_rule 
		WHERE ScheduleId IS NULL 
			AND @iDate BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
			AND IsDeleted = 0
		ORDER BY SortOrder

	OPEN curRules
	FETCH NEXT FROM curRules INTO @cRuleId, @cUmbrellaId, @cGroupId, @cAmount, @cMultiplier
	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_rule_run_log WHERE RuleId = @cRuleId AND RunDate = @iDate)
		BEGIN
			SET @ReturnStatus = 100202	--Rule has already been executed on given day
			GOTO LOG_INS_10
		END	

		IF @cUmbrellaId IS NOT NULL
			EXEC @ReturnStatus = sp_cirrato_wallet_umbrella_add_balance
				@iUmbrellaId	= @cUmbrellaId
				,@iAmount		= @cAmount
				,@iMultiplier	= @cMultiplier
				,@iRuleId		= @cRuleId
				,@iRunDate		= @iDate
				,@iFirstRun		= 1
		ELSE
			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance
				@iGroupId	= @cGroupId
				,@iAmount		= @cAmount
				,@iMultiplier	= @cMultiplier
				,@iRuleId		= @cRuleId
				,@iRunDate		= @iDate
				,@iFirstRun		= 1

		LOG_INS_10:
		EXEC sp_cirrato_wallet_rule_run_log_ins	@iRuleId	= @cRuleId
													,@iRunDate	= @iDate
													,@iErrorNo	= @ReturnStatus

		FETCH NEXT FROM curRules INTO @cRuleId, @cUmbrellaId, @cGroupId, @cAmount, @cMultiplier
	END
	CLOSE curRules
	DEALLOCATE curRules

	UPDATE tbl_cirrato_wallet SET firstRun = @iDate WHERE firstRun IS NULL


	---------------------------------------------------------------------------------------------
	-- REGULAR RULES
	---------------------------------------------------------------------------------------------

	IF @iOnlyInitialBalance = 1 GOTO PROC_END

	-- 2a get active schedules for day
	DECLARE @Schedules TABLE (ScheduleId int)

	INSERT @Schedules
	EXEC @ReturnStatus = sp_cirrato_wallet_schedules_get_active_by_day @iDate = @iDate

	-- 2b match with rules [check start-, enddate, IsDeleted]
		-- cursor med rules: obs! order by SortOrder
			-- sp_cirrato_wallet_umbrella_add_balance eller sp_wallet_group_add_balance
				-- sp_wallet_user_add_balance (userid ELLER username, domain)

	DECLARE curRules CURSOR FOR
		SELECT RuleId, UmbrellaId, GroupId, Amount, Multiplier 
		FROM tbl_cirrato_wallet_rule r
		INNER JOIN @Schedules s
			ON r.ScheduleId = s.ScheduleId
		WHERE
			@iDate BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
			AND IsDeleted = 0
		ORDER BY SortOrder

	OPEN curRules
	FETCH NEXT FROM curRules INTO @cRuleId, @cUmbrellaId, @cGroupId, @cAmount, @cMultiplier
	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_rule_run_log WHERE RuleId = @cRuleId AND RunDate = @iDate)
		BEGIN
			SET @ReturnStatus = 100202	--Rule has already been executed on given day
			GOTO LOG_INS_20
		END	

		IF @cUmbrellaId IS NOT NULL
			EXEC @ReturnStatus = sp_cirrato_wallet_umbrella_add_balance
				@iUmbrellaId	= @cUmbrellaId
				,@iAmount		= @cAmount
				,@iMultiplier	= @cMultiplier
				,@iRuleId		= @cRuleId
				,@iRunDate		= @iDate
				,@iFirstRun		= 0
		ELSE
			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance
				@iGroupId	= @cGroupId
				,@iAmount		= @cAmount
				,@iMultiplier	= @cMultiplier
				,@iRuleId		= @cRuleId
				,@iRunDate		= @iDate
				,@iFirstRun		= 0

		LOG_INS_20:
		EXEC sp_cirrato_wallet_rule_run_log_ins	@iRuleId	= @cRuleId
													,@iRunDate	= @iDate
													,@iErrorNo	= @ReturnStatus


		FETCH NEXT FROM curRules INTO @cRuleId, @cUmbrellaId, @cGroupId, @cAmount, @cMultiplier
	END
	CLOSE curRules
	DEALLOCATE curRules





	-- 3: KOPIA P� STEG 1



	-- 3 end

	PROC_END:

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_batch_do') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_batch_do
GO

CREATE PROCEDURE sp_cirrato_wallet_batch_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iParam1			int		= 0


AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int
	DECLARE @LastRun				datetime 
			,@Today					datetime
			,@CurrentRun			datetime

	SELECT @ErrorNo = 0, @ReturnStatus = 0

	SET @LastRun	= dbo.fn_property_get_date_by_group('CirratoWallet', 'LastRun')
	SET @Today		= convert(char(8), getdate(), 112)

	IF @Today <= @LastRun
	BEGIN
		SET @ErrorNo = 100200	-- Wallet batch has already been run (try again tomorrow)
		GOTO PROC_ERROR
	END


	-- Loop through all days that need to be run
	SET @CurrentRun = DATEADD(d, 1, @LastRun) 

	WHILE @CurrentRun <= @Today
	BEGIN

		EXEC @ReturnStatus = sp_cirrato_wallet_batch_day_do @iDate = @CurrentRun
		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 OR @ReturnStatus <> 0
			GOTO PROC_ERROR


		EXEC @ReturnStatus = sp_property_upd	@ipropertyGroup			= 'CirratoWallet'
												,@ipropertyName			= 'LastRun'
												,@ipropertyValueDate	= @CurrentRun
		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 OR @ReturnStatus <> 0
			GOTO PROC_ERROR



		SET @CurrentRun = DATEADD(d, 1, @CurrentRun) 
	END



	RETURN (0)


PROC_ERROR:

	IF @ErrorNo = 0
		SET @ErrorNo = @ReturnStatus

	RAISERROR(@ErrorNo, 16, 1)

	RETURN(@ErrorNo)

END
GO

IF OBJECT_ID('sp_cirrato_wallet_batch_day_do') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_batch_day_do
GO

CREATE PROCEDURE sp_cirrato_wallet_batch_day_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description:  
------------------------------------------------------------
Modified by: Execute all quota rules scheduled to run on a given day
Modification date:
Description:
************************************************************/
	@iDate			datetime
	,@iOnlyInitialBalance bit = 0

AS
BEGIN

	DECLARE	@ReturnStatus			int
		--	,@CurrentTimestamp datetime


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	--SET @CurrentTimestamp  = getdate()

DECLARE	@cRuleId				int	
		,@cUmbrellaId			int		
		,@cGroupId				int	
		,@cAmount				float 
		,@cMultiplier			float 


	---------------------------------------------------------------------------------------------
	-- NEW USER RULES
	---------------------------------------------------------------------------------------------

	-- 1 cursor, alla rule med ScheduleId = NULL, order by SortOrder
	-- anropa GroupAdd / UmbrellaAdd med @iFirstRun = 1
	-- UPDATE tbl_cirrato_wallet SET firstRun = @iDate WHERE firstRun IS NULL

	DECLARE curRules CURSOR FOR
		SELECT RuleId, UmbrellaId, GroupId, Amount, Multiplier FROM tbl_cirrato_wallet_rule 
		WHERE ScheduleId IS NULL 
			AND @iDate BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
			AND IsDeleted = 0
		ORDER BY SortOrder

	OPEN curRules
	FETCH NEXT FROM curRules INTO @cRuleId, @cUmbrellaId, @cGroupId, @cAmount, @cMultiplier
	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_rule_run_log WHERE RuleId = @cRuleId AND RunDate = @iDate)
		BEGIN
			SET @ReturnStatus = 100202	--Rule has already been executed on given day
			GOTO LOG_INS_10
		END	

		IF @cUmbrellaId IS NOT NULL
			EXEC @ReturnStatus = sp_cirrato_wallet_umbrella_add_balance
				@iUmbrellaId	= @cUmbrellaId
				,@iAmount		= @cAmount
				,@iMultiplier	= @cMultiplier
				,@iRuleId		= @cRuleId
				,@iRunDate		= @iDate
				,@iFirstRun		= 1
		ELSE
			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance
				@iGroupId	= @cGroupId
				,@iAmount		= @cAmount
				,@iMultiplier	= @cMultiplier
				,@iRuleId		= @cRuleId
				,@iRunDate		= @iDate
				,@iFirstRun		= 1

		LOG_INS_10:
		EXEC sp_cirrato_wallet_rule_run_log_ins	@iRuleId	= @cRuleId
													,@iRunDate	= @iDate
													,@iErrorNo	= @ReturnStatus

		FETCH NEXT FROM curRules INTO @cRuleId, @cUmbrellaId, @cGroupId, @cAmount, @cMultiplier
	END
	CLOSE curRules
	DEALLOCATE curRules

	UPDATE tbl_cirrato_wallet SET firstRun = @iDate WHERE firstRun IS NULL


	---------------------------------------------------------------------------------------------
	-- REGULAR RULES
	---------------------------------------------------------------------------------------------

	IF @iOnlyInitialBalance = 1 GOTO PROC_END

	-- 2a get active schedules for day
	DECLARE @Schedules TABLE (ScheduleId int)

	INSERT @Schedules
	EXEC @ReturnStatus = sp_cirrato_wallet_schedules_get_active_by_day @iDate = @iDate

	-- 2b match with rules [check start-, enddate, IsDeleted]
		-- cursor med rules: obs! order by SortOrder
			-- sp_cirrato_wallet_umbrella_add_balance eller sp_wallet_group_add_balance
				-- sp_wallet_user_add_balance (userid ELLER username, domain)

	DECLARE curRules CURSOR FOR
		SELECT RuleId, UmbrellaId, GroupId, Amount, Multiplier 
		FROM tbl_cirrato_wallet_rule r
		INNER JOIN @Schedules s
			ON r.ScheduleId = s.ScheduleId
		WHERE
			@iDate BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
			AND IsDeleted = 0
		ORDER BY SortOrder

	OPEN curRules
	FETCH NEXT FROM curRules INTO @cRuleId, @cUmbrellaId, @cGroupId, @cAmount, @cMultiplier
	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_rule_run_log WHERE RuleId = @cRuleId AND RunDate = @iDate)
		BEGIN
			SET @ReturnStatus = 100202	--Rule has already been executed on given day
			GOTO LOG_INS_20
		END	

		IF @cUmbrellaId IS NOT NULL
			EXEC @ReturnStatus = sp_cirrato_wallet_umbrella_add_balance
				@iUmbrellaId	= @cUmbrellaId
				,@iAmount		= @cAmount
				,@iMultiplier	= @cMultiplier
				,@iRuleId		= @cRuleId
				,@iRunDate		= @iDate
				,@iFirstRun		= 0
		ELSE
			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance
				@iGroupId	= @cGroupId
				,@iAmount		= @cAmount
				,@iMultiplier	= @cMultiplier
				,@iRuleId		= @cRuleId
				,@iRunDate		= @iDate
				,@iFirstRun		= 0

		LOG_INS_20:
		EXEC sp_cirrato_wallet_rule_run_log_ins	@iRuleId	= @cRuleId
													,@iRunDate	= @iDate
													,@iErrorNo	= @ReturnStatus


		FETCH NEXT FROM curRules INTO @cRuleId, @cUmbrellaId, @cGroupId, @cAmount, @cMultiplier
	END
	CLOSE curRules
	DEALLOCATE curRules





	-- 3: KOPIA P� STEG 1



	-- 3 end

	PROC_END:

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_batch_do') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_batch_do
GO

CREATE PROCEDURE sp_cirrato_wallet_batch_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iParam1			int		= 0


AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int
	DECLARE @LastRun				datetime 
			,@Today					datetime
			,@CurrentRun			datetime

	SELECT @ErrorNo = 0, @ReturnStatus = 0

	SET @LastRun	= dbo.fn_property_get_date_by_group('CirratoWallet', 'LastRun')
	SET @Today		= convert(char(8), getdate(), 112)

	IF @Today <= @LastRun
	BEGIN
		SET @ErrorNo = 100200	-- Wallet batch has already been run (try again tomorrow)
		GOTO PROC_ERROR
	END


	-- Loop through all days that need to be run
	SET @CurrentRun = DATEADD(d, 1, @LastRun) 

	WHILE @CurrentRun <= @Today
	BEGIN

		EXEC @ReturnStatus = sp_cirrato_wallet_batch_day_do @iDate = @CurrentRun
		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 OR @ReturnStatus <> 0
			GOTO PROC_ERROR


		EXEC @ReturnStatus = sp_property_upd	@ipropertyGroup			= 'CirratoWallet'
												,@ipropertyName			= 'LastRun'
												,@ipropertyValueDate	= @CurrentRun
		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 OR @ReturnStatus <> 0
			GOTO PROC_ERROR



		SET @CurrentRun = DATEADD(d, 1, @CurrentRun) 
	END



	RETURN (0)


PROC_ERROR:

	IF @ErrorNo = 0
		SET @ErrorNo = @ReturnStatus

	RAISERROR(@ErrorNo, 16, 1)

	RETURN(@ErrorNo)

END
GO

IF OBJECT_ID('sp_cirrato_wallet_group_add_balance') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_group_add_balance
GO

CREATE PROCEDURE sp_cirrato_wallet_group_add_balance
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description: Add balance to all members of a group 
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-24
Description: Updated with support for graph group structure
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupId				int		
	,@iAmount				float = NULL
	,@iMultiplier			float = NULL
	,@iRuleId				int		= NULL		-- dessa ska anv�ndas f�r loggning och felrapportering
	,@iRunDate				datetime = NULL
	,@iFirstRun				bit = 0	
	,@iComment				nvarchar(512) = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
		,@CurrentTimestamp			datetime
		,@ErrorNo					int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM tbl_report_group
		WHERE @CurrentTimestamp BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
		AND IsDeleted = 0)
	RETURN (100301) --	Group does not exist


	-- Build list of users in group and subgroups, and put in temp table, then call procedure to assign quotas 

	CREATE TABLE #users (UserId int)

	EXEC @ReturnStatus = sp_cirrato_wallet_group_get_users
		@iGroupId = @iGroupId
		,@iRecursive = 1
		,@iCrossUmbrella = 1
		,@iSilent = 1


	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR



	EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance @iAmount			= @iAmount
															,@iMultiplier		= @iMultiplier
															,@iRuleId			= @iRuleId
															,@iRunDate			= @iRunDate
															,@iFirstRun			= @iFirstRun
															,@iComment			= @iComment

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_init_balance_adhoc_do') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_init_balance_adhoc_do
GO

CREATE PROCEDURE sp_cirrato_wallet_init_balance_adhoc_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-24
Description: Re-run today's initial balance jobs, only adding balance to users not already having received an initial balance
------------------------------------------------------------
Modified by: 
Modification date:
Description:
************************************************************/
	--@iParam1			int		= 0


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE @Today					datetime


	SET @Today		= convert(char(8), getdate(), 112)


	--Deletet today's initial balance rule logs

	DELETE tbl_cirrato_wallet_rule_run_log WHERE 
		RuleId IN (SELECT RuleId FROM tbl_cirrato_wallet_rule 
					WHERE ScheduleId IS NULL 
						AND @Today BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
						AND IsDeleted = 0)
		AND RunDate = @Today



	EXEC @ReturnStatus = sp_cirrato_wallet_batch_day_do @iDate = @Today
														,@iOnlyInitialBalance = 1


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_rule_run_log_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_rule_run_log_ins
GO

CREATE PROCEDURE sp_cirrato_wallet_rule_run_log_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  Log daily loop error
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRuleId			int
	,@iRunDate			datetime		
	,@iRegDate			datetime = NULL
	,@iErrorNo			int


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF @iRegDate IS NULL
		SET @iRegDate = getdate()

	INSERT tbl_cirrato_wallet_rule_run_log
		(RuleId
		,RunDate
		,RegDate
		,ErrorNo)
	VALUES
		(@iRuleId
		,@iRunDate
		,@iRegDate
		,@iErrorNo)

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedules_get_active_by_day') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedules_get_active_by_day
GO

CREATE PROCEDURE sp_cirrato_wallet_schedules_get_active_by_day
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description:  Get all active schedules on a given day
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iDate					datetime
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF



	DECLARE 	
		@iFirstDayOfWeek		int 
		,@oDayOfWeek			int				
		,@oDayOfMonth			int				
		,@oDayOfQuarter 		int				
		,@oDayOfHalfYear		int				
		,@oDayOfYear			int				
		,@oMonthDay				dt_monthday		
		,@oMonthNumber			int				
		,@rs		int

	EXEC @ReturnStatus = sp_get_date_info
				@iDate				=	@iDate
				,@oDayOfWeek		=	@oDayOfWeek		OUTPUT
				,@oDayOfMonth		=	@oDayOfMonth	OUTPUT
				,@oDayOfQuarter		=	@oDayOfQuarter	OUTPUT
				,@oDayOfHalfYear	=	@oDayOfHalfYear OUTPUT
				,@oDayOfYear		=	@oDayOfYear		OUTPUT
				,@oMonthDay			=	@oMonthDay		OUTPUT
				,@oMonthNumber		=	@oMonthNumber	OUTPUT

	SET @ErrorNo = @@ERROR
	IF @ReturnStatus <> 0 RETURN (@ReturnStatus)
	IF @ErrorNo <> 0 RETURN (@ErrorNo)

--	SELECT
--		@rs	rs
--		,@oDayOfWeek		DayOfWeek
--		,@oDayOfMonth		DayOfMonth
--		,@oDayOfQuarter		DayOfQuarter
--		,@oDayOfHalfYear	DayOfHalfYear
--		,@oDayOfYear		DayOfYear
--		,@oMonthDay			MonthDay
--		,@oMonthNumber		MonthNumber


	DECLARE @Schedules TABLE (ScheduleId int, ScheduleTrigger varchar(10))

	DECLARE 
		@cScheduleId				int
		,@cPeriodicity				tinyint
		,@cOffsetType				tinyint
		,@cOffsetValue				int
		,@cPeriodStart				dt_monthday
		,@cPeriodEnd				dt_monthday
		,@DayOfChosenPeriodicity	int

--	-- simulera params fr�n schedule
--		--SET @cPeriodStart = '0901'
--		--SET @cPeriodEnd = '0715'
--		SET @cPeriodicity = 3 -- 0=daily,1=weekly,2=monthly,3=quarterly
--
--		SET @cOffsetType = 1 -- 0=dag, 1= m�n, 2 = tis, 3 = ons, 4 = tor, 5=fre, 6=l�r, 7=s�n
--		SET @cOffsetValue = 6 -- 3 = fj�rde m�ndagen
--	----------------------------------

	DECLARE curSchedules CURSOR FOR
	SELECT
		ScheduleId
		,Periodicity
		,OffsetType
		,OffsetValue
		,PeriodStart
		,PeriodEnd
	FROM tbl_cirrato_wallet_schedule WHERE IsDeleted = 0


	OPEN curSchedules

	FETCH NEXT FROM curSchedules INTO @cScheduleId, @cPeriodicity, @cOffsetType, @cOffsetValue, @cPeriodStart, @cPeriodEnd

	WHILE @@FETCH_STATUS = 0
	BEGIN
		---- CHECK ONE SCHEDULE -----
		IF @cPeriodicity = 0  SET @DayOfChosenPeriodicity = NULL -- occurs daily
		IF @cPeriodicity = 1  SET @DayOfChosenPeriodicity = @oDayOfWeek
		IF @cPeriodicity = 2  SET @DayOfChosenPeriodicity = @oDayOfMonth
		IF @cPeriodicity = 3  SET @DayOfChosenPeriodicity = @oDayOfQuarter
		IF @cPeriodicity = 4  SET @DayOfChosenPeriodicity = @oDayOfHalfYear
		IF @cPeriodicity = 5  SET @DayOfChosenPeriodicity = @oDayOfYear


		-- period check
		IF NOT (@oMonthDay BETWEEN ISNULL(@cPeriodStart,'0101') AND ISNULL(@cPeriodEnd,'1231'))
			GOTO FETCH_NEXT --print 'date out of period range SKIP TO NEXT SCHEDULE'


		IF @cPeriodicity IS NOT NULL
			BEGIN
			-- daily check
			IF @cPeriodicity = 0 
			BEGIN
				INSERT @Schedules VALUES(@cScheduleId, 'daily check')
				GOTO FETCH_NEXT --PRINT 'DAILY SCHEDULE. INSERT ROW AND GO TO NEXT SCHEDULE'
			END
			

			-- nth DAY check
			IF @cOffsetType = 0 AND @cOffsetValue = @DayOfChosenPeriodicity-1
			BEGIN
				INSERT @Schedules VALUES(@cScheduleId, 'nth day')
				GOTO FETCH_NEXT --PRINT 'nth day check ok. INSERT ROW AND GO TO NEXT SCHEDULE'
			END

			-- nth Monday/tue/etc check
			IF @oDayOfWeek = @cOffsetType -- 1 r�tt dag?
			BEGIN
				--PRINT 'correct day, check if it is the nth day'

				-- @DayOfChosenPeriodicity = vilket dagnummer �r det idag?

				-- 2 r�tt nummer i ordningen?
				--today is nth. n = 
				--SELECT @DayOfChosenPeriodicity / 7 AS nthDay


				IF @cOffsetValue = @DayOfChosenPeriodicity / 7
					INSERT @Schedules VALUES(@cScheduleId, 'nth mon,tue') -- PRINT 'nth day. INSERT ROW AND GO TO NEXT SCHEDULE'
	--			ELSE
	--				PRINT 'not nth day. SKIP TO NEXT SCHEDULE'

			END
		END -- end @cPeriodicity IS NOT NULL


		-- Custom Dates Check
		IF @cPeriodicity IS NULL
			IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_schedule_days WHERE MonthDay = @oMonthDay AND ScheduleId = @cScheduleId)
				INSERT @Schedules VALUES(@cScheduleId, 'custom')

		---- CHECK ONE SCHEDULE END -----
		FETCH_NEXT:
		FETCH NEXT FROM curSchedules INTO @cScheduleId, @cPeriodicity, @cOffsetType, @cOffsetValue, @cPeriodStart, @cPeriodEnd
	END

	CLOSE curSchedules
	DEALLOCATE curSchedules

	-- Return list
	SELECT ScheduleId FROM @Schedules


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_umbrella_add_balance') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_umbrella_add_balance
GO

CREATE PROCEDURE sp_cirrato_wallet_umbrella_add_balance
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description: Add balance to all members of an umbrella 
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-24
Description: Updated with support for graph group structure
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUmbrellaId			int		
	,@iAmount				float = NULL
	,@iMultiplier			float = NULL
	,@iRuleId				int		= NULL		-- dessa ska anv�ndas f�r loggning och felrapportering
	,@iRunDate				datetime = NULL
	,@iFirstRun				bit = 0	
	,@iComment				nvarchar(512) = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
		,@CurrentTimestamp			datetime
		,@ErrorNo					int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM tbl_report_group_umbrella
		WHERE @CurrentTimestamp BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
		AND IsDeleted = 0)
	RETURN (100300) --	Umbrella does not exist


	-- Build list of users in Umbrella and put in temp table, then call procedure to assign quotas 

	CREATE TABLE #users (UserId int)

	EXEC @ReturnStatus = sp_cirrato_wallet_umbrella_get_users
		@iUmbrellaId		= @iUmbrellaId
		,@iCrossUmbrella	= 1
		,@iSilent			= 1

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR


	EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance @iAmount			= @iAmount
															,@iMultiplier		= @iMultiplier
															,@iRuleId			= @iRuleId
															,@iRunDate			= @iRunDate
															,@iFirstRun			= @iFirstRun
															,@iComment			= @iComment

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_userlist_add_balance') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_userlist_add_balance
GO

CREATE PROCEDURE sp_cirrato_wallet_userlist_add_balance
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-24
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUserIds				varchar(8000)
	,@iAmount				float = NULL
	,@iMultiplier			float = NULL
	,@iComment				nvarchar(512) = NULL
	,@iUnDeleteUsers		bit = 0				-- if true, set IsDeleted = 0 for users. (used in webgui when adding user)
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int
			
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #users (UserId int)

	IF ISNUMERIC(LEFT(@iUserIds,1)) = 1 SET @iUserIds = ',' + @iUserIds

	INSERT #users
	SELECT CAST(ValueTypeId AS int) 
	FROM  dbo.fn_value_list_parse (@iUserIds)

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 GOTO PROC_ERROR

	EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance @iAmount			= @iAmount
															,@iMultiplier		= @iMultiplier
															,@iComment			= @iComment
															,@iUnDeleteUsers	= @iUnDeleteUsers

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_cirrato_wallet_userlist_add_reservedbalance') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_userlist_add_reservedbalance
GO

CREATE PROCEDURE sp_cirrato_wallet_userlist_add_reservedbalance
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-05
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUserIds				varchar(8000)
	,@iAmount				float = NULL
	,@iMultiplier			float = NULL
	,@iComment				nvarchar(512) = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int
			
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #users (UserId int)

	IF ISNUMERIC(LEFT(@iUserIds,1)) = 1 SET @iUserIds = ',' + @iUserIds

	INSERT #users
	SELECT CAST(ValueTypeId AS int) 
	FROM  dbo.fn_value_list_parse (@iUserIds)

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 GOTO PROC_ERROR

	IF @iAmount IS NULL AND @iMultiplier IS NULL
		SET @iMultiplier = 1

	UPDATE w
		SET w.wReserved = ISNULL(w.wReserved * @iMultiplier, w.wReserved + @iAmount)
	FROM tbl_cirrato_wallet w
	INNER JOIN #users u
		ON w.wUserId = u.UserId

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	RETURN (@ErrorNo)

END
GO

IF OBJECT_ID('sp_cirrato_wallet_userlist_del') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_userlist_del
GO

CREATE PROCEDURE sp_cirrato_wallet_userlist_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-13
Description:  Delete users
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUserIds				varchar(8000)
	,@iComment				nvarchar(512) = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int
			
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	CREATE TABLE #users (UserId int)

	IF ISNUMERIC(LEFT(@iUserIds,1)) = 1 SET @iUserIds = ',' + @iUserIds

	INSERT #users
	SELECT CAST(ValueTypeId AS int) 
	FROM  dbo.fn_value_list_parse (@iUserIds)

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 GOTO PROC_ERROR

	-- Comment

	DECLARE @CommentId int
			,@TicketIdReplacement varchar(64)

	IF @iComment IS NOT NULL
	EXEC @ReturnStatus = sp_wallet_log_comment_get	@iComment = @iComment
													,@iCreateIfNotExists = 1
													,@oCommentId = @CommentId OUTPUT

	-- Update wallet
	UPDATE w
		SET IsDeleted = 1
	FROM tbl_cirrato_wallet w
	INNER JOIN #users u
		ON w.wUserId = u.UserId



	-- Insert wallet log
	INSERT tbl_cirrato_wallet_log
		(wLogId
		,wLogTicketId
		,wLogUser
		,wLogDomain
		,wLogDate
		,wLogTransDate
		,wLogTransAmount
		,wLogEvent
		,wRuleId
		,wRuleRunDate
		,wCommentId)
	SELECT
		newid()
		,''
		,w.wUser
		,w.wDomain
		,getdate()
		,getdate()
		,0 --@NewBalance - @OldBalance -- wLogTransAmount
		,99 --wLogEvent
		,NULL --@iRuleId
		,NULL --@iRunDate
		,@CommentId
	FROM tbl_cirrato_wallet w
	INNER JOIN #users u
		ON w.wUserId = u.UserId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	RETURN (@ErrorNo)

END
GO
IF OBJECT_ID('sp_cirrato_wallet_user_add_balance') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_user_add_balance
GO

CREATE PROCEDURE sp_cirrato_wallet_user_add_balance
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description:  Add balance to list of users
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-10
Description: Added more event types
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-13
Description: Exclude deleted users from
************************************************************/
	@iAmount				float = NULL
	,@iMultiplier			float = NULL
	,@iRuleId				int		= NULL		-- dessa ska anv�ndas f�r loggning och felrapportering
	,@iRunDate				datetime = NULL
	,@iFirstRun				bit = 0				-- if 1, only apply rule to users with tbl_cirrato_wallet.firstRun = NULL
	,@iComment				nvarchar(512) = NULL
	,@iUnDeleteUsers		bit = 0				-- if true, set IsDeleted = 0 for users. (used in webgui when adding user)
AS
BEGIN

	--	wEvent status types
	--	0 = job
	--	10 = add money [old webgui]
	--	11 = subtract money [old webgui]
	--	50 = batch run
	--	51 = initial balance (batch, ocks�)
	--	52 = manual adjustment
	--	98 = user created
	--	99 = user was deleted

	DECLARE	@ReturnStatus			int

	IF (@iAmount IS NULL AND @iMultiplier IS NULL)
			OR (@iAmount IS NOT NULL AND @iMultiplier IS NOT NULL)
		RETURN (100225) --	Either amount OR multiplier must be specified, not both.

	IF object_id('tempdb..#users') IS NULL
		RETURN (100201) --	This procedure must be called after creating temp table #users


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE @CommentId int
			,@TicketIdReplacement varchar(64)

	IF @iComment IS NOT NULL
	EXEC @ReturnStatus = sp_wallet_log_comment_get	@iComment = @iComment
													,@iCreateIfNotExists = 1
													,@oCommentId = @CommentId OUTPUT


	-- Log which users are new - so we can set Event accordingly
	--------------------------------------------------------------
	DECLARE @NewUsers TABLE (UserId int)
	-- New rows (to be created below)
	INSERT @NewUsers
	SELECT
		u.UserId
	FROM tbl_report_users u
	INNER JOIN #users u1
		ON u.UserId = u1.UserId
	LEFT JOIN tbl_cirrato_wallet w
		ON wUser = u.UserName
		AND wDomain = u.Domain
	WHERE w.wUser IS NULL

	-- create rows for Undeleted users

	INSERT @NewUsers
	SELECT wUserId
	FROM tbl_cirrato_wallet w
		INNER JOIN #users u1
			ON w.wUserId = u1.UserId
	WHERE w.IsDeleted = 1

	-- End log new users --
	-----------------------------------------------------------------


	IF @iFirstRun = 1
		DELETE #users WHERE UserId IN
		(SELECT u1.UserId 
		FROM #users u1
		INNER JOIN tbl_report_users  u2
			ON u1.UserId = u2.UserId
		INNER JOIN tbl_cirrato_wallet w
			ON w.wUser = u2.UserName
			AND w.wDomain = u2.Domain
		WHERE w.firstRun IS NOT NULL)

	IF @iUnDeleteUsers = 1
		UPDATE w
			SET IsDeleted = 0
		FROM tbl_cirrato_wallet w
		INNER JOIN #users u1
			ON w.wUserId = u1.UserId


	-- for each user,
		-- get username/domain from tbl_report_users
		-- create row in tbl_wallet if not exists
		-- update this row
		-- add row to tbl_cirrato_wallet_log

	IF @iRuleId IS NOT NULL
		SET @TicketIdReplacement = 'Batch run'
	ELSE
		SET @TicketIdReplacement = 'Manual adjustment'
	


	DECLARE @Event int
	SET @Event = 50	-- Batch run
	IF @iFirstRun = 1 SET @Event = 51	-- Initial balance
	IF @iRuleId IS NULL SET @Event = 52 -- Manual adjustment




	-- create rows for users not already in wallet
	INSERT tbl_cirrato_wallet
		(wUser
		,wDomain)
	SELECT
		u.UserName
		,u.Domain
	FROM tbl_report_users u
	INNER JOIN #users u1
		ON u.UserId = u1.UserId
	LEFT JOIN tbl_cirrato_wallet w
		ON wUser = u.UserName
		AND wDomain = u.Domain
	WHERE w.wUser IS NULL




	-- update rows & add log rows

	DECLARE @cUserId	int
			,@cUserName	nvarchar(510)
			,@cDomain	nvarchar(510)
			,@cNewUserId int
			,@ErrorNo	int
			,@NewBalance	float
			,@OldBalance	float


	DECLARE curUsers CURSOR FAST_FORWARD FOR
	SELECT
		u1.UserId
		,u.UserName
		,u.Domain
		,NewUsers.UserId
	FROM tbl_report_users u
	INNER JOIN #users u1
		ON u.UserId = u1.UserId
	INNER JOIN tbl_cirrato_wallet w
		ON w.wUserId = u1.UserId
		AND w.IsDeleted = 0
	LEFT JOIN @NewUsers NewUsers
		ON u1.UserId = NewUsers.UserId

	OPEN curUsers

	FETCH NEXT FROM curUsers INTO @cUserId, @cUserName, @cDomain, @cNewUserId

	WHILE @@FETCH_STATUS = 0
	BEGIN

		BEGIN TRANSACTION WalletTrans

			SELECT @OldBalance = wTotal FROM tbl_cirrato_wallet WHERE wUser = @cUserName AND wDomain = @cDomain

			-- Update balance
			IF @iAmount IS NOT NULL
			BEGIN
				UPDATE tbl_cirrato_wallet SET wTotal = wTotal + @iAmount WHERE wUser = @cUserName AND wDomain = @cDomain
				SET @ErrorNo = @@ERROR
				IF @ErrorNo <> 0 GOTO ERR
			END

			IF @iMultiplier IS NOT NULL
			BEGIN
				UPDATE tbl_cirrato_wallet SET wTotal = wTotal * @iMultiplier WHERE wUser = @cUserName AND wDomain = @cDomain
				SET @ErrorNo = @@ERROR
				IF @ErrorNo <> 0 GOTO ERR
			END

			SELECT @NewBalance = wTotal FROM tbl_cirrato_wallet WHERE wUser = @cUserName AND wDomain = @cDomain
			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 GOTO ERR

			-- Log operation
			INSERT tbl_cirrato_wallet_log
				(wLogId
				,wLogTicketId
				,wLogUser
				,wLogDomain
				,wLogDate
				,wLogTransDate
				,wLogTransAmount
				,wLogEvent
				,wRuleId
				,wRuleRunDate
				,wCommentId)
			VALUES
				(newid()
				,@TicketIdReplacement
				,@cUserName
				,@cDomain
				,getdate()
				,getdate()
				,@NewBalance - @OldBalance -- wLogTransAmount
				,CASE WHEN @cNewUserId IS NOT NULL THEN 98 ELSE @Event END --wLogEvent
				,@iRuleId
				,@iRunDate
				,@CommentId)
			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 GOTO ERR

		COMMIT TRANSACTION WalletTrans
		GOTO FETCH_NEXT

		ERR: 
		ROLLBACK TRANSACTION WalletTrans
		INSERT  tbl_cirrato_wallet_error
			(UserId
			,RuleId
			,RunDate
			,RegDate
			,Amount
			,Multiplier
			,ErrorNo)
		VALUES
			(@cUserId
			,@iRuleId
			,@iRunDate
			,getdate()
			,@iAmount
			,@iMultiplier
			,@ErrorNo)
	
		--
		
		FETCH_NEXT:
		FETCH NEXT FROM curUsers INTO @cUserId, @cUserName, @cDomain, @cNewUserId
	END

	CLOSE curUsers
	DEALLOCATE curUsers


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_get_date_info') IS NOT NULL
	DROP PROCEDURE sp_get_date_info
GO

CREATE PROCEDURE sp_get_date_info
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-15
Description:  Get information about a day
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iDate					datetime
	,@iFirstDayOfWeek		int = 1			-- vilken �r veckans f�rsta dag? 1 = m�ndag. SQL Server default �r annars 7 = s�ndag.
	,@oDayOfWeek			int				OUTPUT
	,@oDayOfMonth			int				OUTPUT
	,@oDayOfQuarter 		int				OUTPUT
	,@oDayOfHalfYear		int				OUTPUT
	,@oDayOfYear			int				OUTPUT
	,@oMonthDay				dt_monthday		OUTPUT
	,@oMonthNumber			int				OUTPUT


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET DATEFIRST @iFirstDayOfWeek -- SVERIGE dag1 = m�ndag. default �r annars 7 = s�ndag.


	declare @d datetime
			,@lastdayofyear datetime
			,@daysinyear int
			,@daysinfirsthalfyear int
			,@CurrentMonth int

	declare @currentYear char(4)


	set @d = @iDate
	--set @d = '20000101'

	--set @d = '20010630'
	--set @d = '20010701'

	--output
	declare
		@dayofweek int
		,@dayofmonth int
		,@dayofquarter int
		,@dayofhalfyear int
		,@dayofyear int

	SET @currentYear = left(convert(char(8), @d, 112), 4)
	SET @CurrentMonth = datepart (month, @d)

	SET @lastdayofyear = @currentYear + '1231'



	SELECT @dayofyear = datepart (dayofyear, @d) 

	SELECT @daysinyear = datepart (dayofyear, @lastdayofyear) 
	SELECT @daysinfirsthalfyear = @daysinyear - 184 -- andra halv�ret alltid 184 dagar


	if @dayofyear > @daysinfirsthalfyear
		set @dayofhalfyear = @dayofyear - @daysinfirsthalfyear
	else
		set @dayofhalfyear = @dayofyear

	set @dayofweek = datepart (weekday, @d) 

	declare @CurrentMonthFirstDay_Number int
			,@CurrentQuarterFirstDay_Number int
			,@CurrentMonthFirstDay datetime
			,@CurrentQuarterFirstDay datetime

	-- MONTH
	set @CurrentMonthFirstDay =  left(convert(char(8), @d, 112), 6) + '01'
	set @CurrentMonthFirstDay_Number = datepart(dayofyear, @CurrentMonthFirstDay)
	set @dayofmonth = @dayofyear - @CurrentMonthFirstDay_Number + 1


	-- QUARTER
	SET @CurrentQuarterFirstDay =
		CASE WHEN @CurrentMonth BETWEEN 1 AND 3 THEN @currentYear + '0101'
		 WHEN @CurrentMonth BETWEEN 4 AND 6 THEN @currentYear + '0401'
		 WHEN @CurrentMonth BETWEEN 7 AND 9 THEN @currentYear + '0701'
		 WHEN @CurrentMonth BETWEEN 10 AND 12 THEN @currentYear + '1001' END

	SET @CurrentQuarterFirstDay_Number = datepart(dayofyear, @CurrentQuarterFirstDay)
	set @dayofquarter = @dayofyear - @CurrentQuarterFirstDay_Number + 1



	-- OUTPUT RESULTS
--	select
--		@dayofweek dayofweek 
--		,@dayofmonth dayofmonth 
--		,@dayofquarter dayofquarter
--		,@dayofhalfyear dayofhalfyear
--		,@dayofyear dayofyear 
--	--	,@MonthDay
--	--	,@MonthNumber



	SELECT @oDayOfWeek		= @dayofweek	
		,@oDayOfMonth		= @dayofmonth
		,@oDayOfQuarter 	= @dayofquarter
		,@oDayOfHalfYear	= @dayofhalfyear
		,@oDayOfYear		= @dayofyear
		,@oMonthDay			= RIGHT(convert(char(8), @d, 112),4)
		,@oMonthNumber		= @CurrentMonth



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO
IF OBJECT_ID('sp_wallet_log_comment_get') IS NOT NULL
	DROP PROCEDURE sp_wallet_log_comment_get
GO

CREATE PROCEDURE sp_wallet_log_comment_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-06-24
Description: Add/get a comment for wallet log 
************************************************************/
	@iComment				nvarchar(512)
	,@iCreateIfNotExists	bit = 1
	,@oCommentId			int			OUTPUT
AS
BEGIN


	SELECT @oCommentId = CommentId
	FROM tbl_cirrato_wallet_log_comment
	WHERE Comment = @iComment

	IF @oCommentId IS NULL AND @iCreateIfNotExists = 1
	BEGIN
		INSERT tbl_cirrato_wallet_log_comment
		(Comment)
		VALUES
		(@iComment)

		SELECT @oCommentId  = SCOPE_IDENTITY()

	END


	RETURN (0)


--	PROC_ERROR:
--
--	RETURN (@ErrorNo)



END

GO


IF OBJECT_ID('sp_xxx') IS NOT NULL
	DROP PROCEDURE sp_xxx
GO

CREATE PROCEDURE sp_xxx
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-xx-xx
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iParam1			int		= 0


AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- do stuff

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_get') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_get
GO

CREATE PROCEDURE sp_cirrato_wallet_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Get balance for user, users, group, groups
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-13
Description: Added option to include deleted wallets.
************************************************************/
	-- LIKE match on these
	@iUserName			nvarchar(512) = NULL
	,@iDomain			nvarchar(512) = NULL
	-- If given, only return users specified groups / umbrellas
	,@iUmbrellaId		int				= NULL
	,@iUmbrellaList		varchar(8000)	= NULL
	,@iGroupId			int				= NULL
	,@iGroupList		varchar(8000)	= NULL
	,@iMinBalance		float			= NULL 
	,@iMaxBalance		float			= NULL
	,@iIncludeDeleted	bit		= 0
AS
BEGIN

	DECLARE	@ReturnStatus			int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF @iUserName IS NULL SET @iUserName = '%' ELSE SET @iUserName = '%' + @iUserName + '%'
	IF @iDomain IS NULL SET @iDomain = '%' ELSE SET @iDomain = '%' + @iDomain + '%'
	
	DECLARE @UsersFilter TABLE (UserId int, UserName nvarchar(512), Domain nvarchar(512)) -- this table contains all users in groups/umbrellas

	IF @iUmbrellaId IS NOT NULL
		INSERT @UsersFilter
		EXEC @ReturnStatus = sp_cirrato_wallet_umbrella_get_users @iUmbrellaId = @iUmbrellaId

	
	IF @iGroupId IS NOT NULL
		INSERT @UsersFilter
		EXEC @ReturnStatus = sp_cirrato_wallet_group_get_users @iGroupId = @iGroupId


	DECLARE @UsersAll TABLE (UserId int) -- this table contains users to return balance for

	IF @iUmbrellaId IS NOT NULL OR @iGroupId IS NOT NULL --(SELECT COUNT(*) FROM @UsersFilter) > 0
		INSERT @UsersAll
		SELECT DISTINCT UserId FROM @UsersFilter WHERE UserName LIKE @iUserName AND Domain LIKE @iDomain
	ELSE
		INSERT @UsersAll
		SELECT DISTINCT UserId FROM tbl_report_users WHERE UserName LIKE @iUserName AND Domain LIKE @iDomain




	-- return balance for userids in @UsersAll
	SELECT 
		w.wUser			UserName
		,w.wDomain		Domain
		,w.wDomain + '\' + w.wUser DomainUserName
		,w.wTotal		Balance
		,w.wReserved	ReservedBalance
		,w.firstRun		FirstRun
		,w.wUserId		UserId
	FROM tbl_cirrato_wallet w
	INNER JOIN @UsersAll u
		ON w.wUserId = u.UserId
	WHERE w.wTotal BETWEEN ISNULL(@iMinBalance, -1.79E+308) AND ISNULL(@iMaxBalance, 1.79E+308)
	 	AND w.IsDeleted <= @iIncludeDeleted
	ORDER BY w.wDomain, w.wUser

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_get_by_userid') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_get_by_userid
GO

CREATE PROCEDURE sp_cirrato_wallet_get_by_userid
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Get balance for a single user, given userid
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUserId			int
	,@iIncludeDeleted	bit		= 0
AS
BEGIN

	DECLARE	@ReturnStatus			int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT 
		w.wUser			UserName
		,w.wDomain		Domain
		,w.wDomain + '\' + w.wUser DomainUserName
		,w.wTotal		Balance
		,w.wReserved	ReservedBalance
		,w.firstRun		FirstRun
		,w.wUserId		UserId
	FROM tbl_cirrato_wallet w
	WHERE wUserId= @iUserId
		AND w.IsDeleted <= @iIncludeDeleted

	ORDER BY w.wDomain, w.wUser

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_group_add_user') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_group_add_user
GO

CREATE PROCEDURE sp_cirrato_wallet_group_add_user
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-24
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupId				int		
	,@iUserId				int
AS
BEGIN

	DECLARE	@ReturnStatus			int
		,@CurrentTimestamp			datetime

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM tbl_report_group
		WHERE @CurrentTimestamp BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
		AND IsDeleted = 0
		AND GroupId = @iGroupId)
	RETURN (100301) --	Group does not exist

	IF NOT EXISTS (SELECT 1 FROM tbl_report_users WHERE UserId = @iUserId)
		RETURN (100305) --	User does not exist


	IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_user_group WHERE UserId = @iUserId AND GroupId = @iGroupId)
		RETURN (100306) --	User is already in group


	INSERT tbl_cirrato_wallet_user_group (UserId ,GroupId)
	VALUES (@iUserId, @iGroupId)


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_group_del_user') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_group_del_user
GO

CREATE PROCEDURE sp_cirrato_wallet_group_del_user
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-24
Description: Remove a user from a group
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupId				int		
	,@iUserId				int
AS
BEGIN

	DECLARE	@ReturnStatus			int
		,@CurrentTimestamp			datetime

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM tbl_report_group
		WHERE @CurrentTimestamp BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
		AND IsDeleted = 0
		AND GroupId = @iGroupId)
	RETURN (100301) --	Group does not exist

	IF NOT EXISTS (SELECT 1 FROM tbl_report_users WHERE UserId = @iUserId)
		RETURN (100305) --	User does not exist


	IF NOT EXISTS (SELECT 1 FROM tbl_cirrato_wallet_user_group WHERE UserId = @iUserId AND GroupId = @iGroupId)
		RETURN (100307) --	User is not in group


	DELETE tbl_cirrato_wallet_user_group WHERE UserId = @iUserId AND GroupId = @iGroupId



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_group_get_users') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_group_get_users
GO

CREATE PROCEDURE sp_cirrato_wallet_group_get_users
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-24
Description:  
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-24
Description: Updated with support for graph group structure
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-10
Description: Fixed bug which would include users in deleted groups too.
************************************************************/
	@iGroupId				int		
	,@iRecursive			bit = 1
	,@iCrossUmbrella		bit = 1	
	,@iSilent				bit = 0
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@CurrentTimestamp		datetime
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM vw_report_group
		WHERE @CurrentTimestamp BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
		AND IsDeleted = 0
		AND GroupId = @iGroupId)
	RETURN (100301) --	Group does not exist

	-- Get groups
	--------------------------------------------------

	IF object_id('tempdb..#users') IS NULL
		CREATE TABLE #users (UserId int)

	CREATE TABLE #groups (GroupId int)

	IF @iRecursive = 1
	BEGIN
		EXEC @ReturnStatus = sp_report_group_get_recursive	
			@iGroupId			= @iGroupId
			,@iCrossUmbrella	= @iCrossUmbrella
			,@iSilent			= 1

		SET @ErrorNo = @@ERROR
		IF @ErrorNo <> 0 OR @ReturnStatus <> 0
			GOTO PROC_ERROR
	END
	ELSE
		INSERT #groups (GroupId) VALUES (@iGroupId)


	-- Return results
	--------------------------------------------------
	IF @iSilent = 0
		SELECT DISTINCT
			ug.UserId
			,u.UserName
			,u.Domain
		FROM  tbl_report_users u
		INNER JOIN tbl_cirrato_wallet_user_group ug
			ON ug.UserId = u.UserId
		INNER JOIN vw_report_group g
			ON ug.GroupId = g.GroupId
		INNER JOIN #groups gr
			ON gr.GroupId = g.GroupId
		ORDER BY u.Domain, u.UserName
	ELSE
		INSERT #users (UserId)
		SELECT DISTINCT
			ug.UserId
		FROM  tbl_report_users u
		INNER JOIN tbl_cirrato_wallet_user_group ug
			ON ug.UserId = u.UserId
		INNER JOIN vw_report_group g
			ON ug.GroupId = g.GroupId
		INNER JOIN #groups gr
			ON gr.GroupId = g.GroupId
		--ORDER BY u.Domain, u.UserName

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_log_get') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_log_get
GO

CREATE PROCEDURE sp_cirrato_wallet_log_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-04
Description: Get transaction history for a user
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-10
Description: Job name added
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-12
Description: Multiply jobs by -1 so they show up negative in the transaction history.
************************************************************/
	@iUserId			int		
	,@iStartDate		datetime = NULL
	,@iEndDate			datetime = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT 
		wl.wLogId				LogId
		,wl.wLogTicketId		TicketId
		,wl.wLogUser			UserName
		,wl.wLogDomain			Domain
		,wl.wLogDomain + '\' + wl.wLogUser	DomainUserName
		,wl.wLogDate			LogDate
		,wl.wLogTransDate		TransDate
		,CASE WHEN wl.wLogEvent = 0 THEN -1 * wl.wLogTransAmount ELSE wl.wLogTransAmount END AS		TransAmount
		,wl.wLogEvent			LogEvent
		,wl.wRuleId				RuleId
		,wl.wRuleRunDate		RuleRunDate
		,wl.wCommentId			CommentId
		,c.Comment 
		,r.RuleName
		,Jobs.JobName
	FROM tbl_cirrato_wallet_log wl
	INNER JOIN tbl_cirrato_wallet w
		ON wl.wLogUser = w.wUser
		AND wl.wLogDomain = w.wDomain
	LEFT JOIN tbl_cirrato_wallet_log_comment c
		ON wl.wCommentId = c.CommentId
	LEFT JOIN tbl_cirrato_wallet_rule r
		ON r.RuleId = wl.wRuleId
	INNER JOIN tbl_report_users u
		ON u.UserName = wl.wLogUser
		AND u.Domain = wl.wLogDomain
	LEFT JOIN tbl_report_jobs_detail jobs
		ON jobs.UserId = u.UserId
		AND CAST(jobs.TicketId AS varchar(64)) = wl.wLogTicketId
	WHERE w.wUserId = @iUserId
	AND wl.wLogTransDate BETWEEN ISNULL(@iStartDate, '20000101') AND ISNULL(@iEndDate, '99991231')
	ORDER BY wl.wLogTransDate DESC

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_overview_get') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_overview_get
GO

CREATE PROCEDURE sp_cirrato_wallet_overview_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Get aggregated overview of all wallets
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-08-13
Description: Added support for deleted users
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-10-16
Description: Added multi-language support
************************************************************/
	@iLanguageId				char(2)			= 'en'
AS
BEGIN

	DECLARE	@ReturnStatus			int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SELECT
		1				AS MetricId
		,dbo.fn_translate('TotalBalance', @iLanguageId) AS Metric
		,CONVERT(varchar(128), CAST(SUM (wTotal) AS decimal(38,2))) AS MetricValue -- 2 decimaler
	FROM tbl_cirrato_wallet

	UNION
	SELECT
		2				AS MetricId
		,dbo.fn_translate('Users', @iLanguageId)		AS Metric
		,CAST(COUNT (wTotal) AS varchar(128))	AS MetricValue
	FROM tbl_cirrato_wallet 
	WHERE IsDeleted = 0

	UNION
	SELECT
		3				AS MetricId
		,dbo.fn_translate('UsersWithBalance', @iLanguageId) AS Metric
		,CAST(COUNT (wTotal) AS varchar(128))	AS MetricValue
	FROM tbl_cirrato_wallet
	WHERE wTotal > 0
	AND IsDeleted = 0

	ORDER BY 1


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_rule_del') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_rule_del
GO

CREATE PROCEDURE sp_cirrato_wallet_rule_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Delete a rule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRuleId			int			
	,@iIsDeleted		bit			= 1
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	IF NOT EXISTS (SELECT * FROM tbl_cirrato_wallet_rule WHERE RuleId = @iRuleId)
		RETURN (100213) -- 	Quota rule does not exist



	UPDATE tbl_cirrato_wallet_rule SET 
		IsDeleted		= ISNULL(@iIsDeleted, IsDeleted)	
	WHERE RuleId = @iRuleId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_rule_get') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_rule_get
GO

CREATE PROCEDURE sp_cirrato_wallet_rule_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  List one or all rules, include schedule name
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-07
Description: List column GroupFullPath as well
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRuleId			int		= NULL
	,@iIncludeDeleted		bit		= 0
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	IF @iRuleId IS NOT NULL AND NOT EXISTS( SELECT * FROM tbl_cirrato_wallet_rule WHERE RuleId = @iRuleId)
		RETURN (100213) -- Quota rule does not exist


	SELECT 
		r.* 
		,ISNULL(s.ScheduleName, 'Initial balance rule') ScheduleName
		,g.GroupName
		,g.GroupFullPath
		,u.UmbrellaName
		,GroupParent.UmbrellaId ParentUmbrellaId
		,GroupParent.UmbrellaName ParentUmbrellaName
		,ISNULL(r.Amount, r.Multiplier)		AmountMultiplier
		,ISNULL(u.UmbrellaName, GroupParent.UmbrellaName + g.GroupFullPath) UmbrellaOrGroupName
	FROM tbl_cirrato_wallet_rule r
	LEFT OUTER JOIN tbl_cirrato_wallet_schedule s
		ON r.ScheduleId = s.ScheduleId
	LEFT OUTER JOIN vw_report_group_display_unique g
		ON g.GroupId = r.GroupId
	LEFT OUTER JOIN tbl_report_group_umbrella GroupParent
		ON g.UmbrellaId = GroupParent.UmbrellaId
	LEFT OUTER JOIN tbl_report_group_umbrella u
		ON u.UmbrellaId = r.UmbrellaId
	WHERE r.RuleId = ISNULL(@iRuleId, r.RuleId)
	AND r.IsDeleted <= @iIncludeDeleted
	ORDER BY r.RuleName

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_rule_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_rule_ins
GO

CREATE PROCEDURE sp_cirrato_wallet_rule_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Create new rule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRuleName			nvarchar(256) 
	,@iRuleComment		nvarchar(512) = NULL
	,@iSortOrder		int			= 0
	,@iScheduleId		int			= NULL
	,@iUmbrellaId		int			= NULL
	,@iGroupId			int			= NULL
	,@iAmount			float		= NULL
	,@iMultiplier		float		= NULL
	,@iStartDate		datetime	= NULL
	,@iEndDate			datetime	= NULL
	,@oRuleId			int			OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oRuleId = NULL

	IF (@iAmount IS NULL AND @iMultiplier IS NULL)
			OR (@iAmount IS NOT NULL AND @iMultiplier IS NOT NULL)
		RETURN (100225) -- Either amount OR multiplier must be specified, not both.

	IF (@iUmbrellaId IS NULL AND @iGroupId IS NULL)
			OR (@iUmbrellaId IS NOT NULL AND @iGroupId IS NOT NULL)
		RETURN (100226) -- Either group OR umbrella must be specified, not both or none.

	IF @iScheduleId IS NOT NULL AND NOT EXISTS ( SELECT * FROM tbl_cirrato_wallet_schedule WHERE ScheduleId = @iScheduleId)
		RETURN (100212) -- Schedule does not exist

	IF @iUmbrellaId IS NOT NULL AND NOT EXISTS (SELECT 1 FROM tbl_report_group_umbrella WHERE UmbrellaId = @iUmbrellaId)
		RETURN (100300) -- Umbrella does not exist

	IF @iGroupId IS NOT NULL AND NOT EXISTS (SELECT 1 FROM tbl_report_group WHERE GroupId = @iGroupId)
		RETURN (100301) -- Group does not exist

	IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_rule WHERE RuleName = @iRuleName AND IsDeleted = 0)
		RETURN (100222) -- Rule name must be unique



	INSERT tbl_cirrato_wallet_rule 
		(RuleName
		,RuleComment
		,SortOrder
		,ScheduleId
		,UmbrellaId
		,GroupId
		,Amount
		,Multiplier
		,StartDate
		,EndDate)
	VALUES
		(@iRuleName
		,@iRuleComment
		,@iSortOrder
		,@iScheduleId
		,@iUmbrellaId
		,@iGroupId
		,@iAmount
		,@iMultiplier
		,@iStartDate
		,@iEndDate)

	SET @oRuleId = SCOPE_IDENTITY()

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_rule_upd') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_rule_upd
GO

CREATE PROCEDURE sp_cirrato_wallet_rule_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Edit or delete a rule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iRuleId			int			
	,@iRuleName			nvarchar(256) = NULL
	,@iRuleComment		nvarchar(512) = NULL
	,@iSortOrder		int			= NULL
	,@iScheduleId		int			= NULL
	,@iUmbrellaId		int			= NULL
	,@iGroupId			int			= NULL
	,@iAmount			float		= NULL
	,@iMultiplier		float		= NULL
	,@iStartDate		datetime	= NULL
	,@iEndDate			datetime	= NULL
	,@iIsDeleted		bit			= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	IF NOT EXISTS (SELECT * FROM tbl_cirrato_wallet_rule WHERE RuleId = @iRuleId)
		RETURN (100213) -- 	Quota rule does not exist

	IF (@iAmount IS NULL AND @iMultiplier IS NULL)
			OR (@iAmount IS NOT NULL AND @iMultiplier IS NOT NULL)
		RETURN (100225) -- Either amount OR multiplier must be specified, not both.

	IF (@iUmbrellaId IS NULL AND @iGroupId IS NULL)
			OR (@iUmbrellaId IS NOT NULL AND @iGroupId IS NOT NULL)
		RETURN (100226) -- Either group OR umbrella must be specified, not both or none.

	IF @iScheduleId IS NOT NULL AND NOT EXISTS ( SELECT * FROM tbl_cirrato_wallet_schedule WHERE ScheduleId = @iScheduleId)
		RETURN (100212) -- Schedule does not exist

	IF @iUmbrellaId IS NOT NULL AND NOT EXISTS (SELECT 1 FROM tbl_report_group_umbrella WHERE UmbrellaId = @iUmbrellaId)
		RETURN (100300) -- Umbrella does not exist

	IF @iGroupId IS NOT NULL AND NOT EXISTS (SELECT 1 FROM tbl_report_group WHERE GroupId = @iGroupId)
		RETURN (100301) -- Group does not exist

	IF EXISTS (SELECT 1 FROM tbl_cirrato_wallet_rule WHERE RuleName = @iRuleName AND IsDeleted = 0 AND RuleId <> @iRuleId)
		RETURN (100222) -- Rule name must be unique



	UPDATE tbl_cirrato_wallet_rule SET 
		RuleName		= ISNULL(@iRuleName, RuleName)
		,RuleComment	= ISNULL(@iRuleComment, RuleComment)
		,SortOrder		= ISNULL(@iSortOrder, SortOrder)
		,ScheduleId		= @iScheduleId
		,UmbrellaId		= @iUmbrellaId
		,GroupId		= @iGroupId
		,Amount			= @iAmount
		,Multiplier		= @iMultiplier
		,StartDate		= @iStartDate
		,EndDate		= @iEndDate
		,IsDeleted		= ISNULL(@iIsDeleted, IsDeleted)	
	WHERE RuleId = @iRuleId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedule_days_del') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedule_days_del
GO

CREATE PROCEDURE sp_cirrato_wallet_schedule_days_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Delete custom days from a schedule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iScheduleId			int		
	,@iMonthDay				dt_monthday = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS ( SELECT * FROM tbl_cirrato_wallet_schedule WHERE ScheduleId = @iScheduleId AND Periodicity IS NULL)
		RETURN (100219) --	Schedule is not a custom-date schedule

	IF @iMonthDay IS NOT NULL 
		AND NOT EXISTS ( SELECT * FROM tbl_cirrato_wallet_schedule_days WHERE ScheduleId = @iScheduleId AND MonthDay = @iMonthDay)
			RETURN (100221)	-- Date does not exist in schedule




	DELETE tbl_cirrato_wallet_schedule_days
	WHERE ScheduleId = @iScheduleId
		AND MonthDay = ISNULL(@iMonthDay, MonthDay)


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedule_days_get') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedule_days_get
GO

CREATE PROCEDURE sp_cirrato_wallet_schedule_days_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  List custom days in a schedule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iScheduleId			int		
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS ( SELECT * FROM tbl_cirrato_wallet_schedule WHERE ScheduleId = @iScheduleId AND Periodicity IS NULL)
		RETURN (100219) --	Schedule is not a custom-date schedule


	SELECT * FROM tbl_cirrato_wallet_schedule_days
	WHERE ScheduleId = @iScheduleId
	ORDER BY MonthDay

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedule_days_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedule_days_ins
GO

CREATE PROCEDURE sp_cirrato_wallet_schedule_days_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Add custom days to a schedule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iScheduleId			int		
	,@iMonthDay				dt_monthday
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS ( SELECT * FROM tbl_cirrato_wallet_schedule WHERE ScheduleId = @iScheduleId AND Periodicity IS NULL)
		RETURN (100219) --	Schedule is not a custom-date schedule

	IF EXISTS ( SELECT * FROM tbl_cirrato_wallet_schedule_days WHERE ScheduleId = @iScheduleId AND MonthDay = @iMonthDay)
		RETURN (100220) --	Date is already in schedule



	INSERT tbl_cirrato_wallet_schedule_days
		(ScheduleId
		,MonthDay)
	VALUES
		(@iScheduleId
		,@iMonthDay)


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedule_del') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedule_del
GO

CREATE PROCEDURE sp_cirrato_wallet_schedule_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Delete a schedule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iScheduleId			int
	,@iIsDeleted			bit			= 1
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	DECLARE 	@NewPeriodicity			tinyint

	IF NOT EXISTS (SELECT 1 FROM tbl_cirrato_wallet_schedule WHERE ScheduleId = @iScheduleId)
		RETURN (100212) --	Schedule does not exist

	IF EXISTS (SELECT * FROM tbl_cirrato_wallet_rule WHERE ScheduleId = @iScheduleId AND IsDeleted = 0)
		RETURN (100223) -- Schedule cannot be deleted because it's in use by active rules


	UPDATE tbl_cirrato_wallet_schedule
		SET IsDeleted		= ISNULL(@iIsDeleted, IsDeleted)
	WHERE ScheduleId = @iScheduleId



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedule_get') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedule_get
GO

CREATE PROCEDURE sp_cirrato_wallet_schedule_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  List one or all schedules
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iScheduleId			int		= NULL
	,@iIncludeDeleted		bit		= 0
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	SELECT * FROM tbl_cirrato_wallet_schedule
	WHERE ScheduleId = ISNULL(@iScheduleId, ScheduleId)
	AND IsDeleted <= @iIncludeDeleted
	ORDER BY ScheduleName

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedule_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedule_ins
GO

CREATE PROCEDURE sp_cirrato_wallet_schedule_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Create a schedule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iScheduleName			nvarchar(256)
	,@iScheduleComment		nvarchar(512)	= NULL
	,@iPeriodicity			tinyint			= NULL -- null = custom dates
	,@iOffsetType			tinyint
	,@iOffsetValue			int
	,@iPeriodStart			dt_monthday = NULL
	,@iPeriodEnd			dt_monthday = NULL
	,@iCreatorUserName		nvarchar(512) = NULL
	,@iCreatorDomain		nvarchar(512) = NULL
	,@oScheduleId			int OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oScheduleId = NULL


	IF EXISTS(SELECT * FROM tbl_cirrato_wallet_schedule
		WHERE ScheduleName = @iScheduleName	AND IsDeleted = 0)
		RETURN (100218) --	Schedule name must be unique

	IF @iOffsetType IS NULL OR NOT @iOffsetType BETWEEN 0 AND 7
		RETURN (100215) --	OffsetType invalid or NULL

	IF @iOffsetValue IS NULL OR @iOffsetValue < 0
		RETURN (100216) --	OffsetValue invalid



	INSERT tbl_cirrato_wallet_schedule
		(ScheduleName
		,ScheduleComment
		,Periodicity
		,OffsetType
		,OffsetValue
		,PeriodStart
		,PeriodEnd
		,CreatorUserName
		,CreatorDomain)
	VALUES
		(@iScheduleName
		,@iScheduleComment
		,@iPeriodicity
		,@iOffsetType
		,@iOffsetValue
		,@iPeriodStart
		,@iPeriodEnd
		,@iCreatorUserName
		,@iCreatorDomain)


	SET @oScheduleId = SCOPE_IDENTITY()

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_schedule_upd') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_schedule_upd
GO

CREATE PROCEDURE sp_cirrato_wallet_schedule_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-03
Description:  Edit or delete a schedule
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iScheduleId			int 
	,@iScheduleName			nvarchar(256)	= NULL
	,@iScheduleComment		nvarchar(512)	= NULL
	,@iPeriodicity			tinyint			= 255 -- null = custom dates
	,@iOffsetType			tinyint			= NULL
	,@iOffsetValue			int				= NULL
	,@iPeriodStart			dt_monthday		= NULL
	,@iPeriodEnd			dt_monthday		= NULL
	,@iIsDeleted			bit				= NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS(SELECT 1 FROM tbl_cirrato_wallet_schedule WHERE ScheduleId = @iScheduleId)
		RETURN (100212) --	Schedule does not exist

	DECLARE 	@NewPeriodicity			tinyint

	IF @iPeriodicity = 255 -- unchanged
		SELECT @NewPeriodicity = Periodicity FROM tbl_cirrato_wallet_schedule WHERE ScheduleId = @iScheduleId
	ELSE
		SET @NewPeriodicity = @iPeriodicity


	IF EXISTS(SELECT * FROM tbl_cirrato_wallet_schedule
		WHERE ScheduleName = @iScheduleName	AND IsDeleted = 0 AND ScheduleId <> @iScheduleId)
		RETURN (100218) --	Schedule name must be unique

	IF @iOffsetType IS NOT NULL AND NOT @iOffsetType BETWEEN 0 AND 7
		RETURN (100215) --	OffsetType invalid or NULL

	IF @iOffsetValue IS NOT NULL AND @iOffsetValue < 0
		RETURN (100216) --	OffsetValue invalid

	UPDATE tbl_cirrato_wallet_schedule
	SET ScheduleName	= ISNULL(@iScheduleName, ScheduleName)
		,ScheduleComment= ISNULL(@iScheduleComment, ScheduleComment)
		,Periodicity	= @NewPeriodicity
		,OffsetType		= ISNULL(@iOffsetType, OffsetType)
		,OffsetValue	= ISNULL(@iOffsetValue, OffsetValue)
		,PeriodStart	= @iPeriodStart
		,PeriodEnd		= @iPeriodEnd
		,IsDeleted		= ISNULL(@iIsDeleted, IsDeleted)
	WHERE ScheduleId = @iScheduleId



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_umbrella_get_users') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_umbrella_get_users
GO

CREATE PROCEDURE sp_cirrato_wallet_umbrella_get_users
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-24
Description:  
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-11-24
Description: Updated with support for graph group structure
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-10
Description: Fixed bug which would include users in deleted groups too.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUmbrellaId			int
	,@iCrossUmbrella		bit = 1	
	,@iSilent				bit = 0
AS
BEGIN

	DECLARE	@ReturnStatus			int
		,@CurrentTimestamp			datetime
		,@ErrorNo					int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @CurrentTimestamp = getdate()

	IF NOT EXISTS (SELECT 1 FROM tbl_report_group_umbrella
		WHERE @CurrentTimestamp BETWEEN ISNULL(StartDate,'20000101') AND ISNULL(EndDate,'99991231')
		AND IsDeleted = 0)
	RETURN (100300) --	Umbrella does not exist


	-- Get groups in umbrella
	---------------------------------------------
	IF object_id('tempdb..#users') IS NULL
		CREATE TABLE #users (UserId int)

	CREATE TABLE #groups (GroupId int)

	EXEC @ReturnStatus = sp_report_group_get_recursive	
		@iUmbrellaId		= @iUmbrellaId
		,@iCrossUmbrella	= @iCrossUmbrella
		,@iSilent			= 1

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR



	-- Return result
	---------------------------------------------
	IF @iSilent = 0
		SELECT DISTINCT
			ug.UserId
			,u.UserName
			,u.Domain
		FROM  tbl_report_users u
		INNER JOIN tbl_cirrato_wallet_user_group ug
			ON ug.UserId = u.UserId
		INNER JOIN vw_report_group g
			ON ug.GroupId = g.GroupId
		INNER JOIN #groups gr
			ON gr.GroupId = g.GroupId
		ORDER BY u.Domain, u.UserName
	ELSE
		INSERT #users (UserId) 
		SELECT DISTINCT
			ug.UserId
		FROM  tbl_report_users u
		INNER JOIN tbl_cirrato_wallet_user_group ug
			ON ug.UserId = u.UserId
		INNER JOIN vw_report_group g
			ON ug.GroupId = g.GroupId
		INNER JOIN #groups gr
			ON gr.GroupId = g.GroupId
		--ORDER BY u.Domain, u.UserName


--	SELECT DISTINCT
--		ug.UserId
--		,u.UserName
--		,u.Domain
--	FROM  tbl_report_users u
--	INNER JOIN tbl_cirrato_wallet_user_group ug
--		ON ug.UserId = u.UserId
--	INNER JOIN tbl_report_group g
--		ON ug.GroupId = g.GroupId
--	INNER JOIN tbl_report_group_umbrella um
--		ON g.UmbrellaId = um.UmbrellaId
--	WHERE um.UmbrellaId = @iUmbrellaId
--	ORDER BY u.Domain, u.UserName
		

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_group_bundle_del') IS NOT NULL
	DROP PROCEDURE sp_report_group_bundle_del
GO

CREATE PROCEDURE sp_report_group_bundle_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-20
Description:  Delete a bundle and assocated users
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iBundleId			uniqueidentifier 
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Checks
	IF NOT EXISTS (SELECT * FROM tbl_report_group_bundle WHERE @iBundleId = BundleId)
		RETURN (100321)	-- Bundle does not exist


	-- Delete rows
	DELETE tbl_report_group_bundle_user WHERE BundleId = @iBundleId
	DELETE tbl_report_group_bundle WHERE BundleId = @iBundleId


	SET @ReturnStatus = @@ERROR

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_group_bundle_commit') IS NOT NULL
	DROP PROCEDURE sp_report_group_bundle_commit
GO

CREATE PROCEDURE sp_report_group_bundle_commit
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-20
Description:  Commit a bundle
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iBundleId			uniqueidentifier 
AS
BEGIN

	DECLARE	@ReturnStatus			int
	SET @ReturnStatus = 0

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Checks
	-----------------------------------------------------------
	IF NOT EXISTS (SELECT * FROM tbl_report_group_bundle WHERE @iBundleId = BundleId)
		RETURN (100321)	-- Bundle does not exist


	-- Update UserId in bundle table
	-----------------------------------------------------------
	UPDATE bu
		SET bu.UserId = u.UserId
	FROM tbl_report_group_bundle_user bu
	INNER JOIN tbl_report_users u
		ON bu.UserName = u.UserName
		AND bu.Domain = u.Domain
	WHERE bu.BundleId = @iBundleId

	
	INSERT tbl_report_users (UserName, Domain)
	SELECT bu.UserName, bu.Domain
	FROM tbl_report_group_bundle_user bu
	WHERE bu.BundleId = @iBundleId
		AND bu.UserId IS NULL


	UPDATE bu
		SET bu.UserId = u.UserId
	FROM tbl_report_group_bundle_user bu
	INNER JOIN tbl_report_users u
		ON bu.UserName = u.UserName
		AND bu.Domain = u.Domain
	WHERE bu.BundleId = @iBundleId
		AND bu.UserId IS NULL

	-- Update user/group mapping
	-----------------------------------------------------------
	DECLARE @GroupId int, @BundleType tinyint

	SELECT
		@GroupId = GroupId
		,@BundleType = BundleType
	FROM tbl_report_group_bundle WHERE @iBundleId = BundleId 


	IF @BundleType = 1 -- ADD
		INSERT tbl_cirrato_wallet_user_group (UserId, GroupId)
		SELECT 
			bu.UserId
			,@GroupId
		FROM tbl_report_group_bundle_user bu
		LEFT JOIN tbl_cirrato_wallet_user_group ug
			ON ug.UserId = bu.UserId
			AND ug.GroupId = @GroupId
		WHERE ug.UserId IS NULL
		AND bu.BundleId = @iBundleId

	IF @BundleType = 2 -- REMOVE
		DELETE tbl_cirrato_wallet_user_group
		WHERE GroupId = @GroupId
		AND UserId IN (SELECT UserId FROM tbl_report_group_bundle_user WHERE BundleId = @iBundleId)

	IF @BundleType = 3 -- REPLACE
	BEGIN
		-- Delete users
		DELETE tbl_cirrato_wallet_user_group
		WHERE GroupId = @GroupId
		AND UserId NOT IN (SELECT UserId FROM tbl_report_group_bundle_user WHERE BundleId = @iBundleId)

		-- Add new users (same code as step 1 above)
		INSERT tbl_cirrato_wallet_user_group (UserId, GroupId)
		SELECT 
			bu.UserId
			,@GroupId
		FROM tbl_report_group_bundle_user bu
		LEFT JOIN tbl_cirrato_wallet_user_group ug
			ON ug.UserId = bu.UserId
			AND ug.GroupId = @GroupId
		WHERE ug.UserId IS NULL
		AND bu.BundleId = @iBundleId

	END

	EXEC @ReturnStatus = sp_report_group_bundle_del @iBundleId = @iBundleId

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_group_bundle_del') IS NOT NULL
	DROP PROCEDURE sp_report_group_bundle_del
GO

CREATE PROCEDURE sp_report_group_bundle_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-20
Description:  Delete a bundle and assocated users
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iBundleId			uniqueidentifier 
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Checks
	IF NOT EXISTS (SELECT * FROM tbl_report_group_bundle WHERE @iBundleId = BundleId)
		RETURN (100321)	-- Bundle does not exist


	-- Delete rows
	DELETE tbl_report_group_bundle_user WHERE BundleId = @iBundleId
	DELETE tbl_report_group_bundle WHERE BundleId = @iBundleId


	SET @ReturnStatus = @@ERROR

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_group_bundle_ins') IS NOT NULL
	DROP PROCEDURE sp_report_group_bundle_ins
GO

CREATE PROCEDURE sp_report_group_bundle_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-20
Description:  Create a bundle for updating users
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupId			int		
	,@iBundleType		tinyint -- 1=add, 2=remove, 3=replace
	,@oBundleId			uniqueidentifier OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
	SET @oBundleId = NULL

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Checks
	IF NOT EXISTS (SELECT * FROM tbl_report_group WHERE @iGroupId = GroupId And IsDeleted = 0)
		RETURN (100301) --	Group does not exist

	IF @iBundleType NOT BETWEEN 1 AND 3
		RETURN (100320) --	Invalid bundle type


	-- Insert row
	SET @oBundleId = NEWID()

	INSERT tbl_report_group_bundle (BundleId, GroupId, BundleType) 
	VALUES(@oBundleId, @iGroupId, @iBundleType)

	SET @ReturnStatus = @@ERROR

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_group_bundle_user_ins') IS NOT NULL
	DROP PROCEDURE sp_report_group_bundle_user_ins
GO

CREATE PROCEDURE sp_report_group_bundle_user_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-20
Description:  Insert a user into a bundle
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iBundleId			uniqueidentifier 
	,@iUserName			nvarchar(510)
	,@iDomain			nvarchar(510)
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Checks
	IF NOT EXISTS (SELECT * FROM tbl_report_group_bundle WHERE @iBundleId = BundleId)
		RETURN (100321)	-- Bundle does not exist

	IF EXISTS (SELECT * FROM tbl_report_group_bundle_user
				WHERE BundleId = @iBundleId
				AND UserName = @iUserName
				AND Domain = @iDomain)
	RETURN (100322) -- User is already in bundle



	-- Insert row


	INSERT tbl_report_group_bundle_user (BundleId, UserName, Domain)
	VALUES(@iBundleId, @iUserName, @iDomain)

	SET @ReturnStatus = @@ERROR

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_group_get') IS NOT NULL
	DROP PROCEDURE sp_report_group_get
GO

CREATE PROCEDURE sp_report_group_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  List one or all groups
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-07
Description: List column GroupFullPath as well
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-09
Description: Addded cross-umbrella param, removed IncludeDeleted param.
			 Use sp_report_group_get_recursive to list
************************************************************/
	@iUmbrellaId			int		= NULL
	,@iGroupId				int		= NULL
	,@iCrossUmbrella		bit		= 0

AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF @iUmbrellaId IS NOT NULL AND @iGroupId IS NOT NULL
		RETURN	(100302) --	Cannot specify both group and umbrella.


	
	IF @iUmbrellaId IS NOT NULL
		AND NOT EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE ISNULL(@iUmbrellaId,UmbrellaId) = UmbrellaId)
		RETURN (100300) --	Umbrella does not exist


	IF @iGroupId IS NOT NULL
		AND NOT EXISTS (SELECT * FROM vw_report_group WHERE ISNULL(@iGroupId,GroupId) = GroupId)
		RETURN (100301) --	Group does not exist

	-- Get groups
	-----------------------------

	DECLARE @Groups TABLE (GroupId int)
	
	INSERT @Groups (GroupId)
	EXEC @ReturnStatus = sp_report_group_get_recursive	
		@iUmbrellaId		= @iUmbrellaId
		,@iGroupId			= @iGroupId
		,@iCrossUmbrella	= @iCrossUmbrella
		,@iSilent			= 0

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR

	-- Return results
	-----------------------------

	DECLARE @ActualUmbrella INT
	SET @ActualUmbrella = @iUmbrellaId
	IF @ActualUmbrella IS NULL
		SELECT @ActualUmbrella = UmbrellaId FROM vw_report_group WHERE GroupId = @iGroupId
	

	SELECT 
		g.* 
		,gd.GroupFullPath
	FROM tbl_report_group g
	INNER JOIN vw_report_group_display gd
		ON g.GroupId = gd.GroupId
	INNER JOIN @Groups gf
		ON gf.GroupId = gd.GroupId
	WHERE gd.RootUmbrellaId = @ActualUmbrella OR @iCrossUmbrella=1
	ORDER BY gd.GroupFullPath

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_group_get_recursive') IS NOT NULL
	DROP PROCEDURE sp_report_group_get_recursive
GO

CREATE PROCEDURE sp_report_group_get_recursive
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-11-24
Description:  Given group or umbrella id, get all subgroups recursively
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupId				int = NULL
	,@iUmbrellaId			int = NULL
	,@iCrossUmbrella		bit = 1	
	,@iSilent				bit = 0
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Check input params

	IF @iUmbrellaId IS NOT NULL AND @iGroupId IS NOT NULL
		RETURN	(100302) --	Cannot specify both group and umbrella.

	IF @iUmbrellaId IS NULL AND @iGroupId IS NULL
		RETURN	(100308) --	Must specify either group or umbrella.


	IF @iUmbrellaId IS NOT NULL
		AND NOT EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE ISNULL(@iUmbrellaId,UmbrellaId) = UmbrellaId)
		RETURN (100300) --	Umbrella does not exist


	IF @iGroupId IS NOT NULL
		AND NOT EXISTS (SELECT * FROM vw_report_group WHERE ISNULL(@iGroupId,GroupId) = GroupId)
		RETURN (100301) --	Group does not exist

	-- do stuff

	IF object_id('tempdb..#groups') IS NULL
		CREATE TABLE #groups (GroupId int)


	IF @iUmbrellaId IS NOT NULL
	BEGIN
		IF @iCrossUmbrella = 1
			INSERT #groups (GroupId)
			SELECT DISTINCT 
				GroupId 
			FROM vw_report_group_display
			WHERE RootUmbrellaId = @iUmbrellaId

		ELSE
			INSERT #groups (GroupId)
			SELECT DISTINCT 
				GroupId 
			FROM vw_report_group_display
			WHERE UmbrellaId = @iUmbrellaId
				AND UmbrellaId = RootUmbrellaId
	END
	ELSE -- GroupId specified
	BEGIN

		SELECT @iUmbrellaId = UmbrellaId FROM vw_report_group WHERE GroupId = @iGroupId;
		
		WITH a (GroupId) AS
			(SELECT @iGroupId
			UNION ALL
			SELECT GroupChildId FROM tbl_report_group_group gg
			INNER JOIN a
				ON	a.GroupId = gg.GroupParentId)
		INSERT #groups (GroupId)
		SELECT DISTINCT
			gd.GroupId 
		FROM vw_report_group_display gd
		INNER JOIN a ON a.GroupId = gd.GroupId
		WHERE (@iCrossUmbrella = 1 AND RootUmbrellaId = @iUmbrellaId)
			OR (@iCrossUmbrella = 0 AND UmbrellaId = @iUmbrellaId AND UmbrellaId = RootUmbrellaId)

	END

	IF @iSilent = 0
		SELECT GroupId FROM #groups




	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_report_group_ins') IS NOT NULL
	DROP PROCEDURE sp_report_group_ins
GO

CREATE PROCEDURE sp_report_group_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  Create group
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUmbrellaId			int		
	,@iGroupName			nvarchar(256)
	,@iGroupComment			nvarchar(512) = NULL
	,@iStartDate			datetime = NULL
	,@iEndDate				datetime = NULL
	,@oGroupId				int		OUTPUT

AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	
	IF NOT EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE ISNULL(@iUmbrellaId,UmbrellaId) = UmbrellaId)
		RETURN (100300) --	Umbrella does not exist



	IF EXISTS (SELECT * FROM tbl_report_group WHERE IsDeleted = 0 AND GroupName = @iGroupName AND UmbrellaId = @iUmbrellaId)
		RETURN (100304) --	Duplicate group name not allowed in same umbrella


	INSERT tbl_report_group
		(GroupName
		,GroupComment
		,UmbrellaId
		,StartDate
		,EndDate)
	VALUES
		(@iGroupName
		,@iGroupComment	
		,@iUmbrellaId
		,@iStartDate			
		,@iEndDate)			

	SELECT @oGroupId = SCOPE_IDENTITY()


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_report_group_umbrella_get') IS NOT NULL
	DROP PROCEDURE sp_report_group_umbrella_get
GO

CREATE PROCEDURE sp_report_group_umbrella_get
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  List one or all umbrellas
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUmbrellaId			int		= NULL
	,@iIncludeDeleted		bit		= 0

AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE ISNULL(@iUmbrellaId,UmbrellaId) = UmbrellaId)
		RETURN (100300) --	Umbrella does not exist


	SELECT * 
	FROM tbl_report_group_umbrella 
	WHERE ISNULL(@iUmbrellaId,UmbrellaId) = UmbrellaId
	AND IsDeleted <= @iIncludeDeleted

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_report_group_umbrella_ins') IS NOT NULL
	DROP PROCEDURE sp_report_group_umbrella_ins
GO

CREATE PROCEDURE sp_report_group_umbrella_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  Add an umbrella
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUmbrellaName			nvarchar(256)
	,@iUmbrellaComment		nvarchar(512) = NULL
	,@iMinTicketGroups		int = NULL
	,@iMaxTicketGroups		int = NULL
	,@iStartDate			datetime = NULL
	,@iEndDate				datetime = NULL
	,@oUmbrellaId			int		OUTPUT

AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE IsDeleted = 0 AND UmbrellaName = @iUmbrellaName)
		RETURN (100303) --	Duplicate name not allowed



	INSERT tbl_report_group_umbrella
		(UmbrellaName
		,UmbrellaComment
		,MinTicketGroups
		,MaxTicketGroups
		,StartDate
		,EndDate)
	VALUES
		(@iUmbrellaName			
		,@iUmbrellaComment		
		,@iMinTicketGroups		
		,@iMaxTicketGroups		
		,@iStartDate			
		,@iEndDate)			

	SELECT @oUmbrellaId = SCOPE_IDENTITY()


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_report_group_umbrella_upd') IS NOT NULL
	DROP PROCEDURE sp_report_group_umbrella_upd
GO

CREATE PROCEDURE sp_report_group_umbrella_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  Update an umbrella
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iUmbrellaId			int		
	,@iUmbrellaName			nvarchar(256) = NULL
	,@iUmbrellaComment		nvarchar(512) = NULL
	,@iMinTicketGroups		int = NULL
	,@iMaxTicketGroups		int = NULL
	,@iStartDate			datetime = NULL
	,@iEndDate				datetime = NULL
	,@iIsDeleted			bit = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	IF NOT EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE ISNULL(@iUmbrellaId,UmbrellaId) = UmbrellaId)
		RETURN (100300) --	Umbrella does not exist

	IF @iUmbrellaName IS NOT NULL 
		AND EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE IsDeleted = 0 AND UmbrellaName = @iUmbrellaName AND UmbrellaId <> @iUmbrellaId)
		RETURN (100303) --	Duplicate name not allowed


	UPDATE tbl_report_group_umbrella SET
		UmbrellaName		= ISNULL(@iUmbrellaName, UmbrellaName)
		,UmbrellaComment	= ISNULL(@iUmbrellaComment,	UmbrellaComment)
		,MinTicketGroups	= ISNULL(@iMinTicketGroups,	MinTicketGroups)
		,MaxTicketGroups	= ISNULL(@iMaxTicketGroups, MaxTicketGroups)
		,StartDate			= ISNULL(@iStartDate, StartDate)
		,EndDate			= ISNULL(@iEndDate, EndDate)
		,IsDeleted			= ISNULL(@iIsDeleted, IsDeleted)
	WHERE UmbrellaId = @iUmbrellaId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_report_group_upd') IS NOT NULL
	DROP PROCEDURE sp_report_group_upd
GO

CREATE PROCEDURE sp_report_group_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-07-22
Description:  Update a group
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iGroupId				int		
	,@iUmbrellaId			int	= NULL
	,@iGroupName			nvarchar(256) = NULL
	,@iGroupComment			nvarchar(512) = NULL
	,@iStartDate			datetime = NULL
	,@iEndDate				datetime = NULL
	,@iIsDeleted			bit = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	IF @iGroupId IS NOT NULL
		AND NOT EXISTS (SELECT * FROM tbl_report_group WHERE ISNULL(@iGroupId,GroupId) = GroupId)
		RETURN (100301) --	Group does not exist

	-- todo: kolla umbrellaid finns, namn ej dublett (i nytt eller existerande umbrella)

	UPDATE tbl_report_group SET
		GroupName		= ISNULL(@iGroupName, GroupName)
		,GroupComment	= ISNULL(@iGroupComment, GroupComment)
		,UmbrellaId		= ISNULL(@iUmbrellaId, UmbrellaId)
		,StartDate		= ISNULL(@iStartDate, StartDate)
		,EndDate		= ISNULL(@iEndDate, EndDate)
		,IsDeleted		= ISNULL(@iIsDeleted, IsDeleted)
	WHERE GroupId = @iGroupId

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_ticket_register_ad_group') IS NOT NULL
	DROP PROCEDURE sp_ticket_register_ad_group
GO

CREATE PROCEDURE sp_ticket_register_ad_group
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-08-10
Description:  Register which AD group the user owning this ticket is member of
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iTicketId			uniqueidentifier 
	,@iADGroup			nvarchar(256)		

AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ADUmbrellaId			int
			,@GroupId				int


	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @ADUmbrellaId = dbo.fn_property_get_numeric('ADUmbrellaId')

	IF @ADUmbrellaId IS NULL
		RETURN (100090) --	Property ADUmbrellaId not set - could not log ticket group membership

	IF EXISTS (SELECT * FROM tbl_report_group_umbrella WHERE UmbrellaId = @ADUmbrellaId AND IsDeleted = 1)		
		RETURN (100091) -- Property ADUmbrellaId refers to deleted umbrella - could not log ticket group membership

	IF EXISTS (SELECT * FROM vw_report_group WHERE GroupName = @iADGroup AND IsDeleted = 0 AND LogTickets = 0)
		RETURN (0) -- This group should not be logged
	

	SELECT @GroupId = GroupId 
	FROM vw_report_group 
	WHERE	UmbrellaId = @ADUmbrellaId
			AND GroupName = @iADGroup 
			AND IsDeleted = 0 --AND LogTickets = 1

	IF @GroupId IS NULL
	BEGIN -- Create group
		EXEC @ReturnStatus = sp_report_group_ins @iUmbrellaId		= @ADUmbrellaId
												,@iGroupName		= @iADGroup
												,@iGroupComment		= 'Auto-created by sp_ticket_register_ad_group'
												,@oGroupId			= @GroupId OUTPUT

		IF @ReturnStatus <> 0
			RETURN (@ReturnStatus)
	END

	-- Is this group active for logging?
	IF NOT EXISTS (SELECT * FROM vw_report_group WHERE GroupId = @GroupId AND LogTickets = 1 AND UmbrellaId = @ADUmbrellaId)
		RETURN (0) -- This group should not be logged


	-- Insert group/ticket in mapping table

	IF NOT EXISTS (SELECT * FROM tbl_report_ticket_group WHERE TicketId = @iTicketId AND GroupId = @GroupId)
		INSERT tbl_report_ticket_group (TicketId, GroupId) VALUES(@iTicketId, @GroupId)


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)
END
GO

IF OBJECT_ID('sp_org2umbrella_sync_do') IS NOT NULL
	DROP PROCEDURE sp_org2umbrella_sync_do
GO

CREATE PROCEDURE sp_org2umbrella_sync_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-06
Description:	Actual sync of one Config
				Does not support changing username of a user (which is ok for now as other parts of cirrato don't either).
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-10
Description: Fixed a left join that would cause groups to be duplicated on each run if more than one ConfigId present.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-11
Description: Fixed join group->user mapping
************************************************************/
	@iConfigId				int
	,@oReturnStatusMessage	nvarchar(1024) = NULL OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oReturnStatusMessage = NULL

	-- CHECK IF WE CAN START
	------------------------------------------------------------------------------
	
	IF @@TRANCOUNT = 0
		RETURN (100600) --	SP must be run within a transaction

	IF EXISTS(SELECT * FROM tbl_scheduled_job WHERE JobName = 'Quota batch' AND IsRunning=1)
		RETURN (100611) --	Quota batch job in progress - cannot do umbrella sync now

	-- INIT
	------------------------------------------------------------------------------

	-- Get AD Umbrella Ids:

	DECLARE @ADOUUmbrellaId int
			,@ADUmbrellaId int

	SELECT @ADOUUmbrellaId = propertyValueNumeric 
	FROM tbl_property WHERE propertyName = 'ADOUUmbrellaId' AND propertyGroup = 'Reports'

	SELECT @ADUmbrellaId = propertyValueNumeric 
	FROM tbl_property WHERE propertyName = 'ADUmbrellaId' AND propertyGroup = 'Reports'

	IF @ADOUUmbrellaId IS NULL
		RETURN(100601) -- ADOUUmbrellaId must be set

	IF @ADUmbrellaId IS NULL
		RETURN(100602) -- ADUmbrellaId must be set


	-- Check that it's ok to process this Config:
	IF NOT EXISTS (SELECT * FROM tbl_org_configuration WHERE ConfigID = @iConfigId)
		RETURN (100603)	-- 	ConfigID does not exist

	IF EXISTS (SELECT * FROM tbl_org_configuration WHERE ConfigID = @iConfigId AND InProgress=1)
		RETURN (100604) -- ConfigID dapper sync in progress - cannot do umbrella sync now

	IF EXISTS (SELECT * FROM tbl_org_configuration WHERE ConfigID = @iConfigId AND Valid=0)
		RETURN (100606) --	Config is not valid

	IF EXISTS (SELECT * FROM tbl_org_configuration WHERE ConfigID = @iConfigId AND Blocked=1)
		RETURN (100607) --	Config is blocked



	-- Get current NTDomain, ConfigName, ConfigGUID:

	DECLARE @ConfigName		nvarchar(256)
			,@ConfigGUID	uniqueidentifier
			,@NTDomain		nvarchar(510)
	
	SELECT 
		@ConfigName = Name
		,@ConfigGUID = GUID
	FROM tbl_org_configuration 
	WHERE ConfigID = @iConfigId


	SELECT 
		@NTDomain = NetBIOSName
	FROM tbl_org_domain 
	WHERE ConfigID = @iConfigId


	IF @ConfigName IS NULL 
		RETURN (100608) --	Config name must be set

	IF @ConfigGUID IS NULL 
		RETURN (100609) --	Config GUID must be set

	IF @NTDomain IS NULL 
		RETURN (100610) --	NetBIOSName of the domain must be retrieved from AD


	-- CREATE/GET BASE GROUPS FOR CONFIG
	------------------------------------------------------------------------------

	DECLARE @GroupsBaseGroupId int
			,@OUBaseGroupId int
			,@GroupsBaseGroupExtId	nvarchar(128)
			,@OUBaseGroupExtId		nvarchar(128)

	SET @GroupsBaseGroupExtId	= @ConfigGUID
	SET @OUBaseGroupExtId		= dbo.fn_guid_addone(@ConfigGUID)

	-- Groups base group:
	SELECT @GroupsBaseGroupId = GroupId
	FROM vw_report_group 
	WHERE UmbrellaId = @ADUmbrellaId AND ExternalId = @GroupsBaseGroupExtId

	IF @GroupsBaseGroupId IS NULL
	BEGIN
		INSERT tbl_report_group (UmbrellaId, GroupName, GroupComment, ExternalId)
		VALUES (@ADUmbrellaId, @ConfigName, 'Auto-created group that holds all sub-groups of a dapper Config', @GroupsBaseGroupExtId)
	
		SELECT @GroupsBaseGroupId = SCOPE_IDENTITY()
	END

	-- OUs base group:
	SELECT @OUBaseGroupId = GroupId
	FROM vw_report_group 
	WHERE UmbrellaId = @ADOUUmbrellaId AND ExternalId = @OUBaseGroupExtId

	IF @OUBaseGroupId IS NULL
	BEGIN
		INSERT tbl_report_group (UmbrellaId, GroupName, GroupComment, ExternalId)
		VALUES (@ADOUUmbrellaId, @ConfigName, 'Auto-created group that holds all sub-OUs of a dapper Config', @OUBaseGroupExtId)
	
		SELECT @OUBaseGroupId = SCOPE_IDENTITY()
	END



	-- BACKWARDS COMPATIBILITY (FIRST RUN)
	------------------------------------------------------------------------------

	-- On first run, set GUID for groups in ADUmbrella that do not have an external id:
	-- Then place them all under the configid group. Will be put in correct places later on (below), but need to be in the ConfigId group
	-- to be picked up

	IF NOT EXISTS (SELECT * FROM tbl_property WHERE propertyGroup='Reports' AND propertyName='ADGraphFirstRun')
	BEGIN

		UPDATE gOld
			SET gOld.ExternalId = gNew.GUID
		FROM tbl_report_group gOld
		INNER JOIN vw_org_group gNew
			ON gOld.GroupName = gNew.Name
		WHERE gOld.UmbrellaId = @ADUmbrellaId
			AND gOld.ExternalId IS NULL
			AND gNew.ConfigID = @iConfigId

		-- Catch existing groups that are not in the import table
		-- Set a dummy-id as a NULL value would keep the group "hanging in there" even though it should be deleted.
		UPDATE gOld
			SET gOld.ExternalId = NEWID()
		FROM tbl_report_group gOld
		WHERE gOld.UmbrellaId = @ADUmbrellaId
			AND gOld.ExternalId IS NULL


		-- Put them in the base group:
		INSERT tbl_report_group_group (GroupParentId, GroupChildId)
		SELECT 
			@GroupsBaseGroupId
			,GroupId
		FROM vw_report_group
		WHERE UmbrellaId = @ADUmbrellaId
			AND ExternalId <> @GroupsBaseGroupExtId


		INSERT tbl_property (propertyGroup, propertyName, propertyDate) VALUES ('Reports', 'ADGraphFirstRun', getdate())

	END

	-- GET BASE GROUPS' MEMBERS
	------------------------------------------------------------------------------

	-- Pick out list of groupIds for respective sub-graph into two table variables: 
	DECLARE @AllGroups	TABLE (GroupId int)
	DECLARE @AllOUs		TABLE (GroupId int)

	-- AD Groups:
	INSERT @AllGroups (GroupId)
	EXEC @ReturnStatus = sp_report_group_get_recursive	
		@iGroupId			= @GroupsBaseGroupId
		,@iCrossUmbrella	= 0
		,@iSilent			= 0

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR

	DELETE @AllGroups WHERE GroupId = @GroupsBaseGroupId


	-- AD OUs:
	INSERT @AllOUs (GroupId)
	EXEC @ReturnStatus = sp_report_group_get_recursive	
		@iGroupId			= @OUBaseGroupId
		,@iCrossUmbrella	= 0
		,@iSilent			= 0

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR

	DELETE @AllOUs WHERE GroupId = @OUBaseGroupId


	-- USERS
	------------------------------------------------------------------------------

	-- Fill tbl_report_users with users that are new

	INSERT tbl_report_users (UserName, Domain)
	SELECT 
		Name
		,@NTDomain
	FROM tbl_org_user uNew
	LEFT JOIN tbl_report_users uExist
		ON uExist.UserName = uNew.Name
		AND uExist.Domain = @NTDomain
	WHERE uNew.ConfigID = @iConfigId
		AND uExist.UserName IS NULL

	

	-- AD GROUPS
	------------------------------------------------------------------------------

	-- Mark groups that no longer exist as deleted: --verifiera: bara grupper i denna config
	UPDATE gOld
		SET IsDeleted = 1
	FROM tbl_report_group gOld
	INNER JOIN @AllGroups a
		ON a.GroupId = gOld.GroupId
	LEFT JOIN vw_org_group gNew
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADUmbrellaId
		AND gNew.ConfigID = @iConfigId
	WHERE gNew.GUID IS NULL
		AND gOld.UmbrellaId = @ADUmbrellaId


	-- Add groups that are new: --verify: bara kolla mot grupper i denna config
	INSERT tbl_report_group
		(GroupName
		,UmbrellaId
		,ExternalId)
	SELECT
		Name
		,@ADUmbrellaId
		,GUID
	FROM vw_org_group gNew
	LEFT JOIN vw_report_group gOld
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADUmbrellaId
		AND gOld.GroupId IN (SELECT GroupId FROM @AllGroups)
	WHERE gOld.GroupName IS NULL
		AND gNew.ConfigID = @iConfigId

	-- Update all names, in case any name has changed:
	UPDATE gOld
		SET gOld.GroupName = gNew.Name
	FROM tbl_report_group gOld
	INNER JOIN vw_org_group gNew
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADUmbrellaId
		AND gNew.ConfigID = @iConfigId 
		AND gOld.GroupId IN (SELECT GroupId FROM @AllGroups)
	WHERE gOld.IsDeleted=0

	-- AD ORGANIZATIONAL UNITS (same as group sync above except different table / umbrella id)
	------------------------------------------------------------------------------

	-- Mark OUs that no longer exist as deleted: --verify: bara grupper i denna config
	UPDATE gOld
		SET IsDeleted = 1
	FROM tbl_report_group gOld
	INNER JOIN @AllGroups a
		ON a.GroupId = gOld.GroupId
	LEFT JOIN vw_org_unit gNew
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADOUUmbrellaId
		AND gNew.ConfigID = @iConfigId
	WHERE gNew.GUID IS NULL
		AND gOld.UmbrellaId = @ADOUUmbrellaId


	-- Add OUs that are new: --verify: bara kolla mot grupper i denna config
	INSERT tbl_report_group
		(GroupName
		,UmbrellaId
		,ExternalId)
	SELECT
		Name
		,@ADOUUmbrellaId
		,GUID
	FROM vw_org_unit gNew
	LEFT JOIN vw_report_group gOld
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADOUUmbrellaId

		AND gOld.GroupId IN (SELECT GroupId FROM @AllOUs)
	WHERE gOld.GroupName IS NULL
		AND gNew.ConfigID = @iConfigId;

	-- Update all names, in case any name has changed:
	UPDATE gOld
		SET gOld.GroupName = gNew.Name
	FROM tbl_report_group gOld
	INNER JOIN vw_org_unit gNew
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADOUUmbrellaId
		AND gNew.ConfigID = @iConfigId 
		AND gOld.GroupId IN (SELECT GroupId FROM @AllOUs)
	WHERE gOld.IsDeleted=0


	-- ADD RELATIONS

	------------------------------------------------------------------------------
	-- Delete existing relations:

	-- Delete all relations to/from groups under the Group base node
	DELETE tbl_report_group_group 
	WHERE GroupParentId IN (SELECT GroupId FROM @AllGroups)
		OR GroupChildId IN (SELECT GroupId FROM @AllGroups)
		OR GroupParentId = @GroupsBaseGroupId;

	-- Delete all relations to/from groups under the OU base node
	DELETE tbl_report_group_group 
	WHERE GroupParentId IN (SELECT GroupId FROM @AllOUs)
		OR GroupChildId IN (SELECT GroupId FROM @AllOUs)
		OR GroupParentId = @OUBaseGroupId;

	-- Delete group memberships for users in ADGroups or OUGroups
	DELETE tbl_cirrato_wallet_user_group 
	WHERE GroupId IN (SELECT GroupId FROM @AllGroups)
		OR GroupId IN (SELECT GroupId FROM @AllOUs);


	-- create intra-group links:

	WITH Relations (ParentDN, ChildDN, pGUID, pGroupId, cGUID, cGroupId, pName, cName) AS (
		SELECT 
			ggm.ParentDN
			,ggm.ChildDN
			,pguid.GUID pGUID
			,pid.GroupId pGroupId
			,cguid.GUID cGUID
			,cid.GroupId cGroupId
			,pguid.Name pName
			,cguid.Name cName
		FROM tbl_org_group_group_map ggm
		INNER JOIN vw_org_group pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		INNER JOIN vw_org_group cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN vw_report_group cid
			ON cguid.GUID = cid.ExternalId
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADUmbrellaId
			AND cid.UmbrellaId = @ADUmbrellaId)
	,AllGroups (GroupId, GroupName) AS (
		SELECT
			GroupId
			,GroupName
		FROM vw_org_group gNew
		INNER JOIN vw_report_group gOld
			ON gOld.ExternalId = gNew.GUID
		WHERE gNew.ConfigID = @iConfigId
		AND gOld.UmbrellaId = @ADUmbrellaId)
	INSERT tbl_report_group_group (GroupParentId, GroupChildId)
	SELECT pGroupId,cGroupId FROM Relations
	UNION
	SELECT @GroupsBaseGroupId, ag.GroupId 
	FROM AllGroups ag
	WHERE ag.GroupId NOT IN (SELECT r2.cGroupId FROM Relations r2); -- when something has no parent ou, that means its parent is root


	-- create intra-OU links (copy of intra-group links but other tables/variables):
	WITH Relations (ParentDN, ChildDN, pGUID, pGroupId, cGUID, cGroupId, pName, cName) AS (
		SELECT 
			ggm.ParentDN
			,ggm.ChildDN
			,pguid.GUID pGUID
			,pid.GroupId pGroupId
			,cguid.GUID cGUID
			,cid.GroupId cGroupId
			,pguid.Name pName
			,cguid.Name cName
		FROM tbl_org_unit_unit_map ggm
		INNER JOIN vw_org_unit pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		INNER JOIN vw_org_unit cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN vw_report_group cid
			ON cguid.GUID = cid.ExternalId
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADOUUmbrellaId
			AND cid.UmbrellaId = @ADOUUmbrellaId)
	,AllGroups (GroupId, GroupName) AS (
		SELECT
			GroupId
			,GroupName
		FROM vw_org_unit gNew
		INNER JOIN vw_report_group gOld
			ON gOld.ExternalId = gNew.GUID
		WHERE gNew.ConfigID = @iConfigId
		AND gOld.UmbrellaId = @ADOUUmbrellaId)
	INSERT tbl_report_group_group (GroupParentId, GroupChildId)
	SELECT pGroupId,cGroupId FROM Relations
	UNION
	SELECT @OUBaseGroupId, ag.GroupId 
	FROM AllGroups ag
	WHERE ag.GroupId NOT IN (SELECT r2.cGroupId FROM Relations r2); -- when something has no parent ou, that means its parent is root


	-- create OU->group links:
	
	WITH Relations (pGroupId, cGroupId) AS (
		SELECT 
--			ggm.ParentDN
--			,ggm.ChildDN
--			,pguid.GUID pGUID
			pid.GroupId pGroupId
--			,cguid.GUID cGUID
			,cid.GroupId cGroupId
--			,pguid.Name pName
--			,cguid.Name cName
		FROM tbl_org_unit_group_map ggm
		--parent: map against OUs:
		INNER JOIN vw_org_unit pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		--child: map against Groups:
		INNER JOIN vw_org_group cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN vw_report_group cid
			ON cguid.GUID = cid.ExternalId
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADOUUmbrellaId
			AND cid.UmbrellaId = @ADUmbrellaId)
	INSERT tbl_report_group_group (GroupParentId, GroupChildId)
	SELECT pGroupId,cGroupId FROM Relations;

	-- OU->user links:

	WITH Relations (pGroupId, cUserId) AS (
		SELECT 
			pid.GroupId pGroupId

			,cid.UserId cUserId

		FROM tbl_org_unit_user_map ggm
		--parent: map against OUs:
		INNER JOIN vw_org_unit pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		--child: map against Users:
		INNER JOIN tbl_org_user cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN tbl_report_users cid
			ON cguid.Name = cid.UserName
			AND cid.Domain = @NTDomain
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADOUUmbrellaId)
	INSERT tbl_cirrato_wallet_user_group(GroupId, UserId)
	SELECT pGroupId, cUserId FROM Relations;



	-- group->user links:
	WITH Relations (pGroupId, cUserId) AS (
		SELECT 
			pid.GroupId pGroupId
			,cid.UserId cUserId
		FROM tbl_org_group_user_map ggm
		--parent: map against Groups:
		INNER JOIN vw_org_group pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		--child: map against Users:
		INNER JOIN tbl_org_user cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN tbl_report_users cid
			ON cguid.Name = cid.UserName
			AND cid.Domain = @NTDomain
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADUmbrellaId)
	INSERT tbl_cirrato_wallet_user_group(GroupId, UserId)
	SELECT pGroupId, cUserId FROM Relations;


	-- TEST FOR CIRCULAR PATHS IN THE ANY OF THE UMBRELLAS
	------------------------------------------------------------------------------
	DECLARE @a TABLE (a int)
	INSERT @a (a) SELECT GroupId FROM vw_report_group_display -- will return an error if there are any circular refs




	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_org2umbrella_sync') IS NOT NULL
	DROP PROCEDURE sp_org2umbrella_sync
GO

CREATE PROCEDURE sp_org2umbrella_sync
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-06
Description:  Main SP to be called from dapper.

	Copy data from dapper import tables to umbrella/group structure

	Two umbrellas must exist and be configured in tbl_property:
	"ADUmbrella" - stores groups
	"ADOUUmrella" - stores OUs
	This is done automatically at installation of Cirrato.

------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-10
Description: Added 
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iConfigId					int
	,@oReturnStatusMessage		nvarchar(1024) = NULL OUTPUT
	,@oReturnStatusTranslation	nvarchar(1024) = NULL OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oReturnStatusMessage = NULL



	BEGIN TRY
		IF @@TRANCOUNT = 0
			BEGIN TRANSACTION ADSyncTran

		EXEC @ReturnStatus = sp_org2umbrella_sync_do	@iConfigId				= @iConfigId
														,@oReturnStatusMessage	= @oReturnStatusMessage OUTPUT
	
		IF @ReturnStatus <> 0
			GOTO PROC_ERROR
		
		COMMIT TRANSACTION ADSyncTran -- bortkommentera f�r test

	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION ADSyncTran
	
		SET @oReturnStatusMessage =
			LEFT(ISNULL(ERROR_PROCEDURE(),'') + ':' + CAST(ISNULL(ERROR_LINE(),0) AS NVARCHAR(20)) + ' ' + ISNULL(ERROR_MESSAGE(),''), 1024)

		SET @oReturnStatusTranslation = dbo.fn_errorno_translate(100605,'en')
		RETURN (100605) --	Execution Error

	END CATCH





	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	SET @oReturnStatusTranslation = dbo.fn_errorno_translate(0,'en')
	RETURN (0)

	PROC_ERROR:
	
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION ADSyncTran

	SET @oReturnStatusTranslation = dbo.fn_errorno_translate(@ReturnStatus,'en')
	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_org2umbrella_sync_do') IS NOT NULL
	DROP PROCEDURE sp_org2umbrella_sync_do
GO

CREATE PROCEDURE sp_org2umbrella_sync_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-06
Description:	Actual sync of one Config
				Does not support changing username of a user (which is ok for now as other parts of cirrato don't either).
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-10
Description: Fixed a left join that would cause groups to be duplicated on each run if more than one ConfigId present.
------------------------------------------------------------
Modified by: Henrik Linder
Modification date: 2009-12-11
Description: Fixed join group->user mapping
************************************************************/
	@iConfigId				int
	,@oReturnStatusMessage	nvarchar(1024) = NULL OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oReturnStatusMessage = NULL

	-- CHECK IF WE CAN START
	------------------------------------------------------------------------------
	
	IF @@TRANCOUNT = 0
		RETURN (100600) --	SP must be run within a transaction

	IF EXISTS(SELECT * FROM tbl_scheduled_job WHERE JobName = 'Quota batch' AND IsRunning=1)
		RETURN (100611) --	Quota batch job in progress - cannot do umbrella sync now

	-- INIT
	------------------------------------------------------------------------------

	-- Get AD Umbrella Ids:

	DECLARE @ADOUUmbrellaId int
			,@ADUmbrellaId int

	SELECT @ADOUUmbrellaId = propertyValueNumeric 
	FROM tbl_property WHERE propertyName = 'ADOUUmbrellaId' AND propertyGroup = 'Reports'

	SELECT @ADUmbrellaId = propertyValueNumeric 
	FROM tbl_property WHERE propertyName = 'ADUmbrellaId' AND propertyGroup = 'Reports'

	IF @ADOUUmbrellaId IS NULL
		RETURN(100601) -- ADOUUmbrellaId must be set

	IF @ADUmbrellaId IS NULL
		RETURN(100602) -- ADUmbrellaId must be set


	-- Check that it's ok to process this Config:
	IF NOT EXISTS (SELECT * FROM tbl_org_configuration WHERE ConfigID = @iConfigId)
		RETURN (100603)	-- 	ConfigID does not exist

	IF EXISTS (SELECT * FROM tbl_org_configuration WHERE ConfigID = @iConfigId AND InProgress=1)
		RETURN (100604) -- ConfigID dapper sync in progress - cannot do umbrella sync now

	IF EXISTS (SELECT * FROM tbl_org_configuration WHERE ConfigID = @iConfigId AND Valid=0)
		RETURN (100606) --	Config is not valid

	IF EXISTS (SELECT * FROM tbl_org_configuration WHERE ConfigID = @iConfigId AND Blocked=1)
		RETURN (100607) --	Config is blocked



	-- Get current NTDomain, ConfigName, ConfigGUID:

	DECLARE @ConfigName		nvarchar(256)
			,@ConfigGUID	uniqueidentifier
			,@NTDomain		nvarchar(510)
	
	SELECT 
		@ConfigName = Name
		,@ConfigGUID = GUID
	FROM tbl_org_configuration 
	WHERE ConfigID = @iConfigId


	SELECT 
		@NTDomain = NetBIOSName
	FROM tbl_org_domain 
	WHERE ConfigID = @iConfigId


	IF @ConfigName IS NULL 
		RETURN (100608) --	Config name must be set

	IF @ConfigGUID IS NULL 
		RETURN (100609) --	Config GUID must be set

	IF @NTDomain IS NULL 
		RETURN (100610) --	NetBIOSName of the domain must be retrieved from AD


	-- CREATE/GET BASE GROUPS FOR CONFIG
	------------------------------------------------------------------------------

	DECLARE @GroupsBaseGroupId int
			,@OUBaseGroupId int
			,@GroupsBaseGroupExtId	nvarchar(128)
			,@OUBaseGroupExtId		nvarchar(128)

	SET @GroupsBaseGroupExtId	= @ConfigGUID
	SET @OUBaseGroupExtId		= dbo.fn_guid_addone(@ConfigGUID)

	-- Groups base group:
	SELECT @GroupsBaseGroupId = GroupId
	FROM vw_report_group 
	WHERE UmbrellaId = @ADUmbrellaId AND ExternalId = @GroupsBaseGroupExtId

	IF @GroupsBaseGroupId IS NULL
	BEGIN
		INSERT tbl_report_group (UmbrellaId, GroupName, GroupComment, ExternalId)
		VALUES (@ADUmbrellaId, @ConfigName, 'Auto-created group that holds all sub-groups of a dapper Config', @GroupsBaseGroupExtId)
	
		SELECT @GroupsBaseGroupId = SCOPE_IDENTITY()
	END

	-- OUs base group:
	SELECT @OUBaseGroupId = GroupId
	FROM vw_report_group 
	WHERE UmbrellaId = @ADOUUmbrellaId AND ExternalId = @OUBaseGroupExtId

	IF @OUBaseGroupId IS NULL
	BEGIN
		INSERT tbl_report_group (UmbrellaId, GroupName, GroupComment, ExternalId)
		VALUES (@ADOUUmbrellaId, @ConfigName, 'Auto-created group that holds all sub-OUs of a dapper Config', @OUBaseGroupExtId)
	
		SELECT @OUBaseGroupId = SCOPE_IDENTITY()
	END



	-- BACKWARDS COMPATIBILITY (FIRST RUN)
	------------------------------------------------------------------------------

	-- On first run, set GUID for groups in ADUmbrella that do not have an external id:
	-- Then place them all under the configid group. Will be put in correct places later on (below), but need to be in the ConfigId group
	-- to be picked up

	IF NOT EXISTS (SELECT * FROM tbl_property WHERE propertyGroup='Reports' AND propertyName='ADGraphFirstRun')
	BEGIN

		UPDATE gOld
			SET gOld.ExternalId = gNew.GUID
		FROM tbl_report_group gOld
		INNER JOIN vw_org_group gNew
			ON gOld.GroupName = gNew.Name
		WHERE gOld.UmbrellaId = @ADUmbrellaId
			AND gOld.ExternalId IS NULL
			AND gNew.ConfigID = @iConfigId

		-- Catch existing groups that are not in the import table
		-- Set a dummy-id as a NULL value would keep the group "hanging in there" even though it should be deleted.
		UPDATE gOld
			SET gOld.ExternalId = NEWID()
		FROM tbl_report_group gOld
		WHERE gOld.UmbrellaId = @ADUmbrellaId
			AND gOld.ExternalId IS NULL


		-- Put them in the base group:
		INSERT tbl_report_group_group (GroupParentId, GroupChildId)
		SELECT 
			@GroupsBaseGroupId
			,GroupId
		FROM vw_report_group
		WHERE UmbrellaId = @ADUmbrellaId
			AND ExternalId <> @GroupsBaseGroupExtId


		INSERT tbl_property (propertyGroup, propertyName, propertyDate) VALUES ('Reports', 'ADGraphFirstRun', getdate())

	END

	-- GET BASE GROUPS' MEMBERS
	------------------------------------------------------------------------------

	-- Pick out list of groupIds for respective sub-graph into two table variables: 
	DECLARE @AllGroups	TABLE (GroupId int)
	DECLARE @AllOUs		TABLE (GroupId int)

	-- AD Groups:
	INSERT @AllGroups (GroupId)
	EXEC @ReturnStatus = sp_report_group_get_recursive	
		@iGroupId			= @GroupsBaseGroupId
		,@iCrossUmbrella	= 0
		,@iSilent			= 0

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR

	DELETE @AllGroups WHERE GroupId = @GroupsBaseGroupId


	-- AD OUs:
	INSERT @AllOUs (GroupId)
	EXEC @ReturnStatus = sp_report_group_get_recursive	
		@iGroupId			= @OUBaseGroupId
		,@iCrossUmbrella	= 0
		,@iSilent			= 0

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR

	DELETE @AllOUs WHERE GroupId = @OUBaseGroupId


	-- USERS
	------------------------------------------------------------------------------

	-- Fill tbl_report_users with users that are new

	INSERT tbl_report_users (UserName, Domain)
	SELECT 
		Name
		,@NTDomain
	FROM tbl_org_user uNew
	LEFT JOIN tbl_report_users uExist
		ON uExist.UserName = uNew.Name
		AND uExist.Domain = @NTDomain
	WHERE uNew.ConfigID = @iConfigId
		AND uExist.UserName IS NULL

	

	-- AD GROUPS
	------------------------------------------------------------------------------

	-- Mark groups that no longer exist as deleted: --verifiera: bara grupper i denna config
	UPDATE gOld
		SET IsDeleted = 1
	FROM tbl_report_group gOld
	INNER JOIN @AllGroups a
		ON a.GroupId = gOld.GroupId
	LEFT JOIN vw_org_group gNew
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADUmbrellaId
		AND gNew.ConfigID = @iConfigId
	WHERE gNew.GUID IS NULL
		AND gOld.UmbrellaId = @ADUmbrellaId


	-- Add groups that are new: --verify: bara kolla mot grupper i denna config
	INSERT tbl_report_group
		(GroupName
		,UmbrellaId
		,ExternalId)
	SELECT
		Name
		,@ADUmbrellaId
		,GUID
	FROM vw_org_group gNew
	LEFT JOIN vw_report_group gOld
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADUmbrellaId
		AND gOld.GroupId IN (SELECT GroupId FROM @AllGroups)
	WHERE gOld.GroupName IS NULL
		AND gNew.ConfigID = @iConfigId

	-- Update all names, in case any name has changed:
	UPDATE gOld
		SET gOld.GroupName = gNew.Name
	FROM tbl_report_group gOld
	INNER JOIN vw_org_group gNew
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADUmbrellaId
		AND gNew.ConfigID = @iConfigId 
		AND gOld.GroupId IN (SELECT GroupId FROM @AllGroups)
	WHERE gOld.IsDeleted=0

	-- AD ORGANIZATIONAL UNITS (same as group sync above except different table / umbrella id)
	------------------------------------------------------------------------------

	-- Mark OUs that no longer exist as deleted: --verify: bara grupper i denna config
	UPDATE gOld
		SET IsDeleted = 1
	FROM tbl_report_group gOld
	INNER JOIN @AllGroups a
		ON a.GroupId = gOld.GroupId
	LEFT JOIN vw_org_unit gNew
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADOUUmbrellaId
		AND gNew.ConfigID = @iConfigId
	WHERE gNew.GUID IS NULL
		AND gOld.UmbrellaId = @ADOUUmbrellaId


	-- Add OUs that are new: --verify: bara kolla mot grupper i denna config
	INSERT tbl_report_group
		(GroupName
		,UmbrellaId
		,ExternalId)
	SELECT
		Name
		,@ADOUUmbrellaId
		,GUID
	FROM vw_org_unit gNew
	LEFT JOIN vw_report_group gOld
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADOUUmbrellaId

		AND gOld.GroupId IN (SELECT GroupId FROM @AllOUs)
	WHERE gOld.GroupName IS NULL
		AND gNew.ConfigID = @iConfigId;

	-- Update all names, in case any name has changed:
	UPDATE gOld
		SET gOld.GroupName = gNew.Name
	FROM tbl_report_group gOld
	INNER JOIN vw_org_unit gNew
		ON gOld.ExternalId = gNew.GUID
		AND gOld.UmbrellaId = @ADOUUmbrellaId
		AND gNew.ConfigID = @iConfigId 
		AND gOld.GroupId IN (SELECT GroupId FROM @AllOUs)
	WHERE gOld.IsDeleted=0


	-- ADD RELATIONS

	------------------------------------------------------------------------------
	-- Delete existing relations:

	-- Delete all relations to/from groups under the Group base node
	DELETE tbl_report_group_group 
	WHERE GroupParentId IN (SELECT GroupId FROM @AllGroups)
		OR GroupChildId IN (SELECT GroupId FROM @AllGroups)
		OR GroupParentId = @GroupsBaseGroupId;

	-- Delete all relations to/from groups under the OU base node
	DELETE tbl_report_group_group 
	WHERE GroupParentId IN (SELECT GroupId FROM @AllOUs)
		OR GroupChildId IN (SELECT GroupId FROM @AllOUs)
		OR GroupParentId = @OUBaseGroupId;

	-- Delete group memberships for users in ADGroups or OUGroups
	DELETE tbl_cirrato_wallet_user_group 
	WHERE GroupId IN (SELECT GroupId FROM @AllGroups)
		OR GroupId IN (SELECT GroupId FROM @AllOUs);


	-- create intra-group links:

	WITH Relations (ParentDN, ChildDN, pGUID, pGroupId, cGUID, cGroupId, pName, cName) AS (
		SELECT 
			ggm.ParentDN
			,ggm.ChildDN
			,pguid.GUID pGUID
			,pid.GroupId pGroupId
			,cguid.GUID cGUID
			,cid.GroupId cGroupId
			,pguid.Name pName
			,cguid.Name cName
		FROM tbl_org_group_group_map ggm
		INNER JOIN vw_org_group pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		INNER JOIN vw_org_group cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN vw_report_group cid
			ON cguid.GUID = cid.ExternalId
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADUmbrellaId
			AND cid.UmbrellaId = @ADUmbrellaId)
	,AllGroups (GroupId, GroupName) AS (
		SELECT
			GroupId
			,GroupName
		FROM vw_org_group gNew
		INNER JOIN vw_report_group gOld
			ON gOld.ExternalId = gNew.GUID
		WHERE gNew.ConfigID = @iConfigId
		AND gOld.UmbrellaId = @ADUmbrellaId)
	INSERT tbl_report_group_group (GroupParentId, GroupChildId)
	SELECT pGroupId,cGroupId FROM Relations
	UNION
	SELECT @GroupsBaseGroupId, ag.GroupId 
	FROM AllGroups ag
	WHERE ag.GroupId NOT IN (SELECT r2.cGroupId FROM Relations r2); -- when something has no parent ou, that means its parent is root


	-- create intra-OU links (copy of intra-group links but other tables/variables):
	WITH Relations (ParentDN, ChildDN, pGUID, pGroupId, cGUID, cGroupId, pName, cName) AS (
		SELECT 
			ggm.ParentDN
			,ggm.ChildDN
			,pguid.GUID pGUID
			,pid.GroupId pGroupId
			,cguid.GUID cGUID
			,cid.GroupId cGroupId
			,pguid.Name pName
			,cguid.Name cName
		FROM tbl_org_unit_unit_map ggm
		INNER JOIN vw_org_unit pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		INNER JOIN vw_org_unit cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN vw_report_group cid
			ON cguid.GUID = cid.ExternalId
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADOUUmbrellaId
			AND cid.UmbrellaId = @ADOUUmbrellaId)
	,AllGroups (GroupId, GroupName) AS (
		SELECT
			GroupId
			,GroupName
		FROM vw_org_unit gNew
		INNER JOIN vw_report_group gOld
			ON gOld.ExternalId = gNew.GUID
		WHERE gNew.ConfigID = @iConfigId
		AND gOld.UmbrellaId = @ADOUUmbrellaId)
	INSERT tbl_report_group_group (GroupParentId, GroupChildId)
	SELECT pGroupId,cGroupId FROM Relations
	UNION
	SELECT @OUBaseGroupId, ag.GroupId 
	FROM AllGroups ag
	WHERE ag.GroupId NOT IN (SELECT r2.cGroupId FROM Relations r2); -- when something has no parent ou, that means its parent is root


	-- create OU->group links:
	
	WITH Relations (pGroupId, cGroupId) AS (
		SELECT 
--			ggm.ParentDN
--			,ggm.ChildDN
--			,pguid.GUID pGUID
			pid.GroupId pGroupId
--			,cguid.GUID cGUID
			,cid.GroupId cGroupId
--			,pguid.Name pName
--			,cguid.Name cName
		FROM tbl_org_unit_group_map ggm
		--parent: map against OUs:
		INNER JOIN vw_org_unit pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		--child: map against Groups:
		INNER JOIN vw_org_group cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN vw_report_group cid
			ON cguid.GUID = cid.ExternalId
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADOUUmbrellaId
			AND cid.UmbrellaId = @ADUmbrellaId)
	INSERT tbl_report_group_group (GroupParentId, GroupChildId)
	SELECT pGroupId,cGroupId FROM Relations;

	-- OU->user links:

	WITH Relations (pGroupId, cUserId) AS (
		SELECT 
			pid.GroupId pGroupId

			,cid.UserId cUserId

		FROM tbl_org_unit_user_map ggm
		--parent: map against OUs:
		INNER JOIN vw_org_unit pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		--child: map against Users:
		INNER JOIN tbl_org_user cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN tbl_report_users cid
			ON cguid.Name = cid.UserName
			AND cid.Domain = @NTDomain
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADOUUmbrellaId)
	INSERT tbl_cirrato_wallet_user_group(GroupId, UserId)
	SELECT pGroupId, cUserId FROM Relations;



	-- group->user links:
	WITH Relations (pGroupId, cUserId) AS (
		SELECT 
			pid.GroupId pGroupId
			,cid.UserId cUserId
		FROM tbl_org_group_user_map ggm
		--parent: map against Groups:
		INNER JOIN vw_org_group pguid
			ON ggm.ParentDN = pguid.DN
		INNER JOIN vw_report_group pid
			ON pguid.GUID = pid.ExternalId
		--child: map against Users:
		INNER JOIN tbl_org_user cguid
			ON ggm.ChildDN = cguid.DN
		INNER JOIN tbl_report_users cid
			ON cguid.Name = cid.UserName
			AND cid.Domain = @NTDomain
		WHERE ggm.ConfigID = @iConfigId
			AND pguid.ConfigID = @iConfigId
			AND cguid.ConfigId = @iConfigId
			AND pid.UmbrellaId = @ADUmbrellaId)
	INSERT tbl_cirrato_wallet_user_group(GroupId, UserId)
	SELECT pGroupId, cUserId FROM Relations;


	-- TEST FOR CIRCULAR PATHS IN THE ANY OF THE UMBRELLAS
	------------------------------------------------------------------------------
	DECLARE @a TABLE (a int)
	INSERT @a (a) SELECT GroupId FROM vw_report_group_display -- will return an error if there are any circular refs




	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_chk') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_chk
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_chk
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId					int
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Generic setup checks
	-----------------------------------------------------

	-- Get AD Umbrella Ids:

	DECLARE @ADUmbrellaId int

	SELECT @ADUmbrellaId = propertyValueNumeric 
	FROM tbl_property WHERE propertyName = 'ADUmbrellaId' AND propertyGroup = 'Reports'

	IF @ADUmbrellaId IS NULL
		RETURN(100602) -- ADUmbrellaId must be set


	-- File checks
	-----------------------------------------------------

	--	1.	Header checks
	IF NOT EXISTS (SELECT * FROM tbl_cirrato_wallet_import_file WHERE FileId = @iFileId)
		RETURN (100713) --	FileId does not exist


	--	Kontrollera FileId inte redan �r processed
	IF EXISTS (SELECT * FROM tbl_cirrato_wallet_import_file WHERE FileId = @iFileId AND ProcessedDate IS NOT NULL)
		RETURN (100712) --	File has already been processed


	-- Checksum verified?
	IF NOT EXISTS (SELECT * FROM tbl_cirrato_wallet_import_file WHERE FileId = @iFileId AND ChecksumVerified=1)
		RETURN (100701) --	Checksum not verified



	-- 2.	Verifiera att alla users finns i tbl_report_user (inte n�dv�ndigtvis att de har en wallet)

	-- g�r ej, skapa users ist�llet

	INSERT #errors (RowNo, ErrorNo, Message)
	SELECT
		RowNo
		,100714	-- Username or domain missing/empty
		,Domain + '\' + UserName
	FROM tbl_cirrato_wallet_import_file_user_row
	WHERE FileId = @iFileId 
	AND LEN(UserName) = 0 OR LEN(Domain) = 0

	-- 3.	Verifiera att alla grupper finns under ADUmbrella, matcha p� gruppnamn. 
	INSERT #errors (RowNo, ErrorNo, Message)
	SELECT 
		gr.RowNo
		,100703	-- Group does not exist
		,gr.GroupName
	FROM tbl_cirrato_wallet_import_file_group_row gr
	LEFT JOIN vw_report_group g
		ON g.GroupName = gr.GroupName
		AND g.UmbrellaId = @ADUmbrellaId
	WHERE FileId = @iFileId 
		AND g.GroupName IS NULL


	-- 3a.	Kolla ocks� att varje gruppnamn bara finns EN g�ng
	INSERT #errors (RowNo, ErrorNo, Message)
	SELECT 
		gr.RowNo
		,100704	-- Group name matches more than one group
		,gr.GroupName + ' matches ' + CAST(COUNT(*) AS VARCHAR(20)) + ' groups'
	FROM tbl_cirrato_wallet_import_file_group_row gr
	INNER JOIN vw_report_group g
		ON g.GroupName = gr.GroupName
	WHERE FileId = @iFileId 
		AND g.UmbrellaId = @ADUmbrellaId
	GROUP BY gr.RowNo, gr.GroupName
	HAVING COUNT(*) > 1

--4.	Kontrollera att Action �r giltig
	INSERT #errors (RowNo, ErrorNo, Message)
	SELECT 
		gr.RowNo
		,100707	-- Invalid Action
		,'Action ' + CAST(Action AS VARCHAR(20))
	FROM tbl_cirrato_wallet_import_file_group_row gr
	WHERE FileId = @iFileId 
		AND Action NOT BETWEEN 0 AND 2
	UNION 
	SELECT 
		gr.RowNo
		,100707	-- Invalid Action
		,'Action ' + CAST(Action AS VARCHAR(20))
	FROM tbl_cirrato_wallet_import_file_user_row gr
	WHERE FileId = @iFileId 
		AND Action NOT BETWEEN 0 AND 2


--5.	Kontrollera version







-- Sample SP call
--	EXEC @ReturnStatus = sp_xxxx	@iParam1				= 
--									,@iParam2				= 
--
--	SET @ErrorNo = @@ERROR
--	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
--		GOTO PROC_ERROR



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_process_do') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_process_do
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_process_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  Perform actual quota operations of file
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId					int
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Update file table to indicate we have started
	--------------------------------------------------------

	UPDATE tbl_cirrato_wallet_import_file
	SET ProcessedDate = getdate()
	WHERE FileId = @iFileId

	-- Create users that do not exist
	--------------------------------------------------------

	INSERT tbl_report_users (UserName, Domain)
	SELECT
		ur.UserName
		,ur.Domain
	FROM tbl_cirrato_wallet_import_file_user_row ur
	LEFT JOIN tbl_report_users u
		ON ur.UserName = u.Username
		AND ur.Domain = u.Domain
	WHERE u.UserName IS NULL
		AND ur.FileId = @iFileId


	-- Add balance to users
	--------------------------------------------------------

	CREATE TABLE #users (UserId int)

	DECLARE @cUserId int, @cAmount float, @cAction int, @cDescription nvarchar(510), @cGroupId int

	-- todo: rewrite to fetch distinct action,amount,description and then get all matching users inside the loop. (will make it more efficient)
	DECLARE curFileUsers CURSOR FOR
	SELECT 
		u.UserId
		,ur.Amount
		,ur.Action
		,ur.Description
	FROM tbl_cirrato_wallet_import_file_user_row ur
	INNER JOIN tbl_report_users u
		ON ur.Username = u.UserName
		AND ur.Domain = u.Domain
	WHERE ur.FileId = @iFileId

	OPEN curFileUsers

	FETCH NEXT FROM curFileUsers INTO  @cUserId, @cAmount, @cAction, @cDescription
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- The procedure that we'll call next applies the given balance to all users in this temp table.
		DELETE #users
		INSERT #users (UserId) VALUES(@cUserId)

		IF @cAction = 0
		BEGIN -- replace balance: first set to 0, then add given amount

			EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance	
				@iMultiplier = 0
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR


			EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance	
				@iAmount = @cAmount
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

		END
		ELSE
		BEGIN -- add or subtract

			IF @cAction = 2 SET @cAmount = -1.0 * @cAmount

			EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance	
				@iAmount = @cAmount
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

		END

		FETCH NEXT FROM curFileUsers INTO  @cUserId, @cAmount, @cAction, @cDescription
	END

	CLOSE curFileUsers
	DEALLOCATE curFileUsers




	-- Add balance to groups
	--------------------------------------------------------

	-- Get AD Umbrella Id:

	DECLARE @ADUmbrellaId int
	SELECT @ADUmbrellaId = propertyValueNumeric FROM tbl_property WHERE propertyName = 'ADUmbrellaId' AND propertyGroup = 'Reports'

	IF @ADUmbrellaId IS NULL
		RETURN(100602) -- ADUmbrellaId must be set

	-- Loop through groups in file:

	DECLARE curGroups CURSOR FOR
	SELECT 
		g.GroupId
		,gr.Amount
		,gr.Action
		,gr.Description
	FROM tbl_cirrato_wallet_import_file_group_row gr
	INNER JOIN vw_report_group g
		ON g.GroupName = gr.GroupName
	WHERE FileId = @iFileId 
		AND g.UmbrellaId = @ADUmbrellaId

	

	OPEN curGroups

	FETCH NEXT FROM curGroups INTO  @cGroupId, @cAmount, @cAction, @cDescription
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @cAction = 0
		BEGIN -- replace balance: first set to 0, then add given amount

			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance	
				@iGroupId = @cGroupId
				,@iMultiplier = 0
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance	
				@iGroupId = @cGroupId
				,@iAmount = @cAmount
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

		END
		ELSE
		BEGIN -- add or subtract

			IF @cAction = 2 SET @cAmount = -1.0 * @cAmount

			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance	
				@iGroupId = @cGroupId
				,@iAmount = @cAmount
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

		END

		FETCH NEXT FROM curGroups INTO  @cGroupId, @cAmount, @cAction, @cDescription
	END

	CLOSE curGroups
	DEALLOCATE curGroups


	-- Update file row with statistics
	UPDATE tbl_cirrato_wallet_import_file SET
		NumUsersAffected = (SELECT COUNT(*) FROM tbl_cirrato_wallet_import_file_user_row WHERE FileId = @iFileId)
		,NumGroupsAffected = (SELECT COUNT(*) FROM tbl_cirrato_wallet_import_file_group_row WHERE FileId = @iFileId)
	WHERE FileId = @iFileId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_chk') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_chk
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_chk
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId					int
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Generic setup checks
	-----------------------------------------------------

	-- Get AD Umbrella Ids:

	DECLARE @ADUmbrellaId int

	SELECT @ADUmbrellaId = propertyValueNumeric 
	FROM tbl_property WHERE propertyName = 'ADUmbrellaId' AND propertyGroup = 'Reports'

	IF @ADUmbrellaId IS NULL
		RETURN(100602) -- ADUmbrellaId must be set


	-- File checks
	-----------------------------------------------------

	--	1.	Header checks
	IF NOT EXISTS (SELECT * FROM tbl_cirrato_wallet_import_file WHERE FileId = @iFileId)
		RETURN (100713) --	FileId does not exist


	--	Kontrollera FileId inte redan �r processed
	IF EXISTS (SELECT * FROM tbl_cirrato_wallet_import_file WHERE FileId = @iFileId AND ProcessedDate IS NOT NULL)
		RETURN (100712) --	File has already been processed


	-- Checksum verified?
	IF NOT EXISTS (SELECT * FROM tbl_cirrato_wallet_import_file WHERE FileId = @iFileId AND ChecksumVerified=1)
		RETURN (100701) --	Checksum not verified



	-- 2.	Verifiera att alla users finns i tbl_report_user (inte n�dv�ndigtvis att de har en wallet)

	-- g�r ej, skapa users ist�llet

	INSERT #errors (RowNo, ErrorNo, Message)
	SELECT
		RowNo
		,100714	-- Username or domain missing/empty
		,Domain + '\' + UserName
	FROM tbl_cirrato_wallet_import_file_user_row
	WHERE FileId = @iFileId 
	AND LEN(UserName) = 0 OR LEN(Domain) = 0

	-- 3.	Verifiera att alla grupper finns under ADUmbrella, matcha p� gruppnamn. 
	INSERT #errors (RowNo, ErrorNo, Message)
	SELECT 
		gr.RowNo
		,100703	-- Group does not exist
		,gr.GroupName
	FROM tbl_cirrato_wallet_import_file_group_row gr
	LEFT JOIN vw_report_group g
		ON g.GroupName = gr.GroupName
		AND g.UmbrellaId = @ADUmbrellaId
	WHERE FileId = @iFileId 
		AND g.GroupName IS NULL


	-- 3a.	Kolla ocks� att varje gruppnamn bara finns EN g�ng
	INSERT #errors (RowNo, ErrorNo, Message)
	SELECT 
		gr.RowNo
		,100704	-- Group name matches more than one group
		,gr.GroupName + ' matches ' + CAST(COUNT(*) AS VARCHAR(20)) + ' groups'
	FROM tbl_cirrato_wallet_import_file_group_row gr
	INNER JOIN vw_report_group g
		ON g.GroupName = gr.GroupName
	WHERE FileId = @iFileId 
		AND g.UmbrellaId = @ADUmbrellaId
	GROUP BY gr.RowNo, gr.GroupName
	HAVING COUNT(*) > 1

--4.	Kontrollera att Action �r giltig
	INSERT #errors (RowNo, ErrorNo, Message)
	SELECT 
		gr.RowNo
		,100707	-- Invalid Action
		,'Action ' + CAST(Action AS VARCHAR(20))
	FROM tbl_cirrato_wallet_import_file_group_row gr
	WHERE FileId = @iFileId 
		AND Action NOT BETWEEN 0 AND 2
	UNION 
	SELECT 
		gr.RowNo
		,100707	-- Invalid Action
		,'Action ' + CAST(Action AS VARCHAR(20))
	FROM tbl_cirrato_wallet_import_file_user_row gr
	WHERE FileId = @iFileId 
		AND Action NOT BETWEEN 0 AND 2


--5.	Kontrollera version







-- Sample SP call
--	EXEC @ReturnStatus = sp_xxxx	@iParam1				= 
--									,@iParam2				= 
--
--	SET @ErrorNo = @@ERROR
--	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
--		GOTO PROC_ERROR



	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_del') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_del
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_del
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  Remove fileinfo and associated rows
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId						int
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	-- Checks

	-- Currently none (done later in chk-procedure)

	-- Delete rows in all tables

	BEGIN TRY
		BEGIN TRAN DelTran

		DELETE tbl_cirrato_wallet_import_file_user_row WHERE FileId = @iFileId
		DELETE tbl_cirrato_wallet_import_file_group_row WHERE FileId = @iFileId
		DELETE tbl_cirrato_wallet_import_file WHERE FileId = @iFileId

		COMMIT TRAN DelTran	
	END TRY
	BEGIN CATCH
		ROLLBACK TRAN DelTran
		RETURN (100709) --	Delete file failed
	END CATCH

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_group_row_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_group_row_ins
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_group_row_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  Create a group row
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId						int
	,@iRowNo						int
	,@iGroupName					nvarchar(510)
	,@iGroupExternalId				nvarchar(128) = NULL
	,@iAmount						decimal(10,4)
	,@iAction						int
	,@iDescription					nvarchar(510) = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	-- Checks

	-- Currently none (done later in chk-procedure)

	-- Insert row

	INSERT tbl_cirrato_wallet_import_file_group_row
		(FileId
		,RowNo
		,GroupName
		,GroupExternalId	
		,Amount
		,Action
		,Description)
	VALUES
		(@iFileId
		,@iRowNo
		,@iGroupName
		,@iGroupExternalId	
		,convert(float, @iAmount)
		,@iAction
		,@iDescription)

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_ins
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  Create row for the file info & header
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileName			nvarchar(510)
	,@iFileUniqueId		nvarchar(256)
	,@iMajorVersion		int
	,@iMinorVersion		int
	,@iImporterUserName	nvarchar(510)
	,@iImporterDomain	nvarchar(510)
	,@iChecksum			varchar(64)
	,@oFileId			int OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oFileId = NULL

	-- Checks
	IF EXISTS(SELECT * FROM tbl_cirrato_wallet_import_file WHERE FileUniqueId = @iFileUniqueId)
		RETURN (100700) -- File has already been imported

	IF @iMajorVersion <> 1
		RETURN(100708) --	Major version not supported

	-- Get/create UserId
	DECLARE @RegUserId int
	EXEC @ReturnStatus = sp_report_user_get		@iUserName				= @iImporterUserName
												,@iDomain				= @iImporterDomain
												,@iCreateIfNotExists	= 1
												,@oUserId				= @RegUserId OUTPUT

	SET @ErrorNo = @@ERROR
	IF @ErrorNo <> 0 OR @ReturnStatus <> 0
		GOTO PROC_ERROR

	-- Insert row

	INSERT tbl_cirrato_wallet_import_file
		(FileName		
		,FileUniqueId	
		,MajorVersion		
		,MinorVersion	
		,ImporterUserId	
		,Checksum)
	VALUES
		(@iFileName		
		,@iFileUniqueId	
		,@iMajorVersion		
		,@iMinorVersion	
		,@RegUserId
		,@iChecksum)

	SET @oFileId = SCOPE_IDENTITY()

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_process') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_process
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_process
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  Check & process a file.
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId					int
	,@oReturnStatusMessage		nvarchar(1024) = NULL OUTPUT
--	,@oReturnStatusTranslation	nvarchar(1024) = NULL OUTPUT
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @oReturnStatusMessage = NULL



	BEGIN TRY
		IF @@TRANCOUNT = 0
			BEGIN TRANSACTION FileImportTran


		CREATE TABLE #errors
			(RowNo		int
			,ErrorNo	int
			,Message	nvarchar(1024))


		EXEC @ReturnStatus = sp_cirrato_wallet_import_file_chk	@iFileId = @iFileId
		IF @ReturnStatus <> 0
			GOTO PROC_ERROR

		IF (SELECT COUNT(*) FROM #errors) > 0 
		BEGIN
			SET @ReturnStatus = 100710	-- Processing Error
			GOTO PROC_ERROR
		END

		EXEC @ReturnStatus = sp_cirrato_wallet_import_file_process_do	@iFileId = @iFileId
		IF @ReturnStatus <> 0
			GOTO PROC_ERROR

		IF (SELECT COUNT(*) FROM #errors) > 0 
		BEGIN
			SET @ReturnStatus = 100710	-- Processing Error
			GOTO PROC_ERROR
		END

		COMMIT TRANSACTION FileImportTran

		UPDATE tbl_cirrato_wallet_import_file SET Outcome = 0 WHERE FileId = @iFileId

		SELECT * FROM tbl_cirrato_wallet_import_file WHERE FileId = @iFileId

	END TRY
	BEGIN CATCH

		SELECT * FROM #errors ORDER BY RowNo, ErrorNo, Message

		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION FileImportTran
	
		SET @oReturnStatusMessage =
			LEFT(ISNULL(ERROR_PROCEDURE(),'') + ':' + CAST(ISNULL(ERROR_LINE(),0) AS NVARCHAR(20)) + ' ' + ISNULL(ERROR_MESSAGE(),''), 1024)


		RETURN (100711) --	Execution Error

	END CATCH





	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

	RETURN (0)

	PROC_ERROR:

	SELECT * FROM #errors ORDER BY RowNo, ErrorNo, Message
	
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION FileImportTran

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_process_do') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_process_do
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_process_do
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  Perform actual quota operations of file
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId					int
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	-- Update file table to indicate we have started
	--------------------------------------------------------

	UPDATE tbl_cirrato_wallet_import_file
	SET ProcessedDate = getdate()
	WHERE FileId = @iFileId

	-- Create users that do not exist
	--------------------------------------------------------

	INSERT tbl_report_users (UserName, Domain)
	SELECT
		ur.UserName
		,ur.Domain
	FROM tbl_cirrato_wallet_import_file_user_row ur
	LEFT JOIN tbl_report_users u
		ON ur.UserName = u.Username
		AND ur.Domain = u.Domain
	WHERE u.UserName IS NULL
		AND ur.FileId = @iFileId


	-- Add balance to users
	--------------------------------------------------------

	CREATE TABLE #users (UserId int)

	DECLARE @cUserId int, @cAmount float, @cAction int, @cDescription nvarchar(510), @cGroupId int

	-- todo: rewrite to fetch distinct action,amount,description and then get all matching users inside the loop. (will make it more efficient)
	DECLARE curFileUsers CURSOR FOR
	SELECT 
		u.UserId
		,ur.Amount
		,ur.Action
		,ur.Description
	FROM tbl_cirrato_wallet_import_file_user_row ur
	INNER JOIN tbl_report_users u
		ON ur.Username = u.UserName
		AND ur.Domain = u.Domain
	WHERE ur.FileId = @iFileId

	OPEN curFileUsers

	FETCH NEXT FROM curFileUsers INTO  @cUserId, @cAmount, @cAction, @cDescription
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- The procedure that we'll call next applies the given balance to all users in this temp table.
		DELETE #users
		INSERT #users (UserId) VALUES(@cUserId)

		IF @cAction = 0
		BEGIN -- replace balance: first set to 0, then add given amount

			EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance	
				@iMultiplier = 0
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR


			EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance	
				@iAmount = @cAmount
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

		END
		ELSE
		BEGIN -- add or subtract

			IF @cAction = 2 SET @cAmount = -1.0 * @cAmount

			EXEC @ReturnStatus = sp_cirrato_wallet_user_add_balance	
				@iAmount = @cAmount
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

		END

		FETCH NEXT FROM curFileUsers INTO  @cUserId, @cAmount, @cAction, @cDescription
	END

	CLOSE curFileUsers
	DEALLOCATE curFileUsers




	-- Add balance to groups
	--------------------------------------------------------

	-- Get AD Umbrella Id:

	DECLARE @ADUmbrellaId int
	SELECT @ADUmbrellaId = propertyValueNumeric FROM tbl_property WHERE propertyName = 'ADUmbrellaId' AND propertyGroup = 'Reports'

	IF @ADUmbrellaId IS NULL
		RETURN(100602) -- ADUmbrellaId must be set

	-- Loop through groups in file:

	DECLARE curGroups CURSOR FOR
	SELECT 
		g.GroupId
		,gr.Amount
		,gr.Action
		,gr.Description
	FROM tbl_cirrato_wallet_import_file_group_row gr
	INNER JOIN vw_report_group g
		ON g.GroupName = gr.GroupName
	WHERE FileId = @iFileId 
		AND g.UmbrellaId = @ADUmbrellaId

	

	OPEN curGroups

	FETCH NEXT FROM curGroups INTO  @cGroupId, @cAmount, @cAction, @cDescription
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @cAction = 0
		BEGIN -- replace balance: first set to 0, then add given amount

			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance	
				@iGroupId = @cGroupId
				,@iMultiplier = 0
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance	
				@iGroupId = @cGroupId
				,@iAmount = @cAmount
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

		END
		ELSE
		BEGIN -- add or subtract

			IF @cAction = 2 SET @cAmount = -1.0 * @cAmount

			EXEC @ReturnStatus = sp_cirrato_wallet_group_add_balance	
				@iGroupId = @cGroupId
				,@iAmount = @cAmount
				,@iComment = @cDescription

			SET @ErrorNo = @@ERROR
			IF @ErrorNo <> 0 OR @ReturnStatus <> 0
				GOTO PROC_ERROR

		END

		FETCH NEXT FROM curGroups INTO  @cGroupId, @cAmount, @cAction, @cDescription
	END

	CLOSE curGroups
	DEALLOCATE curGroups


	-- Update file row with statistics
	UPDATE tbl_cirrato_wallet_import_file SET
		NumUsersAffected = (SELECT COUNT(*) FROM tbl_cirrato_wallet_import_file_user_row WHERE FileId = @iFileId)
		,NumGroupsAffected = (SELECT COUNT(*) FROM tbl_cirrato_wallet_import_file_group_row WHERE FileId = @iFileId)
	WHERE FileId = @iFileId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_upd') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_upd
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_upd
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  Update fileinfo
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId						int
	,@iChecksumVerified				bit = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	UPDATE tbl_cirrato_wallet_import_file 
		SET ChecksumVerified = ISNULL(@iChecksumVerified,ChecksumVerified)
	WHERE FileId = @iFileId


	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

IF OBJECT_ID('sp_cirrato_wallet_import_file_user_row_ins') IS NOT NULL
	DROP PROCEDURE sp_cirrato_wallet_import_file_user_row_ins
GO

CREATE PROCEDURE sp_cirrato_wallet_import_file_user_row_ins
/************************************************************
Created by:  Henrik Linder
Creation date: 2009-12-11
Description:  Create a user row
------------------------------------------------------------
Modified by:
Modification date:
Description:
************************************************************/
	@iFileId						int
	,@iRowNo						int
	,@iDomain						nvarchar(510)
	,@iUsername						nvarchar(510)
	,@iAmount						decimal(10,4)
	,@iAction						int
	,@iDescription					nvarchar(510) = NULL
AS
BEGIN

	DECLARE	@ReturnStatus			int
			,@ErrorNo				int

	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF


	-- Checks

	-- Currently none (done later in chk-procedure)

	-- Insert row

	INSERT tbl_cirrato_wallet_import_file_user_row
		(FileId
		,RowNo
		,Domain
		,Username	
		,Amount
		,Action
		,Description)
	VALUES
		(@iFileId
		,@iRowNo
		,@iDomain
		,@iUsername	
		,CONVERT(float, @iAmount)
		,@iAction
		,@iDescription)

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON


	RETURN (0)

	PROC_ERROR:
	IF @ReturnStatus = 0
		SET @ReturnStatus = @ErrorNo

	RETURN (@ReturnStatus)
END
GO

TRUNCATE TABLE tbl_smartalarm_type --WHERE AlarmTypeId IN (1,2) 

-- ENGLISH
INSERT tbl_smartalarm_type (AlarmTypeId ,AlarmSeverityId, AlarmArea, AlarmDescription, LanguageId)
VALUES (1
		,1
		,1
		,'Job printing time has exceeded warning limit'
		,'en')

INSERT tbl_smartalarm_type (AlarmTypeId ,AlarmSeverityId, AlarmArea, AlarmDescription, LanguageId)
VALUES (1
		,2
		,1
		,'Job printing time has exceeded error limit'
		,'en')

INSERT tbl_smartalarm_type (AlarmTypeId ,AlarmSeverityId, AlarmArea, AlarmDescription, LanguageId)
VALUES (2
		,1
		,2
		,'High queue load'
		,'en')


-- SWEDISH
INSERT tbl_smartalarm_type (AlarmTypeId ,AlarmSeverityId, AlarmArea, AlarmDescription, LanguageId)
VALUES (1
		,1
		,1
		,'Tids�tg�ng f�r utskrift av jobb har �verskridit varningsgr�nsen'
		,'sv')

INSERT tbl_smartalarm_type (AlarmTypeId ,AlarmSeverityId, AlarmArea, AlarmDescription, LanguageId)
VALUES (1
		,2
		,1
		,'Tids�tg�ng f�r utskrift av jobb har �verskridit felgr�nsen'
		,'sv')

INSERT tbl_smartalarm_type (AlarmTypeId ,AlarmSeverityId, AlarmArea, AlarmDescription, LanguageId)
VALUES (2
		,1
		,2
		,'H�g k�belastning'
		,'sv')
GO



IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyName = 'smartAlarmJobDurationWarning')

EXEC sp_property_ins
	@ipropertyName				= 'smartAlarmJobDurationWarning'
	,@ipropertyValue			= NULL
	,@ipropertyValueNumeric		= 15
	,@ipropertyValueDate		= NULL
	,@ipropertyCreatedBy		= 'System'
	,@ipropertyDescription		= 'Time (in minutes) job has been printing before issuing a warning'

IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyName = 'smartAlarmJobDurationError')

EXEC sp_property_ins
	@ipropertyName				= 'smartAlarmJobDurationError'
	,@ipropertyValue			= NULL
	,@ipropertyValueNumeric		= 30
	,@ipropertyValueDate		= NULL
	,@ipropertyCreatedBy		= 'System'
	,@ipropertyDescription		= 'Time (in minutes) job has been printing before issuing an error'


IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyName = 'smartAlarmQueueJobCountWarning')

EXEC sp_property_ins
	@ipropertyName				= 'smartAlarmQueueJobCountWarning'
	,@ipropertyValue			= NULL
	,@ipropertyValueNumeric		= 15
	,@ipropertyValueDate		= NULL
	,@ipropertyCreatedBy		= 'System'
	,@ipropertyDescription		= 'Max no. of jobs in any one queue before issuing a warning'


UPDATE tbl_property SET propertyGroup = 'SmartAlarms'
WHERE propertyName LIKE 'smartAlarm%' AND propertyGroup <> 'SmartAlarms'

GO

IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyName = 'DefaultPaperSize')

EXEC sp_property_ins
	@ipropertyName				= 'DefaultPaperSize'
	,@ipropertyValue			= NULL
	,@ipropertyValueNumeric		= 9 -- A4
	,@ipropertyValueDate		= NULL
	,@ipropertyCreatedBy		= 'System'
	,@ipropertyDescription		= 'Default system paper size (values according to enum PageSizes)'



GO

-- DELETE  FROM tbl_property WHERE propertyGroup  = 'LogTrim'

IF NOT EXISTS( SELECT * FROM tbl_property WHERE propertyGroup = 'LogTrim')
BEGIN

	EXEC sp_property_ins
		@ipropertyGroup				= 'LogTrim'
		,@ipropertyName				= 'UserPrintFull'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 365
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Full delete of user print logs after this many days'

	EXEC sp_property_ins
		@ipropertyGroup				= 'LogTrim'
		,@ipropertyName				= 'UserPrintPartial'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 90
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Partial delete of user print logs after this many days'

	EXEC sp_property_ins
		@ipropertyGroup				= 'LogTrim'
		,@ipropertyName				= 'UserTechFull'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 365
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Full delete of user tech logs after this many days'

	EXEC sp_property_ins
		@ipropertyGroup				= 'LogTrim'
		,@ipropertyName				= 'UserTechPartial'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 90
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Partial delete of user tech logs after this many days'

	EXEC sp_property_ins
		@ipropertyGroup				= 'LogTrim'
		,@ipropertyName				= 'UserSensitiveFull'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 0
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Full delete of user sensitive logs after this many days'

	EXEC sp_property_ins
		@ipropertyGroup				= 'LogTrim'
		,@ipropertyName				= 'UserSensitivePartial'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 0
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Partial delete of user sensitive logs after this many days'

	EXEC sp_property_ins
		@ipropertyGroup				= 'LogTrim'
		,@ipropertyName				= 'AdminTechFull'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 365
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Full delete of admin tech logs after this many days'

	EXEC sp_property_ins
		@ipropertyGroup				= 'LogTrim'
		,@ipropertyName				= 'AdminTechPartial'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 90
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Partial delete of admin tech logs after this many days'



END
GO
IF NOT EXISTS( SELECT * FROM tbl_property WHERE propertyGroup = 'Monitoring')
BEGIN

	EXEC sp_property_ins
		@ipropertyGroup				= 'Monitoring'
		,@ipropertyName				= 'CirratoServerErrorThreshold'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 90
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'No. seconds since last heartbeat before reporting an error'

	EXEC sp_property_ins
		@ipropertyGroup				= 'Monitoring'
		,@ipropertyName				= 'MonitoringServiceErrorThreshold'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 90
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'No. seconds since last heartbeat before reporting an error'

	EXEC sp_property_ins
		@ipropertyGroup				= 'Monitoring'
		,@ipropertyName				= 'HandoverPointErrorThreshold'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 60
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'No. seconds since last heartbeat before reporting an error'

END
GO

IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyName = 'JobsQueueCutOff')

	EXEC sp_property_ins
		@ipropertyGroup				= 'Reports'
		,@ipropertyName				= 'JobsQueueCutOff'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= '20000101'
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Where to begin incremental job stats calculation. Needs to be beginning of day (hours=minutes=seconds=0)'

IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyName = 'JobsDetailCutOff')

	EXEC sp_property_ins
		@ipropertyGroup				= 'Reports'
		,@ipropertyName				= 'JobsDetailCutOff'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= '20000101'
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Where to begin incremental job stats calculation. Needs to be beginning of day (hours=minutes=seconds=0)'


GO

GO
TRUNCATE TABLE tbl_papersize
GO

INSERT tbl_papersize VALUES(0, 'Unknown paper', 0, 0)

INSERT tbl_papersize VALUES(1, 'Letter', 8.5*2.54*100000, 11*2.54*100000)
INSERT tbl_papersize VALUES(2, 'Letter Small', 8.5*2.54*100000, 11*2.54*100000)
INSERT tbl_papersize VALUES(3, 'Tabloid', 11*2.54*100000, 17*2.54*100000)
INSERT tbl_papersize VALUES(4, 'Ledger', 17*2.54*100000, 11*2.54*100000)
INSERT tbl_papersize VALUES(5, 'Legal', 8.5*2.54*100000, 14*2.54*100000)
INSERT tbl_papersize VALUES(6, 'Statement', 5.5*2.54*100000, 8.5*2.54*100000)
INSERT tbl_papersize VALUES(7, 'Executive', 7.25*2.54*100000, 10.5*2.54*100000)
INSERT tbl_papersize VALUES(8, 'A3', 29.7*100000, 42*100000)
INSERT tbl_papersize VALUES(9, 'A4', 21*100000, 29.7*100000)
INSERT tbl_papersize VALUES(10, 'A4 Small', 21*100000, 29.7*100000)
INSERT tbl_papersize VALUES(11, 'A5', 14.8*100000, 21*100000)
INSERT tbl_papersize VALUES(12, 'B4', 25*100000, 35.4*100000)
INSERT tbl_papersize VALUES(13, 'B5', 18.2*100000, 25.7*100000)
INSERT tbl_papersize VALUES(14, 'Folio', 8.5*2.54*100000, 13*2.54*100000)
INSERT tbl_papersize VALUES(15, 'Quarto', 21.5*100000, 27.5*100000)
--16 todo
--17 todo
INSERT tbl_papersize VALUES(18, 'Note', 8.5*2.54*100000, 11*2.54*100000)
INSERT tbl_papersize VALUES(19, 'Envelope #9', 3.875*2.54*100000, 8.875*2.54*100000)
INSERT tbl_papersize VALUES(20, 'Envelope #10', 4.125*2.54*100000, 9.5*2.54*100000)
INSERT tbl_papersize VALUES(21, 'Envelope #11', 4.5*2.54*100000, 10.375*2.54*100000)
INSERT tbl_papersize VALUES(22, 'Envelope #12', 4.5*2.54*100000, 11*2.54*100000)


--select * from tbl_papersize




GO

DECLARE @LastRun datetime
SET @LastRun = convert(char(8), DATEADD(D, -1, getdate()), 112)

IF NOT EXISTS( SELECT * FROM tbl_property WHERE propertyName = 'LastRun' AND propertyGroup = 'CirratoWallet')
BEGIN
	UPDATE tbl_cirrato_wallet SET firstRun = '20000101' WHERE firstRun IS NULL -- redan existerande users ska ej f� on-init rules

	EXEC sp_property_ins
		@ipropertyGroup				= 'CirratoWallet'
		,@ipropertyName				= 'LastRun'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= @LastRun
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Last wallet run'

END
GO



IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyName = 'ADUmbrellaId')
BEGIN
	-- finns umbrella med namn "Active Directory"? 
		-- om ja: anv�nd det
		-- om nej: skapa ett
	DECLARE @UmbrellaId int

	SELECT @UmbrellaId = UmbrellaId FROM tbl_report_group_umbrella WHERE UmbrellaName = 'Active Directory' AND IsDeleted = 0

	IF @UmbrellaId IS NULL
	BEGIN

		EXEC sp_report_group_umbrella_ins	@iUmbrellaName = 'Active Directory'
											,@oUmbrellaId = @UmbrellaId OUTPUT

	END


	EXEC sp_property_ins
		@ipropertyGroup				= 'Reports'
		,@ipropertyName				= 'ADUmbrellaId'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= @UmbrellaId
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'What Umbrella is the AD umbrella?'


END
GO

-- 2009-12-06: Added AD OU Umbrella

IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyName = 'ADOUUmbrellaId')
BEGIN
	-- finns umbrella med namn "Active Directory OU"? 
		-- om ja: anv�nd det
		-- om nej: skapa ett
	DECLARE @UmbrellaId int

	SELECT @UmbrellaId = UmbrellaId FROM tbl_report_group_umbrella WHERE UmbrellaName = 'Active Directory OU' AND IsDeleted = 0

	IF @UmbrellaId IS NULL
	BEGIN

		EXEC sp_report_group_umbrella_ins	@iUmbrellaName = 'Active Directory OU'
											,@oUmbrellaId = @UmbrellaId OUTPUT

	END


	EXEC sp_property_ins
		@ipropertyGroup				= 'Reports'
		,@ipropertyName				= 'ADOUUmbrellaId'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= @UmbrellaId
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'What Umbrella is the AD OU umbrella?'


END
GO




--select * from tbl_report_group_umbrella
-- select * from tbl_property
--delete tbl_property where propertyName = 'ADUmbrellaId'
--



IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyGroup = 'ClientBilling')

EXEC sp_property_ins
	@ipropertyGroup				= 'ClientBilling'
	,@ipropertyName				= 'cbLimitMode'
	,@ipropertyValue			= NULL
	,@ipropertyValueNumeric		= 0
	,@ipropertyValueDate		= NULL
	,@ipropertyCreatedBy		= 'System'
	,@ipropertyDescription		= 'Client billing code usage restriction mode. 0=no restrictions, 1=use must be granted on user, group or umbrella level.'



GO

GO
IF NOT EXISTS (SELECT 1 FROM tbl_scheduled_job WHERE ExecSP = 'sp_cirrato_wallet_batch_do')
	INSERT tbl_scheduled_job
		(JobName
		,JobComment
		,Interval
		,RunOffset
		,ExecSP)
	VALUES
		('Quota batch'
		,'Nightly Cirrato wallet (Quota) update batch. Must only be run once a day.'
		,1 -- daily
		,122
		,'sp_cirrato_wallet_batch_do')


IF NOT EXISTS (SELECT 1 FROM tbl_scheduled_job WHERE ExecSP = 'sp_queue_speed_upd')
	INSERT tbl_scheduled_job
		(JobName
		,JobComment
		,Interval
		,RunOffset
		,ExecSP)
	VALUES
		('Queue speed batch'
		,'Updates queues with actual queue speed.'
		,1 -- daily
		,92
		,'sp_queue_speed_upd')

IF NOT EXISTS (SELECT 1 FROM tbl_scheduled_job WHERE ExecSP = 'sp_report_batch_do')
	INSERT tbl_scheduled_job
		(JobName
		,JobComment
		,Interval
		,RunOffset
		,ExecSP)
	VALUES
		('Report batch'
		,'Calculate reporting data up to last midnight. Must only be run once a day.'
		,1 -- daily
		,162
		,'sp_report_batch_do')

GO


DECLARE @ReturnStatus int, @UserId int
EXEC @ReturnStatus = sp_report_user_get		@iUserName				= 'CIRRATO'
											,@iDomain				= 'SYSTEM'
											,@iCreateIfNotExists	= 1
											,@oUserId				= @UserId OUTPUT


IF NOT EXISTS (SELECT * FROM tbl_scan_destination_email)
BEGIN
	INSERT tbl_scan_destination_email
		(DestinationName
		,FromEmailAddress
		,FromName
		,MaxBytes
		,ReplyToEmailAddress
		,SMTPLoginPassword
		,SMTPLoginUserName
		,SMTPServerFQDN
		,SMTPServerPort
		,IsDefault
		,RegUserId)
	VALUES
		('Default'
		,'scan@mfp.organisation.se'
		,'MFP Scanner'
		,10000000
		,'scan@mfp.organisation.se'
		,'password'
		,'username'
		,'mail.organisation.se'
		,25
		,1
		,@UserId)		
END

IF NOT EXISTS (SELECT * FROM tbl_scan_destination_smb)
BEGIN
	INSERT tbl_scan_destination_smb
		(DestinationName
		,SMBLoginUserName
		,SMBLoginPassword
		,SMBPath
		,RegUserId)
	VALUES
		('Default'
		,'username'
		,'password'
		,'/SMB/Path/'
		,@UserId)
END


IF NOT EXISTS (SELECT * FROM tbl_scan_destination_ftp)
BEGIN
	INSERT tbl_scan_destination_ftp
		(DestinationName
		,FTPServerFQDN
		,FTPServerPort
		,FTPPath
		,FTPLoginUserName
		,FTPLoginPassword
		,RegUserId)
	VALUES
		('Default'
		,'server.organsation.se'
		,21
		,'/FTP/Path/'
		,'username'
		,'password'
		,@UserId)

END


IF NOT EXISTS (SELECT * FROM tbl_scan_destination_ncp)
BEGIN
	INSERT tbl_scan_destination_ncp
		(DestinationName
		,NCPPath
		,NCPBindery
		,NCPLoginUserName
		,NCPLoginPassword
		,RegUserId)
	VALUES
		('Default'
		,'/NCP/Path/'
		,0
		,'username'
		,'password'
		,@UserId)
END

IF NOT EXISTS (SELECT * FROM tbl_scan_destination_webdav)
BEGIN
	INSERT tbl_scan_destination_webdav
		(DestinationName
		,WebDAVFQDN
		,WebDAVPort
		,WebDAVSSL
		,WebDAVDirectory
		,WebDAVUserName
		,WebDAVPassword
		,RegUserId)
	VALUES
		('Default'
		,'server.organsation.se'
		,80
		,0
		,'/WebDAV/Directory/'
		,'username'
		,'password'
		,@UserId)
END


GO

IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyGroup = 'AutomaticCardReg')

	EXEC sp_property_ins
		@ipropertyGroup				= 'AutomaticCardReg'
		,@ipropertyName				= 'autoCardConnectionString'
		,@ipropertyValue			= ''
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'ODBC Connection String for automatic card database'

GO

IF NOT EXISTS(SELECT * FROM tbl_property WHERE /*propertyGroup = 'CustomUserDatabase'  and */propertyName = 'cubODBCString') -- kollar ej grupp f�r att h�lla kompatibelt med dptsrv.
	EXEC sp_property_ins
		@ipropertyGroup				= 'CustomUserDatabase'
		,@ipropertyName				= 'cubODBCString'
		,@ipropertyValue			= ''
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'ODBC Connection String for Custom User Database'


IF NOT EXISTS(SELECT * FROM tbl_property WHERE /*propertyGroup = 'CustomUserDatabase'  and */propertyName = 'cubAuthQuery') -- kollar ej grupp f�r att h�lla kompatibelt med dptsrv.
	EXEC sp_property_ins
		@ipropertyGroup				= 'CustomUserDatabase'
		,@ipropertyName				= 'cubAuthQuery'
		,@ipropertyValue			= ''
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= ''


IF NOT EXISTS(SELECT * FROM tbl_property WHERE /*propertyGroup = 'CustomUserDatabase'  and */propertyName = 'cubFailQuery') -- kollar ej grupp f�r att h�lla kompatibelt med dptsrv.
	EXEC sp_property_ins
		@ipropertyGroup				= 'CustomUserDatabase'
		,@ipropertyName				= 'cubFailQuery'
		,@ipropertyValue			= ''
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= ''


IF NOT EXISTS(SELECT * FROM tbl_property WHERE /*propertyGroup = 'CustomUserDatabase'  and */propertyName = 'cubSuccessQuery') -- kollar ej grupp f�r att h�lla kompatibelt med dptsrv.
	EXEC sp_property_ins
		@ipropertyGroup				= 'CustomUserDatabase'
		,@ipropertyName				= 'cubSuccessQuery'
		,@ipropertyValue			= ''
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= ''


IF NOT EXISTS(SELECT * FROM tbl_property WHERE /*propertyGroup = 'CustomUserDatabase'  and */propertyName = 'cubGroupsQuery') -- kollar ej grupp f�r att h�lla kompatibelt med dptsrv.
	EXEC sp_property_ins
		@ipropertyGroup				= 'CustomUserDatabase'
		,@ipropertyName				= 'cubGroupsQuery'
		,@ipropertyValue			= ''
		,@ipropertyValueNumeric		= NULL
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= ''

GO



IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyGroup = 'QueueInstall' AND propertyName='ShowFPRegion')

	EXEC sp_property_ins
		@ipropertyGroup				= 'QueueInstall'
		,@ipropertyName				= 'ShowFPRegion'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 1
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Show Follow Print region on Queue Install page'

GO
IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyGroup = 'QueueInstall' AND propertyName='ShowNormalRegions')

	EXEC sp_property_ins
		@ipropertyGroup				= 'QueueInstall'
		,@ipropertyName				= 'ShowNormalRegions'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 1
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Show normal regions on Queue Install page'

GO

IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyGroup = 'QueueInstall' AND propertyName='ShowFPQueues')

	EXEC sp_property_ins
		@ipropertyGroup				= 'QueueInstall'
		,@ipropertyName				= 'ShowFPQueues'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 1
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Show Follow-Print queues on Queue Install page'

GO
IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyGroup = 'QueueInstall' AND propertyName='ShowNormalQueues')

	EXEC sp_property_ins
		@ipropertyGroup				= 'QueueInstall'
		,@ipropertyName				= 'ShowNormalQueues'
		,@ipropertyValue			= NULL
		,@ipropertyValueNumeric		= 1
		,@ipropertyValueDate		= NULL
		,@ipropertyCreatedBy		= 'System'
		,@ipropertyDescription		= 'Show normal queues on Queue Install page'

GO
--
--IF NOT EXISTS( SELECT 1 FROM tbl_property WHERE propertyGroup = 'xxx' AND propertyName='xxx')
--
--	EXEC sp_property_ins
--		@ipropertyGroup				= 'xxx'
--		,@ipropertyName				= 'xxx'
--		,@ipropertyValue			= NULL
--		,@ipropertyValueNumeric		= 1
--		,@ipropertyValueDate		= NULL
--		,@ipropertyCreatedBy		= 'System'
--		,@ipropertyDescription		= 'xxx'
--
--GO

