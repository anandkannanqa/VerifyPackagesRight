-- Upgrade 2.0.0R16P4 - 2.0.0R16P6
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

go

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R16P4'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R16P6', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

/****************************************** BEGIN tbl_os ******************************************/
IF OBJECT_ID('tbl_os') IS NULL
BEGIN

create Table tbl_os
(
osId varchar(64) not null default '',
osName nvarchar(256) not null default '',
osMajor bigint not null default 0,
osMinor bigint not null default 0,
osSpMajor smallint not null default 0,
osSpMinor smallint not null default 0,
osArch smallint not null default 0
);

END
GO

/****************************************** Updates tbl_os ******************************************/

IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'tbl_os' AND COLUMN_NAME = 'osProductType')
BEGIN
	alter table tbl_os add osProductType smallint not null default 0
	print 'added column osProductType to tbl_printer'	
END
Go

delete from tbl_os where osProductType=0
Go

/****************************************** INSERTS tbl_os ******************************************/


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 5 AND osMinor = 0 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 0 AND osProductType = 1) 
BEGIN
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W2K', 'Windows 2000', 5,0,0,0,0,1);
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 5 AND osMinor = 1 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 0 AND osProductType = 1) 
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('XP32D', 'Windows XP', 5,1,0,0,0,1);
END

IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 5 AND osMinor = 2 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 0 AND osProductType = 1) 
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('XP64', 'Windows XP x64', 5,2,0,0,0,1);
END

IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 5 AND osMinor = 2 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 0 AND osProductType = 3) 
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W2K3', 'Windows server 2003', 5,2,0,0,0,3);
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 5 AND osMinor = 2 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 9 AND osProductType = 3)
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W2K364', 'Windows Server 2003 x64', 5,2,0,0,9,3 )
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 6 AND osMinor = 0 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 0 AND osProductType = 1) 
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('WV32', 'Windows Vista', 6,0,0,0,0,1);
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 5 AND osMinor = 0 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 9 AND osProductType = 1)
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('WV64', 'Windows Vista x64',6,0,0,0,9,1)
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 6 AND osMinor = 1 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 0 AND osProductType = 1)
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W7', 'Windows 7', 6,1,0,0,0,1);
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 6 AND osMinor = 1 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 9 AND osProductType = 1)
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W764', 'Windows 7 x64',6,1,0,0,9,1)
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 6 AND osMinor = 0 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 0 AND osProductType = 3)
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W2K8', 'Windows Server 2008',6,0,0,0,0,3)
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 6 AND osMinor = 0 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 9 AND osProductType = 3)
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W2K864', 'Windows Server 2008 x64',6,0,0,0,9,3)
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 6 AND osMinor = 1 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 0 AND osProductType = 3)
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W2K8R2', 'Windows Server 2008R2',6,1,0,0,0,3)
END


IF NOT EXISTS (SELECT 1 FROM tbl_os WHERE osMajor = 6 AND osMinor = 1 AND osSpMajor = 0 AND osSpMinor = 0 AND osArch = 9 AND osProductType = 3)
BEGIN 
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch, osProductType) values ('W2K8R264', 'Windows Server 2008R2 x64',6,1,0,0,9,3)
END

/************************************************************
Description: Search for billing codes in external DB (clientBillingActive = 3)
************************************************************/

set ANSI_NULLS ON
set QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_client_billing_search_external]
	@iSearchString	nvarchar (510)
	,@iUserName	nvarchar (510)	= NULL -- currently logged in user
	,@iDomain	nvarchar (510)	= NULL -- currently logged in user
AS
BEGIN
	SET NOCOUNT ON			-- needed for Odbc driver to fetch result set correctly
	SET ANSI_WARNINGS OFF

	SET @iSearchString = '%' + UPPER(@iSearchString) + '%'

	-- Handle returning of correct types
	DECLARE @Type TABLE ([Type] smallint)
	DECLARE @iIncludeFolders bit, @iIncludeBillingCodes bit

	-- Return results
	/*SELECT 
		ProjectId as cb_id
		,1 as cb_type
		,ProjectId AS cb_code
		,CompanyName + '\' + DepartmentName + '\' + ProjectId + ' (' + ProjectName + ', ' + EmployeeName + ')' AS cb_name
		,'My Comment' as cb_comment
	FROM Projects
	WHERE (UPPER(CompanyName) LIKE @iSearchString
		OR UPPER(DepartmentId) LIKE @iSearchString
		OR UPPER(DepartmentName) LIKE @iSearchString
		OR UPPER(ProjectId) LIKE @iSearchString		
		OR UPPER(ProjectName) LIKE @iSearchString
		OR UPPER(EmployeeName) LIKE @iSearchString
		)		
	ORDER BY cb_code*/

	SET NOCOUNT OFF
	SET ANSI_WARNINGS ON

END
