-- Upgrade 2.0.0R16P3 - 2.0.0R16P4
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

go

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R16P3'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R16P4', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	--TI_DELETED_AUTOMATICALLY,
	if(@minor=25)
		RETURN 'Automatically deleted'

	--TI_USER_CANCELLED_AUTHENTICATION_DELETE
	if(@minor=26)
		RETURN 'Deleted - User cancel authentication'


	--TI_AUTHENTICATION_ERROR
	if(@minor=27)
		RETURN 'Deleted - Authentication error on client'


	--TI_DELETED_AUTOMATICALLY_NO_CLIENT_SESSION
	if(@minor=28)
		RETURN 'Deleted - No client session on client'


	--TI_RULESET_DELETE,
	if(@minor=29)
		RETURN 'Deleted - By ruleset'

	--TI_RULESET_MOVE,
	if(@minor=30)
		RETURN 'Moved - by ruleset'

	--TI_RULESET_PAUSE
	if(@minor=31)
		RETURN 'Paused - by ruleset'

	-- TI_DELETED_CREATED,
	if(@minor=32)
		RETURN 'Deleted - created job'


	-- TI_DELETED_HANDOVER_OVERDUE,
	if(@minor=33)
		RETURN 'Deleted - handover overdue'

	-- TI_DELETED_AUTOMATICALLY_NO_CONTACT_WITH_CLIENT

	if(@minor=34)
		RETURN 'Deleted - no contact with client during authentication'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_CB_SET
	if(@minor=36)
		RETURN 'Client billing code set'

	-- TI_CB_CANCEL_PRESS_DELETE
	if(@minor=37)
		RETURN 'Deleted - Client billing cancel pressed'

	if(@minor=38)
		RETURN 'Deleted - Wrong client version'

	--TI_MANUALLY_MOVED,
	if(@minor=39)
		RETURN 'Moved - manually'

	--TI_AUTOMATICALLY_MOVED
	if(@minor=40)
		RETURN 'Moved - automatically'

--	TI_PAGES_RESET,
	if(@minor=41)
		RETURN 'Pages reset from 0 to 1 (Driver error)'

	-- TI_DELETED_QUEUE,
	if(@minor=42)
		RETURN 'Deleted - Queue deleted'

	-- TI_DELETED_QUEUE,
	if(@minor=43)
		RETURN 'Deleted - Queue Stopped'

	-- TI_DELETED_WRONG_DRIVER,
	if(@minor=44)
		RETURN 'Deleted - Wrong driver'

--	TI_DELETED_NO_QUEUE
	if(@minor=45)
		RETURN 'Deleted - No queue with UUID'

--
	if(@minor=46)
		RETURN 'Changed price plan'

--	TI_MULTIPLE_PRINT,
	if(@minor=47)
		RETURN 'Multiple print job'

--	TI_CPT_RELEASE_JOB
	if(@minor=48)
		RETURN 'CPT Release job'

--	TI_VDMS_RELEASE_JOB
	if(@minor=49)
		RETURN 'VDMS Release job'

-- TI_FPRINT_RELEASE_JOB
	if(@minor=50)
		RETURN 'Fprint Release job'

--TI_VDMS_RECORD_JOB_ACTION,
	if(@minor=51)
		RETURN 'VDMS Record Job'

--TI_CPT_RELEASE_JOB_FAIL,
	if(@minor=52)
		RETURN 'CPT Release job fail'

--TI_PRINTSERVICE_ORDER,
	if(@minor=53)
		RETURN 'Print divert'

--TI_PRINTSERVICE_ORDER_FAIL,
	if(@minor=54)
		RETURN 'Print divert fail'

--TI_PRINTSERVICE_ORDER_COMPLETE,
	if(@minor=55)
		RETURN 'Print divert order completed'

--TI_PRINTSERVICE_ORDER_COMPLETE_FAIL
	if(@minor=56)
		RETURN 'Print divert order failed'

--TI_VDMS_RECORD_JOB_TRANSACTION
	if(@minor=56)
		RETURN 'VDMS Record Job Transaction (no user)'


	RETURN @minor
END
go

alter table tbl_cirrato_rule_message_text add ruleMessageType smallint not null default 1
alter table tbl_cirrato_priceplan add cppVAT smallint not null default 0


alter table tbl_cirrato_client_session alter column csessionTsId int not null
alter table tbl_cirrato_client_session_log alter column logcsessionTsId int not null

CREATE TABLE [dbo].[tbl_microwallet_open_tab](
	[walletTabTs]  [datetime] default getDate(),
	[walletTransactionID] [varchar](50) ,
	[walletExtTransactionNumber] [varchar] (50),
	[walletExtTransactionId] [varchar](50) ,
	[walletTransactionType] [smallint],
	[walletInternalId] [varchar] (64),
	[ExternalId] [varchar](50),
	[ClientIp] [nvarchar](50),
	[userName] [nvarchar](50) ,
	[userDomain] [nvarchar](50),
	[InitialAmount] [float] NULL,
	[CurrentAmount] [float] NULL,
	[ExternalAmount] [float] NULL,
	[InternalAmount] [float] NULL,
	[ResAmount] [float] NULL,
	[TransactionText] [varchar](max) ,
	[assignedID] [varchar](50)
) ON [PRIMARY]

CREATE TABLE [dbo].[tbl_microwallet_open_transaction](
	[walletTransTs]  [datetime] default getDate(),
	[walletTransActionId] [varchar](50) ,
	[debitAmount] [float] NULL,
	[walletTransactionAmountLeft] [float] NULL,
	[TransactionText] [varchar](max) ,
	[assignedId] [varchar](50) NOT NULL
) ON [PRIMARY]

CREATE TABLE [dbo].[tbl_microwallet_tab_log](
	[walletTs]  [datetime] default getDate(),
	[walletEvent] [smallint],
	[walletTransactionID] [varchar](50) ,
	[walletExtTransactionId] [varchar](50) ,
	[walletExtTransactionNumber] [varchar] (50),
	[walletTransactionType] [smallint],
	[walletInternalId] [varchar] (64),
	[ExternalId] [varchar](50) ,
	[ClientIp] [nvarchar](50),
	[userName] [nvarchar](50),
	[userDomain] [nvarchar](50),
	[InitialAmount] [float] NULL,
	[CurrentAmount] [float] NULL,
	[ExternalAmount] [float] NULL,
	[InternalAmount] [float] NULL,
	[ResAmount] [float] NULL,
	[TransactionText] [varchar](50),
	[assignedID] [varchar](50)
) ON [PRIMARY]

CREATE TABLE [dbo].[tbl_microwallet_transaction_log](
	[wallettranslogts] [datetime] default getDate(),
	[wallettransLogEvent] [smallint] ,
	[walletTransActionId] [varchar](50) ,
	[debitAmount] [float] NULL,
	[walletTransactionAmountLeft] [float] NULL,
	[TransactionText] [varchar](50) ,
	[assignedId] [varchar](50) 
) ON [PRIMARY]

alter table tbl_cirrato_cpt_session add cpt_wid varchar(64) not null default ''
alter table tbl_cirrato_cpt_session_log add cptl_wid varchar(64) not null default ''

alter table tbl_ticket add releaseTime datetime;
alter table tbl_ticket add networkJob smallint not null default 1;

create table tbl_cirrato_cpt_session_setting
(
	csid varchar(64) not null,
	csname nvarchar(64) not null,
	cscomment nvarchar(255) default'',
	cdefault smallint not null default 0,
	ccurrency nvarchar(20),
	cdisplang nvarchar(20),
	cdhelpbutton smallint,
	cdjobproperties smallint,
	cdproofprint smallint,
	cecopy smallint,
	cefastrelease smallint,
	cefastreleaseq smallint,
	cefax smallint,
	cescan smallint,
	cdate datetime default getdate(),
	cstatus smallint not null default 1
)

alter table tbl_cirrato_rule_message_text add ruleMessageName nvarchar(255) ;


alter table tbl_handover_point add handoverTestInterval smallint;
alter table tbl_handover_point add handoverTestTs datetime;
alter table tbl_handover_point add handoverTestIp varchar(64);
alter table tbl_handover_point add handoverTestPort smallint;

alter table tbl_cirrato_rule_limit add rlDocName nvarchar(255);

alter table tbl_cirrato_cpt_session add cpt_jobamount float; -- NY
alter table tbl_ticket add cptSession varchar(64); -- NY

alter table tbl_payex_transaction add payexTransactionNumber  bigint not null default 0; -- Might fail 

alter table tbl_cirrato_rule add rRegion bigint;


IF OBJECT_ID('tbl_dn') IS NULL
BEGIN
 CREATE TABLE tbl_dn
 (DnId    int    PRIMARY KEY NOT NULL IDENTITY(1,1)
 ,Dn     nvarchar(512) NOT NULL)

-- ALTER TABLE tbl_dn
--  ADD CONSTRAINT tbl_dn_uq UNIQUE (Dn)

END

GO

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
    INNER JOIN syscolumns c ON c.id = o.id
    AND o.name = 'tbl_ticket'
    AND c.name = 'DnId')

ALTER TABLE tbl_ticket ADD  DnId int NULL REFERENCES tbl_dn (DnId)
GO

-- Add column
IF NOT EXISTS(SELECT * FROM sysobjects o
    INNER JOIN syscolumns c ON c.id = o.id
    AND o.name = 'tbl_ticket_log'
    AND c.name = 'DnId')

ALTER TABLE tbl_ticket_log ADD  DnId int NULL REFERENCES tbl_dn (DnId)
GO

create table tbl_cirrato_printservice_target
(
targetId uniqueIdentifier PRIMARY KEY NOT NULL,
targetRegion bigint,
targetName varchar(50),
targetComment varchar(128),
targetIp varchar(60),
targetPort varchar(60),
targetMethod smallint, -- 0 - same file - in to directory -- 1 - split files in to directory ( - 2 same file in to tcp port)
targetDirectory varchar(128)
)

create table tbl_cirrato_printservice
(
ticketId varchar(64),
jobTarget uniqueIdentifier REFERENCES tbl_cirrato_printservice_target(targetId),
jobData nvarchar(max)
)

create table tbl_pincode
(
username nvarchar(256),
domainname nvarchar(256),
pincode nvarchar(10),
errorcount smallint,
errordate datetime 
)


alter table tbl_property add propertyValueNumeric int