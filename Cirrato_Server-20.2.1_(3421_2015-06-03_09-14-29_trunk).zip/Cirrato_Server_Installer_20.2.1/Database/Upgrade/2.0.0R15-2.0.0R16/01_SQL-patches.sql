-- Upgrade 2.0.0R15 - 2.0.0R16
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R15'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R16', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	--TI_DELETED_AUTOMATICALLY,
	if(@minor=25)
		RETURN 'Automatically deleted'

	--TI_USER_CANCELLED_AUTHENTICATION_DELETE
	if(@minor=26)
		RETURN 'Deleted - User cancel authentication'


	--TI_AUTHENTICATION_ERROR
	if(@minor=27)
		RETURN 'Deleted - Authentication error on client'


	--TI_DELETED_AUTOMATICALLY_NO_CLIENT_SESSION
	if(@minor=28)
		RETURN 'Deleted - No client session on client'


	--TI_RULESET_DELETE,
	if(@minor=29)
		RETURN 'Deleted - By ruleset'

	--TI_RULESET_MOVE,
	if(@minor=30)
		RETURN 'Moved - by ruleset'

	--TI_RULESET_PAUSE
	if(@minor=31)
		RETURN 'Paused - by ruleset'

	-- TI_DELETED_CREATED,
	if(@minor=32)
		RETURN 'Deleted - created job'


	-- TI_DELETED_HANDOVER_OVERDUE,
	if(@minor=33)
		RETURN 'Deleted - handover overdue'

	-- TI_DELETED_AUTOMATICALLY_NO_CONTACT_WITH_CLIENT

	if(@minor=34)
		RETURN 'Deleted - no contact with client during authentication'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_CB_SET
	if(@minor=36)
		RETURN 'Client billing code set'

	-- TI_CB_CANCEL_PRESS_DELETE
	if(@minor=37)
		RETURN 'Deleted - Client billing cancel pressed'

	if(@minor=38)
		RETURN 'Deleted - Wrong client version'

	--TI_MANUALLY_MOVED,
	if(@minor=39)
		RETURN 'Moved - manually'

	--TI_AUTOMATICALLY_MOVED
	if(@minor=40)
		RETURN 'Moved - automatically'

--	TI_PAGES_RESET,
	if(@minor=41)
		RETURN 'Pages reset from 0 to 1 (Driver error)'

	-- TI_DELETED_QUEUE,
	if(@minor=42)
		RETURN 'Deleted - Queue deleted'

	-- TI_DELETED_QUEUE,
	if(@minor=43)
		RETURN 'Deleted - Queue Stopped'

	-- TI_DELETED_WRONG_DRIVER,
	if(@minor=44)
		RETURN 'Deleted - Wrong driver'

--	TI_DELETED_NO_QUEUE
	if(@minor=45)
		RETURN 'Deleted - No queue with UUID'

	RETURN @minor
END

go

-- Network areas

create table tbl_network_area_use
(
	networkAreaId varchar(64) not null,
	networkAreaUsage smallint not null,
	networkAreaData1 nvarchar(128),
	networkAreaData2 nvarchar(128),
	networkAreaData3 varchar(64),
	networkAreaData4 varchar(64),
	networkAreaIdata1 bigint,
	networkAreaIdata2 bigint
)

create table tbl_network_area_map
(
	networkAreaId varchar(64) not null,
	networkAreaEId varchar(64) not null
)

create table tbl_network_area
(
	networkAreaId varchar(64) not null,
	networkAreaName nvarchar(64) not null default '',
	networkAreaComment nvarchar(255) not null default ''
)

create table tbl_network_area_entry
(
	networkAreaEId varchar(64) not null,
	networkAreaEName nvarchar(64) not null default '',
	networkAreaEComment nvarchar(255) not null default '',
	networkAreaEStartIp varchar(64) not null,
	networkAreaEIpNumStart bigint not null,
	networkAreaEEndIp varchar(64),
	networkAreaEIpNumEnd bigint
)

create table tbl_inventory_printjob
(
  printTime datetime default getDate(),
  swVersion int,
  clientIp varchar(64) ,
  dwMajorVersion bigint,
  dwMinorVersion bigint,
  wServicePackMajor int,
  wServicePackMinor int,
  wProcessorArchitecture int,
  jobSize int,
  dmColor int,
  dmCopies int,
  dmDuplex int,
  dmPaperSize int,
  pPrinterName nvarchar(255),
  TotalPages int,
  pUserName nvarchar(255),
  pUserDomain nvarchar(255),
  pDocument nvarchar(255),
  pDriverName nvarchar(255),
  pMachineName nvarchar(255),
  pNotifyName nvarchar(255),
  printerShareName nvarchar(255),
  printerServer nvarchar(255),
  printerLocation nvarchar(255),
  printerComment nvarchar(255),
  portType nvarchar(255),
  printerPort nvarchar(255),
  iporhost nvarchar(255),
  resolvedDNS nvarchar(255),
  portQueueName nvarchar(255),
  portNo int,
  PortSNMPCommunity nvarchar(255),
  SNMPIndex int,
  wProductType smallint
)

go
drop function GetAbsoluteRegion
go
create FUNCTION GetAbsoluteRegion
(@regionId int)  
RETURNS NVARCHAR(512)   
AS  
BEGIN  
declare @regionName  NVARCHAR(512)  
declare @parentRegion int  
declare @iparentRegion int  
select @regionName= regionName from tbl_region where regionId=@regionId  
select @iparentRegion=@regionId  
while(exists(select regionParentId from tbl_region where regionId=@iparentRegion))  
begin  
select @iparentRegion=regionParentId from tbl_region where regionId=@iparentRegion  
if(@iparentRegion=0)  
 break;  
select @regionName= regionName+'/'+ @regionName from tbl_region where regionId=@iparentRegion  
end  
RETURN (@regionName)  
END
go
alter table tbl_handover_point add handOverPointLastAccessed datetime;
alter table tbl_handover_point add handOverPointServerReplyIp varchar(64);
alter table tbl_printer add printerHidden smallint not null default 0;
alter table tbl_queue add queueHidden smallint not null default 0;