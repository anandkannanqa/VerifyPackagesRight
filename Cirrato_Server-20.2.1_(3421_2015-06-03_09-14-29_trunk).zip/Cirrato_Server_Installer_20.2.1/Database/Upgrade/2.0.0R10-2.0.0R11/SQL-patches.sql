-- Upgrade 2.0.0R10 - 2.0.0R11
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R10'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R11', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	--TI_DELETED_AUTOMATICALLY,
	if(@minor=25)
		RETURN 'Automatically deleted'

	--TI_USER_CANCELLED_AUTHENTICATION_DELETE
	if(@minor=26)
		RETURN 'Deleted - User cancel authentication'


	--TI_AUTHENTICATION_ERROR
	if(@minor=27)
		RETURN 'Deleted - Authentication error on client'


	--TI_DELETED_AUTOMATICALLY_NO_CLIENT_SESSION
	if(@minor=28)
		RETURN 'Deleted - No client session on client'


	--TI_RULESET_DELETE,
	if(@minor=29)
		RETURN 'Deleted - By ruleset'

	--TI_RULESET_MOVE,
	if(@minor=30)
		RETURN 'Moved - by ruleset'

	--TI_RULESET_PAUSE
	if(@minor=31)
		RETURN 'Paused - by ruleset'

	-- TI_DELETED_CREATED,
	if(@minor=32)
		RETURN 'Deleted - created job'

	-- TI_DELETED_HANDOVER_OVERDUE,
	if(@minor=33)
		RETURN 'Deleted - handover overdue'

	-- TI_DELETED_AUTOMATICALLY_NO_CONTACT_WITH_CLIENT

	if(@minor=34)
		RETURN 'Deleted - no contact with client during authentication'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=34)
		RETURN 'No contact with client during send time estimate'



	RETURN @minor
END

go
grant execute on dbo.verboseTicketLog to cirrato;

go

alter table tbl_counter_statistics add counterstatValueString varchar(512);