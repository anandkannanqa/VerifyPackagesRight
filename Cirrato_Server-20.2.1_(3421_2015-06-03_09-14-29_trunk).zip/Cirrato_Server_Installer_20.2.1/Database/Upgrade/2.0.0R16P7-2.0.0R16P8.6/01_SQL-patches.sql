-- Upgrade 2.0.0R16P7 - 2.0.0R16P8
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R16P7'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R16P8', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

alter table tbl_property add statusOctetSwapped smallint default 0
alter table tbl_property add CheckTonerOids SMALLINT NOT NULL DEFAULT 0

DECLARE @OctetSwap INT
SELECT @OctetSwap = count(*) FROM sys.columns
WHERE name IN (N'statusOctetSwapped')
AND object_id = OBJECT_ID(N'tbl_model');

IF (@OctetSwap < 1)
BEGIN
	alter table tbl_model add statusOctetSwapped smallint default 0
END

DECLARE @CheckToner INT
SELECT @CheckToner = count(*) FROM sys.columns
WHERE name IN (N'CheckTonerOids')
AND object_id = OBJECT_ID(N'tbl_model');

IF (@CheckToner < 1)
BEGIN
	alter table tbl_model add CheckTonerOids SMALLINT NOT NULL DEFAULT 0
END

go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	--TI_DELETED_AUTOMATICALLY,
	if(@minor=25)
		RETURN 'Automatically deleted'

	--TI_USER_CANCELLED_AUTHENTICATION_DELETE
	if(@minor=26)
		RETURN 'Deleted - User cancel authentication'


	--TI_AUTHENTICATION_ERROR
	if(@minor=27)
		RETURN 'Deleted - Authentication error on client'


	--TI_DELETED_AUTOMATICALLY_NO_CLIENT_SESSION
	if(@minor=28)
		RETURN 'Deleted - No client session on client'


	--TI_RULESET_DELETE,
	if(@minor=29)
		RETURN 'Deleted - By ruleset'

	--TI_RULESET_MOVE,
	if(@minor=30)
		RETURN 'Moved - by ruleset'

	--TI_RULESET_PAUSE
	if(@minor=31)
		RETURN 'Paused - by ruleset'

	-- TI_DELETED_CREATED,
	if(@minor=32)
		RETURN 'Deleted - created job'


	-- TI_DELETED_HANDOVER_OVERDUE,
	if(@minor=33)
		RETURN 'Deleted - handover overdue'

	-- TI_DELETED_AUTOMATICALLY_NO_CONTACT_WITH_CLIENT

	if(@minor=34)
		RETURN 'Deleted - no contact with client during authentication'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_CB_SET
	if(@minor=36)
		RETURN 'Client billing code set'

	-- TI_CB_CANCEL_PRESS_DELETE
	if(@minor=37)
		RETURN 'Deleted - Client billing cancel pressed'

	if(@minor=38)
		RETURN 'Deleted - Wrong client version'

	--TI_MANUALLY_MOVED,
	if(@minor=39)
		RETURN 'Moved - manually'

	--TI_AUTOMATICALLY_MOVED
	if(@minor=40)
		RETURN 'Moved - automatically'

--	TI_PAGES_RESET,
	if(@minor=41)
		RETURN 'Pages reset from 0 to 1 (Driver error)'

	-- TI_DELETED_QUEUE,
	if(@minor=42)
		RETURN 'Deleted - Queue deleted'

	-- TI_DELETED_QUEUE,
	if(@minor=43)
		RETURN 'Deleted - Queue Stopped'

	-- TI_DELETED_WRONG_DRIVER,
	if(@minor=44)
		RETURN 'Deleted - Wrong driver'

--	TI_DELETED_NO_QUEUE
	if(@minor=45)
		RETURN 'Deleted - No queue with UUID'

--
	if(@minor=46)
		RETURN 'Changed price plan'

--	TI_MULTIPLE_PRINT,
	if(@minor=47)
		RETURN 'Multiple print job'

--	TI_CPT_RELEASE_JOB
	if(@minor=48)
		RETURN 'CPT Release job'

--	TI_VDMS_RELEASE_JOB
	if(@minor=49)
		RETURN 'VDMS Release job'

-- TI_FPRINT_RELEASE_JOB
	if(@minor=50)
		RETURN 'Fprint Release job'

--TI_VDMS_RECORD_JOB_ACTION,

	if(@minor=51)
		RETURN 'VDMS Record Job'

--	TI_CPT_RELEASE_JOB_FAIL,

	if(@minor=52)
		RETURN 'CPT Release job Fail'

-- TI_PRINTSERVICE_ORDER,
	if(@minor=53)
		RETURN 'Print service order'


	--TI_PRINTSERVICE_ORDER_FAIL,
	if(@minor=54)
		RETURN 'Print service order fail'


--	TI_PRINTSERVICE_ORDER_COMPLETE,
	if(@minor=55)
		RETURN 'Print service order complete'


	--TI_PRINTSERVICE_ORDER_COMPLETE_FAIL,
	if(@minor=56)
		RETURN 'Print service order complete fail'

	--TI_VDMS_RECORD_JOB_TRANSACTION,

	if(@minor=57)
		RETURN 'VDMS Record Job Transaction'

	--TI_SET_PAPERSIZE,
	if(@minor=58)
		RETURN 'Set Papersize from SNMP scan'

	--TI_NO_TICKET_FOUND

	if(@minor=59)
		RETURN 'No ticket found'

	if(@minor=60)
		RETURN 'User message sent'


	--TI_EXT_SCAN_SUCCESS,
	if(@minor=61)
		RETURN 'External scan success'

	--TI_EXT_SCAN_FAIL,

	if(@minor=62)
		RETURN 'External scan fail'

	--TI_JOB_DOES_NOT_EXIST_ON_CLIENT,
	if(@minor=63)
		RETURN 'Job with ticket ID does not exist on client (Client request)'


	--TI_HANDOVEREVENT_FAIL,

	if(@minor=64)
		RETURN 'Handoverevent fail'

	--TI_MISSING_PAYMENT,

	if(@minor=65)
		RETURN 'Missing payment'


	--TI_DEBIT_INTERNAL_NO_CONTRACT,

	if(@minor=66)
		RETURN 'Wallet print fail - no wallet entry for user'


	--TI_JOB_HAS_ALREADY_BEEN_PRINTED_3RD

	if(@minor=67)
		RETURN 'Job has already been printed 3Rd'


	RETURN @minor
END


go
IF OBJECT_ID('tbl_toner_log') IS NULL
BEGIN
	CREATE TABLE tbl_toner_log (
		tl_Id			VARCHAR(64) PRIMARY KEY NOT NULL DEFAULT '',
		tl_PrinterId	VARCHAR(64) NOT NULL DEFAULT '',
		tl_GroupId		VARCHAR(64) NOT NULL DEFAULT '',
		tl_Color		VARCHAR(64) NOT NULL DEFAULT '',
		tl_Level		INTEGER NOT NULL DEFAULT 0,
		tl_Created		DATETIME NOT NULL
	)
END

IF OBJECT_ID('tbl_custom_oid') IS NULL
BEGIN
	CREATE TABLE tbl_custom_oid (
		coidId VARCHAR(64) PRIMARY KEY NOT NULL DEFAULT '',
		coidKey VARCHAR(64) NOT NULL DEFAULT '',
		coidModelId VARCHAR(64) NOT NULL DEFAULT '',
		coidOid VARCHAR(1024) NOT NULL DEFAULT '',
		coidCreated DATETIME NOT NULL	
	)
END

alter table tbl_ticket add lastErrorCode smallint NULL
alter table tbl_ticket_log add loglastErrorCode smallint NULL
alter table tbl_ticket alter column ticketDriver varchar(64)
alter table tbl_ticket_log alter column logticketDriver varchar(64)

IF OBJECT_ID('tbl_ticket_log_trans') IS NOT NULL
drop table tbl_ticket_log_trans

select top 1 * into tbl_ticket_log_trans from tbl_ticket_log

truncate table tbl_ticket_log_trans

alter table tbl_client_billing add cb_debituser int NULL

create table tbl_lookup_major_error_code
(
	lmec_rid smallint identity primary key,
	lmec_id smallint not null,
	lmec_printed char,
	lmec_deleted char,
	lmec_delayed char,
	lmec_locale nvarchar(10),
	lmec_description nvarchar(200),
	lmec_definition nvarchar(200)
)

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (10,1,0,0,'Job printed','Print job or copy has been produced in the printer successfully')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (20,0,1,0,'Print job erased','Printjob has been erased automatically from the system and NOT printed.')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (21,0,1,0,'Print job manually erased','Printjob has been manually erased from the system and NOT printed.')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (30,0,0,1,'Print job error','An error has occured that may delay the print job')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (40,0,0,0,'Print job warning','A warning has occured that do not delay the print job initially')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (41,0,0,1,'Print job warning - delay','A warning has occured that delay the print job')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (50,0,0,0,'Print job information','Information regarding a print job')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (51,0,0,1,'Print job information - delay','Information regarding a print job - may cause a delay')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (60,0,0,0,'Ticket debit','Information regarding debit on a print job')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (61,0,0,1,'Ticket debit - warning','Warning regarding debit on a print job - may cause a delay')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (62,0,0,1,'Ticket debit - error','Error regarding debit on a print job - will cause a delay or non printed job')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (70,0,0,0,'CPT Event','Information regarding a Cirrato Printer Terminal event')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (80,0,0,0,'Print Service event','Information regarding a print service event')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (90,0,0,0,'Printer counter information','Information regarding a print job - page counter')

insert into tbl_lookup_major_error_code (lmec_id, lmec_printed, lmec_deleted, lmec_delayed, lmec_description, lmec_definition)
values (91,0,0,1,'Printer counter error','Error when collecting printer page data - may cause delays')

create table tbl_lookup_last_ticket_error
(
	lte_rid smallint identity primary key,
	lte_id smallint not null,
	lte_locale nvarchar(10),
	lte_description nvarchar(200)
)
delete from tbl_lookup_last_ticket_error
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (1,'No contact with client')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (2,'No contact with printer')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (3,'No contact with client during send time estimate')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (4,'Heartbeat failed')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (10,'Administrative: Printer or queue paused')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (20,'SNMP Monitor: Error - No paper')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (21,'SNMP Monitor: Error - No toner')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (22,'SNMP Monitor: Error - Printer offline')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (23,'SNMP Monitor: Error - Paper jam')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (24,'SNMP Monitor: Error - Door open')
insert into tbl_lookup_last_ticket_error (lte_id,lte_description) values (25,'SNMP Monitor: Error - No contact with printer')


IF OBJECT_ID('tbl_custom_oid') IS NOT NULL
BEGIN
	DROP TABLE tbl_custom_oid
END

IF OBJECT_ID('tbl_toner_log') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_log
END

IF OBJECT_ID('tbl_toner_oids') IS NULL
BEGIN
	CREATE TABLE tbl_toner_oids (
		ModelId				VARCHAR(64) PRIMARY KEY NOT NULL DEFAULT '',
		WarningLevelForC	SMALLINT NOT NULL DEFAULT 0,
		WarningLevelForM	SMALLINT NOT NULL DEFAULT 0,
		WarningLevelForY	SMALLINT NOT NULL DEFAULT 0,
		WarningLevelForK	SMALLINT NOT NULL DEFAULT 0,
		OidForC				VARCHAR(1024) NOT NULL DEFAULT '',
		OidForM				VARCHAR(1024) NOT NULL DEFAULT '',
		OidForY				VARCHAR(1024) NOT NULL DEFAULT '',
		OidForK				VARCHAR(1024) NOT NULL DEFAULT '',
	)
END

IF OBJECT_ID('tbl_toner_log') IS NULL
BEGIN
	CREATE TABLE tbl_toner_log (
		Id					VARCHAR(64) PRIMARY KEY NOT NULL DEFAULT '',
		PrinterId			VARCHAR(64) NOT NULL DEFAULT '',
		TonerColor			CHAR(1) NOT NULL DEFAULT '',
		TonerLevel			SMALLINT NOT NULL DEFAULT 0,
		TonerWarningLevel	SMALLINT NOT NULL DEFAULT 0,
		FirstDetected		DATETIME,
		LastDetected		DATETIME,
		IsOpen				BIT NOT NULL DEFAULT 1
	)
END

IF OBJECT_ID('tbl_attribute') IS NULL
BEGIN
CREATE TABLE tbl_attribute(
	[attributeName] [varchar](64) COLLATE Finnish_Swedish_CI_AS NOT NULL,
	[attributeValue] [nvarchar](510) COLLATE Finnish_Swedish_CI_AS NULL
) 
END

IF OBJECT_ID('tbl_attribute_log') IS NULL
BEGIN
CREATE TABLE tbl_attribute_log(
	[ticketId] [varchar](64) COLLATE Finnish_Swedish_CI_AS NOT NULL,
	[attributeName] [varchar](64) COLLATE Finnish_Swedish_CI_AS NOT NULL,
	[attributeValue] [nvarchar](510) COLLATE Finnish_Swedish_CI_AS NULL
)
END

CREATE TABLE [dbo].[tbl_counter_price](
	[ticketId] [uniqueidentifier] NOT NULL,
	[counterType] [smallint] NOT NULL,
	[value] [int] NOT NULL,
	[date] [datetime] NOT NULL
) ON [PRIMARY]

IF OBJECT_ID('tbl_counter_program_external') IS NULL
BEGIN
	CREATE TABLE tbl_counter_program_external (
		[counterProgramId] [uniqueidentifier] NOT NULL,
		[dllName] [nvarchar](255) COLLATE Finnish_Swedish_CI_AS NOT NULL DEFAULT (''),
 	CONSTRAINT [PK_counterProgramId] PRIMARY KEY CLUSTERED 
	(
		[counterProgramId] ASC
	)WITH (PAD_INDEX  = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY]
END


IF OBJECT_ID('tbl_counter_program_external_attribute') IS NULL
BEGIN
	CREATE TABLE tbl_counter_program_external_attribute(
		[counterProgramId] [uniqueidentifier] NOT NULL,
		[attributeName] [nvarchar](255) COLLATE Finnish_Swedish_CI_AS NOT NULL,
		[attributeValue] [nvarchar](255) COLLATE Finnish_Swedish_CI_AS NULL
	) ON [PRIMARY]

	ALTER TABLE tbl_counter_program_external_attribute  WITH CHECK ADD FOREIGN KEY([counterProgramId])
	REFERENCES tbl_counter_program_external ([counterProgramId])
END

IF OBJECT_ID('tbl_counter_program_external_counter') IS NULL
BEGIN
	CREATE TABLE tbl_counter_program_external_counter(
		[counterProgramId] [uniqueidentifier] NOT NULL,
		[counterName] [nvarchar](255) COLLATE Finnish_Swedish_CI_AS NOT NULL,
		[counterType] [smallint] NOT NULL
	) ON [PRIMARY]

	ALTER TABLE tbl_counter_program_external_counter  WITH CHECK ADD  CONSTRAINT [FK__tbl_count__count__03C67B1A] FOREIGN KEY([counterProgramId])
	REFERENCES tbl_counter_program_external ([counterProgramId])
	ALTER TABLE tbl_counter_program_external_counter CHECK CONSTRAINT [FK__tbl_count__count__03C67B1A]	
END


IF OBJECT_ID('tbl_external_counter') IS NULL
BEGIN
	CREATE TABLE tbl_external_counter (
		[ticketId] [uniqueidentifier] NOT NULL,
		[timeStart] [datetime] NULL DEFAULT (getdate()),
		[counterName] [nvarchar](255) COLLATE Finnish_Swedish_CI_AS NOT NULL,
		[counterType] [smallint] NOT NULL,
		[counterValue] [nvarchar](255) COLLATE Finnish_Swedish_CI_AS NULL,
		[counterSize] [int] NULL
) ON [PRIMARY]
END

GO

create table tbl_client_billing_persistent_code
(
	cbpc_username nvarchar(128) NOT NULL,
	cbpc_domain nvarchar(128) NOT NULL,
	cbpc_billingCode nvarchar(128),
	cbpc_expiryDate datetime,
	primary key(cbpc_username, cbpc_domain)
)

create table tbl_missing_payments
(
	mp_id bigint not null identity primary key,	
	mp_ts datetime default getDate(),
	mp_ticketId uniqueidentifier,
	mp_user nvarchar(128),
	mp_domain nvarchar(128),
	mp_paymethod tinyint,
 	mp_amount float
)

-- Ruchira Bomiriya
-- 2010/02/10

IF OBJECT_ID('tbl_action_email_log') IS NULL
BEGIN
	CREATE TABLE tbl_action_email_log (
		emaillogId varchar(64) not null default '',
		emaillogPrinterId varchar(64) not null default '',
		emaillogPrinterName nvarchar(256) not null default '',
		emaillogPhysStatus smallint not null default -1,
		emaillogTo varchar(256) not null default '',
		emaillogSubject varchar(256) not null default '',
		emaillogError int not null default 0,
		emaillogRecorded datetime
	)
END

-- Ruchira Bomiriya
-- 2010/03/22

IF OBJECT_ID('tbl_alert') IS NULL
BEGIN
	CREATE TABLE tbl_alert (
		a_Code				integer PRIMARY KEY NOT NULL DEFAULT 0,
		a_CodeComment		varchar(128) NOT NULL DEFAULT '', 
		a_Priority			integer NOT NULL DEFAULT 0,
		a_IsNotify			bit NOT NULL DEFAULT 1
	)
	
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1, 'OTHER', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (2, 'UNKNOWN', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (3, 'COVER_OPEN', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (4, 'COVER_CLOSED', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (5, 'INTERLOCK_OPEN', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (6, 'INTERLOCK_CLOSED', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (7, 'CONFIGURATION_CHANGE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (8, 'JAM', 1, 1);
	
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (501, 'DOOR_OPEN', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (502, 'DOOR_CLOSED', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (503, 'POWER_UP', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (504, 'POWER_DOWN', 1, 0);
		
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (801, 'INPUT_MEDIA_TRAY_MISSING', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (802, 'INPUT_MEDIA_SIZE_CHANGE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (803, 'INPUT_MEDIA_WEIGHT_CHANGE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (804, 'INPUT_MEDIA_TYPE_CHANGE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (805, 'INPUT_MEDIA_COLOR_CHANGE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (806, 'INPUT_MEDIA_FORM_PARTS_CHANGE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (807, 'INPUT_MEDIA_SUPPLY_LOW', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (808, 'INPUT_MEDIA_SUPPLY_EMPTY', 1, 1);
	
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (901, 'OUTPUT_MEDIA_TRAY_MISSING', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (902, 'OUTPUT_MEDIA_TRAY_ALMOST_FULL', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (903, 'OUTPUT_MEDIA_TRAY_FULL', 1, 1);
	
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1001, 'MARKER_FUSER_UNDER_TEMPERATURE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1002, 'MARKER_FUSER_OVER_TEMPERATURE', 1, 1);
	
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1101, 'MARKER_TONER_EMPTY', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1102, 'MARKER_INK_EMPTY', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1103, 'MARKER_PRINT_RIBBON_EMPTY', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1104, 'MARKER_TONER_ALMOST_EMPTY', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1105, 'MARKER_INK_ALMOST_EMPTY', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1106, 'MARKER_PRINT_RIBBON_ALMOST_EMPTY', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1107, 'MARKER_WASTE_TONER_RECEPTACLE_ALMOST_FULL', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1108, 'MARKER_WASTE_INK_RECEPTACLE_ALMOST_FULL', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1109, 'MARKER_WASTE_TONER_RECEPTACLE_FULL', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1110, 'MARKER_WASTE_INK_RECEPTACLE_FULL', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1111, 'MARKER_OPC_LIFE_ALMOST_OVER', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1112, 'MARKER_OPC_LIFE_OVER', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1113, 'MARKER_DEVELOPER_ALMOST_EMPTY', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1114, 'MARKER_DEVELOPER_EMPTY', 1, 1);
	
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1301, 'MEDIA_PATH_MEDIA_TRAY_MISSING', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1302, 'MEDIA_PATH_MEDIA_TRAY_ALMOST_FULL', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1303, 'MEDIA_PATH_MEDIA_TRAY_FULL', 1, 1);
	
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1501, 'INTERPRETER_MEMORY_INCREASE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1502, 'INTERPRETER_MEMORY_DECREASE', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1503, 'INTERPRETER_CARTRIDGE_ADDED', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1504, 'INTERPRETER_CARTRIDGE_DELETED', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1505, 'INTERPRETER_RESOURCE_ADDED', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1506, 'INTERPRETER_RESOURCE_DELETED', 1, 1);
	INSERT INTO tbl_alert (a_Code, a_CodeComment, a_Priority, a_IsNotify) VALUES (1507, 'INTERPRETER_RESOURCE_UNAVAILABLE', 1, 1);
END

-- Ruchira Bomiriya
-- 2010/03/22

IF OBJECT_ID('tbl_alert_log') IS NULL
BEGIN
	CREATE TABLE tbl_alert_log (
		al_Id			varchar(64) PRIMARY KEY NOT NULL DEFAULT '',
		al_PrinterId	varchar(64) NOT NULL DEFAULT '',
		al_GroupId		varchar(64) NOT NULL DEFAULT '',
		al_Index		integer NOT NULL DEFAULT 0,
		al_Code			integer NOT NULL DEFAULT 0,
		al_Description	varchar(256) NOT NULL DEFAULT '',
		al_IsOpen		bit NOT NULL DEFAULT 1,
		al_Created		datetime NOT NULL,
		al_Updated		datetime
	)
END

-- Ruchira Bomiriya-- 2010/09/20IF OBJECT_ID('tbl_toner_oids') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_oids
END

IF OBJECT_ID('tbl_toner_oid') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_oid
END

GO

IF OBJECT_ID('tbl_toner_oid') IS NULL
BEGIN
	CREATE TABLE tbl_toner_oid (
		Id					UNIQUEIDENTIFIER PRIMARY KEY NOT NULL DEFAULT NEWID(),
		Profile				VARCHAR(32) NOT NULL DEFAULT '',
		Color				VARCHAR(32) NOT NULL DEFAULT '',
		LevelOid			VARCHAR(1024) NOT NULL DEFAULT '',
		MaxCapacityOid		VARCHAR(1024) NOT NULL DEFAULT ''
	)
	
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('STD_CMYK', 'CYAN', '1.3.6.1.2.1.43.11.1.1.9.1.1', '1.3.6.1.2.1.43.11.1.1.8.1.1')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('STD_CMYK', 'MAGENTA', '1.3.6.1.2.1.43.11.1.1.9.1.2', '1.3.6.1.2.1.43.11.1.1.8.1.2')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('STD_CMYK', 'YELLOW', '1.3.6.1.2.1.43.11.1.1.9.1.3', '1.3.6.1.2.1.43.11.1.1.8.1.3')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('STD_CMYK', 'BLACK', '1.3.6.1.2.1.43.11.1.1.9.1.4', '1.3.6.1.2.1.43.11.1.1.8.1.4')
	
	-- RICOH oids are different from the standard
	-- RICOH color order is different (1 == BLACK) from the standard
	--
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_CMYK', 'BLACK', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.1', '')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_CMYK', 'CYAN', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.2', '')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_CMYK', 'MAGENTA', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.3', '')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_CMYK', 'YELLOW', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.4', '')
	
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_BW', 'BLACK', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.1', '')	
END

IF OBJECT_ID('tbl_toner_warning') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_warning
END

GO

IF OBJECT_ID('tbl_toner_warning') IS NULL
BEGIN
	CREATE TABLE tbl_toner_warning (
		Id					UNIQUEIDENTIFIER PRIMARY KEY NOT NULL DEFAULT NEWID(),
		ModelId				UNIQUEIDENTIFIER,
		Profile				VARCHAR(32) NOT NULL DEFAULT '',
		Color				VARCHAR(32) NOT NULL DEFAULT '',
		WarningPercentage	INTEGER NOT NULL DEFAULT 0,
		FOREIGN KEY(ModelId) REFERENCES tbl_model(modelId)
	)
END

IF OBJECT_ID('tbl_toner_log') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_log
END

GO

IF OBJECT_ID('tbl_toner_log') IS NULL
BEGIN
	CREATE TABLE tbl_toner_log (
		Id					UNIQUEIDENTIFIER PRIMARY KEY NOT NULL DEFAULT NEWID(),
		PrinterId			VARCHAR(64) NOT NULL DEFAULT '',
		Profile				VARCHAR(32) NOT NULL DEFAULT '',
		Color				VARCHAR(32) NOT NULL DEFAULT '',
		Level				INTEGER NOT NULL DEFAULT 0,
		MaxCapacity			INTEGER NOT NULL DEFAULT 0,
		Percentage			INTEGER NOT NULL DEFAULT 0,
		WarningPercentage	INTEGER NOT NULL DEFAULT 0,
		FirstDetected		DATETIME,
		LastDetected		DATETIME,
		IsOpen				BIT NOT NULL DEFAULT 0,
		Closed				DATETIME
	)
END
GO

declare @cons nvarchar(128)
select @cons = CONSTRAINT_NAME from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE TABLE_NAME = 'tbl_configfile_map' AND COLUMN_NAME = 'cmap_mid'
select @cons
DECLARE @sql nvarchar(255) 
select @sql = 'ALTER TABLE tbl_configfile_map DROP CONSTRAINT ' + @cons
exec sp_executesql @sql 
alter table tbl_configfile_map add FOREIGN KEY(cmap_mid) REFERENCES tbl_driver_map(mapId) ON DELETE CASCADE
GO

declare @cons nvarchar(128)
select @cons = CONSTRAINT_NAME from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE TABLE_NAME = 'tbl_ticket_feature' AND COLUMN_NAME = 'ticketFeatureTicket'
select @cons
DECLARE @sql nvarchar(255) 
select @sql = 'ALTER TABLE tbl_ticket_feature DROP CONSTRAINT ' + @cons
exec sp_executesql @sql 
ALTER TABLE tbl_ticket_feature WITH CHECK ADD FOREIGN KEY(ticketFeatureTicket) REFERENCES tbl_ticket(ticketId) ON DELETE CASCADE
GO

declare @cons nvarchar(128)
select @cons = CONSTRAINT_NAME from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE TABLE_NAME = 'tbl_cirrato_wallet_transaction' AND COLUMN_NAME = 'wTransactionTicket'
select @cons
DECLARE @sql nvarchar(255) 
select @sql = 'ALTER TABLE tbl_cirrato_wallet_transaction DROP CONSTRAINT ' + @cons
exec sp_executesql @sql 
GO




