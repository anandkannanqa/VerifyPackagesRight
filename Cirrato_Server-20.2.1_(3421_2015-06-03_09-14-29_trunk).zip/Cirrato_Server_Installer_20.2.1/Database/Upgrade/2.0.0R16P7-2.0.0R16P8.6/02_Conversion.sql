-- Conversion script Cirrato 2.0.0R16P7 - 2.0.0R16P8
-- V 1.0 2011-02-04
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R16P8'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO


declare @pid varchar(64)
set @pid = ''
select top 1 @pid = scl_printerId from tbl_snmp_counter_log where LEN(scl_printerId) <> 36 AND LEN([scl_printerId]) > 0
if len(@pid) > 0
begin
	RAISERROR ('Found scl_ticketId in tbl_snmp_counter_log %s which cannot be converted to uniqueidentifier. Please replace the ticketId and rerun this script.',18,1, @pid) with nowait
end

GO

:On error continue

print'Starting update'

:on error continue

IF NOT EXISTS 
(
	SELECT * FROM [information_schema].[columns] 
		WHERE table_name = 'tbl_snmp_counter_log' 
		AND table_schema = 'dbo'
		AND column_name = 'scl_printerId'
		AND is_nullable = 'YES'
		AND data_type = 'uniqueidentifier'
) 
BEGIN
	print 'Updating snmp counter log'

	exec sp_rename 'tbl_snmp_counter_log','tbl_snmp_counter_log_old'

	create table tbl_snmp_counter_log
	(
		scl_ticketId uniqueidentifier null,
		scl_printerId uniqueidentifier null,
		scl_event smallint null,
		scl_eventTs datetime default getDate() null,
		scl_timeStart datetime null,
		scl_timeEnd datetime null,
		scl_bwCounter bigint null,
		scl_coCounter bigint null,
		scl_duCounter bigint null,
		scl_dupCounter bigint null
	)
	
	insert into tbl_snmp_counter_log
		SELECT [scl_ticketId]
			,CASE [scl_printerId] WHEN '' THEN null ELSE [scl_printerId] END
			,[scl_event]
			,[scl_eventTs]
			,[scl_timeStart]
			,[scl_timeEnd]
			,[scl_bwCounter]
			,[scl_coCounter]
			,[scl_duCounter]
			,[scl_dupCounter]
		FROM [tbl_snmp_counter_log_old]

	print 'Updating brands done.'
END
ELSE
BEGIN
	print 'skipping update of snmp counter log'
END




