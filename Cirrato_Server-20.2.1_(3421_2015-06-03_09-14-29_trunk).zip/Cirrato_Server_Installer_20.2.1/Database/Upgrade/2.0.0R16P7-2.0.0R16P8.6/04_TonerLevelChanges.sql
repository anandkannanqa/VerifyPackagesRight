-- Ruchira Bomiriya-- 2010/09/20IF OBJECT_ID('tbl_toner_oids') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_oids
END

IF OBJECT_ID('tbl_toner_oid') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_oid
END

GO

IF OBJECT_ID('tbl_toner_oid') IS NULL
BEGIN
	CREATE TABLE tbl_toner_oid (
		Id					UNIQUEIDENTIFIER PRIMARY KEY NOT NULL DEFAULT NEWID(),
		Profile				VARCHAR(32) NOT NULL DEFAULT '',
		Color				VARCHAR(32) NOT NULL DEFAULT '',
		LevelOid			VARCHAR(1024) NOT NULL DEFAULT '',
		MaxCapacityOid		VARCHAR(1024) NOT NULL DEFAULT ''
	)
	
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('STD_CMYK', 'CYAN', '1.3.6.1.2.1.43.11.1.1.9.1.1', '1.3.6.1.2.1.43.11.1.1.8.1.1')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('STD_CMYK', 'MAGENTA', '1.3.6.1.2.1.43.11.1.1.9.1.2', '1.3.6.1.2.1.43.11.1.1.8.1.2')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('STD_CMYK', 'YELLOW', '1.3.6.1.2.1.43.11.1.1.9.1.3', '1.3.6.1.2.1.43.11.1.1.8.1.3')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('STD_CMYK', 'BLACK', '1.3.6.1.2.1.43.11.1.1.9.1.4', '1.3.6.1.2.1.43.11.1.1.8.1.4')
	
	-- RICOH oids are different from the standard
	-- RICOH color order is different (1 == BLACK) from the standard
	--
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_CMYK', 'BLACK', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.1', '')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_CMYK', 'CYAN', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.2', '')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_CMYK', 'MAGENTA', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.3', '')
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_CMYK', 'YELLOW', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.4', '')
	
	INSERT INTO tbl_toner_oid (Profile, Color, LevelOid, MaxCapacityOid) VALUES ('RICOH_BW', 'BLACK', '1.3.6.1.4.1.367.3.2.1.2.24.1.1.5.1', '')	
END

IF OBJECT_ID('tbl_toner_warning') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_warning
END

GO

IF OBJECT_ID('tbl_toner_warning') IS NULL
BEGIN
	CREATE TABLE tbl_toner_warning (
		Id					UNIQUEIDENTIFIER PRIMARY KEY NOT NULL DEFAULT NEWID(),
		ModelId				UNIQUEIDENTIFIER,
		Profile				VARCHAR(32) NOT NULL DEFAULT '',
		Color				VARCHAR(32) NOT NULL DEFAULT '',
		WarningPercentage	INTEGER NOT NULL DEFAULT 0,
		FOREIGN KEY(ModelId) REFERENCES tbl_model(modelId)
	)
END

IF OBJECT_ID('tbl_toner_log') IS NOT NULL
BEGIN
	DROP TABLE tbl_toner_log
END

GO

IF OBJECT_ID('tbl_toner_log') IS NULL
BEGIN
	CREATE TABLE tbl_toner_log (
		Id					UNIQUEIDENTIFIER PRIMARY KEY NOT NULL DEFAULT NEWID(),
		PrinterId			VARCHAR(64) NOT NULL DEFAULT '',
		Profile				VARCHAR(32) NOT NULL DEFAULT '',
		Color				VARCHAR(32) NOT NULL DEFAULT '',
		Level				INTEGER NOT NULL DEFAULT 0,
		MaxCapacity			INTEGER NOT NULL DEFAULT 0,
		Percentage			INTEGER NOT NULL DEFAULT 0,
		WarningPercentage	INTEGER NOT NULL DEFAULT 0,
		FirstDetected		DATETIME,
		LastDetected		DATETIME,
		IsOpen				BIT NOT NULL DEFAULT 0,
		Closed				DATETIME
	)
END

