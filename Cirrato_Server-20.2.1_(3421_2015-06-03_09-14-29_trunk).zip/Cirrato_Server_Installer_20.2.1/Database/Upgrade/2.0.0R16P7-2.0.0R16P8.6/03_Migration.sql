-- Data migration 2.0.0R16P7 - 2.0.0R16P8
-- Please turn on SQL Command Mode
-- Log migration script
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R16P8'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update of tbl_ticket_log data - 67 data changes to make'

:on error continue


update tbl_ticket_log set logEventMajor=10 where logEventMinor=1
update tbl_ticket_log set logEventMajor=30 where logEventMinor=2
update tbl_ticket_log set logEventMajor=20 where logEventMinor=3
update tbl_ticket_log set logEventMajor=41 where logEventMinor=4
update tbl_ticket_log set logEventMajor=30 where logEventMinor=5
update tbl_ticket_log set logEventMajor=10 where logEventMinor=6
update tbl_ticket_log set logEventMajor=21 where logEventMinor=7
update tbl_ticket_log set logEventMajor=50 where logEventMinor=8
update tbl_ticket_log set logEventMajor=10 where logEventMinor=10
print'10/67'
update tbl_ticket_log set logEventMajor=50 where logEventMinor=11
update tbl_ticket_log set logEventMajor=50 where logEventMinor=12
update tbl_ticket_log set logEventMajor=50 where logEventMinor=13
update tbl_ticket_log set logEventMajor=90 where logEventMinor=14
update tbl_ticket_log set logEventMajor=91 where logEventMinor=15
update tbl_ticket_log set logEventMajor=90 where logEventMinor=16
update tbl_ticket_log set logEventMajor=91 where logEventMinor=17
update tbl_ticket_log set logEventMajor=20 where logEventMinor=18
update tbl_ticket_log set logEventMajor=61 where logEventMinor=19
update tbl_ticket_log set logEventMajor=60 where logEventMinor=20
print'20/67'
update tbl_ticket_log set logEventMajor=62 where logEventMinor=21
update tbl_ticket_log set logEventMajor=60 where logEventMinor=22
update tbl_ticket_log set logEventMajor=62 where logEventMinor=23
update tbl_ticket_log set logEventMajor=62 where logEventMinor=24
update tbl_ticket_log set logEventMajor=20 where logEventMinor=25
update tbl_ticket_log set logEventMajor=21 where logEventMinor=26
update tbl_ticket_log set logEventMajor=20 where logEventMinor=27
update tbl_ticket_log set logEventMajor=20 where logEventMinor=28
update tbl_ticket_log set logEventMajor=20 where logEventMinor=29
update tbl_ticket_log set logEventMajor=50 where logEventMinor=30
print'30/67'
update tbl_ticket_log set logEventMajor=51 where logEventMinor=31
update tbl_ticket_log set logEventMajor=20 where logEventMinor=32
update tbl_ticket_log set logEventMajor=20 where logEventMinor=33
update tbl_ticket_log set logEventMajor=20 where logEventMinor=34
update tbl_ticket_log set logEventMajor=30 where logEventMinor=35
update tbl_ticket_log set logEventMajor=51 where logEventMinor=36
update tbl_ticket_log set logEventMajor=21 where logEventMinor=37
update tbl_ticket_log set logEventMajor=20 where logEventMinor=38
update tbl_ticket_log set logEventMajor=50 where logEventMinor=39
update tbl_ticket_log set logEventMajor=50 where logEventMinor=40
print'40/67'
update tbl_ticket_log set logEventMajor=50 where logEventMinor=41
update tbl_ticket_log set logEventMajor=20 where logEventMinor=42
update tbl_ticket_log set logEventMajor=20 where logEventMinor=43
update tbl_ticket_log set logEventMajor=20 where logEventMinor=44
update tbl_ticket_log set logEventMajor=20 where logEventMinor=45
update tbl_ticket_log set logEventMajor=60 where logEventMinor=46
update tbl_ticket_log set logEventMajor=51 where logEventMinor=47
update tbl_ticket_log set logEventMajor=70 where logEventMinor=48
update tbl_ticket_log set logEventMajor=70 where logEventMinor=49
update tbl_ticket_log set logEventMajor=70 where logEventMinor=50
print'50/67'
update tbl_ticket_log set logEventMajor=10 where logEventMinor=51
update tbl_ticket_log set logEventMajor=70 where logEventMinor=52
update tbl_ticket_log set logEventMajor=80 where logEventMinor=53
update tbl_ticket_log set logEventMajor=80 where logEventMinor=54
update tbl_ticket_log set logEventMajor=80 where logEventMinor=55
update tbl_ticket_log set logEventMajor=80 where logEventMinor=56
update tbl_ticket_log set logEventMajor=80 where logEventMinor=57
update tbl_ticket_log set logEventMajor=90 where logEventMinor=58
update tbl_ticket_log set logEventMajor=30 where logEventMinor=59
update tbl_ticket_log set logEventMajor=50 where logEventMinor=60
print'60/67'
update tbl_ticket_log set logEventMajor=90 where logEventMinor=61
update tbl_ticket_log set logEventMajor=91 where logEventMinor=62
update tbl_ticket_log set logEventMajor=20 where logEventMinor=63
update tbl_ticket_log set logEventMajor=30 where logEventMinor=64
update tbl_ticket_log set logEventMajor=61 where logEventMinor=65
update tbl_ticket_log set logEventMajor=62 where logEventMinor=66
update tbl_ticket_log set logEventMajor=30 where logEventMinor=67
print'Done.'