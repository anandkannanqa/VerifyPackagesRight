-- Upgrade 2.0.0R6 - 2.0.0R7
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode


:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R6'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R7', propertyDate=getDate(),propertyChangedBy=user where propertyName='sysDbVersion';


create table tbl_cirrato_wallet
(
	wUser	nvarchar(128) not null,
	wDomain nvarchar(128) not null,
	wTotal float not null default 0,
	wReserved float not null default 0
)

create table tbl_cirrato_wallet_transaction
(
	wTransactionUser nvarchar(128) not null,
	wTransactionDomain nvarchar(128) not null,
	wTransactionId varchar(64) not null,
	wTransactionTicket varchar(64) not null,
	wTransactionTime datetime not null default getDate(),
	wTransactionAmount float not null default 0
)

create table tbl_cirrato_wallet_log
(
	wLogId varchar(64) not null,
	wLogTicketId varchar(64),
	wLogUser nvarchar(128) not null default '',
	wLogDomain nvarchar(128) not null default '',
	wLogDate datetime not null default getDate(),
	wLogTransDate datetime,
	wLogTransAmount float,
	wLogEvent smallint
)

create table tbl_cirrato_wallet_autocreate
(
	wCreateId bigint identity  not null,
	wCreateName nvarchar(64) not null,
	wCreateComment nvarchar(256) not null default '',
	wCreateGroupName varchar(128) not null,
	wCreatePriority smallint not null,
	wCreateCreator nvarchar(64) not null default '',
	wCreateInitialAmount float not null default 0
)

create table tbl_cirrato_rule
(
	rId varchar(64) not null,
	rType smallint not null,
	rConnectedId varchar(64),
	rRuleId varchar(64) not null,
	rAffectedId varchar(64),
	rGroupId varchar(64),
	rName nvarchar(64) not null default '',
	rComment nvarchar(255) not null default ''
)

create table tbl_cirrato_rule_affected
(
	rafId varchar(64) not null,
	rafType smallint not null,
	rafName nvarchar(128) not null,
	rafEquals smallint not null
)

create table tbl_cirrato_priceplan
(
	cppId varchar(64) not null,
	cppName nvarchar(64) not null,
	cppComment nvarchar(128) not null,
	cppPayment smallint not null
)


create table tbl_cirrato_priceplan_row
(
	cprId varchar(64) not null,
	cprPlanid varchar(64) not null,
	cprRowName nvarchar(64) not null,
	cprType smallint not null,
	cprValue int not null,
	cprCost float not null default 0
)

alter table tbl_ticket add loggedColorPages smallint not null default 0;
alter table tbl_ticket add loggedBWPages smallint not null default 0;
alter table tbl_ticket add pricePlan varchar(64) not null default '';

alter table tbl_ticket_log add logLoggedColorPages smallint not null default 0;
alter table tbl_ticket_log add logLoggedBWPages smallint not null default 0;
alter table tbl_ticket_log add logpricePlan varchar(64) not null default '';
create table tbl_payex_transaction
(
	payexTicket varchar(64) not null,
	payexTransactionId varchar(64) not null default '',
	payexExternalId varchar(64) not null,
	payexAuthAmount int not null default 0,
	payexTimestamp datetime default GetDate()
)

alter table tbl_ticket add ticketPrice float;
alter table tbl_ticket_log add logTicketPrice float;
alter table tbl_vdms_loginsession add vsPricePlan varchar(64) not null default '';
alter table tbl_ticket add originatingIp varchar(64) not null default '';
alter table tbl_ticket_log add logoriginatingIp varchar(64) not null default '';
alter table tbl_ticket add ticketRuleStatus smallint not null default 0;


--drop table tbl_cirrato_client_session
create table tbl_cirrato_client_session
(
	csessionId bigint identity not null,
	csessiontoken varchar(128) not null,
	csessionIp varchar(64) not null,
	csessionAuthUser nvarchar(255),
	csessionAuthDomain nvarchar(255),
	csessionUser nvarchar(255) not null,
	csessionDomain nvarchar(255) not null,
	csessionTsId smallint not null,
	csessionLHI int not null,
	csessionLLO int not null,
	csessionBootTime varchar(64) not null,
	csessionKerberosEnabled smallint not null default 0,
	csessionXres smallint not null default 0,
	csessionYres smallint not null default 0,
	csessionUILang varchar(64) not null default '',	
	csessionCirratoVersion varchar(64) not null default '',
	csessionType smallint not null,
	csessionLocaleAuto nvarchar(64) not null default '',
	csessionLocaleReg nvarchar(64) not null default '',
	csessionauthenticated smallint not null default 0,
	csessionDate datetime default getDate(),
	csessionLastSeen datetime
);

--drop table tbl_cirrato_client_message;

create table tbl_cirrato_client_message
(
	cmessageId bigint identity not null,
	cmessageToken varchar(128) not null,
	cmessageSession bigint not null default 0,
	cmessageType smallint not null default 0,
	cmessageTicketId varchar(64),
	cmessageMessageId varchar(64),
	cmessageDate datetime default getDate(),
	cmessageCaption nvarchar(255),
	cmessageText nvarchar(255),
	cmessageData varchar(128),
	cmessageMbType smallint not null default 0,
	cmessageAnswerRequired smallint not null default 0,
	cmessagePickedUp smallint not null default 0
)