:On error exit
declare @ppname varchar(64)
set @ppname = ''
select top 1 @ppname = logpricePlan from tbl_ticket_log_oldP7 where LEN(logpricePlan) <> 36 AND LEN([logpricePlan]) > 0
if len(@ppname) > 0
begin
	RAISERROR ('Found priceplan %s which cannot be converted to uniqueidentifier. Please rename the priceplan and rerun this script.',18,1, @ppname) with nowait
end

GO

:On error continue

IF OBJECT_ID('tbl_migration_failed') IS NULL
	CREATE TABLE [dbo].[tbl_migration_failed](
		[migrationDate] datetime NULL,
		[ticketId] [varchar](64) NULL,
		[errNum] [int] NULL,
		[errMsg] [nvarchar](256)
	)

declare @curTime datetime
set @curTime = getdate()

declare @cur_row bigint
set @cur_row = 0
declare @num_rows bigint
create table #t
(
name sysname,
rows bigint,
reserved varchar(50),
data varchar(50),
index_size varchar(50),
unused varchar(50)
)
insert into #t exec sp_spaceused 'tbl_ticket_log_oldP7'
select @num_rows = rows from #t
drop table #t

declare 	@logticketId varchar(64)
declare 	@logqueueId varchar(64)
declare 	@logprinterId varchar(64)
declare 	@logjobName nvarchar(255)
declare 	@loguserName nvarchar(128)
declare 	@loguserDomain nvarchar(255)
declare 	@logjobSize bigint
declare 	@logpages int
declare 	@logpaper int
declare 	@logduplex smallint
declare 	@logcolor smallint
declare 	@logdateEvent datetime
declare 	@logdateCreated datetime
declare 	@logdateSort datetime
declare 	@logdateBegan datetime
declare 	@logdateFinished datetime
declare 	@logsentBytes int
declare 	@logsentPages smallint
declare 	@logclientId varchar(64)
declare 	@logclientIp varchar(64)
declare 	@logEventMajor smallint
declare 	@logEventMinor smallint
declare 	@logData smallint
declare 	@logText nvarchar(512)
declare 	@logfprintQ varchar(64)
declare 	@logticketDriver varchar(64)
declare 	@logticketModel varchar(64)
declare 	@logLoggedColorPages smallint
declare 	@logLoggedBWPages smallint
declare 	@logpricePlan varchar(64)
declare 	@logTicketPrice float
declare 	@logoriginatingIp varchar(64)
declare 	@logDocumentTypeId bigint
declare 	@logclientBillingCode nvarchar(255)
declare		@loglastErrorCode smallint
declare		@DnId int

DECLARE mycursor CURSOR FOR
select 
CASE WHEN LEN([logticketId]) = 0 THEN NULL ELSE [logticketId]  END, 
CASE WHEN LEN([logqueueId]) = 0 THEN NULL ELSE [logqueueId] END, 
CASE WHEN LEN([logprinterId]) = 0 THEN NULL ELSE [logprinterId] END, 
logprinterId,
logjobName,
loguserName,
loguserDomain,
logjobSize,
logpages,
logpaper,
logduplex, 
logcolor ,
logdateEvent,
logdateCreated, 
logdateSort ,
logdateBegan,
logdateFinished,
logsentBytes,
logsentPages,
logclientId,
logclientIp,
logEventMajor,
logEventMinor,
logData,
logText,
CASE WHEN LEN([logfprintQ]) = 0 THEN NULL ELSE [logfprintQ]  END,
CASE WHEN LEN([logticketDriver]) <> 36 THEN NULL ELSE [logticketDriver] END,
CASE WHEN LEN([logticketModel]) = 0 THEN NULL ELSE [logticketModel] END,
logLoggedColorPages,
logLoggedBWPages,
CASE WHEN LEN([logpricePlan]) <> 36 THEN NULL ELSE [logpricePlan] END,
logTicketPrice,
logoriginatingIp,
logDocumentTypeId,
logclientBillingCode,
DnId
from tbl_ticket_log_oldP7

OPEN mycursor

FETCH NEXT FROM mycursor INTO 
@logticketId, 
@logqueueId, 
@logprinterId, 
@logprinterId,
@logjobName,
@loguserName,
@loguserDomain,
@logjobSize,
@logpages,
@logpaper,
@logduplex, 
@logcolor ,
@logdateEvent,
@logdateCreated, 
@logdateSort ,
@logdateBegan,
@logdateFinished,
@logsentBytes,
@logsentPages,
@logclientId,
@logclientIp,
@logEventMajor,
@logEventMinor,
@logData,
@logText,
@logfprintQ ,
@logticketDriver,
@logticketModel,
@logLoggedColorPages,
@logLoggedBWPages,
@logpricePlan,
@logTicketPrice,
@logoriginatingIp,
@logDocumentTypeId,
@logclientBillingCode,
@DnId

WHILE @@FETCH_STATUS = 0
BEGIN

BEGIN TRY
SET NOCOUNT ON 
INSERT INTO [dbo].[tbl_ticket_log]
           ([logticketId]
           ,[logqueueId]
           ,[logprinterId]
           ,[logjobName]
           ,[loguserName]
           ,[loguserDomain]
           ,[logjobSize]
           ,[logpages]
           ,[logpaper]
           ,[logduplex]
           ,[logcolor]
           ,[logdateEvent]
           ,[logdateCreated]
           ,[logdateSort]
           ,[logdateBegan]
           ,[logdateFinished]
           ,[logsentBytes]
           ,[logsentPages]
           ,[logclientId]
           ,[logclientIp]
           ,[logEventMajor]
           ,[logEventMinor]
           ,[logData]
           ,[logText]
           ,[logfprintQ]
           ,[logticketDriver]
           ,[logticketModel]
           ,[logLoggedColorPages]
           ,[logLoggedBWPages]
           ,[logpricePlan]
           ,[logTicketPrice]
           ,[logoriginatingIp]
           ,[logDocumentTypeId]
           ,[logclientBillingCode]
           ,[DnId])
     VALUES
           (CASE WHEN LEN(@logticketId) = 0 THEN NULL ELSE @logticketId END, 
CASE WHEN LEN(@logqueueId) = 0 THEN NULL ELSE @logqueueId END, 
CASE WHEN LEN(@logprinterId) = 0 THEN NULL ELSE @logprinterId END, 
@logjobName,
@loguserName,
@loguserDomain,
@logjobSize,
@logpages,
@logpaper,
@logduplex, 
@logcolor,
@logdateEvent,
@logdateCreated, 
@logdateSort,
@logdateBegan,
@logdateFinished,
@logsentBytes,
@logsentPages,
@logclientId,
@logclientIp,
@logEventMajor,
@logEventMinor,
@logData,
@logText,
CASE WHEN LEN(@logfprintQ) = 0 THEN NULL ELSE @logfprintQ  END,
CASE WHEN LEN(@logticketDriver) <> 36 THEN NULL ELSE @logticketDriver END,
CASE WHEN LEN(@logticketModel) = 0 THEN NULL ELSE @logticketModel END,
@logLoggedColorPages,
@logLoggedBWPages,
CASE WHEN LEN(@logpricePlan) <> 36 THEN NULL ELSE @logpricePlan END,
@logTicketPrice,
@logoriginatingIp,
@logDocumentTypeId,
@logclientBillingCode,
@DnId)

END TRY
BEGIN CATCH
	declare @errNum int
	declare @errMsg nvarchar(256)
	SELECT @errNum = ERROR_NUMBER(), @errMsg = ERROR_MESSAGE()
	insert into tbl_migration_failed values(@curTime, @logticketId, @errNum, @errMsg)
END CATCH

set @cur_row = @cur_row+1

IF @num_rows > 0
BEGIN
	IF @cur_row%(@num_rows/100) = 0
	BEGIN
		print str(@cur_row) + '   of' + str(@num_rows) + ' rows migrated'
	END
END

FETCH NEXT FROM mycursor INTO 
@logticketId, 
@logqueueId, 
@logprinterId, 
@logprinterId,
@logjobName,
@loguserName,
@loguserDomain,
@logjobSize,
@logpages,
@logpaper,
@logduplex, 
@logcolor ,
@logdateEvent,
@logdateCreated, 
@logdateSort ,
@logdateBegan,
@logdateFinished,
@logsentBytes,
@logsentPages,
@logclientId,
@logclientIp,
@logEventMajor,
@logEventMinor,
@logData,
@logText,
@logfprintQ ,
@logticketDriver,
@logticketModel,
@logLoggedColorPages,
@logLoggedBWPages,
@logpricePlan,
@logTicketPrice,
@logoriginatingIp,
@logDocumentTypeId,
@logclientBillingCode,
@DnId

END

CLOSE mycursor
DEALLOCATE mycursor

declare @failed int
select @failed = count(*) from tbl_migration_failed
if @failed > 0
begin
	print str(@failed) + ' tickets could not be migrated, check tbl_migration_failed'
end
else
begin
	print 'all tickets migrated'
end
