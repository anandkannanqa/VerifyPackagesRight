-- Conversion script Cirrato 2.0.0R16P6 - 2.0.0R16P7
-- V 1.2 2010-06-29
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R16P7'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue


print'Updating brands'
-- tbl_brand
go
create table tbl_brand_p7
(
brandId uniqueidentifier primary key clustered,
brandName nvarchar(256) not null default '',
brandComment nvarchar(1024) not null default ''
)
insert into tbl_brand_p7 (brandId, brandName) select brandId, brandName from tbl_brand 
go
sp_rename 'tbl_brand','tbl_brand_old'
go
sp_rename 'tbl_brand_p7','tbl_brand'
go

print'Updating brands done.'


print'Updating models'
-- tbl_model
create table tbl_model_p7
(
modelId uniqueidentifier primary key clustered,
modelBrandId uniqueidentifier,
modelName nvarchar(256) not null default '',
modelComment nvarchar(1024) not null default '',
modelVisible smallint not null default 1,
statusOctetSwapped smallint default 0,
CheckTonerOids SMALLINT NOT NULL DEFAULT 0,
FOREIGN KEY(modelBrandId) REFERENCES tbl_brand(brandId)
)
--insert into tbl_model_p7 (modelId, modelBrandId, modelname, modelVisible, statusOctetSwapped)
--select modelId, modelBrandId, modelname, modelVisible, statusOctetSwapped from tbl_model
insert into tbl_model_p7 (modelId, modelBrandId, modelname, modelVisible )
select modelId, modelBrandId, modelname, modelVisible from tbl_model

go
sp_rename 'tbl_model','tbl_model_old'
go
sp_rename 'tbl_model_p7','tbl_model'
go
print'Updating models done '


-- tbl_printer
print 'Updating printers'
create table tbl_printer_p7
(
printerId uniqueidentifier primary key,
printerName nvarchar(255) NOT NULL default '',
printerLocation nvarchar(255) NOT NULL default '',
printerComment  nvarchar(255) NOT NULL default '',
printerModel uniqueIdentifier,
printerIp  varchar(64) not null default '',
printerPort varchar(64) not null default '', 
printerNetPort smallint not null default 0,
modelId uniqueidentifier,
region bigint not null default 0,
physStatus smallint not null default 0,  
printStatus smallint not null default 0,  
deviceStatus smallint not null default 0,
adminStatus smallint not null default 0,
printerAdminComment nvarchar(255) not null default '',
localDriverCheck char not null default 0,
localConfigCheck char not null default 0,
printerTTL smallint not null default 0,
printerType char not null default 0,
printerNewStatus smallint default NULL,
snmpCheck char not null default 0,
printerCommunity nvarchar(64) not null default '',
printerSnmpIndex smallint not null default 0,
printerLastCheck datetime,
printerNextCheck datetime,
printerDisplayText nvarchar(100) not null default '',
printerMailMessage nvarchar(512) not null default '',
printerSnmpVersion smallint not null default 0,
printerProgramId varchar(64) not null default '',
printerChecking smallint not null default 0,
printerCheckInterval int not null default 0,
printerStatLastCheck datetime default getDate(),
printerStatNextCheck datetime default getDate(),
printerCounterProgramId varchar(64) not null default '',
printerHidden smallint not null default 0,
printerNumIp bigint,
statusOctetSwapped smallint default 0,
CheckTonerOids SMALLINT NOT NULL DEFAULT 0,
FOREIGN KEY(printerModel) REFERENCES tbl_model(modelId),
FOREIGN KEY(modelId) REFERENCES tbl_model(modelId)
);


--insert into tbl_printer_p7
--(printerId,
--printerName,
--printerLocation ,
--printerComment,
--printerModel,
--printerIp,
--printerPort, 
--printerNetPort,
--modelId,
--region,
--physStatus,  
--printStatus,  
--deviceStatus,
--adminStatus,
--printerAdminComment,
--localDriverCheck,
--localConfigCheck,
--printerTTL,
--printerType,
--printerNewStatus,
--snmpCheck,
--printerCommunity,
--printerSnmpIndex,
--printerLastCheck,
--printerNextCheck,
--printerDisplayText,
--printerMailMessage,
--printerSnmpVersion,
--printerProgramId,
--printerChecking,
--printerCheckInterval,
--printerStatLastCheck,
--printerStatNextCheck,
--printerCounterProgramId,
--printerHidden,
--printerNumIp,
--statusOctetSwapped)
--select 
--printerId,
--printerName,
--printerLocation ,
--printerComment,
--printerModel,
--printerIp,
--printerPort, 
--printerNetPort,
--modelId,
--region,
--physStatus,  
--printStatus,  
--deviceStatus,
--adminStatus,
--printerAdminComment,
--localDriverCheck,
--localConfigCheck,
--printerTTL,
--printerType,
--printerNewStatus,
--snmpCheck,
--printerCommunity,
--printerSnmpIndex,
--printerLastCheck,
--printerNextCheck,
--printerDisplayText,
--printerMailMessage,
--printerSnmpVersion,
--printerProgramId,
--printerChecking,
--printerCheckInterval,
--printerStatLastCheck,
--printerStatNextCheck,
--printerCounterProgramId,
--printerHidden,
--printerNumIp,
--statusOctetSwapped 
--from tbl_printer
insert into tbl_printer_p7
(printerId,
printerName,
printerLocation ,
printerComment,
printerModel,
printerIp,
printerPort, 
printerNetPort,
modelId,
region,
physStatus,  
printStatus,  
deviceStatus,
adminStatus,
printerAdminComment,
localDriverCheck,
localConfigCheck,
printerTTL,
printerType,
printerNewStatus,
snmpCheck,
printerCommunity,
printerSnmpIndex,
printerLastCheck,
printerNextCheck,
printerDisplayText,
printerMailMessage,
printerSnmpVersion,
printerProgramId,
printerChecking,
printerCheckInterval,
printerStatLastCheck,
printerStatNextCheck,
printerCounterProgramId,
printerHidden,
printerNumIp)
select 
printerId,
printerName,
printerLocation ,
printerComment,
printerModel,
printerIp,
printerPort, 
printerNetPort,
modelId,
region,
physStatus,  
printStatus,  
deviceStatus,
adminStatus,
printerAdminComment,
localDriverCheck,
localConfigCheck,
printerTTL,
printerType,
printerNewStatus,
snmpCheck,
printerCommunity,
printerSnmpIndex,
printerLastCheck,
printerNextCheck,
printerDisplayText,
printerMailMessage,
printerSnmpVersion,
printerProgramId,
printerChecking,
printerCheckInterval,
printerStatLastCheck,
printerStatNextCheck,
printerCounterProgramId,
printerHidden,
printerNumIp
from tbl_printer
go
sp_rename 'tbl_printer','tbl_printer_old'
go
sp_rename 'tbl_printer_p7','tbl_printer'
go
print 'Updating printers done'

print 'Updating regions'
go
alter table dbo.tbl_region add constraint PK_tbl_region_regionId primary key clustered (regionId)

go
alter table dbo.tbl_lregion add constraint PK_tbl_lregion_regionId primary key clustered (lregionId)
print 'Updating regions done.'


go
print 'Updating queues'
create table tbl_queue_p7
(
queueId uniqueidentifier primary key,
queueName nvarchar(255) not null default '',
queueModelId uniqueidentifier,
queueLocation nvarchar(255) not null default '',
queueComment nvarchar(255) not null default '',
queueRegion bigint not null default 0,
queueType smallint not null default 0,
queueStatus smallint not null default 0,
queueTTL smallint not null default 0,
queueAdminComment nvarchar(255) not null default '',
queueNewStatus smallint default NULL,
queueHidden smallint not null default 0,
FOREIGN KEY(queueModelId) REFERENCES tbl_model(modelId),
FOREIGN KEY(queueRegion) REFERENCES tbl_region(regionId)
);

-- Adjust any broken queues not to break foreign keys
update tbl_queue set queueModelId=(select top 1 modelId from tbl_model) where queueModelId = ''


insert into tbl_queue_p7
(
queueId ,
queueName ,
queueModelId ,
queueLocation ,
queueComment ,
queueRegion ,
queueType,
queueStatus,
queueTTL ,
queueAdminComment ,
queueNewStatus,
queueHidden)
select queueId ,
queueName ,
queueModelId ,
queueLocation ,
queueComment ,
queueRegion ,
queueType,
queueStatus,
queueTTL ,
queueAdminComment ,
queueNewStatus,
queueHidden from tbl_queue

go
sp_rename 'tbl_queue','tbl_queue_old'
go
sp_rename 'tbl_queue_p7','tbl_queue'
go

print 'Updating queues done'
go
print 'Updating follow print'
alter table dbo.tbl_fprint add constraint PK_tbl_fprint_fprintId primary key clustered (fprintId)
print 'Updating follow print done'
go

print 'Updating follow print map '
create table tbl_fprint_map_p7
(
fprintMapId uniqueidentifier primary key,
fprintMapIp varchar(65) not null default '',
fprintMapPrn varchar(65) not null default ''
);

insert into tbl_fprint_map_p7 (fprintMapId, fprintMapIp, fprintMapPrn)
select fprintMapId, fprintMapIp, fprintMapPrn from tbl_fprint_map 
where  fprintMapIp!='' and fprintmapPrn!=''

go
sp_rename 'tbl_fprint_map','tbl_fprint_map_old'
go
sp_rename 'tbl_fprint_map_p7','tbl_fprint_map'
print 'Updating follow print map done'
go


print 'Updating queue printer map'
create table tbl_queue_printer_map_p7
(
mapId uniqueidentifier primary key,
mapPhyPrinter uniqueidentifier not null,
mapQueue uniqueidentifier not null,
mapStatus smallint not null default 0,
FOREIGN KEY( mapPhyPrinter) REFERENCES tbl_printer(printerId),
FOREIGN KEY( mapQueue) REFERENCES tbl_queue(queueId)
)

insert into tbl_queue_printer_map_p7 (mapId, mapPhyPrinter, mapQueue, mapStatus)
select mapId, mapPhyPrinter, mapQueue, mapStatus from tbl_queue_printer_map
where mapQueue in (Select queueId from tbl_queue)
AND mapPhyPrinter in (select printerId from tbl_printer)

go
sp_rename 'tbl_queue_printer_map','tbl_queue_printer_map_old'
go
sp_rename 'tbl_queue_printer_map_p7','tbl_queue_printer_map'
go
print 'Updating queue printer map done'

go
print 'Updating tbl_os'
alter table dbo.tbl_os alter column osId varchar(10) not null
alter table dbo.tbl_os add constraint PK_tbl_osOsId primary key clustered (osId)
print 'Updating tbl_os done'
go

print 'Updating tbl_driver_file'

create table tbl_driver_file_p7
(
driverFileId uniqueidentifier primary key clustered,
driverFileLocation nvarchar(512) not null default '',
driverFileVersion nvarchar(512) not null default '',
driverFileComment nvarchar(1024) not null default '',
driverFileUploaded datetime,
driverFileUploadedUser nvarchar(64),
driverFileUploadedDomain nvarchar(64),
driverFileLanguage int not null default 0
)


insert into tbl_driver_file_p7
(
driverFileId ,
driverFileLocation,
driverFileVersion,
driverFileComment,
driverFileUploaded,
driverFileUploadedUser,
driverFileUploadedDomain ,
driverFileLanguage
)
select driverFileId ,
driverFileLocation,
driverFileVersion,
driverFileComment,
driverFileUploaded,
driverFileUploadedUser,
driverFileUploadedDomain ,
driverFileLanguage
from tbl_driver_file

go
sp_rename 'tbl_driver_file','tbl_driver_file_old'
go
sp_rename 'tbl_driver_file_p7','tbl_driver_file'



print 'Updating tbl_driver_file done'
go

print 'Updating tbl_driver_file_models'


create table tbl_driver_file_models_p7
(
driverFileId uniqueidentifier,
driverModelName nvarchar(256) not null default '',
driverModelBrand nvarchar(256) not null default '',
driverModelId uniqueidentifier
)

insert into tbl_driver_file_models_p7 (driverFileId ,
driverModelName,
driverModelBrand,
driverModelId)
select driverFileId ,
driverModelName,
driverModelBrand,
driverModelId from tbl_driver_file_models


go
sp_rename 'tbl_driver_file_models','tbl_driver_file_models_old'
go
sp_rename 'tbl_driver_file_models_p7','tbl_driver_file_models'


print 'Updating tbl_driver_file_models done'
go

print 'Updating driver map'
create table tbl_driver_map_p7
(
mapId uniqueidentifier primary key clustered,
mapDriverFileId uniqueidentifier not null,
mapModelId uniqueidentifier not null,
mapDeployed int not null default 0,
mapInstall int not null default 0,
mapOs int not null default 0,
mapOsId varchar(10) not null,
mapLocale nvarchar(255) not null default '',
mapSpecial smallint not null default 0,
mapIm smallint not null default 0,
mapQ smallint not null default 0,
FOREIGN KEY( mapDriverFileId) REFERENCES tbl_driver_file(driverFileId),
FOREIGN KEY( mapModelId) REFERENCES tbl_model(modelId),
FOREIGN KEY( mapOsId) REFERENCES tbl_os(osId),
)

insert into tbl_driver_map_p7
(mapId ,
mapDriverFileId ,
mapModelId ,
mapDeployed ,
mapInstall ,
mapOs ,
mapOsId,
mapLocale,
mapSpecial ,
mapIm ,
mapQ )
select 
mapId ,
mapDriverFileId ,
mapModelId ,
mapDeployed ,
mapInstall ,
mapOs ,
mapOsId,
mapLocale,
mapSpecial ,
mapIm ,
mapQ from tbl_driver_map

go
sp_rename 'tbl_driver_map','tbl_driver_map_old'
go
sp_rename 'tbl_driver_map_p7','tbl_driver_map'

print 'Updating driver map done'
go
print 'Updating configfile'


create table tbl_configfile_p7
(
	configfile_id uniqueidentifier primary key clustered,
	configfile_model varchar(128) not null default '',
	configfile_date datetime,
	configfile_creator nvarchar(256) not null default '',
	configfile_domain nvarchar(256) not null default '',
	configfile_arch int not null default 0,
	configfile_majorOs int not null default 0,
	configfile_minorOs int not null default 0,
	configfile_Locale nvarchar(256) not null default '',
	configfile_majorversion smallint not null default 0,
	configfile_minorversion smallint not null default 0,
	configfile_comment varchar(256) not null default '',
	configfile_queueName nvarchar(256) not null default '',
	configfile_queueId varchar(256) not null default '',
	configfile_configdata image
)

insert into tbl_configfile_p7
(
	configfile_id ,
	configfile_model,
	configfile_date,
	configfile_creator,
	configfile_domain,
	configfile_arch,
	configfile_majorOs,
	configfile_minorOs ,
	configfile_Locale ,
	configfile_majorversion ,
	configfile_minorversion,
	configfile_comment,
	configfile_queueName ,
	configfile_queueId,
	configfile_configdata
)
select 
	configfile_id ,
	configfile_model,
	configfile_date,
	configfile_creator,
	configfile_domain,
	configfile_arch,
	configfile_majorOs,
	configfile_minorOs ,
	configfile_Locale ,
	configfile_majorversion ,
	configfile_minorversion,
	configfile_comment,
	configfile_queueName ,
	configfile_queueId,
	configfile_configdata
from tbl_configfile

go
sp_rename 'tbl_configfile','tbl_configfile_old'
go
sp_rename 'tbl_configfile_p7','tbl_configfile'


create table tbl_configfile_map_p7
(
	cmap_id uniqueidentifier primary key clustered,
	cmap_cid uniqueidentifier,
	cmap_mid uniqueidentifier,
	cmap_did uniqueidentifier,
	FOREIGN KEY(cmap_cid) REFERENCES tbl_configfile(configfile_id),
	FOREIGN KEY(cmap_mid) REFERENCES tbl_driver_map(mapId),
	FOREIGN KEY(cmap_did) REFERENCES tbl_queue(queueId)
)

insert into tbl_configfile_map_p7 (cmap_id, cmap_cid, cmap_mid, cmap_did) 
select cmap_id, cmap_cid, cmap_mid, cmap_did from tbl_configfile_map
where cmap_cid in (select configfile_id from tbl_configfile)
AND cmap_mid in (select mapId from tbl_driver_map)
AND cmap_did in (select queueId from tbl_queue)

go
sp_rename 'tbl_configfile_map','tbl_configfile_map_old'
go
sp_rename 'tbl_configfile_map_p7','tbl_configfile_map'
print 'Updating configfile done'
go


print 'Renaming ticket log'
go
sp_rename 'tbl_ticket_log','tbl_ticket_log_oldP7'
go

create table tbl_ticket_log
(
logticketId uniqueIdentifier,
logqueueId uniqueIdentifier,
logprinterId uniqueIdentifier,
logjobName nvarchar(255) NOT NULL default '',
loguserName nvarchar(255) NOT NULL default '',
loguserDomain nvarchar(255) NOT NULL default '',
logjobSize bigint ,
logpages int ,
logpaper int ,
logduplex smallint,  
logcolor smallint ,
logdateEvent datetime,  
logdateCreated datetime,
logdateSort datetime,
logdateBegan datetime,
logdateFinished datetime,
logsentBytes int,
logsentPages smallint,
logclientId varchar(64) ,
logclientIp varchar(64),
logEventMajor smallint ,
logEventMinor smallint ,
logData smallint ,
logText nvarchar(512),
logfprintQ uniqueIdentifier,
logticketDriver uniqueIdentifier,
logticketModel uniqueIdentifier,
logLoggedColorPages smallint,
logLoggedBWPages smallint,
logpricePlan uniqueIdentifier,
logTicketPrice float,
logoriginatingIp varchar(64),
logDocumentTypeId bigint,
logclientBillingCode nvarchar(255),
DnId int NULL REFERENCES tbl_dn (DnId)
);

print 'Renaming install log'
go
sp_rename 'tbl_install_log','tbl_install_log_oldP7'

go

create table tbl_install_log
(
installLogId uniqueIdentifier,
installClientIp varchar(62) not null default '',
installName nvarchar(64) not null default '',
installUUID uniqueidentifier,
installLogBegin datetime,
installLogEnd datetime,
installLogDriverFileId uniqueidentifier,
installLogCurrentDriverId uniqueidentifier,
installLogConfigId uniqueidentifier,
installLogQueueId uniqueidentifier,
installLogModelId uniqueidentifier,
installLogOs int not null default 0,
installLogLocale nvarchar(255) not null default '',
installLogSpecial smallint not null default 0,
installLogIm smallint not null default 0,
installLogQ smallint not null default 0,
installLogMajorOs int not null default 0,
installLogMinorOs int not null default 0,
installLogMajorSp smallint not null default 0,
installLogMinorSp smallint not null default 0,
installLogArch smallint not null default 0,
installLogResult smallint not null default 0
)

go
print 'Changing migration plans...'
alter table tbl_migration_plan alter column mig_id uniqueidentifier not null
alter table tbl_migration_plan add constraint PL_tbl_migration_planMigId primary key clustered (mig_id)

alter table tbl_migration_transaction alter column mtr_id uniqueidentifier not null
alter table tbl_migration_transaction add constraint PL_tbl__transactionmtr_id primary key clustered (mtr_id)

alter table tbl_migration_transaction_log alter column mtrl_id uniqueidentifier not null
alter table tbl_migration_transaction_log add constraint PL_tbl__transaction_logmtrl_id primary key clustered (mtrl_id)


print 'Changing migration plans done.'
go


print 'Changing rule affected'
create table tbl_cirrato_rule_affected_p7
(
	rafId uniqueIdentifier primary key clustered,
	rafType smallint not null,
	rafName nvarchar(128) not null,
	rafEquals smallint not null
)

insert into tbl_cirrato_rule_affected_p7 (rafId, rafType, rafName, rafEquals)
select rafId, rafType, rafName, rafEquals from tbl_cirrato_rule_affected
go
sp_rename 'tbl_cirrato_rule_affected','tbl_cirrato_rule_affected_old'
go
sp_rename 'tbl_cirrato_rule_affected_p7','tbl_cirrato_rule_affected'
print 'Changing rule affected done'

go


print 'Changing rule'
create table tbl_cirrato_rule_p7
(
	rId uniqueIdentifier primary key clustered,
	rType smallint not null,
	rConnectedId uniqueIdentifier,
	rRuleId uniqueIdentifier,
	rAffectedId uniqueIdentifier,
	rGroupId uniqueIdentifier,
	rName nvarchar(64) not null default '',
	rComment nvarchar(255) not null default '',
	rRegion bigint,
	FOREIGN KEY(rAffectedId) REFERENCES tbl_cirrato_rule_affected(rafId)
)

insert into tbl_cirrato_rule_p7 ( rId, rType, rConnectedId, rRuleId, rAffectedId, rGroupId, rName, rComment, rRegion)
select
rId, 
rType, 
CASE WHEN LEN(rConnectedId) = 0 THEN NULL ELSE rConnectedId END,
CASE WHEN LEN(rRuleId) = 0 THEN NULL ELSE rRuleId END,
CASE WHEN LEN(rAffectedId) = 0 THEN NULL ELSE rAffectedId END,
CASE WHEN LEN(rGroupId) = 0 THEN NULL ELSE rGroupId END, 
rName, 
rComment, 
rRegion
from tbl_cirrato_rule
go
sp_rename 'tbl_cirrato_rule','tbl_cirrato_rule_old'
go
sp_rename 'tbl_cirrato_rule_p7','tbl_cirrato_rule'
print 'Changing rule done'
go


print 'Changing price plans'
alter table tbl_cirrato_priceplan alter column cppId uniqueidentifier not null 
alter table tbl_cirrato_priceplan add constraint PK_tbl_cirrato_priceplan_cppId primary key clustered (cppId)


alter table tbl_cirrato_priceplan_row alter column cprId uniqueidentifier 
alter table tbl_cirrato_priceplan_row alter column cprPlanid uniqueidentifier 

-- Remove any old data
delete from tbl_cirrato_priceplan_row where cprPlanId not in (select cppId from tbl_cirrato_priceplan)

alter table  tbl_cirrato_priceplan_row  add constraint FK_tbl_cirrato_priceplan_rowcppid
	FOREIGN KEY(cprPlanid)
		REFERENCES tbl_cirrato_priceplan(cppId)	

print 'Changing price plans done'
go


print 'Changing sessions'
alter table tbl_cirrato_client_session add constraint PK_tbl_cirrato_client_session_csessionId primary key (csessionId)
print 'Changing sessions done.'

go
print 'Changing client message'
alter table tbl_cirrato_client_message add constraint PK_tbl_cirrato_client_message_cmessageId primary key (cmessageId)
print 'Changing client message done'
go

print 'Changing counter program'
alter table tbl_counter_program add constraint PK_tbl_counter_programcounterprogId primary key clustered (counterprogId)

alter table  tbl_counter_program_map  add constraint FK_tbl_counter_program_mapcounterpmapProgramId
	FOREIGN KEY(counterpmapProgramId)
		REFERENCES tbl_counter_program(counterprogId)

print 'Changing counter program done'
go

print 'Changing rule message text'
create table tbl_cirrato_rule_message_text_p7
(
	ruleMessageTId bigint identity not null,
	ruleMessageName nvarchar(255),
	ruleMessageTUid uniqueIdentifier primary key,
	ruleMessageTLocale nvarchar(32),
	ruleMessageTCaption nvarchar(128) not null,
	ruleMessageTText nvarchar(512) not null,
	ruleMessageTIcon smallint not null,
	ruleMessageType smallint not null default 1
);

set IDENTITY_INSERT tbl_cirrato_rule_message_text_p7 on
insert into tbl_cirrato_rule_message_text_p7 
(ruleMessageTId ,
	ruleMessageName,
	ruleMessageTUid ,
	ruleMessageTLocale,
	ruleMessageTCaption,
	ruleMessageTText,
	ruleMessageTIcon,
	ruleMessageType )
select ruleMessageTId ,
	ruleMessageName,
	ruleMessageTUid ,
	ruleMessageTLocale,
	ruleMessageTCaption,
	ruleMessageTText,
	ruleMessageTIcon,
	ruleMessageType from tbl_cirrato_rule_message_text
go
set IDENTITY_INSERT tbl_cirrato_rule_message_text_p7 off

go
sp_rename 'tbl_cirrato_rule_message_text','tbl_cirrato_rule_message_text_old'
go
sp_rename 'tbl_cirrato_rule_message_text_p7','tbl_cirrato_rule_message_text'
print 'Changing rule message text done'
go


print 'Changing rule limit'
create table tbl_cirrato_rule_limit_p7
(
	rlId uniqueIdentifier primary key clustered,
	rlPrio smallint not null default 0,
	rlName nvarchar(128) not null,
	rlComment nvarchar(256),
	rlPaperType smallint,
	rlColour smallint,
	rlDuplex smallint,
	rlPages smallint,
	rlAction smallint ,
	rlMaxPrice float,
	rlMessageUid uniqueIdentifier,
	rlMoveUid uniqueIdentifier,
	rlEnforce smallint not null default 0,
	rlDocName nvarchar(255),
	FOREIGN KEY(rlMessageUid) REFERENCES tbl_cirrato_rule_message_text(ruleMessageTUid),
	FOREIGN KEY(rlMoveUid) REFERENCES tbl_queue(queueId)
);


insert into tbl_cirrato_rule_limit_p7
(	rlId ,
	rlPrio ,
	rlName ,
	rlComment ,
	rlPaperType ,
	rlColour ,
	rlDuplex ,
	rlPages ,
	rlAction  ,
	rlMaxPrice ,
	rlMessageUid ,
	rlMoveUid ,
	rlEnforce ,
	rlDocName
)
select 
	rlId ,
	rlPrio ,
	rlName ,
	rlComment ,
	rlPaperType ,
	rlColour ,
	rlDuplex ,
	rlPages ,
	rlAction  ,
	rlMaxPrice ,
	CASE WHEN LEN(rlMessageUid) = 0 THEN NULL ELSE rlMessageUid END, 
	CASE WHEN LEN(rlMoveUid) = 0 THEN NULL ELSE rlMoveUid END, 
	rlEnforce ,
	rlDocName
from tbl_cirrato_rule_limit

go
sp_rename 'tbl_cirrato_rule_limit','tbl_cirrato_rule_limit_old'
go
sp_rename 'tbl_cirrato_rule_limit_p7','tbl_cirrato_rule_limit'
print 'Changing rule limit done.'
go


print 'Changing model connections'
create table tbl_model_connection_p7
(
modc_id uniqueIdentifier primary key,
modc_modelid uniqueIdentifier,
modc_connmodelid uniqueIdentifier,
FOREIGN KEY(modc_modelid) REFERENCES tbl_model(modelId),
FOREIGN KEY(modc_connmodelid) REFERENCES tbl_model(modelId)	
);

insert into tbl_model_connection_p7 (modc_id, modc_modelId, modc_connmodelId)
select modc_id, modc_modelId, modc_connmodelId from tbl_model_connection
go
sp_rename 'tbl_model_connection','tbl_model_connection_old'
go
sp_rename 'tbl_model_connection_p7','tbl_model_connection'
go
print 'Changing model connections done'

go

print 'Updating CPT'
drop table tbl_cirrato_cpt_session

create table tbl_cirrato_cpt_session
(
	cpt_id uniqueIdentifier primary key,
	cpt_ip varchar(64) not null,
	cpt_printerId uniqueIdentifier,
	cpt_user nvarchar(256) not null,
	cpt_domain nvarchar(256) not null,
	cpt_fullName nvarchar(510),
	cpt_pricePlan uniqueIdentifier,
	cpt_dateLogin datetime default getDate(),
	cpt_lastSeen datetime default getDate(),
	cpt_authType smallint,
	cpt_sessionTimeout smallint,
	cpt_wid varchar(64) not null default '',
	cpt_jobamount float,
	cpt_logoutDate datetime,
	FOREIGN KEY(cpt_printerId) REFERENCES tbl_printer(printerId),
	FOREIGN KEY(cpt_priceplan) REFERENCES tbl_cirrato_priceplan(cppId)
)

go
sp_rename 'tbl_cirrato_cpt_session_log','tbl_cirrato_cpt_session_log_oldp7'

create table tbl_cirrato_cpt_session_log
(
	cptl_id uniqueidentifier,
	cptl_ts datetime default getDate(),
	cptl_ip varchar(64) not null,
	cptl_printerId uniqueidentifier,
	cptl_user nvarchar(510) not null,
	cptl_domain nvarchar(510) not null,
	cptl_fullName nvarchar(510),
	cptl_pricePlan uniqueidentifier,
	cptl_authType smallint,
	cptl_authId varchar(512),
	cptl_authSubType smallint,
	cptl_wid varchar(64) not null default ''
)

go
sp_rename 'tbl_cirrato_cpt_session_log_row','tbl_cirrato_cpt_session_log_row_oldp7'
go
create table tbl_cirrato_cpt_session_log_row
(
	cptlr_id uniqueidentifier,
	cptlr_ts datetime default getDate(),
	cptlr_event smallint not null,
	cptlr_eventData smallint,
	unique(cptlr_id,cptlr_ts)
)

print 'Done changing CPT'
go
print 'Changing print service'

IF OBJECT_ID('tbl_cirrato_printservice') IS NOT NULL
drop table tbl_cirrato_printservice

IF OBJECT_ID('tbl_cirrato_printservice_target') IS NOT NULL
drop table tbl_cirrato_printservice_target

create table tbl_cirrato_printservice_target
(
targetId uniqueIdentifier PRIMARY KEY NOT NULL,
targetRegion bigint,
targetName varchar(50),
targetComment varchar(128),
targetIp varchar(60),
targetPort varchar(60),
targetMethod smallint, -- 0 - same file - in to directory -- 1 - split files in to directory ( - 2 same file in to tcp port)
targetDirectory varchar(128)
)

create table tbl_cirrato_printservice
(
ticketId uniqueidentifier,
jobTarget uniqueIdentifier REFERENCES tbl_cirrato_printservice_target(targetId),
jobData nvarchar(max)
)

print 'Done changing print service'

go
print 'Changing tbl_ticket'
drop table tbl_ticket

create table tbl_ticket
(
ticketId uniqueidentifier primary key,
queueId uniqueidentifier,
printerId uniqueidentifier,
jobName nvarchar(255) NOT NULL default '',
userName nvarchar(255) NOT NULL default '',
userDomain nvarchar(255) NOT NULL default '',
jobSize bigint not null default 0,
pages int not null default 0,
paper int not null default 0,
duplex smallint not null default 0,  
color smallint not null default 0,  
ticketStatus  smallint not null default 0,  
ticketAdminStatus smallint not null default 0,  
dateCreated datetime,
dateSort datetime,
dateBegan datetime,
heartbeat datetime,
sentBytes int not null default 0,
sentPages smallint not null default 0,
clientId varchar(64) not null default '',
clientIp varchar(64) not null default '',
fprintDate dateTime default NULL,
fprintQ uniqueidentifier,
ticketDriver uniqueidentifier,
ticketModel uniqueidentifier,
ticketNewStatus smallint default NULL,
tsId bigint,
tsaLUIDlow bigint,
tsaLUIDhigh bigint,
bootTime varchar(64),
simpleClient smallint not null default 0,
ticketVDMS int identity not null,
loggedColorPages smallint not null default 0,
loggedBWPages smallint not null default 0,
pricePlan uniqueIdentifier,
ticketPrice float,
originatingIp varchar(64) not null default '',
ticketRuleStatus smallint not null default 0,
documentTypeId bigint not null default 0,
clientBillingCode nvarchar(255),
clientBillingCodePreset nvarchar(255),
retryTimes smallint,
authIp varchar(64),
numCopies smallint,
deleteAfterPrint smallint default 1,
snmpHeartBeat dateTime,
releaseTime dateTime,
networkJob smallint not null default 1,
cptSession varchar(64),
DnId int NULL REFERENCES tbl_dn (DnId),
FOREIGN KEY(printerId) REFERENCES tbl_printer(printerId),
FOREIGN KEY(queueId) REFERENCES tbl_queue(queueId),
FOREIGN KEY(pricePlan) REFERENCES tbl_cirrato_priceplan(cppid)
);

drop table tbl_ticket_feature

create table tbl_ticket_feature
(
	ticketFeatureTime datetime default GetDate(),
	ticketFeatureTicket uniqueidentifier,
	ticketFeatureFeature smallint not null,
	ticketFeatureData1 varchar(64),
	ticketFeatureDataInt1 int,
	ticketFeatureData2 varchar(64),
	ticketFeatureDataInt2 int,
	FOREIGN KEY(ticketFeatureTicket) REFERENCES tbl_ticket(ticketId)
)

print 'Done changing tbl_ticket'


IF OBJECT_ID('tbl_ticket_log_trans') IS NULL
select top 1 * into tbl_ticket_log_trans from tbl_ticket_log

truncate table tbl_ticket_log_trans


go
drop table tbl_cirrato_wallet_transaction

create table tbl_cirrato_wallet_transaction
(
	wTransactionUser nvarchar(128) not null,
	wTransactionDomain nvarchar(128) not null,
	wTransactionId varchar(64) not null,
	wTransactionTicket uniqueIdentifier,
	wTransactionTime datetime not null default getDate(),
	wTransactionAmount float not null default 0
	FOREIGN KEY(wTransactionTicket) REFERENCES tbl_ticket(ticketId) ON DELETE CASCADE
)

drop table tbl_event_status_open

create table tbl_event_status_open
(
statopenId		varchar(64) not null default '',
statopenPrinterId	uniqueidentifier,
statopenPhysStatus	smallint not null default 0,
statopenDisplayText	nvarchar(100) not null default '',
statopenTotalPagesAtOpen int not null default 0,
statopenFirstDetected	datetime,
statopenLastDetected	datetime,
FOREIGN KEY(statopenPrinterId) REFERENCES tbl_printer(printerId)
)
