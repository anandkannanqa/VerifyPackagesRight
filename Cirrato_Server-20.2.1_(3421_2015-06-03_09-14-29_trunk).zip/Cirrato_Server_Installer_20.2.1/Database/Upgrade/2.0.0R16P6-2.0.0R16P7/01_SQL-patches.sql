-- Upgrade 2.0.0R16P6 - 2.0.0R16P7
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R16P6'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R16P7', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	--TI_DELETED_AUTOMATICALLY,
	if(@minor=25)
		RETURN 'Automatically deleted'

	--TI_USER_CANCELLED_AUTHENTICATION_DELETE
	if(@minor=26)
		RETURN 'Deleted - User cancel authentication'


	--TI_AUTHENTICATION_ERROR
	if(@minor=27)
		RETURN 'Deleted - Authentication error on client'


	--TI_DELETED_AUTOMATICALLY_NO_CLIENT_SESSION
	if(@minor=28)
		RETURN 'Deleted - No client session on client'


	--TI_RULESET_DELETE,
	if(@minor=29)
		RETURN 'Deleted - By ruleset'

	--TI_RULESET_MOVE,
	if(@minor=30)
		RETURN 'Moved - by ruleset'

	--TI_RULESET_PAUSE
	if(@minor=31)
		RETURN 'Paused - by ruleset'

	-- TI_DELETED_CREATED,
	if(@minor=32)
		RETURN 'Deleted - created job'


	-- TI_DELETED_HANDOVER_OVERDUE,
	if(@minor=33)
		RETURN 'Deleted - handover overdue'

	-- TI_DELETED_AUTOMATICALLY_NO_CONTACT_WITH_CLIENT

	if(@minor=34)
		RETURN 'Deleted - no contact with client during authentication'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_CB_SET
	if(@minor=36)
		RETURN 'Client billing code set'

	-- TI_CB_CANCEL_PRESS_DELETE
	if(@minor=37)
		RETURN 'Deleted - Client billing cancel pressed'

	if(@minor=38)
		RETURN 'Deleted - Wrong client version'

	--TI_MANUALLY_MOVED,
	if(@minor=39)
		RETURN 'Moved - manually'

	--TI_AUTOMATICALLY_MOVED
	if(@minor=40)
		RETURN 'Moved - automatically'

--	TI_PAGES_RESET,
	if(@minor=41)
		RETURN 'Pages reset from 0 to 1 (Driver error)'

	-- TI_DELETED_QUEUE,
	if(@minor=42)
		RETURN 'Deleted - Queue deleted'

	-- TI_DELETED_QUEUE,
	if(@minor=43)
		RETURN 'Deleted - Queue Stopped'

	-- TI_DELETED_WRONG_DRIVER,
	if(@minor=44)
		RETURN 'Deleted - Wrong driver'

--	TI_DELETED_NO_QUEUE
	if(@minor=45)
		RETURN 'Deleted - No queue with UUID'

--
	if(@minor=46)
		RETURN 'Changed price plan'

--	TI_MULTIPLE_PRINT,
	if(@minor=47)
		RETURN 'Multiple print job'

--	TI_CPT_RELEASE_JOB
	if(@minor=48)
		RETURN 'CPT Release job'

--	TI_VDMS_RELEASE_JOB
	if(@minor=49)
		RETURN 'VDMS Release job'

-- TI_FPRINT_RELEASE_JOB
	if(@minor=50)
		RETURN 'Fprint Release job'

--TI_VDMS_RECORD_JOB_ACTION,

	if(@minor=51)
		RETURN 'VDMS Record Job'

--	TI_CPT_RELEASE_JOB_FAIL,

	if(@minor=52)
		RETURN 'CPT Release job Fail'

-- TI_PRINTSERVICE_ORDER,
	if(@minor=53)
		RETURN 'Print service order'


	--TI_PRINTSERVICE_ORDER_FAIL,
	if(@minor=54)
		RETURN 'Print service order fail'


--	TI_PRINTSERVICE_ORDER_COMPLETE,
	if(@minor=55)
		RETURN 'Print service order complete'


	--TI_PRINTSERVICE_ORDER_COMPLETE_FAIL,
	if(@minor=56)
		RETURN 'Print service order complete fail'

	--TI_VDMS_RECORD_JOB_TRANSACTION,

	if(@minor=57)
		RETURN 'VDMS Record Job Transaction'

	--TI_SET_PAPERSIZE,
	if(@minor=58)
		RETURN 'Set Papersize from SNMP scan'

	--TI_NO_TICKET_FOUND

	if(@minor=59)
		RETURN 'No ticket found'

	if(@minor=60)
		RETURN 'User message sent'

	RETURN @minor
END
go

--alter table tbl_model add statusOctetSwapped smallint default 0
--ALTER TABLE tbl_model ADD CheckTonerOids SMALLINT NOT NULL DEFAULT 0
--alter table tbl_printer add statusOctetSwapped smallint default 0
--ALTER TABLE tbl_printer ADD CheckTonerOids SMALLINT NOT NULL DEFAULT 0IF OBJECT_ID('tbl_toner_log') IS NULL
BEGIN
	CREATE TABLE tbl_toner_log (
		tl_Id			VARCHAR(64) PRIMARY KEY NOT NULL DEFAULT '',
		tl_PrinterId	VARCHAR(64) NOT NULL DEFAULT '',
		tl_GroupId		VARCHAR(64) NOT NULL DEFAULT '',
		tl_Color		VARCHAR(64) NOT NULL DEFAULT '',
		tl_Level		INTEGER NOT NULL DEFAULT 0,
		tl_Created		DATETIME NOT NULL
	)
END

IF OBJECT_ID('tbl_custom_oid') IS NULL
BEGIN
	CREATE TABLE tbl_custom_oid (
		coidId VARCHAR(64) PRIMARY KEY NOT NULL DEFAULT '',
		coidKey VARCHAR(64) NOT NULL DEFAULT '',
		coidModelId VARCHAR(64) NOT NULL DEFAULT '',
		coidOid VARCHAR(1024) NOT NULL DEFAULT '',
		coidCreated DATETIME NOT NULL	
	)
END