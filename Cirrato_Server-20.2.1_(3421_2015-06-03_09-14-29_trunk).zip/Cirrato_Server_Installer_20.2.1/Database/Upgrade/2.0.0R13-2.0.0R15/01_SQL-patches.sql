-- Upgrade 2.0.0R13 - 2.0.0R15
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

if (db_name() = 'master' 
 OR db_name() = 'msdb'
 OR db_name() = 'model'
 OR db_name() = 'tempdb'
 OR db_name() = 'ReportServer'
 OR db_name() = 'ReportServerTempDB')
RAISERROR('Please ensure you run this script in the Cirrato database', 20, 1) with log

GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R13'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R15', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	--TI_DELETED_AUTOMATICALLY,
	if(@minor=25)
		RETURN 'Automatically deleted'

	--TI_USER_CANCELLED_AUTHENTICATION_DELETE
	if(@minor=26)
		RETURN 'Deleted - User cancel authentication'


	--TI_AUTHENTICATION_ERROR
	if(@minor=27)
		RETURN 'Deleted - Authentication error on client'


	--TI_DELETED_AUTOMATICALLY_NO_CLIENT_SESSION
	if(@minor=28)
		RETURN 'Deleted - No client session on client'


	--TI_RULESET_DELETE,
	if(@minor=29)
		RETURN 'Deleted - By ruleset'

	--TI_RULESET_MOVE,
	if(@minor=30)
		RETURN 'Moved - by ruleset'

	--TI_RULESET_PAUSE
	if(@minor=31)
		RETURN 'Paused - by ruleset'

	-- TI_DELETED_CREATED,
	if(@minor=32)
		RETURN 'Deleted - created job'


	-- TI_DELETED_HANDOVER_OVERDUE,
	if(@minor=33)
		RETURN 'Deleted - handover overdue'

	-- TI_DELETED_AUTOMATICALLY_NO_CONTACT_WITH_CLIENT

	if(@minor=34)
		RETURN 'Deleted - no contact with client during authentication'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_NO_CONTACT_WITH_CLIENT_DURING_TIME_ESTIMATE
	if(@minor=35)
		RETURN 'No contact with client during send time estimate'

	-- TI_CB_SET
	if(@minor=36)
		RETURN 'Client billing code set'

	-- TI_CB_CANCEL_PRESS_DELETE
	if(@minor=37)
		RETURN 'Deleted - Client billing cancel pressed'

	if(@minor=38)
		RETURN 'Deleted - Wrong client version'

	--TI_MANUALLY_MOVED,
	if(@minor=39)
		RETURN 'Moved - manually'

	--TI_AUTOMATICALLY_MOVED
	if(@minor=40)
		RETURN 'Moved - automatically'


	RETURN @minor
END


go

alter table tbl_cirrato_priceplan_row add cprTypeSubtype smallint

go

--drop table tbl_snmp_counter
create table tbl_snmp_counter
(
	sc_ticketId varchar(64) not null,
	sc_printerId varchar(64) not null,
	sc_timeStart datetime default getDate(),
	sc_bwCounter bigint,
	sc_coCounter bigint,
	sc_duCounter bigint,
	sc_dupCounter bigint
);

--drop table tbl_snmp_counter_log
create table tbl_snmp_counter_log
(
	scl_ticketId varchar(64) not null,
	scl_printerId varchar(64) not null,
	scl_event smallint,
	scl_eventTs datetime default getDate(),
	scl_timeStart datetime,
	scl_timeEnd datetime,
	scl_bwCounter bigint,
	scl_coCounter bigint,
	scl_duCounter bigint,
	scl_dupCounter bigint
);


create table tbl_migrate_run_schema
(
	mir_id varchar(64) not null,
	mir_name nvarchar(128) not null,
	mir_comment nvarchar(256) not null default '',
	mir_active smallint not null default 0,
	mir_type smallint not null default 0,
	mir_startip nvarchar(20) not null,
	mir_endip nvarchar(20) not null,
	mir_numipstart bigint not null,
	mir_numipend bigint not null,
	mir_priority smallint not null default 0,
	mir_creator nvarchar(128) not null,
	mir_domain nvarchar(128) not null
);

go


insert into tbl_client_billing (cb_parentid, cb_type, cb_code, cb_active, cb_name, cb_creator_name, cb_creator_domain)
values (0,0,'',1,'Default','System','INITIAL');

go

delete from tbl_os where osId='W2K364';
delete from tbl_os where osId='WV64';

insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch) values ('W2K364', 'Windows 2003 Server x64', 5,2,0,0,9);
insert into tbl_os(osId, osName, osMajor, osMinor, osSpMajor, osSpMinor, osArch) values ('WV64', 'Windows Vista x64',6,0,0,0,9);


go
