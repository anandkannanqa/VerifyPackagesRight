-- Grant scripts for Cirrato
-- Replace cirrato with the username used for cirrato applications to access database (default: cirrato)


grant execute on dbo.verboseTicketLog to cirrato;
GRANT execute on sp_wallet_search to cirrato
GRANT execute on sp_vdms_search to cirrato
GRANT execute on sp_ticket_search to cirrato
GRANT execute on sp_ticket_move to cirrato
GRANT execute on sp_ticket_history to cirrato
GRANT execute on sp_ticket_action_ins to cirrato
GRANT execute on sp_tickets_get_related_queues to cirrato
GRANT execute on sp_region_get_path_by_verbose_path to cirrato
GRANT execute on sp_region_get_path to cirrato
GRANT execute on sp_region_get_children_web to cirrato
GRANT execute on sp_region_get_children to cirrato
GRANT execute on sp_queue_search to cirrato
GRANT execute on sp_queue_install to cirrato
GRANT execute on sp_queue_get_tickets to cirrato
GRANT execute on sp_queue_get_related_queues_by_queue to cirrato
GRANT execute on sp_queue_get_related_queues_by_printer to cirrato
GRANT execute on sp_queue_get_name to cirrato
GRANT execute on sp_printer_get_tickets to cirrato
GRANT execute on sp_localprinter_get_tickets to cirrato
GRANT execute on sp_get_tickets_sub to cirrato
GRANT execute on sp_client_session_search to cirrato
GRANT execute on sp_client_billing_upd to cirrato
GRANT execute on sp_client_billing_ins to cirrato
GRANT execute on sp_client_billing_del to cirrato
GRANT execute on sp_client_billing_chk to cirrato
GRANT execute on verboseWalletLogEvent to cirrato
GRANT execute on verboseTicketNewStatus to cirrato
GRANT execute on verbosePrinterPhysicalStatus to cirrato
GRANT execute on verbosePrinterNewStatus to cirrato
GRANT execute on fn_region_get_path to cirrato
GRANT execute on verboseTicketLog to cirrato
GRANT execute on verboseTicketAdminStatus to cirrato
GRANT execute on verboseRuleStatus to cirrato
GRANT execute on verboseTicketStatus to cirrato
GRANT execute on GetAbsoluteLocalRegion to cirrato
GRANT execute on GetAbsoluteRegion to cirrato
GRANT execute  on dbo.GetAbsoluteLocalRegion to cirrato
GRANT execute  on dbo.GetAbsoluteRegion to cirrato
grant execute on dbo.verboseTicketAdminStatus to cirrato;
grant execute on dbo.verboseTicketStatus to cirrato;
grant execute on dbo.verboseRuleStatus to cirrato;
