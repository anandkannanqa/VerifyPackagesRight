-- Upgrade 2.0.0R9 - 2.0.0R10
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R9'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R10', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	--TI_DELETED_AUTOMATICALLY,
	if(@minor=25)
		RETURN 'Automatically deleted'

	--TI_USER_CANCELLED_AUTHENTICATION_DELETE
	if(@minor=26)
		RETURN 'Deleted - User cancel authentication'


	--TI_AUTHENTICATION_ERROR
	if(@minor=27)
		RETURN 'Deleted - Authentication error on client'


	--TI_DELETED_AUTOMATICALLY_NO_CLIENT_SESSION
	if(@minor=28)
		RETURN 'Deleted - No client session on client'


	--TI_RULESET_DELETE,
	if(@minor=29)
		RETURN 'Deleted - By ruleset'

	--TI_RULESET_MOVE,
	if(@minor=30)
		RETURN 'Moved - by ruleset'

	--TI_RULESET_PAUSE
	if(@minor=31)
		RETURN 'Paused - by ruleset'

	-- TI_DELETED_CREATED,
	if(@minor=32)
		RETURN 'Deleted - created job'


	-- TI_DELETED_HANDOVER_OVERDUE,
	if(@minor=33)
		RETURN 'Deleted - handover overdue'

	-- TI_DELETED_AUTOMATICALLY_NO_CONTACT_WITH_CLIENT

	if(@minor=34)
		RETURN 'Deleted - no contact with client during authentication'



	RETURN @minor
END

go


create table tbl_cirrato_client_session_log
(
	logcsessionId bigint identity not null,
	logcsessionts datetime default getDate(),
	logcsessionEvent smallint not null default 0,
	logcsessionText varchar(256),
	logcsessiontoken varchar(128) ,
	logcsessionIp varchar(64) ,
	logcsessionAuthUser nvarchar(255),
	logcsessionAuthDomain nvarchar(255),
	logcsessionUser nvarchar(255),
	logcsessionDomain nvarchar(255),
	logcsessionTsId smallint,
	logcsessionLHI bigint ,
	logcsessionLLO bigint ,
	logcsessionBootTime varchar(64) ,
	logcsessionKerberosEnabled smallint ,
	logcsessionXres smallint ,
	logcsessionYres smallint ,
	logcsessionUILang varchar(64),	
	logcsessionCirratoVersion varchar(64),
	logcsessionType smallint,
	logcsessionLocaleAuto nvarchar(64),
	logcsessionLocaleReg nvarchar(64),
	logcsessionauthenticated smallint,
	logcsessionDate datetime,
	logcsessionLastSeen datetime
);

go

alter table tbl_cirrato_client_session alter column csessionLHI bigint 
alter table tbl_cirrato_client_session alter column csessionLLO bigint 

create table tbl_cirrato_rule_limit
(
	rlId varchar(64) not null,
	rlPrio smallint not null default 0,
	rlName nvarchar(128) not null,
	rlComment nvarchar(256),
	rlPaperType smallint,
	rlColour smallint,
	rlDuplex smallint,
	rlPages smallint,
	rlAction smallint ,
	rlMaxPrice float,
	rlMessageUid varchar(64),
	rlMoveUid varchar(64),
	rlEnforce smallint not null default 0
);

create table tbl_cirrato_rule_message_text
(
	ruleMessageTId bigint identity not null,
	ruleMessageTUid varchar(64) not null,
	ruleMessageTLocale nvarchar(32),
	ruleMessageTCaption nvarchar(128) not null,
	ruleMessageTText nvarchar(512) not null,
	ruleMessageTIcon smallint not null
);

update tbl_os set osName='Windows 2000' where osId='W2K'
update tbl_os set osName='Windows XP' where osId='XP32D'
update tbl_os set osName='Windows Server 2003' where osId='W2K3'
update tbl_os set osName='Windows Vista' where osId='WV32'


create table tbl_cirrato_client_backup_message
(
	ccbm_id bigint identity not null,
	ccbm_ts datetime default getDate(),
	ccbm_ip varchar(64) not null,
	ccbm_tsid bigint not null,
	ccbm_text nvarchar(512) not null,
	ccbm_caption nvarchar(256) not null,
	ccbm_Icon smallint not null default 0
);

--drop table tbl_vdms_loginsession_log
create table tbl_vdms_loginsession_log
(
lvsId bigint identity not null,
lvsTid bigint,
lvsLogTs datetime default getDate(),
lvsEvent smallint not null default 0,
lvsCardNumber nvarchar(255),
lvsUser nvarchar(255),
lvsFullName nvarchar(255),
lvsDomain nvarchar(255) ,
lvsIp nvarchar(30) ,
lvsPricePlan varchar(64),
lvsDateLogin datetime default getDate(),
lvsDateLastSeen datetime default getDate()
)

go

grant execute on dbo.verboseTicketLog to cirrato;

go
