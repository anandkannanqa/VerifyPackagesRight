-- Upgrade 2.0.0R8 - 2.0.0R9
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode

:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R8'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R9', propertyDate=getDate(), propertyChangedBy=user where propertyName='sysDbVersion';

----------------------------
-- tbl_counter_statistics --
----------------------------
alter table tbl_counter_statistics add counterstatCounterId varchar(64) not null default ''

----------------
-- tbl_region --
----------------
alter table tbl_region add regionAlarmProgramId varchar(64) not null default ''


alter table tbl_handover_point add handoverPointCheck datetime;
alter table tbl_handover_point add handoverPointLastCheck datetime;
alter table tbl_handover_point add handoverPrio smallint not null default 0;

alter table tbl_handover_rules add handoverRulePrio smallint not null default 0;

alter table tbl_ticket_log add logDocumentTypeId bigint not null default 0
alter table tbl_ticket add documentTypeId bigint not null default 0

CREATE TABLE [dbo].[tbl_documenttype](
 [typeId] [bigint] NOT NULL,
 [typeName] [nvarchar](256) NULL,
 [typeRule] [nvarchar](256) NULL,
 [typeImageURL] [nvarchar](256) NULL
) ON [PRIMARY]

insert into tbl_documenttype ( typeId, typeName, typeImageUrl ) values (0,'Unknown','images/icon-txt.gif');

go
ALTER view [dbo].[view_log] AS
select logDateCreated, logdateBegan, logDateFinished, 
logJobName, logUserName, logUserdomain, logJobsize, logPages, logPaper, logDuplex, logColor, 
queueId, queueName, queueLocation,
modelName,
printerName,
printerId, regionId, regionName, regionActive, typeId, typeName, typeImageURL
from tbl_ticket_log, tbl_queue , tbl_printer , tbl_model, tbl_region, tbl_documenttype
where (logEventMinor=1 OR logeventMinor=6) 
and logQueueId=queueId 
and logPrinterId=printerId
and queueModelId=tbl_model.modelId
and tbl_printer.region=tbl_region.regionId
and tbl_ticket_log.logDocumentTypeId=tbl_documenttype.typeId;

go
create table tbl_payex_log
(
pexLogId bigint identity not null ,
pexLogDate datetime default getDate(),
pexLogEvent smallint not null default 0,
pexLogTransId varchar(64),
pexLogTicketId varchar(64),
pexLogUser nvarchar(255),
pexLogDomain nvarchar(255),
pexLogExtId varchar(255),
pexLogDescr nvarchar(255),
pexLogText nvarchar(255),
pexLogExtText nvarchar(255),
pexLogAmount bigint
);

create table tbl_process_log
(
plogId bigint identity not null,
plogDate datetime default getDate(),
plogEvent smallint not null default 0,
plogType smallint not null default 0,
plogPid bigint not null default 0,
plogThreadCount bigint not null default 0,
plogHandleCount bigint not null default 0,
plogMemUsage bigint not null default 0,
plogCpuUsage smallint not null default 0,
plogAId varchar(64) not null default ''
);


go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

--	TI_DEBIT_OVERCHARGE,
	if(@minor=19)
		RETURN 'Ticket debit - charging supplementary money'

	--TI_DEBIT_EXTERNAL_SUCCESS,
	if(@minor=20)
		RETURN 'External debit success'

	--TI_DEBIT_EXTERNAL_FAIL,
	if(@minor=21)
		RETURN 'External debit fail'

--	TI_DEBIT_INTERNAL_SUCCESS,
	if(@minor=22)
		RETURN 'Internal debit success'

	--TI_DEBIT_INTERNAL_FAIL,
	if(@minor=23)
		RETURN 'Internal debit fail'

	--TI_DEBIT_EXTERNAL_NO_CONTRACT
	if(@minor=24)
		RETURN 'External debit fail - no contract'

	RETURN @minor
END

go
grant execute on dbo.verboseTicketLog to cirrato;

go