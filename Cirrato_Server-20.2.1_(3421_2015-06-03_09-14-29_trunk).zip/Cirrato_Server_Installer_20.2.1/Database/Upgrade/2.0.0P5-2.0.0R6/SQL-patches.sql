-- SQL Patches 2.0.0P5 - 2.0.0R6
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode


:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R5'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R6', propertyDate=getDate(),propertyChangedBy=user where propertyName='sysDbVersion';

create table tbl_ticket_feature
(
	ticketFeatureTime datetime default GetDate(),
	ticketFeatureTicket varchar(64) not null,
	ticketFeatureFeature smallint not null,
	ticketFeatureData1 varchar(64),
	ticketFeatureDataInt1 int,
	ticketFeatureData2 varchar(64),
	ticketFeatureDataInt2 int
)

create table tbl_handover_point
(
	handoverPointId varchar(64) not null,
	handoverPointName nvarchar(64) not null default '',
	handoverPointComment nvarchar(255) not null default '',
	handoverPointHostname varchar(128) not null,
	handoverPointPort smallint not null
)

create table tbl_handover_rules
(
	handoverRuleId varchar(64) not null,
	handoverRuleName nvarchar(64) not null default '',
	handoverRuleComment nvarchar(255) not null default '',
	handoverRuleStartIp varchar(64) not null,
	handoverRuleStartIpNum bigint not null,
	handoverRuleEndIp varchar(64),
	handoverRuleEndIpNum bigint,
	handoverRulePointId varchar(64),
	handoverRuleTrustedNetwork smallint not null default 1
)

alter table tbl_ticket add tsId bigint;
alter table tbl_ticket add tsaLUIDlow bigint;
alter table tbl_ticket add tsaLUIDhigh bigint;
alter table tbl_ticket add bootTime varchar(64);
alter table tbl_ticket add simpleClient smallint not null default 0;

create table tbl_vdms_loginsession
(
vsId int identity not null,
vsUser nvarchar(255) not null,
vsFullName nvarchar(255) not null,
vsDomain nvarchar(255) not null,
vsIp nvarchar(30) not null,
vsDateLogin datetime default getDate(),
vsDateLastSeen datetime default getDate()
)

alter table tbl_ticket add ticketVDMS int identity not null;