-- Upgrade 2.0.0R7 - 2.0.0R8
-- Please turn on SQL Command Mode
-- Menu Query -> SQLCMD Mode


:setvar SqlCmdIsOn Yes
:On error exit

GO
if ('$(SqlCmdIsOn)'<>'Yes')
  RAISERROR ('Cannot run without being in SQLCMD mode',20,1) with log
GO

print'Checking dbversion'
IF NOT EXISTS(SELECT 1 FROM tbl_property WHERE propertyName='sysDbVersion' and (propertyValue='2.0.0R7'))
 RAISERROR(N'The target database is not the correct version or wrong database selected', 18, 1, N'')
GO

print'Starting update'

:on error continue

update tbl_property set propertyValue='2.0.0R8', propertyDate=getDate(),propertyChangedBy=user where propertyName='sysDbVersion';

-----------------
-- tbl_printer --
-----------------

alter table tbl_printer add deviceStatus smallint not null default 0
alter table tbl_printer add printerCounterProgramId varchar(64) not null default ''

--------------------
-- tbl_statistics --
--------------------

drop table tbl_statistics

---------------------------
-- tbl_event_status_open --
---------------------------

exec sp_rename 'tbl_event_status_open.statopenStatusCode', 'statopenPhysStatus'
exec sp_rename 'tbl_event_status_open.statopenPagesTotalAtOpen', 'statopenTotalPagesAtOpen'

--alter table tbl_event_status_open drop column statopenPagesColorAtOpen

--------------------------
-- tbl_event_status_log --
--------------------------

exec sp_rename 'tbl_event_status_log.statlogStatusCode', 'statlogPhysStatus'
exec sp_rename 'tbl_event_status_log.statlogPagesTotalAtOpen', 'statlogTotalPagesAtOpen'
exec sp_rename 'tbl_event_status_log.statlogPagesTotalAtClose', 'statlogTotalPagesAtClose'

-- alter table tbl_event_status_log drop column statlogPagesColorAtOpen
-- alter table tbl_event_status_log drop column statlogPagesColorAtClose

/* Counter Statistics */

create table tbl_counter_program
(
counterprogId varchar(64) not null default '',
counterprogName nvarchar(100) not null default '',
counterprogCreator nvarchar(100) not null default '',
counterprogComment nvarchar(255) not null default '',
counterprogLastChanged datetime
)

create table tbl_counter_program_map
(
counterpmapProgramId varchar(64) not null default '',
counterpmapCounterId varchar(64) not null default ''
)

create table tbl_counter_oid
(
counterId varchar(64) not null default '',
counterType smallint not null default 0,
counterOid varchar(255) not null default '',
counterEncrypted smallint not null default 0,
counterComment nvarchar(255) not null default ''
)

create table tbl_counter_statistics
(
counterstatId varchar(64) not null default '',
counterstatCheckId varchar(64) not null default '',
counterstatPrinterId varchar(64) not null default '',
counterstatType smallint not null default 0,
counterstatCount int not null default 0,
counterstatChecked datetime
)

create table tbl_trap_log
(
traplogId varchar(64) not null default '',
traplogPrinterId varchar(64) not null default '',
traplogPrinterIp varchar(64) not null default '',
traplogNotificationId varchar(255) not null default '',
traplogName varchar(255) not null default '',
traplogType varchar(64) not null default '',
traplogValue varchar(1024) not null default '',
traplogRecorded datetime
)


go
drop function verboseTicketStatus
go
create function verboseTicketStatus(@ticketStatus smallint)
returns varchar(64)
as
begin

--	TICKET_NOOP =-1,

	if(@ticketStatus=-1)
		return 'Noop'

--	TICKET_CREATED = 0,

	if(@ticketStatus=0)
		return 'Created'

--	TICKET_SPOOLING = 1,

	if(@ticketStatus=1)
		return 'Spooling'

--	TICKET_READY = 2,

	if(@ticketStatus=2)
		return 'Ready'

--	TICKET_IN_NOTIFIER_QUEUE = 3,

	if(@ticketStatus=3)
		return 'In notifier queue'

--	TICKET_CONTACTING_CLIENT = 4,

	if(@ticketStatus=4)
		return 'Server contacting client'

--	TICKET_CLIENT_CONTACTING_PRINTER = 5,

	if(@ticketStatus=5)
		return 'Client contacting printer'

--	TICKET_PRINTING = 6,

	if(@ticketStatus=6)
		return 'Printing'

--	TICKET_PAUSED = 7 ,

	if(@ticketStatus=7)
		return 'Paused'

--	TICKET_LOCKED = 8 ,

	if(@ticketStatus=8)
		return 'Locked'

--	TICKET_DELETED = 9 ,

	if(@ticketStatus=9)
		return 'Deleted'

--	TICKET_HANDOVER_PENDING = 10 , // Ticket must be handover to handover point

	if(@ticketStatus=10)
		return 'Handover pending'

--	TICKET_HANDOVER_IN_PROGRESS = 11, // Ticket is set to be handover

	if(@ticketStatus=11)
		return 'Handover in progress'

--	TICKET_HANDOVER_FAILED = 12, // Handover has failed - retry ?

	if(@ticketStatus=12)
		return 'Handover failed'

--	TICKET_AUTH_PENDING = 13,// Ticket need an authentication before print

	if(@ticketStatus=13)
		return 'Authorization pending'

--	TICKET_SIMPLE_CLIENT_PENDING = 14

	if(@ticketStatus=14)
		return 'Simple client transferring job'

return ''
end

go

drop function verboseRuleStatus;
go
create function verboseRuleStatus( @status smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@status=0)
		RETURN ''
--	TI_PRINT_OK,
	if(@status=1)
		RETURN 'Auth needed'
	RETURN ''
END

go
drop function verboseTicketLog;
go
create function verboseTicketLog( @major smallint, @minor smallint)
returns varchar(64)
AS
BEGIN 
--	TI_PRINT_MISC,
	if(@minor=0)
		RETURN 'Misc'
--	TI_PRINT_OK,
	if(@minor=1)
		RETURN 'Print OK'

--	TI_NO_CONTACT,
	if(@minor=2)
		RETURN 'No Contact with client'

--	TI_TTL_EXCEEDED,
	if(@minor=3)
		RETURN 'TTL Exceeded'

--	TI_HEARTBEAT_FAILED,
	if(@minor=4)
		RETURN 'Heartbeat failed'

--	PR_NO_CONTACT_WITH_PRINTER,
	if(@minor=5)
		RETURN 'No contact with printer'

--	TI_PRINT_3RD,
	if(@minor=6)
		RETURN '3rd printjob'

--	TI_DELETED_MANUALLY,
	if(@minor=7)
		RETURN 'Manually deleted'

--	TI_HANDOVEREVENT,
	if(@minor=8)
		RETURN 'Handoverevent'

--	TI_DEBIT_PRINT,
	if(@minor=9)
		RETURN 'Debit print'

--	TI_DEBIT_COPY,
	if(@minor=10)
		RETURN 'Debit copy'

--	TI_DEIT_SCAN,
	if(@minor=11)
		RETURN 'Debit scan'

--	TI_DEBIT_FAX,
	if(@minor=12)
		RETURN 'Debit fax'

--	TI_AUTH_DONE,
	if(@minor=13)
		RETURN 'Authorization done'

--	TI_SNMP_SCAN_SUCCESS,
	if(@minor=14)
		RETURN 'Snmp scan success'

--	TI_SNMP_SCAN_FAIL,
	if(@minor=15)
		RETURN 'Snmp scan failed'

--	TI_PS_PARSE_SUCCESS,
	if(@minor=16)
		RETURN 'PS Parser success'

--	TI_PS_PARSE_FAIL,
	if(@minor=17)
		RETURN 'PS Parser fail'

--	TI_POST_AUTH_RULESET_FAIL
	if(@minor=18)
		RETURN 'Post auth ruleset fail'

	RETURN @minor
END

go
drop function verboseTicketAdminStatus
go
create function verboseTicketAdminStatus(@ticketStatus smallint)
returns varchar(64)
as
begin

--	TICKET_PAUSED = 7 ,

	if(@ticketStatus=7)
		return 'Paused'

--	TICKET_LOCKED = 8 ,

	if(@ticketStatus=8)
		return 'Locked'

--	TICKET_DELETED = 9 ,

	if(@ticketStatus=9)
		return 'Deleted'


return ''
end
go



-- Note: This username (cirrato) should be changed to whatever username is used for cirrato webgui

grant execute on dbo.verboseTicketAdminStatus to cirrato;
go
grant execute on dbo.verboseTicketLog to cirrato;
go
grant execute on dbo.verboseTicketStatus to cirrato;
go
grant execute on dbo.verboseRuleStatus to cirrato;