﻿// JScript File

/***************************************************************** messages JobAction ***************************************************/
function confirm_dialog(message, show) {
    if (show) {
        if (confirm(message) == true)
            return true;
        else
            return false;
    }
    else return true;
}

function veryfy_SendMessage(msgtextbox, message, messageconfirm) {
    var targetElement = document.getElementById(msgtextbox);

    if (targetElement.value == "") {
        alert(message);
        return false;
    }
    else
        return confirm_dialog(messageconfirm, true);
}

function veryfy_ChangeOwner(usertextbox, domaintextbox, message, messageconfirm) {
    var u = document.getElementById(usertextbox);
    var d = document.getElementById(domaintextbox);


    if ((u.value == "") || (d.value == "")) {
        alert(message);
        return false;
    }
    else
        return confirm_dialog(messageconfirm, true);
}

function veryfy_JobAction(message) {
    return confirm_dialog(message, true);
}

/****************************************************************** messages Pause / Start / Stop queue *****************************************/
function confirm_queue_action(messageconfirm) {
    return confirm_dialog(messageconfirm, true);
}

function confirm_queue_action_with_reason(reasontextbox, message, messageconfirm) {
    var targetElement = document.getElementById(reasontextbox);

    if (targetElement.value == "") {
        alert(message);
        return false;
    }
    else
        return confirm_dialog(messageconfirm, true);
}

/* used instead for simple_queue_install, used by QueueAction.ascx */
function simple_queue_install_non_Windows_client(queueid, pushAddress, message, showconfirm) {
    /* If queue action is being performed on another IP, don't generate a mac/linux install script */
    try {
        var hf = document.getElementById(pushAddress);
        if (hf.value != "") return true;
    } catch (e) { }

    alert(showconfirm);
    
    if (showconfirm) {
        if (!confirm_dialog(message, showconfirm))
            return false;
    }

    window.open('GenInstall.aspx?qid=' + queueid, 'queueinstallwindow');
    return false;
}

/* used instead for simple_queue_install_l1 */
function simple_queue_install_non_Windows_client_by_name(queueid, queuename, showconfirm, pushAddress, message) {
    /* If queue action is being performed on another IP, don't generate a mac/linux install script */
    try {
        var hf = document.getElementById(pushAddress);
        if (hf.value != "") return true;
    } catch (e) { }

    if (showconfirm) {
        if (!confirm_dialog(message + ' ' + queuename + '?', showconfirm))
            return false;
    }
    window.open('../GenInstall.aspx?qid=' + queueid, 'queueinstallwindow');
    return false;
}

/****************************************************** Quota ******************************************************/
function confirm_quota_reset(reasontextbox, msg1, msg2) {
    var targetElement = document.getElementById(reasontextbox);

    if (targetElement.value == "") {
        alert(msg1);
        return false;
    }

    return confirm_dialog(msg2, true);
}

/************************************************ Client billing **************************************************/
function confirm_delete(message) {
    return confirm_dialog(message, true);
}