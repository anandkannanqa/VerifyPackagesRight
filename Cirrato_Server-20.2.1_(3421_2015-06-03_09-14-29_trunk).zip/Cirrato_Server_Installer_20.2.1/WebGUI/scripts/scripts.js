﻿// JScript File

/**************************************** window.open, Generic ******************************************************************/
function openInformationUrlNoScrollbars(url, width, height) 
{
    popupWin = window.open(url, '', 'menubar=no, toolbar=no, location=no, directories=no, status=no, scrollbars=no, resizable=no, dependent, ' +
        'width=' + width + ', ' +
        'height=' + height)
}

function openInformationUrl(url, width, height)
{
    popupWin = window.open(url, '', 'menubar=no, toolbar=no, location=no, directories=no, status=no, scrollbars=yes, resizable=yes, dependent, ' +
        'width=' + width + ', ' +
        'height=' + height)
}

function openInformationJobInfoUrl(url, width, height) 
{
    popupWin = window.open(url, '', 'menubar=no, toolbar=no, location=no, directories=no, status=no, scrollbars=no, resizable=no, dependent, ' +
        'width=' + width + ', ' +
        'height=' + height)
}

function openInformationUrlWithoutSize(url) 
{
    popupWin = window.open(url, '', 'menubar=no, toolbar=no, location=no, directories=no, status=no, scrollbars=yes, resizable=yes, dependent')
}

function openNewWindowAbout() {
  popupWin = window.open('about.aspx',
  'open_window',
  'menubar=no, toolbar=no, location=no, directories=no, status=no, scrollbars=no, resizable=no, dependent, width=300, height=240, left=200, top=200')
}

function openNewWindowAboutLevel1() {
  popupWin = window.open('../about.aspx',
  'open_window',
  'menubar=no, toolbar=no, location=no, directories=no, status=no, scrollbars=no, resizable=no, dependent, width=300, height=240, left=200, top=200')
}

function openHelpWindow(url, height, options) {
    popupWin = window.open(url,'help_window','width=750,height=' + height + options)
}

/********************************************************************************************************************************************/
    function toggle(obj) {
	    var el = document.getElementById(obj);
	    el.style.display = (el.style.display != 'none' ? 'none' : '' );
    	
	    //alert(arguments[0]);
    	
    	
	    if (arguments[1] != null) {
		    var el = document.getElementById(arguments[1]);
	        el.style.display = (el.style.display != 'none' ? 'none' : '' );	
	    }
    }

    function clickclear(thisfield) 
    {
        if (thisfield.value == document.getElementById("SearchStringHelpText").value) {
            thisfield.value = "";
            thisfield.style.fontStyle = "normal";
        }
    }

    function clickrecall(thisfield) 
    {
        if (thisfield.value == "") {
            thisfield.value = document.getElementById("SearchStringHelpText").value;
            thisfield.style.fontStyle = "italic";
        } else
        thisfield.style.fontStyle = "normal";
    }
    
    
    /* used by RegionTree.aspx */
    function TreeNodeCheckChanged(event, control) 
    {
        // Do postback on checkchanged
        // Valid for IE and Firefox/Safari/Chrome.
        //alert('');
        
        var obj = window.event ? window.event.srcElement : event.target;
        var source = window.event ? window.event.srcElement.id : event.target.id;
        if (source == "")
            return;

        source = source.replace(control.id + "t", control.id + "n");
        source = source.replace("CheckBox", "");
        var checkbox = document.getElementById(source);
        if (checkbox != null && obj.tagName == "INPUT" && obj.type == "checkbox") 
        {
            __doPostBack(checkbox.id, "");
        }
    }  
    
    
    function openPrintJobInfo(ticketId) {
        
    }

    /***************************************************************** messages JobAction ***************************************************/
    

/* Treeview scripts [to be replaced / obsolete] */

function clickt(treeview,hidden1)
{
    
    var obj = window.event.srcElement;
    var treeNodeFound = false;
    var checkedState;
    if (obj.tagName == "INPUT" && obj.type == "checkbox") 
    {
        var treeNode = obj;
        checkedState = treeNode.checked;
    }
    var element=obj.nextSibling;
    if(element.tagName=="A")
    {
        var strhref=element.href;
        var begpos = strhref.indexOf("\\");
        begpos+=2;
        var endpos = strhref.lastIndexOf("'");
        var ans = strhref.substring(begpos,endpos);
    ///////////////////////////////// 
        ans = "'"+ans+"'";
      /* if(checkedState==true)
            __doPostBack("Checked",ans);
        else
            __doPostBack("Unchecked",ans);
            */
       if(checkedState==true)
       {
       var temp = hidden1.value;
       temp+=ans;
       temp += " , ";
       hidden1.value = temp;
     /////////  alert(hidden1.value);
       }
        else
        {
            var temp = hidden1.value;
            var tp = temp.indexOf(ans);
            var tpup;
            var tpdown;
            if(temp.length<= 42)
                {
                    hidden1.value = "";
                }
                       
                else
                {
                if(tp==0)
                tpup = "";
                else
                tpup = temp.substring(tp);
                
          //////////  alert("tp" + tp + "length"+ temp.length);
            tpdown = temp.substring(tp+41,temp.length);
            hidden1.value = tpup+tpdown
            }
         /////////   alert(hidden1.value);
            
        
        }
           
    }
  
}
		    
function client_OnTreeNodeChecked()
{
    var obj = window.event.srcElement;
    var treeNodeFound = false;
    var checkedState;
    if (obj.tagName == "INPUT" && obj.type == "checkbox") 
    {
        var treeNode = obj;
        checkedState = treeNode.checked;
        do
        {
            obj = obj.parentElement;
        }while (obj.tagName != "TABLE")
        var parentTreeLevel = obj.rows[0].cells.length;
        var parentTreeNode = obj.rows[0].cells[0];
        var tables = obj.parentElement.getElementsByTagName("TABLE");
        var numTables = tables.length
        if (numTables >= 1)
        {
            for (i=0; i < numTables; i++)
            {
                if (tables[i] == obj)
                {
                    treeNodeFound = true;
                    i++;
                    if (i == numTables)
                    {
                        return;
                    }
                }
                if (treeNodeFound == true)
                {
                    var childTreeLevel = tables[i].rows[0].cells.length;
                    if (childTreeLevel > parentTreeLevel)
                    {
                        var cell = tables[i].rows[0].cells[childTreeLevel - 1];
                        var inputs = cell.getElementsByTagName("INPUT");
                        inputs[0].checked = checkedState;
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }
    }
} 
            
function SelectAll(CheckBoxControl,datagridcontrol)
{
	if(CheckBoxControl.checked == true)
	{
		var i;
		for(i=0; i < document.forms[0].elements.length; i++)
		{ 
			if((document.forms[0].elements[i].type == 'checkbox')&& (document.forms[0].elements[i].name.indexOf(datagridcontrol)> -1)) 
			{
				document.forms[0].elements[i].checked = true;
			}//if
		}//for
	}//if 
	else
	{
		var i;
		for(i=0; i < document.forms[0].elements.length; i++) 
		{
			if((document.forms[0].elements[i].type == 'checkbox') &&(document.forms[0].elements[i].name.indexOf(datagridcontrol) > -1)) 
			{
				document.forms[0].elements[i].checked = false;
			}//if
		}//for
	}//else
} //function


/****************************************************** VPAT 508 **********************************************************/
function onBodyKeyDown(event) {
    if (event.keyCode == 9) {
        //alert(event.keyCode);
        var el = document.getElementById("skip_menu");

        if ((el != null) || (el != "")) {
            if (el.style.display = 'none') {
                //alert(el.style.display);
                el.style.display = 'block';
            }
            //el.style.display = (el.style.display != 'none' ? 'none' : 'block');
            //            if (el.style.display == 'none') {
            //                el.style.display = 'block';
            //            }
            //el.style.display = (el.style.display != 'none' ? 'none' : 'block');
            //alert(el.style.display);
        }
    }
}

/*
function convertEnterToTab() {
    if (event.keyCode == 9) {
        alert('13');
        event.keyCode = 9;
    }
}
document.onkeydown = convertEnterToTab;   


function onkey(e) {
    alert(e.event);
    alert(window.event.keyCode.ToString());
    
    if (window.event.keyCode == 09) // to capture tab key press 
        alert('');
}

function onkeydown(o, e) {
    alert('');
    var kC = e.keyCode ? e.keyCode : e.charCode ? e.charCode : e.which;
    alert(e.altKey.ToString());
    if (kC == 9 && !e.shiftKey && !e.ctrlKey && !e.altKey) {
        var oS = o.scrollTop;
        if (o.setSelectionRange) {
            var sS = o.selectionStart;
            var sE = o.selectionEnd;
            o.value = o.value.substring(0, sS) + "\t" + o.value.substr(sE);
            o.setSelectionRange(sS + 1, sS + 1);
            o.focus();
        }
        else if (o.createTextRange) {
            document.selection.createRange().text = "\t";
            e.returnValue = false;
        }
        o.scrollTop = oS;
        if (e.preventDefault) {
            e.preventDefault();
        }
        return false;
    }
    return true;
}
*/
