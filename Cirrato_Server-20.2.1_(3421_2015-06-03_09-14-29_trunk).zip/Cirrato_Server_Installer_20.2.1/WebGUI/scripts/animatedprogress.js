﻿/// <reference name="MicrosoftAjax.js"/>

try
{
var prm = Sys.WebForms.PageRequestManager.getInstance();
prm.add_initializeRequest(InitializeRequest);
prm.add_endRequest(EndRequest);
}
catch()

var postBackElement;
function InitializeRequest(sender, args) {
    if (prm.get_isInAsyncPostBack()) {
        args.set_cancel(true);
    }
    postBackElement = args.get_postBackElement();
    
    if (postBackElement.id == btnSearch) /* 'btnSearch' */{
        $get(updp_upnl_JobList).style.display = "block"; /* updp_upnl_JobList */
    }
}
function EndRequest(sender, args) {
    if (postBackElement.id == btnSearch) /* 'btnSearch' */{
        $get(updp_upnl_JobList).style.display = "none"; /* updp_upnl_JobList */
    }
}
function AbortPostBack() {
    if (prm.get_isInAsyncPostBack()) {
        prm.abortPostBack();
    }
}