﻿// JScript File


function HideContent(d, outerPanel) 
{
    if(d.length < 1) { return; }
    
    if (CurrentPrinterPopupMouseIn) return; //göm inte om musen ligger i den
    
    document.getElementById(d).style.display = "none";
    
    
    var outerPanelItem = document.getElementById(outerPanel);
    outerPanelItem.className = "Printer";
}

function ShowContent(d, outerPanel) 
{
    if(d.length < 1) { return; }
    var dd = document.getElementById(d);
    //AssignPosition(dd);
    dd.style.display = "block";
    
    
    var outerPanelItem = document.getElementById(outerPanel);
    outerPanelItem.className = "PrinterPoppingUp";
    
    CurrentPrinterMouseIn = true;
}


function EnterPrinter ()
{
    CurrentPrinterPopupMouseIn = true;
}
function LeavePrinter ()
{
    CurrentPrinterPopupMouseIn = false;
}


var CurrentPrinterPopupMouseIn = false;
var CurrentPrinterMouseIn = false;



function EnterPrinterTest(d) 
{
    if(d.length < 1) { return; }
    var dd = document.getElementById(d);
    //AssignPosition(dd);
    dd.style.backgroundColor = "pink";
    

}

function LeavePrinterTest(d) 
{
    if(d.length < 1) { return; }
    var dd = document.getElementById(d);
    //AssignPosition(dd);
    dd.style.backgroundColor = "white";
    

}